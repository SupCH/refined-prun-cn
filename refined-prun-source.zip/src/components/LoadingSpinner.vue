<template>
  <div :class="C.Loading.loader" title="Loading…" />
</template>
