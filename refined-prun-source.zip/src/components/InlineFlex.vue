<template>
  <span :class="C.InlineFlex.inlineFlex">
    <slot />
  </span>
</template>
