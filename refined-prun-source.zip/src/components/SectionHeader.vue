<template>
  <div :class="[C.SectionHeader.container, C.fonts.fontRegular]"><slot /></div>
</template>
