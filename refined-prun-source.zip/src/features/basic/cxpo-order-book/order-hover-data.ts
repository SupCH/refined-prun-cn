export interface OrderHoverData {
  order: PrunApi.CXBrokerOrder;
  cumulative: boolean;
}
