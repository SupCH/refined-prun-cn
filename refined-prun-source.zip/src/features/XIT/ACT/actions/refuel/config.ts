export interface Config {
  origin?: string;
}
