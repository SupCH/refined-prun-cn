export interface Config {
  origin?: string;
  destination?: string;
}
