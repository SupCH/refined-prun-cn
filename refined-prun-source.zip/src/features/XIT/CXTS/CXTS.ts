import CXTS from '@src/features/XIT/CXTS/CXTS.vue';

xit.add({
  command: ['CXTS'],
  name: 'COMMODITY EXCHANGE TRADES',
  description: 'List of all your commodity exchange trades.',
  component: () => CXTS,
});
