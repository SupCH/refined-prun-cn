import START from '@src/features/XIT/START.vue';

xit.add({
  command: 'START',
  name: '(zh-cn)refined-prun INTRO',
  description: '(zh-cn)refined-prun start screen.',
  component: () => START,
});
