const root = "rp-FINCH__root___c2549a0";
const clickable = "rp-FINCH__clickable___0ceced3";
const style0 = {
  root,
  clickable
};
export {
  clickable,
  style0 as default,
  root
};
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiRklOQ0gudnVlMy5qcyIsInNvdXJjZXMiOltdLCJzb3VyY2VzQ29udGVudCI6W10sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7OzsifQ==
