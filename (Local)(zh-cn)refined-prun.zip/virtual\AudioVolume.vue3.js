const label = "rp-AudioVolume__label___ac59d55";
const slider = "rp-AudioVolume__slider___6f8988b";
const style0 = {
  label,
  slider
};
export {
  style0 as default,
  label,
  slider
};
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiQXVkaW9Wb2x1bWUudnVlMy5qcyIsInNvdXJjZXMiOltdLCJzb3VyY2VzQ29udGVudCI6W10sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7OzsifQ==
