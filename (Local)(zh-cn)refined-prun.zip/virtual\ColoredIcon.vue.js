import _sfc_main from "./ColoredIcon.vue2.js";
import style0 from "./ColoredIcon.vue3.js";
import _export_sfc from "./plugin-vue_export-helper.js";
const cssModules = {
  "$style": style0
};
const ColoredIcon = /* @__PURE__ */ _export_sfc(_sfc_main, [["__cssModules", cssModules]]);
export {
  ColoredIcon as default
};
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiQ29sb3JlZEljb24udnVlLmpzIiwic291cmNlcyI6W10sInNvdXJjZXNDb250ZW50IjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7OzsifQ==
