const settings = "rp-cxpc-chart-types__settings___f60a2dd";
const $style = {
  settings
};
export {
  $style as default,
  settings
};
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY3hwYy1jaGFydC10eXBlcy5tb2R1bGUuY3NzLmpzIiwic291cmNlcyI6W10sInNvdXJjZXNDb250ZW50IjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7OzsifQ==
