const heading = "rp-Header__heading___01ac829";
const editable = "rp-Header__editable___e2b3973";
const input = "rp-Header__input___6bbe41a";
const style0 = {
  heading,
  editable,
  input
};
export {
  style0 as default,
  editable,
  heading,
  input
};
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiSGVhZGVyLnZ1ZTMuanMiLCJzb3VyY2VzIjpbXSwic291cmNlc0NvbnRlbnQiOltdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7OzsifQ==
