const funny = "rp-funny-rations__funny___dbff329";
const rat = "rp-funny-rations__rat___3a6bcad";
const $style = {
  funny,
  rat
};
export {
  $style as default,
  funny,
  rat
};
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZnVubnktcmF0aW9ucy5tb2R1bGUuY3NzLmpzIiwic291cmNlcyI6W10sInNvdXJjZXNDb250ZW50IjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7OyJ9
