const ownOrder = "rp-highlight-own-exchange-orders__ownOrder___95825be";
const $style = {
  ownOrder
};
export {
  $style as default,
  ownOrder
};
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaGlnaGxpZ2h0LW93bi1leGNoYW5nZS1vcmRlcnMubW9kdWxlLmNzcy5qcyIsInNvdXJjZXMiOltdLCJzb3VyY2VzQ29udGVudCI6W10sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7In0=
