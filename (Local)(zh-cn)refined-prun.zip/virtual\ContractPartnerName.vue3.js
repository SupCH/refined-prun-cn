const label = "rp-ContractPartnerName__label___62b9f27";
const style0 = {
  label
};
export {
  style0 as default,
  label
};
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiQ29udHJhY3RQYXJ0bmVyTmFtZS52dWUzLmpzIiwic291cmNlcyI6W10sInNvdXJjZXNDb250ZW50IjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7OzsifQ==
