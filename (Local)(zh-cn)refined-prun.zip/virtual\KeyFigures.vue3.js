const tooltip = "rp-KeyFigures__tooltip___e4622e7";
const style0 = {
  tooltip
};
export {
  style0 as default,
  tooltip
};
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiS2V5RmlndXJlcy52dWUzLmpzIiwic291cmNlcyI6W10sInNvdXJjZXNDb250ZW50IjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7OzsifQ==
