const title = "rp-CHAT__title___7f90d0a";
const name = "rp-CHAT__name___989f301";
const style0 = {
  title,
  name
};
export {
  style0 as default,
  name,
  title
};
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiQ0hBVC52dWUzLmpzIiwic291cmNlcyI6W10sInNvdXJjZXNDb250ZW50IjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7OyJ9
