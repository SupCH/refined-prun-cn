import _sfc_main from "./KeyFigures.vue2.js";
import style0 from "./KeyFigures.vue3.js";
import _export_sfc from "./plugin-vue_export-helper.js";
const cssModules = {
  "$style": style0
};
const KeyFigures = /* @__PURE__ */ _export_sfc(_sfc_main, [["__cssModules", cssModules]]);
export {
  KeyFigures as default
};
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiS2V5RmlndXJlcy52dWUuanMiLCJzb3VyY2VzIjpbXSwic291cmNlc0NvbnRlbnQiOltdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7OyJ9
