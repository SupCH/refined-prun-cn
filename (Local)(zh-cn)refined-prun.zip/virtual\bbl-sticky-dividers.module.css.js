const divider = "rp-bbl-sticky-dividers__divider___ccb162a";
const $style = {
  divider
};
export {
  $style as default,
  divider
};
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYmJsLXN0aWNreS1kaXZpZGVycy5tb2R1bGUuY3NzLmpzIiwic291cmNlcyI6W10sInNvdXJjZXNDb250ZW50IjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7OzsifQ==
