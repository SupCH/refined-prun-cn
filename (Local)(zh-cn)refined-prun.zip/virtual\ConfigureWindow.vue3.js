const config = "rp-ConfigureWindow__config___5e0ce79";
const sectionHeader = "rp-ConfigureWindow__sectionHeader___94a4730";
const style0 = {
  config,
  sectionHeader
};
export {
  config,
  style0 as default,
  sectionHeader
};
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiQ29uZmlndXJlV2luZG93LnZ1ZTMuanMiLCJzb3VyY2VzIjpbXSwic291cmNlc0NvbnRlbnQiOltdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7In0=
