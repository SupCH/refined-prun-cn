function castArray(value) {
  return Array.isArray(value) ? value : [value];
}
export {
  castArray
};
