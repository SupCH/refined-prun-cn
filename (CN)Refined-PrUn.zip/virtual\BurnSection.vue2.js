import _sfc_main from "./BurnSection.vue.js";
export {
  _sfc_main as default
};
