import { subscribe } from "./subscribe-async-generator.js";
import { $$, $ } from "./select-dom.js";
import { C } from "./prun-css.js";
import tiles from "./tiles.js";
import features from "./feature-registry.js";
import { cxobStore } from "./cxob.js";
import { changeInputValue } from "./util.js";
import { fixed02 } from "./format.js";
import { refValue } from "./reactive-dom.js";
import { createReactiveDiv } from "./reactive-element.js";
import { watchEffectWhileNodeAlive } from "./watch.js";
import { isFiniteOrder } from "./orders.js";
import { computed } from "./runtime-core.esm-bundler.js";
import { ref } from "./reactivity.esm-bundler.js";
function onTileReady(tile) {
  subscribe($$(tile.anchor, C.ComExPlaceOrderForm.form), (x) => onFormReady(x, tile.parameter));
}
async function onFormReady(form, parameter) {
  const orderBook = computed(() => cxobStore.getByTicker(parameter));
  const quantityInput = await $(form.children[7], "input");
  const quantityValue = refValue(quantityInput);
  const priceInfo = computed(() => {
    const quantity = Number(quantityValue.value);
    if (!Number.isFinite(quantity) || quantity <= 0 || !orderBook.value) {
      return void 0;
    }
    return {
      buy: fillQuantity(orderBook.value.sellingOrders, quantity),
      sell: fillQuantity(orderBook.value.buyingOrders, quantity)
    };
  });
  const priceBuy = computed(() => priceInfo.value?.buy.price ?? 0);
  const priceSell = computed(() => priceInfo.value?.sell.price ?? 0);
  const priceInput = await $(form.children[8], "input");
  const priceInputValue = refValue(priceInput);
  const showAutoValues = computed(() => priceInputValue.value === "");
  const buttonsField = form.children[12];
  const isBuyFocused = ref(false);
  const buy = await $(buttonsField, C.Button.success);
  buy.addEventListener("mouseover", () => isBuyFocused.value = true);
  buy.addEventListener("mouseleave", () => isBuyFocused.value = false);
  buy.addEventListener("click", (e) => {
    if (showAutoValues.value) {
      changeInputValue(priceInput, fixed02(priceBuy.value));
      e.stopPropagation();
      e.preventDefault();
    }
  });
  const isSellFocused = ref(false);
  const sell = await $(buttonsField, C.Button.danger);
  sell.addEventListener("mouseover", () => isSellFocused.value = true);
  sell.addEventListener("mouseleave", () => isSellFocused.value = false);
  sell.addEventListener("click", (e) => {
    if (showAutoValues.value) {
      changeInputValue(priceInput, fixed02(priceSell.value));
      e.stopPropagation();
      e.preventDefault();
    }
  });
  const placeholderText = computed(() => {
    if (isBuyFocused.value) {
      return fixed02(priceBuy.value);
    }
    if (isSellFocused.value) {
      return fixed02(priceSell.value);
    }
    return "Auto";
  });
  watchEffectWhileNodeAlive(form, () => {
    priceInput.placeholder = placeholderText.value;
  });
  const currencyCode = orderBook.value?.currency.code ?? "";
  const showBuyValues = computed(() => showAutoValues.value && !isSellFocused.value);
  const showSellValues = computed(() => showAutoValues.value && !isBuyFocused.value);
  const effectivePriceLabel = await $(form.children[9], C.StaticInput.static);
  createDualLabels(
    effectivePriceLabel.parentElement,
    currencyCode,
    showAutoValues,
    computed(() => showBuyValues.value ? priceInfo.value?.buy.effectivePrice : void 0),
    computed(() => showSellValues.value ? priceInfo.value?.sell.effectivePrice : void 0)
  );
  const volumeLabel = await $(form.children[10], C.StaticInput.static);
  createDualLabels(
    volumeLabel.parentElement,
    currencyCode,
    showAutoValues,
    computed(() => showBuyValues.value ? priceInfo.value?.buy.volume : void 0),
    computed(() => showSellValues.value ? priceInfo.value?.sell.volume : void 0)
  );
  watchEffectWhileNodeAlive(form, () => {
    effectivePriceLabel.style.display = showAutoValues.value ? "none" : "";
    volumeLabel.style.display = showAutoValues.value ? "none" : "";
  });
}
function createDualLabels(container, currencyUnit, showAutoValues, buyValue, sellValue) {
  const text = computed(() => {
    if (!showAutoValues.value) {
      return void 0;
    }
    if (buyValue.value !== void 0 && sellValue.value !== void 0) {
      return `${fixed02(buyValue.value)} ${currencyUnit} / ${fixed02(sellValue.value)} ${currencyUnit}`;
    }
    if (buyValue.value !== void 0) {
      return `${fixed02(buyValue.value)} ${currencyUnit}`;
    }
    if (sellValue.value !== void 0) {
      return `${fixed02(sellValue.value)} ${currencyUnit}`;
    }
    return "--";
  });
  const div = createReactiveDiv(container, text);
  div.classList.add(C.StaticInput.static, C.forms.static);
  container.prepend(div);
}
function fillQuantity(orders, quantityNeeded) {
  const filled = {
    amount: 0,
    priceLimit: 0,
    volume: 0
  };
  for (const order of orders) {
    const orderAmount = isFiniteOrder(order) ? order.amount : Number.POSITIVE_INFINITY;
    const remaining = quantityNeeded - filled.amount;
    const filledByOrder = Math.min(remaining, orderAmount);
    const orderPrice = order.limit.amount;
    filled.priceLimit = orderPrice;
    filled.amount += filledByOrder;
    filled.volume += filledByOrder * orderPrice;
    if (filled.amount === quantityNeeded) {
      break;
    }
  }
  const leftover = quantityNeeded - filled.amount;
  filled.volume += leftover * filled.priceLimit;
  return {
    price: filled.priceLimit,
    effectivePrice: filled.volume / quantityNeeded,
    volume: filled.volume
  };
}
function init() {
  tiles.observe("CXPO", onTileReady);
}
features.add(import.meta.url, init, "CXPO: Adds automatic price calculation.");
