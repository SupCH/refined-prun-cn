const divider = "rp-bbl-collapsible-categories__divider___b0465ea";
const $style = {
  divider
};
export {
  $style as default,
  divider
};
