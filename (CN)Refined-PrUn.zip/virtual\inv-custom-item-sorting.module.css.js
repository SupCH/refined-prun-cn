const custom = "rp-inv-custom-item-sorting__custom___b4657eb";
const $style = {
  custom
};
export {
  custom,
  $style as default
};
