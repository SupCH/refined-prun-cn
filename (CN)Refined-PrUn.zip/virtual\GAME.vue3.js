const tooltip = "rp-GAME__tooltip___74e4fdf";
const sidebarInputPair = "rp-GAME__sidebarInputPair___76840bf";
const sidebarInput = "rp-GAME__sidebarInput___41eca58";
const style0 = {
  tooltip,
  sidebarInputPair,
  sidebarInput
};
export {
  style0 as default,
  sidebarInput,
  sidebarInputPair,
  tooltip
};
