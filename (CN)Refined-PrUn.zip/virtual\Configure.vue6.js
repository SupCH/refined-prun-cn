import _sfc_main from "./Configure.vue2.js";
export {
  _sfc_main as default
};
