const label = "rp-ContractPartnerName__label___62b9f27";
const style0 = {
  label
};
export {
  style0 as default,
  label
};
