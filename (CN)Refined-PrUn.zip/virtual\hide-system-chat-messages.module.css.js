const hideJoined = "rp-hide-system-chat-messages__hideJoined___41806f0";
const joined = "rp-hide-system-chat-messages__joined___97fe30c";
const hideDeleted = "rp-hide-system-chat-messages__hideDeleted___786e02f";
const deleted = "rp-hide-system-chat-messages__deleted___d147b57";
const $style = {
  hideJoined,
  joined,
  hideDeleted,
  deleted
};
export {
  $style as default,
  deleted,
  hideDeleted,
  hideJoined,
  joined
};
