const log = "rp-LogWindow__log___95b382d";
const success = "rp-LogWindow__success___10c20c1";
const failure = "rp-LogWindow__failure___ebc9057";
const warning = "rp-LogWindow__warning___3991891";
const style0 = {
  log,
  success,
  failure,
  warning
};
export {
  style0 as default,
  failure,
  log,
  success,
  warning
};
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiTG9nV2luZG93LnZ1ZTMuanMiLCJzb3VyY2VzIjpbXSwic291cmNlc0NvbnRlbnQiOltdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7OyJ9
