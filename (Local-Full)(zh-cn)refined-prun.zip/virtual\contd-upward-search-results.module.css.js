const suggestions = "rp-contd-upward-search-results__suggestions___ece5509";
const $style = {
  suggestions
};
export {
  $style as default,
  suggestions
};
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY29udGQtdXB3YXJkLXNlYXJjaC1yZXN1bHRzLm1vZHVsZS5jc3MuanMiLCJzb3VyY2VzIjpbXSwic291cmNlc0NvbnRlbnQiOltdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7OyJ9
