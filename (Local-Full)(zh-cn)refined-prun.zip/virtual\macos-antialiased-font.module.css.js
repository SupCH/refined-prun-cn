const body = "rp-macos-antialiased-font__body___5e3f4e6";
const $style = {
  body
};
export {
  body,
  $style as default
};
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibWFjb3MtYW50aWFsaWFzZWQtZm9udC5tb2R1bGUuY3NzLmpzIiwic291cmNlcyI6W10sInNvdXJjZXNDb250ZW50IjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7OzsifQ==
