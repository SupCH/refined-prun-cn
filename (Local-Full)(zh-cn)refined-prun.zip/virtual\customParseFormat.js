import { getDefaultExportFromCjs } from "./commonjsHelpers.js";
import { __require as requireCustomParseFormat } from "./customParseFormat2.js";
var customParseFormatExports = requireCustomParseFormat();
const CustomParseFormat = /* @__PURE__ */ getDefaultExportFromCjs(customParseFormatExports);
export {
  CustomParseFormat as default
};
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY3VzdG9tUGFyc2VGb3JtYXQuanMiLCJzb3VyY2VzIjpbXSwic291cmNlc0NvbnRlbnQiOltdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7OyJ9
