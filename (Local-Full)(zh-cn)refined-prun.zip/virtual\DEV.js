import xit from "./xit-registry.js";
import _sfc_main from "./DEV.vue.js";
xit.add({
  command: "DEV",
  name: "DEVELOPMENT MENU",
  description: "Development menu.",
  component: () => _sfc_main
});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiREVWLmpzIiwic291cmNlcyI6WyIuLi8uLi8uLi9zcmMvZmVhdHVyZXMvWElUL0RFVi9ERVYudHMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IERFViBmcm9tICdAc3JjL2ZlYXR1cmVzL1hJVC9ERVYvREVWLnZ1ZSc7XG5cbnhpdC5hZGQoe1xuICBjb21tYW5kOiAnREVWJyxcbiAgbmFtZTogJ0RFVkVMT1BNRU5UIE1FTlUnLFxuICBkZXNjcmlwdGlvbjogJ0RldmVsb3BtZW50IG1lbnUuJyxcbiAgY29tcG9uZW50OiAoKSA9PiBERVYsXG59KTtcbiJdLCJuYW1lcyI6WyJERVYiXSwibWFwcGluZ3MiOiI7O0FBRUEsSUFBQSxJQUFBO0FBQUEsRUFBUSxTQUFBO0FBQUEsRUFDRyxNQUFBO0FBQUEsRUFDSCxhQUFBO0FBQUEsRUFDTyxXQUFBLE1BQUFBO0FBRWYsQ0FBQTsifQ==
