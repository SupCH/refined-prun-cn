import _sfc_main from "./BalanceSheetSection.vue2.js";
/* empty css                         */
import _export_sfc from "./plugin-vue_export-helper.js";
const BalanceSheetSection = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-6f3fe4a2"]]);
export {
  BalanceSheetSection as default
};
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiQmFsYW5jZVNoZWV0U2VjdGlvbi52dWUuanMiLCJzb3VyY2VzIjpbXSwic291cmNlc0NvbnRlbnQiOltdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7OyJ9
