const container = "rp-MaterialIcon__container___45161db";
const indicatorSmall = "rp-MaterialIcon__indicatorSmall___3b69c31";
const style0 = {
  container,
  indicatorSmall
};
export {
  container,
  style0 as default,
  indicatorSmall
};
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiTWF0ZXJpYWxJY29uLnZ1ZTMuanMiLCJzb3VyY2VzIjpbXSwic291cmNlc0NvbnRlbnQiOltdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7In0=
