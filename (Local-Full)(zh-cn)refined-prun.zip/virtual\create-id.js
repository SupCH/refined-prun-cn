import v4 from "./v4.js";
const createId = () => v4().replaceAll("-", "");
export {
  createId
};
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY3JlYXRlLWlkLmpzIiwic291cmNlcyI6WyIuLi8uLi8uLi9zcmMvc3RvcmUvY3JlYXRlLWlkLnRzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHY0IGFzIHV1aWR2NCB9IGZyb20gJ3V1aWQnO1xuXG5leHBvcnQgY29uc3QgY3JlYXRlSWQgPSAoKSA9PiB1dWlkdjQoKS5yZXBsYWNlQWxsKCctJywgJycpO1xuIl0sIm5hbWVzIjpbInV1aWR2NCJdLCJtYXBwaW5ncyI6IjtBQUVPLE1BQU0sV0FBVyxNQUFNQSxHQUFBLEVBQVMsV0FBVyxLQUFLLEVBQUU7In0=
