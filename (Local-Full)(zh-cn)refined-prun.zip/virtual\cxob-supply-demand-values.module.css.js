const spread = "rp-cxob-supply-demand-values__spread___de99b06";
const $style = {
  spread
};
export {
  $style as default,
  spread
};
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY3hvYi1zdXBwbHktZGVtYW5kLXZhbHVlcy5tb2R1bGUuY3NzLmpzIiwic291cmNlcyI6W10sInNvdXJjZXNDb250ZW50IjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7OzsifQ==
