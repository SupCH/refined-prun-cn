const indicator = "rp-bigger-item-count-font__indicator___43b9d75";
const $style = {
  indicator
};
export {
  $style as default,
  indicator
};
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYmlnZ2VyLWl0ZW0tY291bnQtZm9udC5tb2R1bGUuY3NzLmpzIiwic291cmNlcyI6W10sInNvdXJjZXNDb250ZW50IjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7OzsifQ==
