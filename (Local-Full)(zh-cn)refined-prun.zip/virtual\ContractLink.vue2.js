import PrunLink from "./PrunLink.vue.js";
import { canAcceptContract, canPartnerAcceptContract, isFactionContract } from "./utils4.js";
import fa from "./font-awesome.module.css.js";
import coloredValue from "./colored-value.module.css.js";
import { defineComponent, computed, createBlock, openBlock, withCtx, createTextVNode, createElementBlock, createCommentVNode } from "./runtime-core.esm-bundler.js";
import { normalizeStyle, toDisplayString, normalizeClass } from "./shared.esm-bundler.js";
import { unref } from "./reactivity.esm-bundler.js";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "ContractLink",
  props: {
    contract: {}
  },
  setup(__props) {
    const canAccept = computed(() => canAcceptContract(__props.contract));
    const canPartnerAccept = computed(() => canPartnerAcceptContract(__props.contract));
    const linkStyle = computed(() => ({
      display: isFactionContract(__props.contract) ? "inline" : "block"
    }));
    return (_ctx, _cache) => {
      return openBlock(), createBlock(PrunLink, {
        command: `CONT ${_ctx.contract.localId}`,
        style: normalizeStyle(unref(linkStyle))
      }, {
        default: withCtx(() => [
          createTextVNode(toDisplayString(_ctx.contract.name || _ctx.contract.localId) + " ", 1),
          unref(canAccept) ? (openBlock(), createElementBlock("span", {
            key: 0,
            class: normalizeClass([unref(fa).solid, unref(coloredValue).warning])
          }, toDisplayString(""), 2)) : createCommentVNode("", true),
          unref(canPartnerAccept) ? (openBlock(), createElementBlock("span", {
            key: 1,
            class: normalizeClass([unref(fa).solid, unref(coloredValue).warning])
          }, toDisplayString(""), 2)) : createCommentVNode("", true)
        ]),
        _: 1
      }, 8, ["command", "style"]);
    };
  }
});
export {
  _sfc_main as default
};
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiQ29udHJhY3RMaW5rLnZ1ZTIuanMiLCJzb3VyY2VzIjpbIi4uLy4uLy4uL3NyYy9mZWF0dXJlcy9YSVQvQ09OVFMvQ29udHJhY3RMaW5rLnZ1ZSJdLCJzb3VyY2VzQ29udGVudCI6WyI8c2NyaXB0IHNldHVwIGxhbmc9XCJ0c1wiPlxuaW1wb3J0IFBydW5MaW5rIGZyb20gJ0BzcmMvY29tcG9uZW50cy9QcnVuTGluay52dWUnO1xuaW1wb3J0IHtcbiAgY2FuQWNjZXB0Q29udHJhY3QsXG4gIGNhblBhcnRuZXJBY2NlcHRDb250cmFjdCxcbiAgaXNGYWN0aW9uQ29udHJhY3QsXG59IGZyb20gJ0BzcmMvZmVhdHVyZXMvWElUL0NPTlRTL3V0aWxzJztcbmltcG9ydCBmYSBmcm9tICdAc3JjL3V0aWxzL2ZvbnQtYXdlc29tZS5tb2R1bGUuY3NzJztcbmltcG9ydCBjb2xvcmVkVmFsdWUgZnJvbSAnQHNyYy9pbmZyYXN0cnVjdHVyZS9wcnVuLXVpL2Nzcy9jb2xvcmVkLXZhbHVlLm1vZHVsZS5jc3MnO1xuXG5jb25zdCB7IGNvbnRyYWN0IH0gPSBkZWZpbmVQcm9wczx7IGNvbnRyYWN0OiBQcnVuQXBpLkNvbnRyYWN0IH0+KCk7XG5cbmNvbnN0IGNhbkFjY2VwdCA9IGNvbXB1dGVkKCgpID0+IGNhbkFjY2VwdENvbnRyYWN0KGNvbnRyYWN0KSk7XG5cbmNvbnN0IGNhblBhcnRuZXJBY2NlcHQgPSBjb21wdXRlZCgoKSA9PiBjYW5QYXJ0bmVyQWNjZXB0Q29udHJhY3QoY29udHJhY3QpKTtcblxuY29uc3QgbGlua1N0eWxlID0gY29tcHV0ZWQoKCkgPT4gKHtcbiAgZGlzcGxheTogaXNGYWN0aW9uQ29udHJhY3QoY29udHJhY3QpID8gJ2lubGluZScgOiAnYmxvY2snLFxufSkpO1xuPC9zY3JpcHQ+XG5cbjx0ZW1wbGF0ZT5cbiAgPFBydW5MaW5rIDpjb21tYW5kPVwiYENPTlQgJHtjb250cmFjdC5sb2NhbElkfWBcIiA6c3R5bGU9XCJsaW5rU3R5bGVcIj5cbiAgICB7eyBjb250cmFjdC5uYW1lIHx8IGNvbnRyYWN0LmxvY2FsSWQgfX1cbiAgICA8c3BhbiB2LWlmPVwiY2FuQWNjZXB0XCIgOmNsYXNzPVwiW2ZhLnNvbGlkLCBjb2xvcmVkVmFsdWUud2FybmluZ11cIj57eyAnXFx1ZjBlMCcgfX08L3NwYW4+XG4gICAgPHNwYW4gdi1pZj1cImNhblBhcnRuZXJBY2NlcHRcIiA6Y2xhc3M9XCJbZmEuc29saWQsIGNvbG9yZWRWYWx1ZS53YXJuaW5nXVwiPnt7ICdcXHVmMWQ4JyB9fTwvc3Bhbj5cbiAgPC9QcnVuTGluaz5cbjwvdGVtcGxhdGU+XG4iXSwibmFtZXMiOlsiX25vcm1hbGl6ZVN0eWxlIiwiX3VucmVmIiwiX2NyZWF0ZVRleHRWTm9kZSIsIl90b0Rpc3BsYXlTdHJpbmciLCJfb3BlbkJsb2NrIiwiX2NyZWF0ZUVsZW1lbnRCbG9jayIsIl9jcmVhdGVDb21tZW50Vk5vZGUiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7QUFZQSxVQUFBLFlBQUEsU0FBQSxNQUFBLGtCQUFBLFFBQUEsUUFBQSxDQUFBO0FBRUEsVUFBQSxtQkFBQSxTQUFBLE1BQUEseUJBQUEsUUFBQSxRQUFBLENBQUE7QUFFQSxVQUFBLFlBQUEsU0FBQSxPQUFBO0FBQUEsTUFBa0MsU0FBQSxrQkFBQSxRQUFBLFFBQUEsSUFBQSxXQUFBO0FBQUEsSUFDa0IsRUFBQTs7O1FBU3ZDLFNBQUEsUUFBQSxLQUFBLFNBQUEsT0FBQTtBQUFBLFFBSmlDLE9BQUFBLGVBQUFDLE1BQUEsU0FBQSxDQUFBO0FBQUEsTUFBcUIsR0FBQTtBQUFBO1VBQ3hCQyxnQkFBQUMsZ0JBQUEsS0FBQSxTQUFBLFFBQUEsS0FBQSxTQUFBLE9BQUEsSUFBQSxLQUFBLENBQUE7QUFBQSxVQUN2Q0YsTUFBQSxTQUFBLEtBQUFHLFVBQUEsR0FBQUMsbUJBQUEsUUFBQTtBQUFBLFlBQXNGLEtBQUE7QUFBQTtVQUF4QixHQUFBRixnQkFBQSxHQUFBLEdBQUEsQ0FBQSxLQUFBRyxtQkFBQSxJQUFBLElBQUE7QUFBQTtZQUMrQixLQUFBO0FBQUE7VUFBeEIsR0FBQUgsZ0JBQUEsR0FBQSxHQUFBLENBQUEsS0FBQUcsbUJBQUEsSUFBQSxJQUFBO0FBQUE7Ozs7OzsifQ==
