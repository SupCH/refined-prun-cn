const container = "rp-align-chat-delete-button__container___bf61efb";
const username = "rp-align-chat-delete-button__username___4ba777a";
const $style = {
  container,
  "delete": "rp-align-chat-delete-button__delete___1ae0a18",
  username
};
export {
  container,
  $style as default,
  username
};
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYWxpZ24tY2hhdC1kZWxldGUtYnV0dG9uLm1vZHVsZS5jc3MuanMiLCJzb3VyY2VzIjpbXSwic291cmNlc0NvbnRlbnQiOltdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7OyJ9
