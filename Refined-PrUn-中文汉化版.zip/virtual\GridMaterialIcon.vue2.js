import _sfc_main from "./GridMaterialIcon.vue.js";
export {
  _sfc_main as default
};
