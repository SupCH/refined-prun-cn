const container = "rp-BuildingIcon__container___aed8f37";
const style0 = {
  container
};
export {
  container,
  style0 as default
};
