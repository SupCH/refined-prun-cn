import _sfc_main from "./AssetPieChart.vue.js";
export {
  _sfc_main as default
};
