import "./deserialize-prun-app.js";
import "./config.js";
import "./request-hooks.js";
import "./extension-update.js";
document.documentElement.classList.add("refined-prun");
