import _sfc_main from "./InventorySortControls.vue.js";
export {
  _sfc_main as default
};
