var es = { exports: {} };
export {
  es as __module
};
