const hidden = "rp-css-utils__hidden___a7357f8";
const css = {
  hidden
};
export {
  css as default,
  hidden
};
