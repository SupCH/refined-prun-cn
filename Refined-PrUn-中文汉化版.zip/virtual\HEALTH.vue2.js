import _sfc_main from "./HEALTH.vue.js";
export {
  _sfc_main as default
};
