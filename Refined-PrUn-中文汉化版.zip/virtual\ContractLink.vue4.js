import _sfc_main from "./ContractLink.vue2.js";
export {
  _sfc_main as default
};
