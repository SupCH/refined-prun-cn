const tooltip = "rp-FIN__tooltip___13df833";
const style0 = {
  tooltip
};
export {
  style0 as default,
  tooltip
};
