const container = "rp-GIF__container___41f92a2";
const image = "rp-GIF__image___7c61666";
const style0 = {
  container,
  image
};
export {
  container,
  style0 as default,
  image
};
