import _sfc_main from "./Commands.vue.js";
export {
  _sfc_main as default
};
