var hammer = { exports: {} };
export {
  hammer as __module
};
