const funny = "rp-funny-rations__funny___dbff329";
const rat = "rp-funny-rations__rat___3a6bcad";
const $style = {
  funny,
  rat
};
export {
  $style as default,
  funny,
  rat
};
