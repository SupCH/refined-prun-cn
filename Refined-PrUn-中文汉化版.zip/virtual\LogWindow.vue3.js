const log = "rp-LogWindow__log___95b382d";
const success = "rp-LogWindow__success___10c20c1";
const failure = "rp-LogWindow__failure___ebc9057";
const warning = "rp-LogWindow__warning___3991891";
const style0 = {
  log,
  success,
  failure,
  warning
};
export {
  style0 as default,
  failure,
  log,
  success,
  warning
};
