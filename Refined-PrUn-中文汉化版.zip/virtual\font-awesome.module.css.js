const solid = "rp-font-awesome__solid___33343de";
const regular = "rp-font-awesome__regular___638eb05";
const fa = {
  solid,
  regular
};
export {
  fa as default,
  regular,
  solid
};
