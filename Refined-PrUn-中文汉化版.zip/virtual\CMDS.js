import xit from "./xit-registry.js";
import _sfc_main from "./CMDS.vue.js";
xit.add({
  command: "CMDS",
  name: "XIT COMMANDS",
  description: "List of available XIT commands.",
  component: () => _sfc_main
});
