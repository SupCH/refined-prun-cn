import _sfc_main from "./MaterialList.vue2.js";
export {
  _sfc_main as default
};
