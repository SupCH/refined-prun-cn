const wide = "rp-EquityHistoryChart__wide___6848ff2";
const style0 = {
  wide
};
export {
  style0 as default,
  wide
};
