function isPresent(value) {
  return value !== null && value !== void 0;
}
export {
  isPresent
};
