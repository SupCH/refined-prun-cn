const text = "rp-lm-hide-rating__text___ddd6143";
const $style = {
  text
};
export {
  $style as default,
  text
};
