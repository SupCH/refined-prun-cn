const containerError = "rp-hide-form-errors__containerError___ed7f67d";
const $style = {
  containerError
};
export {
  containerError,
  $style as default
};
