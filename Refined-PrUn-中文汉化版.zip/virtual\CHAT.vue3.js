const title = "rp-CHAT__title___7f90d0a";
const name = "rp-CHAT__name___989f301";
const style0 = {
  title,
  name
};
export {
  style0 as default,
  name,
  title
};
