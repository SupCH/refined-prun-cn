var lexer = {};
export {
  lexer as __exports
};
