const indicator = "rp-bigger-item-count-font__indicator___43b9d75";
const $style = {
  indicator
};
export {
  $style as default,
  indicator
};
