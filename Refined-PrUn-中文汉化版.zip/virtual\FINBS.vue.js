import _sfc_main from "./FINBS.vue2.js";
/* empty css           */
import _export_sfc from "./plugin-vue_export-helper.js";
const FINBS = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-e7f564c4"]]);
export {
  FINBS as default
};
