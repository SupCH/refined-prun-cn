var dayjs_min = { exports: {} };
export {
  dayjs_min as __module
};
