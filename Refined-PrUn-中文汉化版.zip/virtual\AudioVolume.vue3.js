const label = "rp-AudioVolume__label___ac59d55";
const slider = "rp-AudioVolume__slider___6f8988b";
const style0 = {
  label,
  slider
};
export {
  style0 as default,
  label,
  slider
};
