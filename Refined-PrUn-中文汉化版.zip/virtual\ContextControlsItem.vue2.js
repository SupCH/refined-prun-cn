import _sfc_main from "./ContextControlsItem.vue.js";
export {
  _sfc_main as default
};
