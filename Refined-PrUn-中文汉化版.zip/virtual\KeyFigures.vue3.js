const tooltip = "rp-KeyFigures__tooltip___e4622e7";
const style0 = {
  tooltip
};
export {
  style0 as default,
  tooltip
};
