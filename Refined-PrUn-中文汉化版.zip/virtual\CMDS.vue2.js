import _sfc_main from "./CMDS.vue.js";
export {
  _sfc_main as default
};
