const list = "rp-BuildingCountSection__list___fb252cf";
const style0 = {
  list
};
export {
  style0 as default,
  list
};
