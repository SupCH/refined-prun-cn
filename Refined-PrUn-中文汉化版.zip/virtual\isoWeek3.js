var isoWeek = { exports: {} };
export {
  isoWeek as __module
};
