const loading = "rp-CALC__loading___a435280";
const calc = "rp-CALC__calc___29001eb";
const style0 = {
  loading,
  calc
};
export {
  calc,
  style0 as default,
  loading
};
