import _sfc_main from "./EditMaterialGroup.vue.js";
export {
  _sfc_main as default
};
