import _sfc_main from "./EditAction.vue.js";
export {
  _sfc_main as default
};
