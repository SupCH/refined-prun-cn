import _sfc_main from "./ContractLink.vue.js";
export {
  _sfc_main as default
};
