const inputText = "rp-inv-search__inputText___5702997";
const $style = {
  inputText
};
export {
  $style as default,
  inputText
};
