const column = "rp-DateRow__column___6dae58c";
const totals = "rp-DateRow__totals___c8bbf55";
const totalsColumn = "rp-DateRow__totalsColumn___25ccac3";
const totalsSeparator = "rp-DateRow__totalsSeparator___58002b1";
const style0 = {
  column,
  totals,
  totalsColumn,
  totalsSeparator
};
export {
  column,
  style0 as default,
  totals,
  totalsColumn,
  totalsSeparator
};
