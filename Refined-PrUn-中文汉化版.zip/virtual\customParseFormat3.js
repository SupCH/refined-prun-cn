var customParseFormat = { exports: {} };
export {
  customParseFormat as __module
};
