const hidden = "rp-BalanceSheetRow__hidden___fe30cc1";
const tooltip = "rp-BalanceSheetRow__tooltip___e4bff0b";
const style0 = {
  hidden,
  tooltip
};
export {
  style0 as default,
  hidden,
  tooltip
};
