const expand = "rp-MaterialPurchaseTable__expand___17bacee";
const total = "rp-MaterialPurchaseTable__total___07955f3";
const materialCell = "rp-MaterialPurchaseTable__materialCell___d6750c9";
const fakeRow = "rp-MaterialPurchaseTable__fakeRow___fe9ce32";
const style0 = {
  expand,
  total,
  materialCell,
  fakeRow
};
export {
  style0 as default,
  expand,
  fakeRow,
  materialCell,
  total
};
