const item = "rp-AddTaskItem__item___43d3125";
const checkmark = "rp-AddTaskItem__checkmark___610406f";
const plus = "rp-AddTaskItem__plus___6b7b078";
const plusHover = "rp-AddTaskItem__plusHover___f4736e9";
const content = "rp-AddTaskItem__content___be4ccd9";
const style0 = {
  item,
  checkmark,
  plus,
  plusHover,
  content
};
export {
  checkmark,
  content,
  style0 as default,
  item,
  plus,
  plusHover
};
