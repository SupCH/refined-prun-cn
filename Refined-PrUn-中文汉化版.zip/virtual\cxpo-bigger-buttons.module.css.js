const container = "rp-cxpo-bigger-buttons__container___2b49772";
const $style = {
  container
};
export {
  container,
  $style as default
};
