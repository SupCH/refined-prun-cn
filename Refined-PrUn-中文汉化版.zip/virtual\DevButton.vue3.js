const button = "rp-DevButton__button___8c66896";
const style0 = {
  button
};
export {
  button,
  style0 as default
};
