const suggestions = "rp-contd-upward-search-results__suggestions___ece5509";
const $style = {
  suggestions
};
export {
  $style as default,
  suggestions
};
