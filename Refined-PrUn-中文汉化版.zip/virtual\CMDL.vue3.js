const create = "rp-CMDL__create___7052d84";
const button = "rp-CMDL__button___64cc033";
const style0 = {
  create,
  button
};
export {
  button,
  create,
  style0 as default
};
