import _sfc_main from "./CONTS.vue.js";
export {
  _sfc_main as default
};
