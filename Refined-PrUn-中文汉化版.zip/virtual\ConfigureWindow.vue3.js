const config = "rp-ConfigureWindow__config___5e0ce79";
const sectionHeader = "rp-ConfigureWindow__sectionHeader___94a4730";
const style0 = {
  config,
  sectionHeader
};
export {
  config,
  style0 as default,
  sectionHeader
};
