const container = "rp-MaterialIcon__container___45161db";
const indicatorSmall = "rp-MaterialIcon__indicatorSmall___3b69c31";
const style0 = {
  container,
  indicatorSmall
};
export {
  container,
  style0 as default,
  indicatorSmall
};
