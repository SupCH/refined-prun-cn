const warning = "rp-colored-value__warning___8e5e695";
const coloredValue = {
  warning
};
export {
  coloredValue as default,
  warning
};
