import _sfc_main from "./BuildingIcon.vue2.js";
import style0 from "./BuildingIcon.vue3.js";
import _export_sfc from "./plugin-vue_export-helper.js";
const cssModules = {
  "$style": style0
};
const BuildingIcon = /* @__PURE__ */ _export_sfc(_sfc_main, [["__cssModules", cssModules]]);
export {
  BuildingIcon as default
};
