const settings = "rp-cxpc-chart-types__settings___f60a2dd";
const $style = {
  settings
};
export {
  $style as default,
  settings
};
