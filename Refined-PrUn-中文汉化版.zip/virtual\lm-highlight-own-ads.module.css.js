const ownAd = "rp-lm-highlight-own-ads__ownAd___e546d51";
const $style = {
  ownAd
};
export {
  $style as default,
  ownAd
};
