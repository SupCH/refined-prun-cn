const container = "rp-align-chat-delete-button__container___bf61efb";
const username = "rp-align-chat-delete-button__username___4ba777a";
const $style = {
  container,
  "delete": "rp-align-chat-delete-button__delete___1ae0a18",
  username
};
export {
  container,
  $style as default,
  username
};
