const materialContainer = "rp-MaterialRow__materialContainer___d13ef05";
const style0 = {
  materialContainer
};
export {
  style0 as default,
  materialContainer
};
