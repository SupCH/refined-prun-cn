import _sfc_main from "./Edit.vue6.js";
export {
  _sfc_main as default
};
