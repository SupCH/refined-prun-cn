import xit from "./xit-registry.js";
import _sfc_main from "./DEV.vue.js";
xit.add({
  command: "DEV",
  name: "DEVELOPMENT MENU",
  description: "Development menu.",
  component: () => _sfc_main
});
