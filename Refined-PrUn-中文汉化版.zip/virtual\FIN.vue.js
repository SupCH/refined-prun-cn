import _sfc_main from "./FIN.vue2.js";
/* empty css         */
import _export_sfc from "./plugin-vue_export-helper.js";
const FIN = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-14fc6ada"]]);
export {
  FIN as default
};
