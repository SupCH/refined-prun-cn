const tbody = "rp-cxob-depth-bars__tbody___95e0d47";
const bids = "rp-cxob-depth-bars__bids___b3c73d2";
const asks = "rp-cxob-depth-bars__asks___2e5ab59";
const $style = {
  tbody,
  bids,
  asks
};
export {
  asks,
  bids,
  $style as default,
  tbody
};
