var advancedFormat = { exports: {} };
export {
  advancedFormat as __module
};
