import _sfc_main from "./GridItemView.vue.js";
export {
  _sfc_main as default
};
