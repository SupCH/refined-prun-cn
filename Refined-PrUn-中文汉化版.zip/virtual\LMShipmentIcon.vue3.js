const icon = "rp-LMShipmentIcon__icon___0708a41";
const style0 = {
  icon
};
export {
  style0 as default,
  icon
};
