const icon = "rp-LMMaterialIcon__icon___97af3c9";
const style0 = {
  icon
};
export {
  style0 as default,
  icon
};
