import _sfc_main from "./DaysCell.vue.js";
export {
  _sfc_main as default
};
