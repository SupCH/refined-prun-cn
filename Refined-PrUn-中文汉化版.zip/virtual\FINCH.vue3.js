const root = "rp-FINCH__root___c2549a0";
const clickable = "rp-FINCH__clickable___0ceced3";
const style0 = {
  root,
  clickable
};
export {
  clickable,
  style0 as default,
  root
};
