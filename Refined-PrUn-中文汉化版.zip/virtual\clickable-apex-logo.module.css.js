const logo = "rp-clickable-apex-logo__logo___63cd318";
const $style = {
  logo
};
export {
  $style as default,
  logo
};
