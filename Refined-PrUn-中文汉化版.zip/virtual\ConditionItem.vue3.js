const pending = "rp-ConditionItem__pending___452fa78";
const fulfilled = "rp-ConditionItem__fulfilled___886ebc7";
const failed = "rp-ConditionItem__failed___8472444";
const unavailable = "rp-ConditionItem__unavailable___3dd5e23";
const style0 = {
  pending,
  fulfilled,
  failed,
  unavailable
};
export {
  style0 as default,
  failed,
  fulfilled,
  pending,
  unavailable
};
