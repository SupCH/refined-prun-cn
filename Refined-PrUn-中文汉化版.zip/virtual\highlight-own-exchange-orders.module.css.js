const ownOrder = "rp-highlight-own-exchange-orders__ownOrder___95825be";
const $style = {
  ownOrder
};
export {
  $style as default,
  ownOrder
};
