import { subscribe } from "./subscribe-async-generator.js";
import { $$ } from "./select-dom.js";
import { C } from "./prun-css.js";
import tiles from "./tiles.js";
import features from "./feature-registry.js";
import { extractPlanetName } from "./util.js";
function onTileReady(tile) {
  if (tile.parameter) {
    return;
  }
  subscribe($$(tile.anchor, C.Link.link), (link) => {
    if (link.textContent) {
      link.textContent = extractPlanetName(link.textContent);
    }
  });
}
function init() {
  tiles.observe("INV", onTileReady);
}
features.add(import.meta.url, init, "INV: Shortens addresses in the main INV command.");
