const shadow = "rp-item-ticker-shadow__shadow___d0df755";
const $style = {
  shadow
};
export {
  $style as default,
  shadow
};
