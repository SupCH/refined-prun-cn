function isEmpty(array) {
  return array.length === 0;
}
export {
  isEmpty
};
