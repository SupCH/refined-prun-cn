var localizedFormat = { exports: {} };
export {
  localizedFormat as __module
};
