import _sfc_main from "./CreateActionPackage.vue.js";
export {
  _sfc_main as default
};
