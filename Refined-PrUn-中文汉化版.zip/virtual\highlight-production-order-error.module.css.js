const inputMissingContainer = "rp-highlight-production-order-error__inputMissingContainer___2b577eb";
const orderRow = "rp-highlight-production-order-error__orderRow___4f1dbb2";
const $style = {
  inputMissingContainer,
  orderRow
};
export {
  $style as default,
  inputMissingContainer,
  orderRow
};
