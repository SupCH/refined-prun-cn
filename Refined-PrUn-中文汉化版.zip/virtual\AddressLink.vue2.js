import _sfc_main from "./AddressLink.vue.js";
export {
  _sfc_main as default
};
