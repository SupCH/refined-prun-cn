import { getDefaultExportFromCjs } from "./commonjsHelpers.js";
import { __require as requireEs } from "./index8.js";
var esExports = requireEs();
const Mexp = /* @__PURE__ */ getDefaultExportFromCjs(esExports);
export {
  Mexp as default
};
