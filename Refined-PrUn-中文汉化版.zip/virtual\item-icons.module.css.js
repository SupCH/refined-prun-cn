const container = "rp-item-icons__container___8e5388f";
const label = "rp-item-icons__label___0de7df1";
const $style = {
  container,
  label
};
export {
  container,
  $style as default,
  label
};
