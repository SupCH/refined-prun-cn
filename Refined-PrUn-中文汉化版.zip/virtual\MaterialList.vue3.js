import _sfc_main from "./MaterialList.vue.js";
export {
  _sfc_main as default
};
