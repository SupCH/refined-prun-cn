import _sfc_main from "./EditTask.vue.js";
export {
  _sfc_main as default
};
