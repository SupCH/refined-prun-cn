const spread = "rp-cxob-supply-demand-values__spread___de99b06";
const $style = {
  spread
};
export {
  $style as default,
  spread
};
