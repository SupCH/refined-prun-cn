import _sfc_main from "./CXTS.vue.js";
export {
  _sfc_main as default
};
