const fakeRow = "rp-BURN__fakeRow___931b8ea";
const expand = "rp-BURN__expand___4888051";
const style0 = {
  fakeRow,
  expand
};
export {
  style0 as default,
  expand,
  fakeRow
};
