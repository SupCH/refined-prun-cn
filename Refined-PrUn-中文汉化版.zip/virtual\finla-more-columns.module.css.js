const row = "rp-finla-more-columns__row___845c4e0";
const $style = {
  row
};
export {
  $style as default,
  row
};
