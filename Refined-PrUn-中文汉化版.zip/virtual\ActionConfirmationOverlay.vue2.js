import _sfc_main from "./ActionConfirmationOverlay.vue.js";
export {
  _sfc_main as default
};
