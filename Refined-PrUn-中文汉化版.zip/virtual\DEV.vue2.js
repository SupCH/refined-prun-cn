import _sfc_main from "./DEV.vue.js";
export {
  _sfc_main as default
};
