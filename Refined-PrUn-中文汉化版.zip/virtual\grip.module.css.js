const grip = "rp-grip__grip___8f6617d";
const grip$1 = {
  grip
};
export {
  grip$1 as default,
  grip
};
