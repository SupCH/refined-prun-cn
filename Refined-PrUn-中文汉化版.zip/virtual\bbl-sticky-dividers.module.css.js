const divider = "rp-bbl-sticky-dividers__divider___ccb162a";
const $style = {
  divider
};
export {
  $style as default,
  divider
};
