var duration = { exports: {} };
export {
  duration as __module
};
