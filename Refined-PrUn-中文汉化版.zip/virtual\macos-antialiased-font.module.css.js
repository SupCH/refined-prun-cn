const body = "rp-macos-antialiased-font__body___5e3f4e6";
const $style = {
  body
};
export {
  body,
  $style as default
};
