import _sfc_main from "./CategoryHeader.vue.js";
export {
  _sfc_main as default
};
