import _sfc_main from "./Edit.vue.js";
export {
  _sfc_main as default
};
