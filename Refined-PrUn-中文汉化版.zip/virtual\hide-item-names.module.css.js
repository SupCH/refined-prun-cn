const gridItem = "rp-hide-item-names__gridItem___8b1a22f";
const $style = {
  gridItem
};
export {
  $style as default,
  gridItem
};
