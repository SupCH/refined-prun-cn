import o from "./ConfigureWindow.vue2.js";
import s from "./ConfigureWindow.vue3.js";
import t from "./plugin-vue_export-helper.js";
const r = {
  $style: s
}, c = /* @__PURE__ */ t(o, [["__cssModules", r]]);
export {
  c as default
};
