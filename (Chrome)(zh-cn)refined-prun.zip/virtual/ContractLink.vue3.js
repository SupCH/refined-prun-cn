import f from "./ContractLink.vue.js";
export {
  f as default
};
