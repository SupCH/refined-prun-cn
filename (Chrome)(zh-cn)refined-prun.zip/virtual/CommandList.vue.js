import s from "./CommandList.vue2.js";
import o from "./CommandList.vue3.js";
import t from "./plugin-vue_export-helper.js";
const m = {
  $style: o
}, f = /* @__PURE__ */ t(s, [["__cssModules", m]]);
export {
  f as default
};
