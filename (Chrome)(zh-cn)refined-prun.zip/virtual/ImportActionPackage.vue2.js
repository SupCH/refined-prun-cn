import f from "./ImportActionPackage.vue.js";
export {
  f as default
};
