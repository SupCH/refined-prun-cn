import p from "./SectionHeader.vue.js";
import { act as f } from "./act-registry.js";
import { defineComponent as g, computed as l, createElementBlock as r, openBlock as a, Fragment as m, renderList as d, createVNode as C, createBlock as y, withCtx as $, createTextVNode as k, resolveDynamicComponent as h } from "./runtime-core.esm-bundler.js";
import { normalizeClass as s, toDisplayString as B } from "./shared.esm-bundler.js";
import { unref as G } from "./reactivity.esm-bundler.js";
const H = /* @__PURE__ */ g({
  __name: "ConfigureWindow",
  props: {
    pkg: {},
    config: {}
  },
  setup(c) {
    const u = l(() => {
      const e = [];
      for (const o of c.pkg.groups) {
        const n = f.getMaterialGroupInfo(o.type);
        if (!n || !n.configureComponent || !n.needsConfigure?.(o))
          continue;
        const t = o.name;
        let i = c.config.materialGroups[t];
        i && e.push({
          name: `[${t}]: ${n.type} Material Group`,
          component: n.configureComponent,
          data: o,
          config: i
        });
      }
      for (const o of c.pkg.actions) {
        const n = f.getActionInfo(o.type);
        if (!n || !n.configureComponent || !n.needsConfigure?.(o))
          continue;
        const t = o.name;
        let i = c.config.actions[t];
        i && e.push({
          name: `[${t}]: ${n.type} Action`,
          component: n.configureComponent,
          data: o,
          config: i
        });
      }
      return e;
    });
    return (e, o) => (a(), r("div", {
      class: s(e.$style.config)
    }, [
      (a(!0), r(m, null, d(G(u), (n) => (a(), r(m, {
        key: n.name
      }, [
        C(p, {
          class: s(e.$style.sectionHeader)
        }, {
          default: $(() => [
            k(B(n.name), 1)
          ]),
          _: 2
        }, 1032, ["class"]),
        (a(), y(h(n.component), {
          data: n.data,
          config: n.config
        }, null, 8, ["data", "config"]))
      ], 64))), 128))
    ], 2));
  }
});
export {
  H as default
};
