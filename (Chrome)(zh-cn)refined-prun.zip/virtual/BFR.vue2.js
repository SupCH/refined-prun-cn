import { useCssModule as P } from "./runtime-dom.esm-bundler.js";
import { $ as B, _$ as W } from "./select-dom.js";
import { C as p } from "./prun-css.js";
import { t as r } from "./index5.js";
import Y from "./ActionBar.vue.js";
import h from "./PrunButton.vue.js";
import j from "./SectionHeader.vue.js";
import { userData as v } from "./user-data.js";
import A from "./remove-array-element.js";
import { vDraggable as H } from "./vue-draggable-plus.js";
import X from "./TextInput.vue.js";
import T from "./grip.module.css.js";
import q from "./font-awesome.module.css.js";
import U from "./Tooltip.vue.js";
import E from "./NumberInput.vue.js";
import { objectId as G } from "./object-id.js";
import J from "./InlineFlex.vue.js";
import { defineComponent as K, useTemplateRef as Q, computed as Z, createElementBlock as c, openBlock as f, createVNode as s, createElementVNode as l, createBlock as N, withCtx as g, createTextVNode as y, Fragment as V, withDirectives as _, renderList as x, createCommentVNode as ee, Teleport as te } from "./runtime-core.esm-bundler.js";
import { ref as w, unref as t } from "./reactivity.esm-bundler.js";
import { toDisplayString as m, normalizeClass as a, normalizeStyle as le } from "./shared.esm-bundler.js";
const ne = { key: 0 }, oe = { colspan: "5" }, Te = /* @__PURE__ */ K({
  __name: "BFR",
  setup(ie) {
    const i = P(), b = w(!1), C = Q("overlay"), d = w(null), F = Z(() => d.value ? "pointer" : "default");
    function M(e) {
      if (!b.value)
        return;
      const n = d.value;
      d.value = $(e), n?.classList.remove(i.highlight), d.value?.classList.add(i.highlight);
    }
    async function R(e) {
      const n = $(e);
      if (d.value?.classList.remove(i.highlight), d.value = null, b.value = !1, !n)
        return;
      const o = await B(n, p.TileFrame.cmd);
      if (!o.textContent)
        return;
      const u = await B(n, p.Window.body), S = parseInt(u.style.width.replace("px", ""), 10), O = parseInt(u.style.height.replace("px", ""), 10);
      v.settings.buffers.unshift([o.textContent, S, O]);
    }
    function $(e) {
      const n = z(e);
      if (!n)
        return;
      const o = n.closest(`.${p.Window.window}`);
      if (!(!o || !W(o, p.TileFrame.cmd)))
        return o;
    }
    function z(e) {
      C.value.style.pointerEvents = "none";
      const n = document.elementFromPoint(e.clientX, e.clientY);
      return C.value.style.pointerEvents = "all", n;
    }
    function D() {
      v.settings.buffers.unshift(["", 450, 300]);
    }
    function I(e) {
      A(v.settings.buffers, e);
    }
    const k = w(!1), L = {
      animation: 150,
      handle: `.${T.grip}`,
      onStart: () => k.value = !0,
      onEnd: () => k.value = !1
    };
    return (e, n) => (f(), c(V, null, [
      s(j, null, {
        default: g(() => [
          y(m(("t" in e ? e.t : t(r))("bfr.title")) + " ", 1),
          s(U, {
            position: "bottom",
            class: a(t(i).tooltip),
            tooltip: ("t" in e ? e.t : t(r))("bfr.tooltip")
          }, null, 8, ["class", "tooltip"])
        ]),
        _: 1
      }),
      s(Y, null, {
        default: g(() => [
          t(b) ? (f(), N(h, {
            key: 0,
            neutral: ""
          }, {
            default: g(() => [
              y(m(t(d) ? ("t" in e ? e.t : t(r))("bfr.clickToPick") : ("t" in e ? e.t : t(r))("bfr.clickToCancel")), 1)
            ]),
            _: 1
          })) : (f(), c(V, { key: 1 }, [
            s(h, {
              primary: "",
              onClick: n[0] || (n[0] = (o) => b.value = !0)
            }, {
              default: g(() => [
                y(m(("t" in e ? e.t : t(r))("bfr.pickBuffer")), 1)
              ]),
              _: 1
            }),
            s(h, {
              primary: "",
              onClick: D
            }, {
              default: g(() => [
                y(m(("t" in e ? e.t : t(r))("bfr.addNewRule")), 1)
              ]),
              _: 1
            })
          ], 64))
        ]),
        _: 1
      }),
      l("table", null, [
        l("thead", null, [
          l("tr", null, [
            n[1] || (n[1] = l("th", null, null, -1)),
            l("th", null, [
              s(J, null, {
                default: g(() => [
                  y(m(("t" in e ? e.t : t(r))("bfr.command")) + " ", 1),
                  s(U, {
                    position: "right",
                    tooltip: ("t" in e ? e.t : t(r))("bfr.commandTooltip")
                  }, null, 8, ["tooltip"])
                ]),
                _: 1
              })
            ]),
            l("th", null, m(("t" in e ? e.t : t(r))("bfr.width")), 1),
            l("th", null, m(("t" in e ? e.t : t(r))("bfr.height")), 1),
            n[2] || (n[2] = l("th", null, null, -1))
          ])
        ]),
        t(v).settings.buffers.length === 0 ? (f(), c("tbody", ne, [
          l("tr", null, [
            l("td", oe, m(("t" in e ? e.t : t(r))("bfr.nothingYet")), 1)
          ])
        ])) : _((f(), c("tbody", {
          key: 1,
          class: a(t(k) ? t(i).dragging : null)
        }, [
          (f(!0), c(V, null, x(t(v).settings.buffers, (o) => (f(), c("tr", {
            key: t(G)(o)
          }, [
            l("td", {
              class: a(t(i).gripCell)
            }, [
              l("span", {
                class: a([t(T).grip, t(q).solid, t(i).grip])
              }, m(""), 2)
            ], 2),
            l("td", {
              class: a(t(i).commandCell)
            }, [
              l("div", {
                class: a([("C" in e ? e.C : t(p)).forms.input, t(i).inline])
              }, [
                s(X, {
                  modelValue: o[0],
                  "onUpdate:modelValue": (u) => o[0] = u
                }, null, 8, ["modelValue", "onUpdate:modelValue"])
              ], 2)
            ], 2),
            l("td", {
              class: a(t(i).sizeCell)
            }, [
              l("div", {
                class: a([("C" in e ? e.C : t(p)).forms.input, t(i).inline])
              }, [
                s(E, {
                  modelValue: o[1],
                  "onUpdate:modelValue": (u) => o[1] = u
                }, null, 8, ["modelValue", "onUpdate:modelValue"])
              ], 2)
            ], 2),
            l("td", {
              class: a(t(i).sizeCell)
            }, [
              l("div", {
                class: a([("C" in e ? e.C : t(p)).forms.input, t(i).inline])
              }, [
                s(E, {
                  modelValue: o[2],
                  "onUpdate:modelValue": (u) => o[2] = u
                }, null, 8, ["modelValue", "onUpdate:modelValue"])
              ], 2)
            ], 2),
            l("td", null, [
              s(h, {
                danger: "",
                onClick: (u) => I(o)
              }, {
                default: g(() => [
                  y(m(("t" in e ? e.t : t(r))("bfr.delete")), 1)
                ]),
                _: 2
              }, 1032, ["onClick"])
            ])
          ]))), 128))
        ], 2)), [
          [t(H), [t(v).settings.buffers, L]]
        ])
      ]),
      (f(), N(te, { to: "body" }, [
        t(b) ? (f(), c("div", {
          key: 0,
          ref_key: "overlay",
          ref: C,
          class: a(t(i).overlay),
          style: le({ cursor: t(F) }),
          onClick: R,
          onMousemove: M
        }, null, 38)) : ee("", !0)
      ]))
    ], 64));
  }
});
export {
  Te as default
};
