import { sitesStore as n, getBuildingLastRepair as s } from "./sites.js";
import { shipsStore as a, getShipLastRepair as u } from "./ships.js";
import { getEntityNameFromAddress as d, getEntityNaturalIdFromAddress as c } from "./addresses.js";
import { isRepairableBuilding as f, getBuildingBuildMaterials as p } from "./buildings.js";
import { isEmpty as m } from "./is-empty.js";
function B(r) {
  let i = [];
  if (m(r)) {
    if (n.all.value === void 0)
      return;
    i = n.all.value;
  }
  for (let t = 0; t < r.length; t++) {
    const e = n.getByPlanetNaturalIdOrName(r[t]);
    e && i.push(e);
  }
  return i;
}
function M(r) {
  if (!r)
    return;
  const i = [];
  for (const t of r) {
    const e = d(t.address), l = c(t.address);
    for (const o of t.platforms.filter(f))
      i.push({
        ticker: o.module.reactorTicker,
        target: e,
        naturalId: l,
        lastRepair: s(o),
        condition: o.condition,
        materials: o.repairMaterials,
        fullMaterials: p(o, t)
      });
  }
  return i.sort((t, e) => t.condition - e.condition), i;
}
function E(r) {
  let i = [];
  if (r.length === 0 || r.some(g)) {
    if (a.all.value === void 0)
      return;
    i = a.all.value;
  }
  return i;
}
function R(r) {
  if (!r)
    return;
  const i = [];
  for (const t of r)
    i.push({
      ticker: t.name,
      target: t.name,
      naturalId: "SHIP",
      lastRepair: u(t),
      condition: t.condition,
      materials: t.repairMaterials,
      fullMaterials: t.repairMaterials
    });
  return i.sort((t, e) => t.condition - e.condition), i;
}
function g(r) {
  const i = r.toUpperCase();
  return i === "SHIP" || i === "SHIPS";
}
export {
  M as calculateBuildingEntries,
  R as calculateShipEntries,
  E as getParameterShips,
  B as getParameterSites
};
