var a = { exports: {} };
export {
  a as __module
};
