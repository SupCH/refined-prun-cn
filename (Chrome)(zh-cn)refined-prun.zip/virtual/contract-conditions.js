import { contractsStore as C, isFactionContract as S } from "./contracts.js";
import L from "./dayjs.min.js";
import { timestampEachMinute as E } from "./dayjs.js";
import { sumBy as l } from "./sum-by.js";
import { calcMaterialAmountPrice as d } from "./cx.js";
import { binarySearch as N } from "./binary-search.js";
import { map as D } from "./map-values.js";
import { computed as u } from "./runtime-core.esm-bundler.js";
const f = u(() => {
  const n = C.active.value;
  if (!n)
    return;
  const t = [];
  for (const e of n) {
    const i = e.conditions.filter((o) => o.status !== "FULFILLED");
    for (const o of i)
      t.push({
        contract: e,
        condition: o,
        isSelf: o.party === e.party,
        deadline: v(e, o),
        dependencies: o.dependencies.map((r) => e.conditions.find((c) => c.id === r)).filter((r) => r !== void 0)
      });
  }
  return t.sort((e, i) => e.deadline - i.deadline), t;
});
function v(n, t) {
  return t.type === "COMEX_PURCHASE_PICKUP" ? m(n, t) : t.deadline ? t.deadline.timestamp : t.deadlineDuration ? m(n, t) + t.deadlineDuration.millis : Number.POSITIVE_INFINITY;
}
function m(n, t) {
  let e = n.date.timestamp;
  for (const i of t.dependencies) {
    const o = n.conditions.find((r) => r.id === i);
    o && (e = Math.max(
      e,
      v(n, o)
    ));
  }
  return e;
}
const M = L.duration(1, "week").asMilliseconds(), I = u(() => {
  const n = f.value;
  if (!n)
    return;
  const t = E.value + M;
  return N(t, n, (e) => e.deadline);
}), y = u(() => f.value?.slice(0, I.value)), h = u(() => y.value?.filter((n) => n.isSelf)), H = u(() => y.value?.filter((n) => !n.isSelf)), P = u(() => f.value?.slice(I.value)), Y = u(() => P.value?.filter((n) => n.isSelf)), k = u(() => P.value?.filter((n) => !n.isSelf));
function b(n) {
  return s(n, ["PAYMENT", "LOAN_PAYOUT"], (t) => t.amount.amount);
}
function g(n) {
  return s(n, ["LOAN_INSTALLMENT"], (t) => t.repayment.amount);
}
function q(n) {
  const t = n.value?.filter(
    (e) => e.condition.type === "LOAN_INSTALLMENT" && e.dependencies.every((i) => i.status === "FULFILLED")
  );
  return l(t, (e) => e.condition.interest.amount);
}
function K(n) {
  return s(n, ["DELIVERY"], a);
}
function X(n) {
  return s(n, ["PROVISION"], a);
}
function j(n) {
  const t = n.value?.filter(
    (e) => S(e.contract) && e.condition.type === "PROVISION_SHIPMENT"
  );
  return l(t, (e) => a(e.condition));
}
function w(n) {
  return s(n, ["COMEX_PURCHASE_PICKUP"], (t) => D(
    [d(t.quantity), d(t.pickedUp)],
    (e, i) => e - i
  ));
}
function B(n) {
  let t = 0;
  const e = n.value?.filter((i) => i.condition.type === "DELIVERY_SHIPMENT");
  if (e) {
    for (const i of e) {
      const o = p(i.contract, i.condition, "PICKUP_SHIPMENT");
      if (!o)
        continue;
      const r = p(i.contract, o, "PROVISION_SHIPMENT");
      if (r?.status !== "FULFILLED" || !r?.quantity)
        continue;
      const c = a(r);
      if (c === void 0)
        return;
      t += c;
    }
    return t;
  }
}
function p(n, t, e) {
  for (const i of t.dependencies) {
    const o = n.conditions.find((r) => r.id === i);
    if (o?.type === e)
      return o;
  }
}
function s(n, t, e) {
  const i = n.value?.filter((o) => t.includes(o.condition.type));
  return l(i, (o) => e(o.condition));
}
function a(n) {
  return d(n.quantity);
}
export {
  y as currentConditions,
  P as nonCurrentConditions,
  H as partnerCurrentConditions,
  k as partnerNonCurrentConditions,
  h as selfCurrentConditions,
  Y as selfNonCurrentConditions,
  b as sumAccountsPayable,
  K as sumDeliveries,
  j as sumFactionProvisions,
  q as sumLoanInterest,
  g as sumLoanRepayments,
  w as sumMaterialsPickup,
  X as sumProvisions,
  B as sumShipmentDeliveries
};
