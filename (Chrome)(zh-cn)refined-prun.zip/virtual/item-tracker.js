import { subscribe as m } from "./subscribe-async-generator.js";
import { $$ as f } from "./select-dom.js";
import { C as s } from "./prun-css.js";
import i from "./tinycolor.js";
import { refTextContent as u } from "./reactive-dom.js";
import { watchEffectWhileNodeAlive as p } from "./watch.js";
import { materialsStore as g } from "./materials.js";
import { materialCategoriesStore as b } from "./material-categories.js";
import { objectKeys as y } from "./object-keys.js";
function w() {
  C(), m(f(document, s.ColoredIcon.label), (o) => {
    const r = o.closest(`.${s.ColoredIcon.container}`);
    if (!r)
      return;
    const e = [], t = u(o);
    p(o, () => {
      for (const l of e)
        r.classList.remove(l);
      if (e.length = 0, !t.value)
        return;
      e.push("rp-ticker-" + t.value);
      const c = g.getByTicker(t.value), n = b.getById(c?.category);
      n && e.push("rp-category-" + a(n.name));
      for (const l of e)
        r.classList.add(l);
    });
  });
}
function C() {
  const o = document.createElement("style");
  o.id = "rp-css-icon-colors";
  const r = i("black"), e = r.darken(20).toHexString(), t = r.brighten(10).toHexString(), c = r.brighten(40).toHexString(), n = `.${s.ColoredIcon.container} {
  background: linear-gradient(135deg, ${e}, ${t});
  color: ${c};
}

`;
  o.textContent = n + y(d).map(h).join(`

`), document.head.appendChild(o);
}
function h(o) {
  const r = i(d[o].color), e = r.darken(20).toHexString(), t = r.brighten(10).toHexString(), c = r.brighten(40).toHexString();
  return `.rp-category-${a(o)} {
  background: linear-gradient(135deg, ${e}, ${t});
  color: ${c};
}`;
}
function a(o) {
  return o.replaceAll(" ", "-").replaceAll("(", "").replaceAll(")", "");
}
const d = {
  "agricultural products": {
    color: "b22222"
  },
  alloys: {
    color: "cd7f32"
  },
  chemicals: {
    color: "db7093"
  },
  "construction materials": {
    color: "6495ed"
  },
  "construction parts": {
    color: "4682b4"
  },
  "construction prefabs": {
    color: "1c39bb"
  },
  "consumable bundles": {
    color: "971728"
  },
  "consumables (basic)": {
    color: "cd5c5c"
  },
  "consumables (luxury)": {
    color: "da2c43"
  },
  drones: {
    color: "e25822"
  },
  "electronic devices": {
    color: "8a2be2"
  },
  "electronic parts": {
    color: "9370db"
  },
  "electronic pieces": {
    color: "b19cd9"
  },
  "electronic systems": {
    color: "663399"
  },
  elements: {
    color: "806043"
  },
  "energy systems": {
    color: "2e8b57"
  },
  fuels: {
    color: "32cd32"
  },
  gases: {
    color: "00ced1"
  },
  infrastructure: {
    color: "1e1e8c"
  },
  liquids: {
    color: "bcd4e6"
  },
  "medical equipment": {
    color: "99cc99"
  },
  metals: {
    color: "696969"
  },
  minerals: {
    color: "C4A484"
  },
  ores: {
    color: "838996"
  },
  plastics: {
    color: "cb3365"
  },
  "ship engines": {
    color: "ff4500"
  },
  "ship kits": {
    color: "ff8c00"
  },
  "ship parts": {
    color: "ffa500"
  },
  "ship shields": {
    color: "ffb347"
  },
  "software components": {
    color: "c5b358"
  },
  "software systems": {
    color: "9b870c"
  },
  "software tools": {
    color: "daa520"
  },
  textiles: {
    color: "96a53c"
  },
  "unit prefabs": {
    color: "534b4f"
  },
  utility: {
    color: "CEC7C1"
  }
};
export {
  a as sanitizeCategoryName,
  w as trackItemTickers
};
