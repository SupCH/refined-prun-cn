import s from "./CommandLists.vue2.js";
import o from "./CommandLists.vue3.js";
import t from "./plugin-vue_export-helper.js";
const m = {
  $style: o
}, f = /* @__PURE__ */ t(s, [["__cssModules", m]]);
export {
  f as default
};
