import { getDefaultExportFromCjs as r } from "./commonjsHelpers.js";
import { __require as o } from "./duration2.js";
var t = o();
const i = /* @__PURE__ */ r(t);
export {
  i as default
};
