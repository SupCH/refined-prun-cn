import { createEntityStore as o } from "./create-entity-store.js";
import { onApiMessage as a } from "./api-messages.js";
import { createMapGetter as s } from "./create-map-getter.js";
const e = o(), r = e.state;
a({
  CONTRACT_DRAFTS_DRAFTS(t) {
    e.setAll(t.drafts), e.setFetched();
  },
  CONTRACT_DRAFTS_DRAFT(t) {
    e.setOne(t);
  }
});
const c = s(r.all, (t) => t.naturalId), l = {
  ...r,
  getByNaturalId: c
};
export {
  l as contractDraftsStore
};
