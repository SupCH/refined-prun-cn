import z from "./hammer.js";
import { F as y, Q as d, z as N, v as R, aK as B, s as Y, C as dn } from "./helpers.dataset.js";
/*!
* chartjs-plugin-zoom v2.2.0
* https://www.chartjs.org/chartjs-plugin-zoom/2.2.0/
 * (c) 2016-2024 chartjs-plugin-zoom Contributors
 * Released under the MIT License
 */
const P = (n) => n && n.enabled && n.modifierKey, J = (n, e) => n && e[n + "Key"], F = (n, e) => n && !e[n + "Key"];
function b(n, e, o) {
  return n === void 0 ? !0 : typeof n == "string" ? n.indexOf(e) !== -1 : typeof n == "function" ? n({ chart: o }).indexOf(e) !== -1 : !1;
}
function E(n, e) {
  return typeof n == "function" && (n = n({ chart: e })), typeof n == "string" ? { x: n.indexOf("x") !== -1, y: n.indexOf("y") !== -1 } : { x: !1, y: !1 };
}
function mn(n, e) {
  let o;
  return function() {
    return clearTimeout(o), o = setTimeout(n, e), e;
  };
}
function pn({ x: n, y: e }, o) {
  const t = o.scales, i = Object.keys(t);
  for (let s = 0; s < i.length; s++) {
    const a = t[i[s]];
    if (e >= a.top && e <= a.bottom && n >= a.left && n <= a.right)
      return a;
  }
  return null;
}
function $(n, e, o) {
  const { mode: t = "xy", scaleMode: i, overScaleMode: s } = n || {}, a = pn(e, o), r = E(t, o), l = E(i, o);
  if (s) {
    const f = E(s, o);
    for (const m of ["x", "y"])
      f[m] && (l[m] = r[m], r[m] = !1);
  }
  if (a && l[a.axis])
    return [a];
  const u = [];
  return y(o.scales, function(f) {
    r[f.axis] && u.push(f);
  }), u;
}
const C = /* @__PURE__ */ new WeakMap();
function c(n) {
  let e = C.get(n);
  return e || (e = {
    originalScaleLimits: {},
    updatedScaleLimits: {},
    handlers: {},
    panDelta: {},
    dragging: !1,
    panning: !1
  }, C.set(n, e)), e;
}
function gn(n) {
  C.delete(n);
}
function nn(n, e, o, t) {
  const i = Math.max(0, Math.min(1, (n - e) / o || 0)), s = 1 - i;
  return {
    min: t * i,
    max: t * s
  };
}
function en(n, e) {
  const o = n.isHorizontal() ? e.x : e.y;
  return n.getValueForPixel(o);
}
function on(n, e, o) {
  const t = n.max - n.min, i = t * (e - 1), s = en(n, o);
  return nn(s, n.min, t, i);
}
function xn(n, e, o) {
  const t = en(n, o);
  if (t === void 0)
    return { min: n.min, max: n.max };
  const i = Math.log10(n.min), s = Math.log10(n.max), a = Math.log10(t), r = s - i, l = r * (e - 1), u = nn(a, i, r, l);
  return {
    min: Math.pow(10, i + u.min),
    max: Math.pow(10, s - u.max)
  };
}
function bn(n, e) {
  return e && (e[n.id] || e[n.axis]) || {};
}
function A(n, e, o, t, i) {
  let s = o[t];
  if (s === "original") {
    const a = n.originalScaleLimits[e.id][t];
    s = R(a.options, a.scale);
  }
  return R(s, i);
}
function yn(n, e, o) {
  const t = n.getValueForPixel(e), i = n.getValueForPixel(o);
  return {
    min: Math.min(t, i),
    max: Math.max(t, i)
  };
}
function wn(n, { min: e, max: o, minLimit: t, maxLimit: i }, s) {
  const a = (n - o + e) / 2;
  e -= a, o += a;
  const r = s.min.options ?? s.min.scale, l = s.max.options ?? s.max.scale, u = n / 1e6;
  return B(e, r, u) && (e = r), B(o, l, u) && (o = l), e < t ? (e = t, o = Math.min(t + n, i)) : o > i && (o = i, e = Math.max(i - n, t)), { min: e, max: o };
}
function w(n, { min: e, max: o }, t, i = !1) {
  const s = c(n.chart), { options: a } = n, r = bn(n, t), { minRange: l = 0 } = r, u = A(s, n, r, "min", -1 / 0), f = A(s, n, r, "max", 1 / 0);
  if (i === "pan" && (e < u || o > f))
    return !0;
  const m = n.max - n.min, p = i ? Math.max(o - e, l) : m;
  if (i && p === l && m <= l)
    return !0;
  const x = wn(p, { min: e, max: o, minLimit: u, maxLimit: f }, s.originalScaleLimits[n.id]);
  return a.min = x.min, a.max = x.max, s.updatedScaleLimits[n.id] = x, n.parse(x.min) !== n.min || n.parse(x.max) !== n.max;
}
function Sn(n, e, o, t) {
  const i = on(n, e, o), s = { min: n.min + i.min, max: n.max - i.max };
  return w(n, s, t, !0);
}
function zn(n, e, o, t) {
  const i = xn(n, e, o);
  return w(n, i, t, !0);
}
function Mn(n, e, o, t) {
  w(n, yn(n, e, o), t, !0);
}
const I = (n) => n === 0 || isNaN(n) ? 0 : n < 0 ? Math.min(Math.round(n), -1) : Math.max(Math.round(n), 1);
function Pn(n) {
  const o = n.getLabels().length - 1;
  n.min > 0 && (n.min -= 1), n.max < o && (n.max += 1);
}
function On(n, e, o, t) {
  const i = on(n, e, o);
  n.min === n.max && e < 1 && Pn(n);
  const s = { min: n.min + I(i.min), max: n.max - I(i.max) };
  return w(n, s, t, !0);
}
function Rn(n) {
  return n.isHorizontal() ? n.width : n.height;
}
function Zn(n, e, o) {
  const i = n.getLabels().length - 1;
  let { min: s, max: a } = n;
  const r = Math.max(a - s, 1), l = Math.round(Rn(n) / Math.max(r, 10)), u = Math.round(Math.abs(e / l));
  let f;
  return e < -l ? (a = Math.min(a + u, i), s = r === 1 ? a : a - r, f = a === i) : e > l && (s = Math.max(0, s - u), a = r === 1 ? s : s + r, f = s === 0), w(n, { min: s, max: a }, o) || f;
}
const Dn = {
  second: 500,
  minute: 30 * 1e3,
  hour: 1800 * 1e3,
  day: 720 * 60 * 1e3,
  week: 3.5 * 24 * 60 * 60 * 1e3,
  month: 360 * 60 * 60 * 1e3,
  quarter: 1440 * 60 * 60 * 1e3,
  year: 4368 * 60 * 60 * 1e3
};
function tn(n, e, o, t = !1) {
  const { min: i, max: s, options: a } = n, r = a.time && a.time.round, l = Dn[r] || 0, u = n.getValueForPixel(n.getPixelForValue(i + l) - e), f = n.getValueForPixel(n.getPixelForValue(s + l) - e);
  return isNaN(u) || isNaN(f) ? !0 : w(n, { min: u, max: f }, o, t ? "pan" : !1);
}
function V(n, e, o) {
  return tn(n, e, o, !0);
}
const k = {
  category: On,
  default: Sn,
  logarithmic: zn
}, L = {
  default: Mn
}, h = {
  category: Zn,
  default: tn,
  logarithmic: V,
  timeseries: V
};
function En(n, e, o) {
  const { id: t, options: { min: i, max: s } } = n;
  if (!e[t] || !o[t])
    return !0;
  const a = o[t];
  return a.min !== i || a.max !== s;
}
function X(n, e) {
  y(n, (o, t) => {
    e[t] || delete n[t];
  });
}
function S(n, e) {
  const { scales: o } = n, { originalScaleLimits: t, updatedScaleLimits: i } = e;
  return y(o, function(s) {
    En(s, t, i) && (t[s.id] = {
      min: { scale: s.min, options: s.options.min },
      max: { scale: s.max, options: s.options.max }
    });
  }), X(t, o), X(i, o), t;
}
function K(n, e, o, t) {
  const i = k[n.type] || k.default;
  d(i, [n, e, o, t]);
}
function T(n, e, o, t) {
  const i = L[n.type] || L.default;
  d(i, [n, e, o, t]);
}
function Cn(n) {
  const e = n.chartArea;
  return {
    x: (e.left + e.right) / 2,
    y: (e.top + e.bottom) / 2
  };
}
function j(n, e, o = "none", t = "api") {
  const { x: i = 1, y: s = 1, focalPoint: a = Cn(n) } = typeof e == "number" ? { x: e, y: e } : e, r = c(n), { options: { limits: l, zoom: u } } = r;
  S(n, r);
  const f = i !== 1, m = s !== 1, p = $(u, a, n);
  y(p || n.scales, function(x) {
    x.isHorizontal() && f ? K(x, i, a, l) : !x.isHorizontal() && m && K(x, s, a, l);
  }), n.update(o), d(u.onZoom, [{ chart: n, trigger: t }]);
}
function sn(n, e, o, t = "none", i = "api") {
  const s = c(n), { options: { limits: a, zoom: r } } = s, { mode: l = "xy" } = r;
  S(n, s);
  const u = b(l, "x", n), f = b(l, "y", n);
  y(n.scales, function(m) {
    m.isHorizontal() && u ? T(m, e.x, o.x, a) : !m.isHorizontal() && f && T(m, e.y, o.y, a);
  }), n.update(t), d(r.onZoom, [{ chart: n, trigger: i }]);
}
function kn(n, e, o, t = "none", i = "api") {
  const s = c(n);
  S(n, s);
  const a = n.scales[e];
  w(a, o, void 0, !0), n.update(t), d(s.options.zoom?.onZoom, [{ chart: n, trigger: i }]);
}
function Ln(n, e = "default") {
  const o = c(n), t = S(n, o);
  y(n.scales, function(i) {
    const s = i.options;
    t[i.id] ? (s.min = t[i.id].min.options, s.max = t[i.id].max.options) : (delete s.min, delete s.max), delete o.updatedScaleLimits[i.id];
  }), n.update(e), d(o.options.zoom.onZoomComplete, [{ chart: n }]);
}
function hn(n, e) {
  const o = n.originalScaleLimits[e];
  if (!o)
    return;
  const { min: t, max: i } = o;
  return R(i.options, i.scale) - R(t.options, t.scale);
}
function vn(n) {
  const e = c(n);
  let o = 1, t = 1;
  return y(n.scales, function(i) {
    const s = hn(e, i.id);
    if (s) {
      const a = Math.round(s / (i.max - i.min) * 100) / 100;
      o = Math.min(o, a), t = Math.max(t, a);
    }
  }), o < 1 ? o : t;
}
function W(n, e, o, t) {
  const { panDelta: i } = t, s = i[n.id] || 0;
  Y(s) === Y(e) && (e += s);
  const a = h[n.type] || h.default;
  d(a, [n, e, o]) ? i[n.id] = 0 : i[n.id] = e;
}
function an(n, e, o, t = "none") {
  const { x: i = 0, y: s = 0 } = typeof e == "number" ? { x: e, y: e } : e, a = c(n), { options: { pan: r, limits: l } } = a, { onPan: u } = r || {};
  S(n, a);
  const f = i !== 0, m = s !== 0;
  y(o || n.scales, function(p) {
    p.isHorizontal() && f ? W(p, i, l, a) : !p.isHorizontal() && m && W(p, s, l, a);
  }), n.update(t), d(u, [{ chart: n }]);
}
function rn(n) {
  const e = c(n);
  S(n, e);
  const o = {};
  for (const t of Object.keys(n.scales)) {
    const { min: i, max: s } = e.originalScaleLimits[t] || { min: {}, max: {} };
    o[t] = { min: i.scale, max: s.scale };
  }
  return o;
}
function Hn(n) {
  const e = c(n), o = {};
  for (const t of Object.keys(n.scales))
    o[t] = e.updatedScaleLimits[t];
  return o;
}
function Nn(n) {
  const e = rn(n);
  for (const o of Object.keys(n.scales)) {
    const { min: t, max: i } = e[o];
    if (t !== void 0 && n.scales[o].min !== t || i !== void 0 && n.scales[o].max !== i)
      return !0;
  }
  return !1;
}
function _(n) {
  const e = c(n);
  return e.panning || e.dragging;
}
const U = (n, e, o) => Math.min(o, Math.max(e, n));
function g(n, e) {
  const { handlers: o } = c(n), t = o[e];
  t && t.target && (t.target.removeEventListener(e, t), delete o[e]);
}
function M(n, e, o, t) {
  const { handlers: i, options: s } = c(n), a = i[o];
  if (a && a.target === e)
    return;
  g(n, o), i[o] = (l) => t(n, l, s), i[o].target = e;
  const r = o === "wheel" ? !1 : void 0;
  e.addEventListener(o, i[o], { passive: r });
}
function Fn(n, e) {
  const o = c(n);
  o.dragStart && (o.dragging = !0, o.dragEnd = e, n.update("none"));
}
function jn(n, e) {
  const o = c(n);
  !o.dragStart || e.key !== "Escape" || (g(n, "keydown"), o.dragging = !1, o.dragStart = o.dragEnd = null, n.update("none"));
}
function v(n, e) {
  if (n.target !== e.canvas) {
    const o = e.canvas.getBoundingClientRect();
    return {
      x: n.clientX - o.left,
      y: n.clientY - o.top
    };
  }
  return N(n, e);
}
function ln(n, e, o) {
  const { onZoomStart: t, onZoomRejected: i } = o;
  if (t) {
    const s = v(e, n);
    if (d(t, [{ chart: n, event: e, point: s }]) === !1)
      return d(i, [{ chart: n, event: e }]), !1;
  }
}
function Bn(n, e) {
  if (n.legend) {
    const s = N(e, n);
    if (dn(s, n.legend))
      return;
  }
  const o = c(n), { pan: t, zoom: i = {} } = o.options;
  if (e.button !== 0 || J(P(t), e) || F(P(i.drag), e))
    return d(i.onZoomRejected, [{ chart: n, event: e }]);
  ln(n, e, i) !== !1 && (o.dragStart = e, M(n, n.canvas.ownerDocument, "mousemove", Fn), M(n, window.document, "keydown", jn));
}
function Yn({ begin: n, end: e }, o) {
  let t = e.x - n.x, i = e.y - n.y;
  const s = Math.abs(t / i);
  s > o ? t = Math.sign(t) * Math.abs(i * o) : s < o && (i = Math.sign(i) * Math.abs(t / o)), e.x = n.x + t, e.y = n.y + i;
}
function q(n, e, o, { min: t, max: i, prop: s }) {
  n[t] = U(Math.min(o.begin[s], o.end[s]), e[t], e[i]), n[i] = U(Math.max(o.begin[s], o.end[s]), e[t], e[i]);
}
function An(n, e, o) {
  const t = {
    begin: v(e.dragStart, n),
    end: v(e.dragEnd, n)
  };
  if (o) {
    const i = n.chartArea.width / n.chartArea.height;
    Yn(t, i);
  }
  return t;
}
function un(n, e, o, t) {
  const i = b(e, "x", n), s = b(e, "y", n), { top: a, left: r, right: l, bottom: u, width: f, height: m } = n.chartArea, p = { top: a, left: r, right: l, bottom: u }, x = An(n, o, t && i && s);
  i && q(p, n.chartArea, x, { min: "left", max: "right", prop: "x" }), s && q(p, n.chartArea, x, { min: "top", max: "bottom", prop: "y" });
  const Z = p.right - p.left, D = p.bottom - p.top;
  return {
    ...p,
    width: Z,
    height: D,
    zoomX: i && Z ? 1 + (f - Z) / f : 1,
    zoomY: s && D ? 1 + (m - D) / m : 1
  };
}
function In(n, e) {
  const o = c(n);
  if (!o.dragStart)
    return;
  g(n, "mousemove");
  const { mode: t, onZoomComplete: i, drag: { threshold: s = 0, maintainAspectRatio: a } } = o.options.zoom, r = un(n, t, { dragStart: o.dragStart, dragEnd: e }, a), l = b(t, "x", n) ? r.width : 0, u = b(t, "y", n) ? r.height : 0, f = Math.sqrt(l * l + u * u);
  if (o.dragStart = o.dragEnd = null, f <= s) {
    o.dragging = !1, n.update("none");
    return;
  }
  sn(n, { x: r.left, y: r.top }, { x: r.right, y: r.bottom }, "zoom", "drag"), o.dragging = !1, o.filterNextClick = !0, d(i, [{ chart: n }]);
}
function Vn(n, e, o) {
  if (F(P(o.wheel), e)) {
    d(o.onZoomRejected, [{ chart: n, event: e }]);
    return;
  }
  if (ln(n, e, o) !== !1 && (e.cancelable && e.preventDefault(), e.deltaY !== void 0))
    return !0;
}
function Xn(n, e) {
  const { handlers: { onZoomComplete: o }, options: { zoom: t } } = c(n);
  if (!Vn(n, e, t))
    return;
  const i = e.target.getBoundingClientRect(), s = t.wheel.speed, a = e.deltaY >= 0 ? 2 - 1 / (1 - s) : 1 + s, r = {
    x: a,
    y: a,
    focalPoint: {
      x: e.clientX - i.left,
      y: e.clientY - i.top
    }
  };
  j(n, r, "zoom", "wheel"), d(o, [{ chart: n }]);
}
function Kn(n, e, o, t) {
  o && (c(n).handlers[e] = mn(() => d(o, [{ chart: n }]), t));
}
function Tn(n, e) {
  const o = n.canvas, { wheel: t, drag: i, onZoomComplete: s } = e.zoom;
  t.enabled ? (M(n, o, "wheel", Xn), Kn(n, "onZoomComplete", s, 250)) : g(n, "wheel"), i.enabled ? (M(n, o, "mousedown", Bn), M(n, o.ownerDocument, "mouseup", In)) : (g(n, "mousedown"), g(n, "mousemove"), g(n, "mouseup"), g(n, "keydown"));
}
function Wn(n) {
  g(n, "mousedown"), g(n, "mousemove"), g(n, "mouseup"), g(n, "wheel"), g(n, "click"), g(n, "keydown");
}
function _n(n, e) {
  return function(o, t) {
    const { pan: i, zoom: s = {} } = e.options;
    if (!i || !i.enabled)
      return !1;
    const a = t && t.srcEvent;
    return a && !e.panning && t.pointerType === "mouse" && (F(P(i), a) || J(P(s.drag), a)) ? (d(i.onPanRejected, [{ chart: n, event: t }]), !1) : !0;
  };
}
function Un(n, e) {
  const o = Math.abs(n.clientX - e.clientX), t = Math.abs(n.clientY - e.clientY), i = o / t;
  let s, a;
  return i > 0.3 && i < 1.7 ? s = a = !0 : o > t ? s = !0 : a = !0, { x: s, y: a };
}
function fn(n, e, o) {
  if (e.scale) {
    const { center: t, pointers: i } = o, s = 1 / e.scale * o.scale, a = o.target.getBoundingClientRect(), r = Un(i[0], i[1]), l = e.options.zoom.mode, u = {
      x: r.x && b(l, "x", n) ? s : 1,
      y: r.y && b(l, "y", n) ? s : 1,
      focalPoint: {
        x: t.x - a.left,
        y: t.y - a.top
      }
    };
    j(n, u, "zoom", "pinch"), e.scale = o.scale;
  }
}
function qn(n, e, o) {
  if (e.options.zoom.pinch.enabled) {
    const t = N(o, n);
    d(e.options.zoom.onZoomStart, [{ chart: n, event: o, point: t }]) === !1 ? (e.scale = null, d(e.options.zoom.onZoomRejected, [{ chart: n, event: o }])) : e.scale = 1;
  }
}
function Qn(n, e, o) {
  e.scale && (fn(n, e, o), e.scale = null, d(e.options.zoom.onZoomComplete, [{ chart: n }]));
}
function cn(n, e, o) {
  const t = e.delta;
  t && (e.panning = !0, an(n, { x: o.deltaX - t.x, y: o.deltaY - t.y }, e.panScales), e.delta = { x: o.deltaX, y: o.deltaY });
}
function Gn(n, e, o) {
  const { enabled: t, onPanStart: i, onPanRejected: s } = e.options.pan;
  if (!t)
    return;
  const a = o.target.getBoundingClientRect(), r = {
    x: o.center.x - a.left,
    y: o.center.y - a.top
  };
  if (d(i, [{ chart: n, event: o, point: r }]) === !1)
    return d(s, [{ chart: n, event: o }]);
  e.panScales = $(e.options.pan, r, n), e.delta = { x: 0, y: 0 }, cn(n, e, o);
}
function Jn(n, e) {
  e.delta = null, e.panning && (e.panning = !1, e.filterNextClick = !0, d(e.options.pan.onPanComplete, [{ chart: n }]));
}
const H = /* @__PURE__ */ new WeakMap();
function Q(n, e) {
  const o = c(n), t = n.canvas, { pan: i, zoom: s } = e, a = new z.Manager(t);
  s && s.pinch.enabled && (a.add(new z.Pinch()), a.on("pinchstart", (r) => qn(n, o, r)), a.on("pinch", (r) => fn(n, o, r)), a.on("pinchend", (r) => Qn(n, o, r))), i && i.enabled && (a.add(new z.Pan({
    threshold: i.threshold,
    enable: _n(n, o)
  })), a.on("panstart", (r) => Gn(n, o, r)), a.on("panmove", (r) => cn(n, o, r)), a.on("panend", () => Jn(n, o))), H.set(n, a);
}
function G(n) {
  const e = H.get(n);
  e && (e.remove("pinchstart"), e.remove("pinch"), e.remove("pinchend"), e.remove("panstart"), e.remove("pan"), e.remove("panend"), e.destroy(), H.delete(n));
}
function $n(n, e) {
  const { pan: o, zoom: t } = n, { pan: i, zoom: s } = e;
  return t?.zoom?.pinch?.enabled !== s?.zoom?.pinch?.enabled || o?.enabled !== i?.enabled || o?.threshold !== i?.threshold;
}
var ne = "2.2.0";
function O(n, e, o) {
  const t = o.zoom.drag, { dragStart: i, dragEnd: s } = c(n);
  if (t.drawTime !== e || !s)
    return;
  const { left: a, top: r, width: l, height: u } = un(n, o.zoom.mode, { dragStart: i, dragEnd: s }, t.maintainAspectRatio), f = n.ctx;
  f.save(), f.beginPath(), f.fillStyle = t.backgroundColor || "rgba(225,225,225,0.3)", f.fillRect(a, r, l, u), t.borderWidth > 0 && (f.lineWidth = t.borderWidth, f.strokeStyle = t.borderColor || "rgba(225,225,225)", f.strokeRect(a, r, l, u)), f.restore();
}
var te = {
  id: "zoom",
  version: ne,
  defaults: {
    pan: {
      enabled: !1,
      mode: "xy",
      threshold: 10,
      modifierKey: null
    },
    zoom: {
      wheel: {
        enabled: !1,
        speed: 0.1,
        modifierKey: null
      },
      drag: {
        enabled: !1,
        drawTime: "beforeDatasetsDraw",
        modifierKey: null
      },
      pinch: {
        enabled: !1
      },
      mode: "xy"
    }
  },
  start: function(n, e, o) {
    const t = c(n);
    t.options = o, Object.prototype.hasOwnProperty.call(o.zoom, "enabled") && console.warn("The option `zoom.enabled` is no longer supported. Please use `zoom.wheel.enabled`, `zoom.drag.enabled`, or `zoom.pinch.enabled`."), (Object.prototype.hasOwnProperty.call(o.zoom, "overScaleMode") || Object.prototype.hasOwnProperty.call(o.pan, "overScaleMode")) && console.warn("The option `overScaleMode` is deprecated. Please use `scaleMode` instead (and update `mode` as desired)."), z && Q(n, o), n.pan = (i, s, a) => an(n, i, s, a), n.zoom = (i, s) => j(n, i, s), n.zoomRect = (i, s, a) => sn(n, i, s, a), n.zoomScale = (i, s, a) => kn(n, i, s, a), n.resetZoom = (i) => Ln(n, i), n.getZoomLevel = () => vn(n), n.getInitialScaleBounds = () => rn(n), n.getZoomedScaleBounds = () => Hn(n), n.isZoomedOrPanned = () => Nn(n), n.isZoomingOrPanning = () => _(n);
  },
  beforeEvent(n, { event: e }) {
    if (_(n))
      return !1;
    if (e.type === "click" || e.type === "mouseup") {
      const o = c(n);
      if (o.filterNextClick)
        return o.filterNextClick = !1, !1;
    }
  },
  beforeUpdate: function(n, e, o) {
    const t = c(n), i = t.options;
    t.options = o, $n(i, o) && (G(n), Q(n, o)), Tn(n, o);
  },
  beforeDatasetsDraw(n, e, o) {
    O(n, "beforeDatasetsDraw", o);
  },
  afterDatasetsDraw(n, e, o) {
    O(n, "afterDatasetsDraw", o);
  },
  beforeDraw(n, e, o) {
    O(n, "beforeDraw", o);
  },
  afterDraw(n, e, o) {
    O(n, "afterDraw", o);
  },
  stop: function(n) {
    Wn(n), z && G(n), gn(n);
  },
  panFunctions: h,
  zoomFunctions: k,
  zoomRectFunctions: L
};
export {
  te as default,
  an as pan,
  Ln as resetZoom,
  j as zoom,
  sn as zoomRect,
  kn as zoomScale
};
