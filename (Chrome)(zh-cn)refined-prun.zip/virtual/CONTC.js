import m from "./xit-registry.js";
import n from "./CONTC.vue.js";
m.add({
  command: ["CONTC"],
  name: "PENDING CONTRACT CONDITIONS",
  description: "Displays pending contract conditions.",
  contextItems: () => [{ cmd: "XIT CONTS" }, { cmd: "CONTS" }, { cmd: "CONTD" }],
  component: () => n
});
