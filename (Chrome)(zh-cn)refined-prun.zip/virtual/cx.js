import { userData as p } from "./user-data.js";
import m from "./dayjs.min.js";
import { isPresent as d } from "./is-present.js";
import { computed as g } from "./runtime-core.esm-bundler.js";
import { shallowReactive as A } from "./reactivity.esm-bundler.js";
const v = m.duration(15, "minutes").asMilliseconds();
async function M() {
  setTimeout(M, v);
  const c = await (await fetch("https://refined-prun.github.io/refined-prices/all.json")).json(), r = /* @__PURE__ */ new Map(), t = /* @__PURE__ */ new Set();
  for (const s of c) {
    const n = s.ExchangeCode;
    let f = r.get(n);
    f || (f = /* @__PURE__ */ new Map(), r.set(n, f));
    const e = s.MaterialTicker;
    f.set(e, s), t.add(e);
  }
  const u = /* @__PURE__ */ new Map();
  r.set("UNIVERSE", u);
  for (const s of t.values()) {
    const n = Array.from(r.values()).map((e) => e.get(s)), f = {
      MaterialTicker: s,
      ExchangeCode: "UNIVERSE",
      MMBuy: a(n, (e) => e.MMBuy),
      MMSell: a(n, (e) => e.MMSell),
      PriceAverage: a(n, (e) => e.PriceAverage),
      Ask: a(n, (e) => e.Ask),
      Bid: a(n, (e) => e.Bid),
      VWAP7D: a(
        n,
        (e) => e.VWAP7D,
        (e) => e.Traded7D
      ),
      VWAP30D: a(
        n,
        (e) => e.VWAP30D,
        (e) => e.Traded30D
      )
    };
    u.set(s, f);
  }
  l.age = Date.now(), l.prices = r, l.fetched = !0;
}
function a(i, o, c) {
  let r = null, t = null;
  for (const u of i) {
    if (u === void 0)
      continue;
    const s = o(u), n = c ? c(u) : 1;
    !d(s) || !d(n) || (r = (r ?? 0) + s * n, t = (t ?? 0) + n);
  }
  return !d(r) || !d(t) ? null : r / t;
}
const P = g(() => new Set(p.settings.financial.ignoredMaterials.split(","))), h = g(() => new Set(p.settings.financial.mmMaterials.split(",")));
function D(i) {
  if (!i)
    return;
  const o = i.toUpperCase();
  if (P.value.has(o))
    return 0;
  if (!l.fetched)
    return;
  const c = p.settings.pricing, r = l.prices.get(c.exchange);
  if (!r)
    return;
  if (h.value.has(o))
    return r.get(i)?.MMBuy ?? 0;
  const t = r.get(i);
  if (!t)
    return 0;
  switch (c.method) {
    case "ASK":
      return t.Ask ?? 0;
    case "BID":
      return t.Bid ?? 0;
    case "AVG":
      return t.PriceAverage ?? 0;
    case "VWAP7D":
      return t.VWAP7D ?? 0;
    case "VWAP30D":
      return t.VWAP30D ?? 0;
    case "DEFAULT":
      return t.VWAP7D ?? t.VWAP30D ?? t.PriceAverage ?? t.Ask ?? t.Bid ?? 0;
  }
}
function V(i) {
  return D(i.ticker);
}
function k(i) {
  const o = V(i.material);
  return o !== void 0 ? o * i.amount : void 0;
}
function x(i) {
  if (!i)
    return;
  let o = 0;
  for (const c of i) {
    const r = k(c);
    if (r === void 0)
      return;
    o += r;
  }
  return o;
}
const l = A({
  prices: void 0,
  age: 0,
  fetched: !1
});
export {
  k as calcMaterialAmountPrice,
  l as cxStore,
  M as fetchPrices,
  V as getMaterialPrice,
  D as getPrice,
  x as sumMaterialAmountPrice
};
