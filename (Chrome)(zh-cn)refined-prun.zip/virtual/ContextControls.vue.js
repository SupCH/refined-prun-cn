import { C as t } from "./prun-css.js";
import m from "./ContextControlsItem.vue.js";
import { defineComponent as l, createElementBlock as n, openBlock as o, Fragment as a, renderList as s, createBlock as c } from "./runtime-core.esm-bundler.js";
import { normalizeClass as i } from "./shared.esm-bundler.js";
import { unref as p } from "./reactivity.esm-bundler.js";
const B = /* @__PURE__ */ l({
  __name: "ContextControls",
  props: {
    items: {}
  },
  setup(f) {
    return (e, u) => (o(), n("div", {
      class: i(("C" in e ? e.C : p(t)).ContextControls.container)
    }, [
      (o(!0), n(a, null, s(e.items, (r) => (o(), c(m, {
        key: r.cmd,
        cmd: r.cmd,
        label: r.label
      }, null, 8, ["cmd", "label"]))), 128))
    ], 2));
  }
});
export {
  B as default
};
