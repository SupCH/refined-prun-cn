import f from "./Configure.vue3.js";
export {
  f as default
};
