import { applyCssRule as t } from "./refined-prun-css.js";
import d from "./feature-registry.js";
import i from "./css-utils.module.css.js";
function r() {
  t("CXOB", "tbody:nth-child(2) > tr:first-child", i.hidden), t("CXOB", "tbody:nth-child(4) > tr:first-child", i.hidden);
}
d.add(import.meta.url, r, 'CXOB: Hides "Offers" and "Requests" headers.');
