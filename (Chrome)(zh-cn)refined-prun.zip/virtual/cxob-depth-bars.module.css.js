const s = "rp-cxob-depth-bars__tbody___95e0d47", _ = "rp-cxob-depth-bars__bids___b3c73d2", b = "rp-cxob-depth-bars__asks___2e5ab59", t = {
  tbody: s,
  bids: _,
  asks: b
};
export {
  b as asks,
  _ as bids,
  t as default,
  s as tbody
};
