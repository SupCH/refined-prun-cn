import f from "./ContractRow.vue.js";
export {
  f as default
};
