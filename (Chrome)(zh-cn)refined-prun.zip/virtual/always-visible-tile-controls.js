import { applyCssRule as r } from "./refined-prun-css.js";
import { C as o } from "./prun-css.js";
import t from "./feature-registry.js";
import i from "./always-visible-tile-controls.module.css.js";
import l from "./css-utils.module.css.js";
function s() {
  r(`.${o.TileControls.container} > .${o.TileControls.icon}`, l.hidden), r(`.${o.TileControls.container} > .${o.TileControls.controls}`, i.show);
}
t.add(import.meta.url, s, "Makes top-right tile controls always visible.");
