import { userData as u } from "./user-data.js";
import { watch as P } from "./runtime-core.esm-bundler.js";
let n = null;
P(u, () => n = null, { immediate: !0, deep: !0 });
const S = [450, 300];
function m(i) {
  n || (n = u.settings.buffers.filter((e) => !!e[0] && typeof e[1] == "number" && typeof e[2] == "number").map((e) => {
    const s = e[0] === "*" ? ".*" : e[0];
    return [new RegExp(s.toUpperCase()), e[1], e[2]];
  }));
  const r = i.toUpperCase().trim();
  for (const e of n)
    if (r.match(e[0]))
      return [e[1], e[2]];
  if (r === "PLI" || r === "SYSI")
    return S.slice();
  const t = r.split(" ");
  let f = t[0];
  return f === "XIT" && t.length > 1 ? (f = t[1].split("_")[0], c[f]) : o[f];
}
function O(i, r) {
  let t = o[i];
  t === void 0 && (t = S.slice(), o[i] = t), t[0] += r.width ?? 0, t[1] += r.height ?? 0;
}
const o = {
  ADM: [380, 550],
  BBC: [500, 450],
  BLU: [550, 600],
  BS: [610, 300],
  BSC: [550, 620],
  BTF: [570, 700],
  BUI: [500, 400],
  COGC: [500, 580],
  CONT: [600, 400],
  CONTD: [450, 550],
  CONTS: [550, 300],
  CORPARC: [350, 550],
  CORPNP: [450, 430],
  CORPP: [460, 640],
  CX: [550, 600],
  CXL: [600, 180],
  CXM: [625, 300],
  CXOS: [750, 300],
  CXPO: [450, 310],
  FLT: [650, 180],
  GOV: [470, 550],
  HQ: [450, 600],
  INV: [530, 250],
  LEAD: [700, 400],
  LM: [500, 580],
  LMA: [425, 370],
  LMOS: [700, 420],
  LMP: [450, 500],
  MAT: [500, 400],
  MOTS: [600, 450],
  MU: [512, 512],
  NOTS: [425, 625],
  PLI: [450, 600],
  POPI: [550, 300],
  POPID: [460, 500],
  POPR: [515, 400],
  PROD: [400, 500],
  PRODCO: [415, 600],
  PRODQ: [650, 300],
  SHP: [450, 450],
  SHY: [450, 450],
  STEAM: [300, 450],
  STNS: [400, 280],
  SYSI: [600, 600],
  WAR: [400, 580],
  WF: [710, 300]
}, c = {
  CALC: [275, 326],
  YAPT: [1100, 700],
  PRUNSTAT: [830, 680],
  PRUNSTATS: [830, 680]
};
export {
  O as increaseDefaultBufferSize,
  m as matchBufferSize
};
