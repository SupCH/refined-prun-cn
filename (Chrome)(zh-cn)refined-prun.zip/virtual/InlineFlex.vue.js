import { C as r } from "./prun-css.js";
import n from "./plugin-vue_export-helper.js";
import { createElementBlock as o, openBlock as l, renderSlot as t } from "./runtime-core.esm-bundler.js";
import { normalizeClass as i } from "./shared.esm-bundler.js";
import { unref as m } from "./reactivity.esm-bundler.js";
const s = {};
function f(e, a) {
  return l(), o("span", {
    class: i(("C" in e ? e.C : m(r)).InlineFlex.inlineFlex)
  }, [
    t(e.$slots, "default")
  ], 2);
}
const C = /* @__PURE__ */ n(s, [["render", f]]);
export {
  C as default
};
