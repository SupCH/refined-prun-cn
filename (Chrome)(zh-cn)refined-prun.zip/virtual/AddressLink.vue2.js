import f from "./AddressLink.vue.js";
export {
  f as default
};
