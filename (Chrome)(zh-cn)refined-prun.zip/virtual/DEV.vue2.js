import f from "./DEV.vue.js";
export {
  f as default
};
