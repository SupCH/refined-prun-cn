import s from "./FIN.vue5.js";
import o from "./FIN.vue6.js";
import t from "./plugin-vue_export-helper.js";
const r = {
  $style: o
}, f = /* @__PURE__ */ t(s, [["__cssModules", r]]);
export {
  f as default
};
