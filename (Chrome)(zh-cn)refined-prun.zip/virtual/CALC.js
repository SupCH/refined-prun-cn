import o from "./xit-registry.js";
import m from "./CALC.vue.js";
o.add({
  command: ["CALC", "CALCULATOR"],
  name: "CALCULATOR",
  description: "Provides an in-game calculator.",
  component: () => m
});
