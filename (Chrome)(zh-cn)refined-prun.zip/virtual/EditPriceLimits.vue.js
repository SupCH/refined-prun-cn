import { C as $ } from "./prun-css.js";
import { objectId as k } from "./object-id.js";
import E from "./NumberInput.vue.js";
import f from "./PrunButton.vue.js";
import u from "./Active.vue.js";
import b from "./TextInput.vue.js";
import s from "./Commands.vue.js";
import N from "./SectionHeader.vue.js";
import { defineComponent as U, createElementBlock as i, openBlock as n, createVNode as e, createElementVNode as y, withCtx as t, createTextVNode as a, Fragment as p, renderList as B } from "./runtime-core.esm-bundler.js";
import { unref as c } from "./reactivity.esm-bundler.js";
import { normalizeClass as D } from "./shared.esm-bundler.js";
const H = /* @__PURE__ */ U({
  __name: "EditPriceLimits",
  props: {
    priceLimits: {}
  },
  emits: ["close"],
  setup(V, { emit: _ }) {
    const C = _;
    function L() {
      V.priceLimits.push(["", 0]);
    }
    return (m, o) => (n(), i("div", {
      class: D(("C" in m ? m.C : c($)).DraftConditionEditor.form)
    }, [
      e(N, null, {
        default: t(() => [...o[1] || (o[1] = [
          a("Edit Price Limits", -1)
        ])]),
        _: 1
      }),
      y("form", null, [
        (n(!0), i(p, null, B(m.priceLimits, (l, d) => (n(), i(p, {
          key: c(k)(l)
        }, [
          e(u, {
            label: `Material Ticker #${d + 1}`
          }, {
            default: t(() => [
              e(b, {
                modelValue: l[0],
                "onUpdate:modelValue": (r) => l[0] = r
              }, null, 8, ["modelValue", "onUpdate:modelValue"])
            ]),
            _: 2
          }, 1032, ["label"]),
          e(u, {
            label: `Price Limit #${d + 1}`
          }, {
            default: t(() => [
              e(E, {
                modelValue: l[1],
                "onUpdate:modelValue": (r) => l[1] = r
              }, null, 8, ["modelValue", "onUpdate:modelValue"])
            ]),
            _: 2
          }, 1032, ["label"])
        ], 64))), 128)),
        e(s, null, {
          default: t(() => [
            e(f, {
              primary: "",
              onClick: L
            }, {
              default: t(() => [...o[2] || (o[2] = [
                a("ADD", -1)
              ])]),
              _: 1
            })
          ]),
          _: 1
        }),
        e(s, null, {
          default: t(() => [
            e(f, {
              primary: "",
              onClick: o[0] || (o[0] = (l) => C("close"))
            }, {
              default: t(() => [...o[3] || (o[3] = [
                a("CLOSE", -1)
              ])]),
              _: 1
            })
          ]),
          _: 1
        })
      ])
    ], 2));
  }
});
export {
  H as default
};
