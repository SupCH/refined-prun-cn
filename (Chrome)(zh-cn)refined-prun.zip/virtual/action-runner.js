import "./config.js";
import { act as h } from "./act-registry.js";
import { deepToRaw as a } from "./deep-to-raw.js";
import { TileAllocator as p } from "./tile-allocator.js";
import { StepMachine as l } from "./step-machine.js";
import { StepGenerator as u } from "./step-generator.js";
import { t as r } from "./index5.js";
class w {
  // Track auto-execute mode
  constructor(t) {
    this.options = t, this.tileAllocator = new p(t), this.stepGenerator = new u(t);
  }
  tileAllocator;
  stepGenerator;
  stepMachine;
  autoMode = !1;
  get log() {
    return this.options.log;
  }
  get isRunning() {
    return this.stepMachine?.isRunning ?? !1;
  }
  get isAutoMode() {
    return this.autoMode;
  }
  async preview(t, s) {
    if (this.isRunning) {
      this.log.error("Action Package is already running");
      return;
    }
    const e = structuredClone(a(t)), { steps: i, fail: n } = await this.stepGenerator.generateSteps(e, s);
    if (i.length !== 0) {
      n && this.log.info("Generated steps for valid actions:");
      for (const o of i) {
        const c = h.getActionStepInfo(o.type);
        this.log.action(c.description(o));
      }
    }
  }
  async execute(t, s, e = !1) {
    if (this.isRunning) {
      this.log.error("Action Package is already running");
      return;
    }
    const i = structuredClone(a(t)), { steps: n, fail: o } = await this.stepGenerator.generateSteps(i, s);
    if (o) {
      this.log.error("Action Package execution failed");
      return;
    }
    this.autoMode = e, this.log.info(e ? r("act.autoExecutionStarted") : r("act.executionStarted")), this.stepMachine = new l(n, {
      ...this.options,
      tileAllocator: this.tileAllocator,
      // Override onActReady to support auto-execution
      onActReady: () => {
        this.options.onActReady(), this.autoMode && this.stepMachine?.isRunning && setTimeout(() => {
          this.autoMode && this.stepMachine?.isRunning && this.act();
        }, 500);
      }
    }), this.stepMachine.start();
  }
  act() {
    this.stepMachine?.act(), this.stepMachine?.isRunning || (this.stepMachine = void 0, this.autoMode = !1);
  }
  skip() {
    this.stepMachine?.skip(), this.stepMachine?.isRunning || (this.stepMachine = void 0, this.autoMode = !1);
  }
  cancel() {
    this.stepMachine?.cancel(), this.stepMachine = void 0, this.autoMode = !1;
  }
  stopAuto() {
    this.autoMode = !1, this.options.log.info("Auto-execution stopped, switched to manual mode");
  }
}
export {
  w as ActionRunner
};
