import { subscribe as v } from "./subscribe-async-generator.js";
import { $$ as y, $ as i, _$$ as b } from "./select-dom.js";
import { C as n } from "./prun-css.js";
import { createFragmentApp as A } from "./vue-fragment-app.js";
import T from "./tiles.js";
import $ from "./feature-registry.js";
import { getMaterialName as V } from "./i18n.js";
import w from "./cx-search-bar.module.css.js";
import { materialsStore as M } from "./materials.js";
import l from "./css-utils.module.css.js";
import { watchEffectWhileNodeAlive as R } from "./watch.js";
import _ from "./TextInput.vue.js";
import k from "./PrunButton.vue.js";
import x from "./font-awesome.module.css.js";
import { refValue as E } from "./reactive-dom.js";
import { ref as N, triggerRef as B } from "./reactivity.esm-bundler.js";
import { watch as L, createVNode as m, createTextVNode as U } from "./runtime-core.esm-bundler.js";
function S(t) {
  v(y(t.anchor, n.ComExPanel.input), X);
}
async function X(t) {
  const f = await i(t, n.ActionBar.container), p = await i(f, "select"), C = E(p), o = N(""), s = /* @__PURE__ */ new Map();
  for (const e of Array.from(p.options))
    s.set(e.value, e);
  const c = /* @__PURE__ */ new Map();
  async function d() {
    const e = await i(t, "tbody");
    for (const a of b(e, "tr")) {
      const r = await i(a, n.ColoredIcon.label);
      c.set(r.innerText, a);
    }
    B(o);
  }
  v(y(t, "tbody"), d), L(C, d);
  const u = (e) => {
    e.isConnected && e.classList.toggle(l.hidden, o.value.length !== 0);
  };
  R(t, () => {
    const e = o.value.toUpperCase();
    s.forEach(u), c.forEach(u);
    const a = M.all.value;
    if (!(e.length === 0 || !a)) {
      for (const r of a)
        if (r.ticker.includes(e) || V(r)?.toUpperCase().includes(e)) {
          const h = s.get(r.category);
          h && h.classList.remove(l.hidden);
          const g = c.get(r.ticker);
          g?.isConnected && g.classList.remove(l.hidden);
        }
    }
  }), A(() => m("div", {
    class: [n.ActionBar.element, w.container]
  }, [U("Search: "), m(_, {
    modelValue: o.value,
    "onUpdate:modelValue": (e) => o.value = e
  }, null), m(k, {
    dark: !0,
    class: [w.button, x.solid],
    onClick: () => o.value = ""
  }, {
    default: () => [""]
  })])).prependTo(f);
}
function F() {
  T.observe("CX", S);
}
$.add(import.meta.url, F, "CX: Adds a search bar for materials.");
