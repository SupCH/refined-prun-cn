import m from "./xit-registry.js";
import c from "./CONTS.vue.js";
m.add({
  command: ["CONTS", "CONTRACTS"],
  name: "ACTIVE CONTRACTS",
  description: "Displays active contracts.",
  contextItems: () => [{ cmd: "XIT CONTC" }, { cmd: "CONTS" }, { cmd: "CONTD" }],
  component: () => c
});
