async function a(i, { filter: n, signal: t, ...s } = {}) {
  return t?.aborted ? [] : new Promise((o) => {
    const e = new MutationObserver((r) => {
      (!n || n(r)) && (e.disconnect(), o(r));
    });
    e.observe(i, s), t?.addEventListener("abort", () => {
      e.disconnect(), o([]);
    });
  });
}
export {
  a as default
};
