const t = "rp-EquityHistoryChart__wide___6848ff2", e = {
  wide: t
};
export {
  e as default,
  t as wide
};
