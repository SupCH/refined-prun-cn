import o from "./xit-registry.js";
import i from "./CMDL.vue.js";
o.add({
  command: "CMDL",
  name: "COMMAND LISTS",
  description: "Provides a customizable list of command links.",
  optionalParameters: "List Identifier or Name",
  component: () => i
});
