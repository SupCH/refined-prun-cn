import a from "./Active.vue.js";
import n from "./TextInput.vue.js";
import { defineComponent as d, computed as c, createElementBlock as u, openBlock as s, createVNode as e, withCtx as t, Fragment as p } from "./runtime-core.esm-bundler.js";
import { unref as f } from "./reactivity.esm-bundler.js";
const x = /* @__PURE__ */ d({
  __name: "Edit",
  props: {
    action: {}
  },
  setup(i) {
    const m = c(() => (i.action.tickers || []).join(", "));
    return (o, l) => (s(), u(p, null, [
      e(a, { label: "Exchange" }, {
        default: t(() => [
          e(n, {
            modelValue: o.action.exchange,
            "onUpdate:modelValue": l[0] || (l[0] = (r) => o.action.exchange = r),
            disabled: ""
          }, null, 8, ["modelValue"])
        ]),
        _: 1
      }),
      e(a, { label: "Tickers" }, {
        default: t(() => [
          e(n, {
            "model-value": f(m),
            disabled: ""
          }, null, 8, ["model-value"])
        ]),
        _: 1
      })
    ], 64));
  }
});
export {
  x as default
};
