import p from "./ConditionItem.vue.js";
import { defineComponent as L, computed as e, createElementBlock as r, openBlock as n, Fragment as m, createCommentVNode as N, renderList as _, createBlock as I } from "./runtime-core.esm-bundler.js";
import { unref as o } from "./reactivity.esm-bundler.js";
import { toDisplayString as d } from "./shared.esm-bundler.js";
const k = { key: 0 }, A = /* @__PURE__ */ L({
  __name: "ConditionList",
  props: {
    conditions: {},
    contract: {}
  },
  setup(i) {
    const u = e(() => i.conditions.slice().sort((t, a) => t.index - a.index).filter((t) => t.type !== "LOAN_INSTALLMENT")), l = e(() => i.conditions.filter((t) => t.type === "LOAN_INSTALLMENT")), c = e(() => l.value.length), f = e(
      () => l.value.filter((t) => t.status === "FULFILLED").length
    );
    return (t, a) => (n(), r(m, null, [
      (n(!0), r(m, null, _(o(u), (s) => (n(), I(p, {
        key: s.id,
        condition: s,
        contract: t.contract
      }, null, 8, ["condition", "contract"]))), 128)),
      o(c) !== 0 ? (n(), r("div", k, d(o(f)) + "/" + d(o(c)) + " Loan Installment", 1)) : N("", !0)
    ], 64));
  }
});
export {
  A as default
};
