import { $ as m } from "./select-dom.js";
import s from "./feature-registry.js";
import { screensStore as c } from "./screens.js";
import { alertsStore as l } from "./alerts.js";
import { refTextContent as f } from "./reactive-dom.js";
import { computed as u, watchEffect as p } from "./runtime-core.esm-bundler.js";
async function v() {
  const e = await m(document, "title"), i = f(e), r = u(() => {
    const o = c.current.value?.name, n = l.all.value?.filter((a) => !a.seen).length ?? 0;
    let t = "Prosperous Universe";
    return o !== void 0 && (t = `${o} - ${t}`), n > 0 && (t = `(${n}) ${t}`), t;
  });
  p(() => {
    i.value !== r.value && (e.textContent = r.value);
  });
}
s.add(import.meta.url, v, "Renames browser tab based on the current screen");
