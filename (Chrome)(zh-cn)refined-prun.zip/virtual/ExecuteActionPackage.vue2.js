import { C as I } from "./prun-css.js";
import Z from "./ActionBar.vue.js";
import r from "./PrunButton.vue.js";
import ee from "./Header.vue.js";
import { ActionRunner as te } from "./action-runner.js";
import { useTile as oe } from "./use-tile.js";
import { Logger as ae } from "./logger.js";
import ne from "./LogWindow.vue.js";
import se from "./ConfigureWindow.vue.js";
import { act as $ } from "./act-registry.js";
import { t as n } from "./index5.js";
import { defineComponent as ie, watch as le, watchEffect as re, computed as E, createElementBlock as k, openBlock as i, createVNode as u, createBlock as C, createElementVNode as F, withCtx as s, createTextVNode as l, Fragment as T, createCommentVNode as h } from "./runtime-core.esm-bundler.js";
import { ref as m, unref as t } from "./reactivity.esm-bundler.js";
import { toDisplayString as a, normalizeClass as g } from "./shared.esm-bundler.js";
const ce = { key: 0 }, ue = { key: 0 }, fe = { key: 1 }, pe = { key: 2 }, Ve = /* @__PURE__ */ ie({
  __name: "ExecuteActionPackage",
  props: {
    pkg: {}
  },
  setup(f) {
    const R = oe();
    let P = m(!1);
    const c = m({
      materialGroups: {},
      actions: {}
    }), V = m([]), A = m(!0), x = m(!1), B = m(!1), v = m(void 0), d = m(!1);
    le(c, b, { deep: !0 }), re(() => {
      for (const e of f.pkg.groups.map((o) => o.name))
        c.value.materialGroups[e] === void 0 && (c.value.materialGroups[e] = {});
      for (const e of f.pkg.actions.map((o) => o.name))
        c.value.actions[e] === void 0 && (c.value.actions[e] = {});
    });
    const U = E(() => {
      for (const e of f.pkg.actions) {
        const o = $.getActionInfo(e.type);
        if (o && o.needsConfigure?.(e))
          return !0;
      }
      for (const e of f.pkg.groups) {
        const o = $.getMaterialGroupInfo(e.type);
        if (o && o.needsConfigure?.(e))
          return !0;
      }
      return !1;
    }), q = E(() => f.pkg.actions.some((e) => e.type === "CX Fetch")), _ = E(() => {
      for (const e of f.pkg.actions) {
        const o = $.getActionInfo(e.type);
        let y = c.value.actions[e.name] ?? {};
        if (!(o?.isValidConfig?.(e, y) ?? !0))
          return !1;
      }
      for (const e of f.pkg.groups) {
        const o = $.getMaterialGroupInfo(e.type);
        let y = c.value.materialGroups[e.name] ?? {};
        if (!(o?.isValidConfig?.(e, y) ?? !0))
          return !1;
      }
      return !0;
    }), S = m(!0), W = E(() => U.value && (!_.value || S.value)), p = new te({
      tile: R,
      log: new ae(O),
      onBufferSplit: () => P.value = !0,
      onStart: () => B.value = !0,
      onEnd: () => {
        B.value = !1, v.value = void 0;
      },
      onStatusChanged: (e, o) => {
        v.value = e, o || (d.value = !1);
      },
      onActReady: () => {
        d.value = !0;
      }
    });
    function L() {
      S.value = !1;
    }
    function G() {
      S.value = !0;
    }
    async function X() {
      A.value = !1, b(), x.value = !0, await p.preview(f.pkg, c.value), x.value = !1, v.value = void 0;
    }
    function z() {
      A.value = !0, b(), d.value = !1, p.execute(f.pkg, c.value, !1);
    }
    function D() {
      A.value = !0, b(), d.value = !1, p.execute(f.pkg, c.value, !0);
    }
    function H() {
      p.stopAuto();
    }
    function j() {
      d.value = !1, p.cancel();
    }
    function J() {
      d.value = !1, p.act();
    }
    function K() {
      d.value = !1, p.skip();
    }
    function O(e, o) {
      return V.value.push({ tag: e, message: o });
    }
    function b() {
      V.value.length = 0;
    }
    function Q() {
      const e = Array.from(document.getElementsByClassName(I.Window.window));
      for (const o of e) {
        let y = !1;
        if (o.getAttribute("data-cx-fetch-session"))
          y = !0;
        else {
          const w = (o.querySelector(`.${I.TileFrame.cmd}`)?.textContent || "").toUpperCase();
          (w.startsWith("XIT ") || w.startsWith("XIT_")) && (y = !0);
        }
        if (y) {
          const N = o.querySelectorAll(`.${I.Window.button}`), w = Array.from(N).find((Y) => Y.textContent === "x");
          w && w.click();
        }
      }
    }
    return (e, o) => t(P) ? (i(), k("div", ce)) : (i(), k("div", {
      key: 1,
      class: g(e.$style.root)
    }, [
      u(ee, {
        class: g(e.$style.header)
      }, {
        default: s(() => [
          l(a(e.pkg.global.name), 1)
        ]),
        _: 1
      }, 8, ["class"]),
      t(W) ? (i(), C(se, {
        key: 0,
        pkg: e.pkg,
        config: t(c),
        class: g(e.$style.mainWindow)
      }, null, 8, ["pkg", "config", "class"])) : (i(), C(ne, {
        key: 1,
        messages: t(V),
        scrolling: t(A),
        class: g(e.$style.mainWindow)
      }, null, 8, ["messages", "scrolling", "class"])),
      F("div", {
        class: g(e.$style.status)
      }, [
        F("span", null, a(t(n)("act.status")) + ": ", 1),
        t(v) ? (i(), k("span", ue, a(t(v)), 1)) : t(W) ? (i(), k("span", fe, a(t(n)("act.configureParams")), 1)) : (i(), k("span", pe, a(t(n)("act.pressExecute")), 1))
      ], 2),
      u(Z, {
        class: g(e.$style.actionBar)
      }, {
        default: s(() => [
          t(W) ? (i(), C(r, {
            key: 0,
            primary: "",
            disabled: !t(_),
            onClick: L
          }, {
            default: s(() => [
              l(a(t(n)("act.apply").toUpperCase()), 1)
            ]),
            _: 1
          }, 8, ["disabled"])) : t(x) ? (i(), k(T, { key: 1 }, [
            t(U) ? (i(), C(r, {
              key: 0,
              primary: "",
              onClick: G
            }, {
              default: s(() => [
                l(a(t(n)("act.configure").toUpperCase()), 1)
              ]),
              _: 1
            })) : h("", !0),
            u(r, { disabled: "" }, {
              default: s(() => [
                l(a(t(n)("act.preview").toUpperCase()), 1)
              ]),
              _: 1
            }),
            u(r, { disabled: "" }, {
              default: s(() => [
                l(a(t(n)("act.execute").toUpperCase()), 1)
              ]),
              _: 1
            })
          ], 64)) : t(B) ? (i(), k(T, { key: 3 }, [
            t(U) ? (i(), C(r, {
              key: 0,
              primary: "",
              disabled: ""
            }, {
              default: s(() => [
                l(a(t(n)("act.configure").toUpperCase()), 1)
              ]),
              _: 1
            })) : h("", !0),
            u(r, {
              primary: "",
              disabled: ""
            }, {
              default: s(() => [
                l(a(t(n)("act.preview").toUpperCase()), 1)
              ]),
              _: 1
            }),
            u(r, {
              danger: "",
              class: g(e.$style.executeButton),
              onClick: j
            }, {
              default: s(() => [
                l(a(t(n)("act.cancel").toUpperCase()), 1)
              ]),
              _: 1
            }, 8, ["class"]),
            t(p).isAutoMode ? (i(), C(r, {
              key: 1,
              primary: "",
              onClick: H
            }, {
              default: s(() => [
                l(a(t(n)("act.stopAuto").toUpperCase()), 1)
              ]),
              _: 1
            })) : h("", !0),
            u(r, {
              primary: "",
              disabled: !t(d) || t(p).isAutoMode,
              onClick: J
            }, {
              default: s(() => [
                l(a(t(n)("act.act").toUpperCase()), 1)
              ]),
              _: 1
            }, 8, ["disabled"]),
            u(r, {
              neutral: "",
              disabled: !t(d) || t(p).isAutoMode,
              onClick: K
            }, {
              default: s(() => [
                l(a(t(n)("act.skip").toUpperCase()), 1)
              ]),
              _: 1
            }, 8, ["disabled"])
          ], 64)) : (i(), k(T, { key: 2 }, [
            t(U) ? (i(), C(r, {
              key: 0,
              primary: "",
              onClick: G
            }, {
              default: s(() => [
                l(a(t(n)("act.configure").toUpperCase()), 1)
              ]),
              _: 1
            })) : h("", !0),
            u(r, {
              primary: "",
              onClick: X
            }, {
              default: s(() => [
                l(a(t(n)("act.preview").toUpperCase()), 1)
              ]),
              _: 1
            }),
            u(r, {
              primary: "",
              onClick: z
            }, {
              default: s(() => [
                l(a(t(n)("act.execute").toUpperCase()), 1)
              ]),
              _: 1
            }),
            u(r, {
              primary: "",
              class: g(e.$style.executeButton),
              onClick: D
            }, {
              default: s(() => [
                l(a(t(n)("act.autoExecute").toUpperCase()), 1)
              ]),
              _: 1
            }, 8, ["class"]),
            t(q) ? (i(), C(r, {
              key: 1,
              class: g(e.$style.executeButton),
              onClick: Q,
              dark: ""
            }, {
              default: s(() => [
                l(a(t(n)("quickPurchase.closeAllWindows").toUpperCase()), 1)
              ]),
              _: 1
            }, 8, ["class"])) : h("", !0)
          ], 64))
        ]),
        _: 1
      }, 8, ["class"])
    ], 2));
  }
});
export {
  Ve as default
};
