import { subscribe as C } from "./subscribe-async-generator.js";
import { $$ as T, $ as d } from "./select-dom.js";
import { C as m } from "./prun-css.js";
import D from "./tiles.js";
import N from "./feature-registry.js";
import { cxobStore as R } from "./cxob.js";
import { changeInputValue as g } from "./util.js";
import { fixed02 as c } from "./format.js";
import { refValue as B } from "./reactive-dom.js";
import { createReactiveDiv as V } from "./reactive-element.js";
import { watchEffectWhileNodeAlive as F } from "./watch.js";
import { isFiniteOrder as X } from "./orders.js";
import { computed as i } from "./runtime-core.esm-bundler.js";
import { ref as O } from "./reactivity.esm-bundler.js";
function M(t) {
  C(T(t.anchor, m.ComExPlaceOrderForm.form), (o) => Q(o, t.parameter));
}
async function Q(t, o) {
  const e = i(() => R.getByTicker(o)), l = await d(t.children[7], "input"), r = B(l), a = i(() => {
    const u = Number(r.value);
    if (!(!Number.isFinite(u) || u <= 0 || !e.value))
      return {
        buy: k(e.value.sellingOrders, u),
        sell: k(e.value.buyingOrders, u)
      };
  }), s = i(() => a.value?.buy.price ?? 0), p = i(() => a.value?.sell.price ?? 0), v = await d(t.children[8], "input"), x = B(v), n = i(() => x.value === ""), L = t.children[12], f = O(!1), h = await d(L, m.Button.success);
  h.addEventListener("mouseover", () => f.value = !0), h.addEventListener("mouseleave", () => f.value = !1), h.addEventListener("click", (u) => {
    n.value && (g(v, c(s.value)), u.stopPropagation(), u.preventDefault());
  });
  const b = O(!1), y = await d(L, m.Button.danger);
  y.addEventListener("mouseover", () => b.value = !0), y.addEventListener("mouseleave", () => b.value = !1), y.addEventListener("click", (u) => {
    n.value && (g(v, c(p.value)), u.stopPropagation(), u.preventDefault());
  });
  const A = i(() => f.value ? c(s.value) : b.value ? c(p.value) : "Auto");
  F(t, () => {
    v.placeholder = A.value;
  });
  const I = e.value?.currency.code ?? "", E = i(() => n.value && !b.value), P = i(() => n.value && !f.value), $ = await d(t.children[9], m.StaticInput.static);
  S(
    $.parentElement,
    I,
    n,
    i(() => E.value ? a.value?.buy.effectivePrice : void 0),
    i(() => P.value ? a.value?.sell.effectivePrice : void 0)
  );
  const w = await d(t.children[10], m.StaticInput.static);
  S(
    w.parentElement,
    I,
    n,
    i(() => E.value ? a.value?.buy.volume : void 0),
    i(() => P.value ? a.value?.sell.volume : void 0)
  ), F(t, () => {
    $.style.display = n.value ? "none" : "", w.style.display = n.value ? "none" : "";
  });
}
function S(t, o, e, l, r) {
  const a = i(() => {
    if (e.value)
      return l.value !== void 0 && r.value !== void 0 ? `${c(l.value)} ${o} / ${c(r.value)} ${o}` : l.value !== void 0 ? `${c(l.value)} ${o}` : r.value !== void 0 ? `${c(r.value)} ${o}` : "--";
  }), s = V(t, a);
  s.classList.add(m.StaticInput.static, m.forms.static), t.prepend(s);
}
function k(t, o) {
  const e = {
    amount: 0,
    priceLimit: 0,
    volume: 0
  };
  for (const r of t) {
    const a = X(r) ? r.amount : Number.POSITIVE_INFINITY, s = o - e.amount, p = Math.min(s, a), v = r.limit.amount;
    if (e.priceLimit = v, e.amount += p, e.volume += p * v, e.amount === o)
      break;
  }
  const l = o - e.amount;
  return e.volume += l * e.priceLimit, {
    price: e.priceLimit,
    effectivePrice: e.volume / o,
    volume: e.volume
  };
}
function W() {
  D.observe("CXPO", M);
}
N.add(import.meta.url, W, "CXPO: Adds automatic price calculation.");
