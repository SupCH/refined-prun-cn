import { t as n } from "./index5.js";
import h from "./LoadingSpinner.vue.js";
import { contractsStore as u } from "./contracts.js";
import E from "./ContractRow.vue.js";
import { canAcceptContract as a } from "./utils4.js";
import { isEmpty as L } from "./is-empty.js";
import { defineComponent as k, computed as y, createBlock as p, createElementBlock as c, openBlock as o, createElementVNode as r, Fragment as _, renderList as C } from "./runtime-core.esm-bundler.js";
import { unref as e } from "./reactivity.esm-bundler.js";
import { toDisplayString as s } from "./shared.esm-bundler.js";
const D = { key: 1 }, S = { key: 0 }, A = { colspan: "4" }, V = /* @__PURE__ */ k({
  __name: "CONTS",
  setup(N) {
    const l = y(
      () => u.all.value.filter(f).sort(d)
    );
    function f(t) {
      switch (t.status) {
        case "OPEN":
        case "CLOSED":
        case "PARTIALLY_FULFILLED":
        case "DEADLINE_EXCEEDED":
          return !0;
        default:
          return !1;
      }
    }
    function d(t, i) {
      return a(t) && !a(i) ? -1 : a(i) && !a(t) ? 1 : (i.date?.timestamp ?? 0) - (t.date?.timestamp ?? 0);
    }
    return (t, i) => e(u).fetched ? (o(), c("table", D, [
      r("thead", null, [
        r("tr", null, [
          r("th", null, s(("t" in t ? t.t : e(n))("conts.contract")), 1),
          r("th", null, s(("t" in t ? t.t : e(n))("conts.item")), 1),
          r("th", null, s(("t" in t ? t.t : e(n))("conts.partner")), 1),
          r("th", null, s(("t" in t ? t.t : e(n))("conts.self")), 1)
        ])
      ]),
      r("tbody", null, [
        e(L)(e(l)) ? (o(), c("tr", S, [
          r("td", A, s(("t" in t ? t.t : e(n))("conts.noActive")), 1)
        ])) : (o(!0), c(_, { key: 1 }, C(e(l), (m) => (o(), p(E, {
          key: m.id,
          contract: m
        }, null, 8, ["contract"]))), 128))
      ])
    ])) : (o(), p(h, { key: 0 }));
  }
});
export {
  V as default
};
