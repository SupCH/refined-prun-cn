import { createEntityStore as a } from "./create-entity-store.js";
import { onApiMessage as d } from "./api-messages.js";
import { createMapGetter as f } from "./create-map-getter.js";
import { computed as l } from "./runtime-core.esm-bundler.js";
const s = a(), r = s.state;
d({
  CONTRACTS_CONTRACTS(t) {
    s.setAll(t.contracts), s.setFetched();
  },
  CONTRACTS_CONTRACT(t) {
    s.setOne(t);
  }
});
const u = f(r.all, (t) => t.localId);
function I(t) {
  if (!t)
    return;
  const e = r.all.value;
  if (e !== void 0) {
    for (const n of e)
      if (n.conditions.find(
        (i) => i.type === "DELIVERY_SHIPMENT" && i.shipmentItemId?.startsWith(t)
      ))
        return n;
  }
}
function E(t) {
  return p(t)?.destination;
}
function p(t) {
  if (!t)
    return;
  const e = r.all.value;
  if (e !== void 0)
    for (const n of e)
      for (const o of n.conditions) {
        if (o.type === "PROVISION_SHIPMENT" && o.blockId?.toLowerCase().startsWith(t.toLowerCase())) {
          const i = n.conditions.find((c) => c.type === "DELIVERY_SHIPMENT");
          if (i)
            return i;
        }
        if (o.type === "DELIVERY_SHIPMENT" && o.shipmentItemId?.toLowerCase().startsWith(t.toLowerCase()))
          return o;
      }
}
const C = l(
  () => r.all.value?.filter(
    (t) => t.status === "CLOSED" || t.status === "PARTIALLY_FULFILLED" || t.status === "DEADLINE_EXCEEDED"
  )
), T = {
  ...r,
  active: C,
  getByLocalId: u,
  getByShipmentId: I,
  getDestinationByShipmentId: E
};
function y(t) {
  return t.partner.countryCode !== void 0;
}
export {
  C as active,
  T as contractsStore,
  y as isFactionContract
};
