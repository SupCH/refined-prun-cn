import { onApiMessage as n } from "./api-messages.js";
import { createEntityStore as s } from "./create-entity-store.js";
import { ref as a } from "./reactivity.esm-bundler.js";
import { computed as u } from "./runtime-core.esm-bundler.js";
const t = s((e) => e.currency), o = t.state, r = a("");
n({
  ACCOUNTING_CASH_BALANCES(e) {
    r.value = e.ownCurrency.code, t.setAll(e.currencyAccounts.map((c) => c.currencyBalance)), t.setFetched();
  },
  ACCOUNTING_BOOKINGS(e) {
    for (const c of e.items)
      c.accountCategory !== "LIQUID_ASSETS" && c.accountType !== 1800 || t.setOne(c.balance);
  }
});
const m = u(() => o.all.value?.map((e) => e.currency)), A = {
  ...o,
  ownCurrency: r,
  currencies: m
};
export {
  A as balancesStore
};
