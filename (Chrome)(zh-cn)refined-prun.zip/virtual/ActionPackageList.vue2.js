import { t as n } from "./index5.js";
import B from "./ActionBar.vue.js";
import p from "./PrunButton.vue.js";
import { showBuffer as h } from "./buffers.js";
import { showTileOverlay as $, showConfirmationOverlay as L } from "./tile-overlay.js";
import V from "./CreateActionPackage.vue.js";
import O from "./ImportActionPackage.vue.js";
import X from "./Quickstart.vue.js";
import { userData as r } from "./user-data.js";
import q from "./PrunLink.vue.js";
import Q from "./remove-array-element.js";
import { objectId as j } from "./object-id.js";
import { vDraggable as H } from "./vue-draggable-plus.js";
import T from "./grip.module.css.js";
import S from "./font-awesome.module.css.js";
import { defineComponent as z, computed as v, createElementBlock as u, openBlock as s, createVNode as d, createElementVNode as a, withCtx as c, createCommentVNode as b, createBlock as F, createTextVNode as f, withDirectives as G, Fragment as _, renderList as J } from "./runtime-core.esm-bundler.js";
import { ref as K, unref as e } from "./reactivity.esm-bundler.js";
import { normalizeClass as k, toDisplayString as o } from "./shared.esm-bundler.js";
const M = { key: 1 }, R = { key: 0 }, U = { colspan: "5" }, kt = /* @__PURE__ */ z({
  __name: "ActionPackageList",
  setup(W) {
    const P = v(() => r.actionPackages), g = v(() => r.actionPackages.length === 0), C = K(!1), I = {
      animation: 150,
      handle: `.${T.grip}`,
      onStart: () => C.value = !0,
      onEnd: () => C.value = !1
    };
    function D(t) {
      $(t, X);
    }
    function N(t) {
      $(t, V, {
        onCreate: (i) => {
          r.actionPackages.push({
            global: { name: i },
            groups: [],
            actions: []
          }), h("XIT ACT_EDIT_" + i.split(" ").join("_"));
        }
      });
    }
    function w(t) {
      $(t, O, {
        onImport: (i) => {
          const l = r.actionPackages.find((m) => m.global.name === i.global.name);
          if (l) {
            const m = r.actionPackages.indexOf(l);
            r.actionPackages[m] = i;
          } else
            r.actionPackages.push(i);
        }
      });
    }
    function A(t, i) {
      L(t, () => Q(r.actionPackages, i), {
        message: n("act.deleteConfirm", i.global.name),
        confirmLabel: n("act.delete")
      });
    }
    function E(t) {
      return t.global.name.split("_").join(" ");
    }
    function y(t) {
      return t.global.name.split(" ").join("_");
    }
    return (t, i) => (s(), u(_, null, [
      d(B, null, {
        default: c(() => [
          e(g) ? (s(), u("div", {
            key: 0,
            class: k(t.$style.quickstartLabel)
          }, o(("t" in t ? t.t : e(n))("act.quickstartHelp")), 3)) : b("", !0),
          e(g) ? (s(), u("div", M, "→")) : b("", !0),
          e(g) ? (s(), F(p, {
            key: 2,
            primary: "",
            onClick: D
          }, {
            default: c(() => [
              f(o(("t" in t ? t.t : e(n))("act.quickstart")), 1)
            ]),
            _: 1
          })) : b("", !0),
          d(p, {
            primary: "",
            onClick: N
          }, {
            default: c(() => [
              f(o(("t" in t ? t.t : e(n))("act.createPackage")), 1)
            ]),
            _: 1
          }),
          d(p, {
            primary: "",
            onClick: w
          }, {
            default: c(() => [
              f(o(("t" in t ? t.t : e(n))("act.import")), 1)
            ]),
            _: 1
          })
        ]),
        _: 1
      }),
      a("table", null, [
        a("thead", null, [
          a("tr", null, [
            a("th", {
              class: k(t.$style.dragHeaderCell)
            }, null, 2),
            a("th", null, o(("t" in t ? t.t : e(n))("act.name")), 1),
            a("th", null, o(("t" in t ? t.t : e(n))("act.execute")), 1),
            a("th", null, o(("t" in t ? t.t : e(n))("act.edit")), 1),
            a("th", null, o(("t" in t ? t.t : e(n))("act.delete")), 1)
          ])
        ]),
        e(r).actionPackages.length === 0 ? (s(), u("tbody", R, [
          a("tr", null, [
            a("td", U, o(("t" in t ? t.t : e(n))("act.noPackages")), 1)
          ])
        ])) : G((s(), u("tbody", {
          key: 1,
          class: k(e(C) ? t.$style.dragging : null)
        }, [
          (s(!0), u(_, null, J(e(P), (l) => (s(), u("tr", {
            key: e(j)(l)
          }, [
            a("td", {
              class: k(t.$style.dragCell)
            }, [
              a("span", {
                class: k([e(T).grip, e(S).solid, t.$style.grip])
              }, o(""), 2)
            ], 2),
            a("td", null, [
              d(q, {
                inline: "",
                command: `XIT ACT_${y(l)}`
              }, {
                default: c(() => [
                  f(o(E(l)), 1)
                ]),
                _: 2
              }, 1032, ["command"])
            ]),
            a("td", null, [
              d(p, {
                primary: "",
                onClick: (m) => e(h)(`XIT ACT_${y(l)}`)
              }, {
                default: c(() => [
                  f(o(("t" in t ? t.t : e(n))("act.execute")), 1)
                ]),
                _: 2
              }, 1032, ["onClick"])
            ]),
            a("td", null, [
              d(p, {
                primary: "",
                onClick: (m) => e(h)(`XIT ACT_EDIT_${y(l)}`)
              }, {
                default: c(() => [
                  f(o(("t" in t ? t.t : e(n))("act.edit")), 1)
                ]),
                _: 2
              }, 1032, ["onClick"])
            ]),
            a("td", null, [
              d(p, {
                dark: "",
                inline: "",
                onClick: (m) => A(m, l)
              }, {
                default: c(() => [
                  f(o(("t" in t ? t.t : e(n))("act.delete")), 1)
                ]),
                _: 2
              }, 1032, ["onClick"])
            ])
          ]))), 128))
        ], 2)), [
          [e(H), [e(P), I]]
        ])
      ])
    ], 64));
  }
});
export {
  kt as default
};
