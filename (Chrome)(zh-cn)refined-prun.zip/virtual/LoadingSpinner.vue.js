import { C as r } from "./prun-css.js";
import e from "./plugin-vue_export-helper.js";
import { createElementBlock as n, openBlock as i } from "./runtime-core.esm-bundler.js";
import { normalizeClass as t } from "./shared.esm-bundler.js";
import { unref as m } from "./reactivity.esm-bundler.js";
const a = {};
function c(o, f) {
  return i(), n("div", {
    class: t(("C" in o ? o.C : m(r)).Loading.loader),
    title: "Loading…"
  }, null, 2);
}
const u = /* @__PURE__ */ e(a, [["render", c]]);
export {
  u as default
};
