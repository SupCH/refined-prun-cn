import { getDefaultExportFromCjs as e } from "./commonjsHelpers.js";
import { __require as r } from "./isoWeek2.js";
var o = r();
const i = /* @__PURE__ */ e(o);
export {
  i as default
};
