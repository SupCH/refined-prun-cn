import f from "./CategoryHeader.vue.js";
export {
  f as default
};
