import o from "./xit-registry.js";
import t from "./HELP.vue.js";
o.add({
  command: "HELP",
  name: "HELP",
  description: "Useful information to get started with (zh-cn)refined-prun.",
  optionalParameters: "ACTION",
  component: () => t
});
