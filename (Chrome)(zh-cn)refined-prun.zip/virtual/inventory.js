import { storagesStore as u } from "./storage.js";
import { sumMapValues as b, getStoreLocationName as P } from "./utils.js";
import { shipyardProjectsStore as V } from "./shipyard-projects.js";
import { shipyardsStore as F } from "./shipyards.js";
import { getEntityNameFromAddress as _, getEntityNaturalIdFromAddress as v } from "./addresses.js";
import { calcMaterialAmountPrice as E, sumMaterialAmountPrice as k } from "./cx.js";
import { cxosStore as U } from "./cxos.js";
import { warehousesStore as p } from "./warehouses.js";
import { sumBy as q } from "./sum-by.js";
import { sum as S } from "./sum.js";
import { sumShipmentDeliveries as x, sumMaterialsPickup as D, sumDeliveries as G, partnerCurrentConditions as C, selfCurrentConditions as H } from "./contract-conditions.js";
import { sitesStore as A } from "./sites.js";
import { getPlanetBurn as w } from "./burn2.js";
import { mergeMaterialAmounts as W } from "./sort-materials.js";
import { workInProgress as j } from "./orders2.js";
import { userData as X } from "./user-data.js";
import { isPresent as z } from "./is-present.js";
import { computed as n } from "./runtime-core.esm-bundler.js";
function L(t) {
  return q(t, (e) => e.value);
}
function J(t) {
  return t?.lines[1]?.type === "PLANET";
}
function B(t) {
  return t?.lines[1]?.type === "STATION";
}
const y = n(() => {
  const t = u.all.value;
  if (!t)
    return;
  const e = /* @__PURE__ */ new Map();
  for (const s of t) {
    const r = [];
    for (const o of s.items) {
      if (!o.quantity)
        continue;
      const a = E(o.quantity);
      if (a === void 0)
        return;
      r.push({
        material: o.quantity.material,
        amount: o.quantity.amount,
        value: a
      });
    }
    e.set(s.id, r);
  }
  return e;
});
function h(t) {
  const e = y.value;
  if (!e || !t)
    return;
  let s = 0;
  for (const r of t) {
    const o = L(e.get(r.id));
    if (o === void 0)
      return;
    s += o;
  }
  return s;
}
const N = n(() => {
  const t = V.all.value;
  if (!t)
    return;
  const e = /* @__PURE__ */ new Map();
  for (const s of t.filter((r) => r.status === "CREATED")) {
    const r = k(s.inventory.items);
    if (r === void 0)
      return;
    const o = F.getById(s.shipyardId);
    if (!o)
      continue;
    const a = _(o.address);
    e.set(a, (e.get(a) ?? 0) + r);
  }
  return e;
}), K = n(() => b(N.value)), Q = n(() => {
  const t = y.value, e = u.all.value, s = N.value;
  if (!t || !e || !s)
    return;
  const r = /* @__PURE__ */ new Map();
  for (const o of e) {
    const a = L(t.get(o.id));
    if (a === void 0)
      return;
    const i = P(o);
    r.set(i, (r.get(i) ?? 0) + a);
  }
  for (const o of s.keys()) {
    const a = s.get(o);
    r.set(o, (r.get(o) ?? 0) + a);
  }
  return r;
}), Y = n(() => {
  const t = U.all.value?.filter(
    (e) => e.type === "SELLING" && e.status !== "FILLED"
  );
  return k(t);
}), T = n(() => u.all.value?.filter(Z));
function Z(t) {
  if (t.type !== "WAREHOUSE_STORE")
    return !1;
  const e = p.getById(t.addressableId);
  return B(e?.address);
}
const $ = n(() => new Set(X.settings.financial.mmMaterials.split(","))), g = n(() => {
  if (!T.value)
    return;
  const t = /* @__PURE__ */ new Map();
  let e = 0;
  for (const s of T.value) {
    const r = y.value?.get(s.id);
    if (!r)
      return;
    let o = 0;
    for (const m of r)
      $.value.has(m.material.ticker) ? o += m.value : e += m.value;
    const a = p.getById(s.addressableId), i = v(a?.address), d = {
      ANT: "AIC",
      BEN: "CIS",
      MOR: "NCC",
      HRT: "ICA",
      HUB: "NCC",
      ARC: "CIS"
    }[i];
    t.set(d, (t.get(d) ?? 0) + o);
  }
  return {
    mmMaterialsTotal: t,
    otherMaterialsTotal: e
  };
}), tt = n(() => b(g.value?.mmMaterialsTotal)), et = n(() => g.value?.otherMaterialsTotal), I = n(() => {
  const t = y.value, e = A.all.value;
  if (!t || !e)
    return;
  let s = 0, r = 0, o = 0, a = 0;
  e.map(w);
  for (const i of e) {
    let c = u.getByAddressableId(i.siteId);
    const d = w(i);
    if (!c || !d)
      return;
    const m = v(i.address), R = p.getByEntityNaturalId(m), M = u.getById(R?.storeId);
    M && (c = c.slice(), c.push(M));
    const O = W(
      c.flatMap((f) => f.items.map((l) => l.quantity).filter(z))
    );
    for (const f of O) {
      const l = E(f);
      if (l === void 0)
        return;
      switch (d.burn[f.material.ticker]?.type) {
        case "input":
          r += l;
          break;
        case "output":
          s += l;
          break;
        case "workforce":
          o += l;
          break;
        default:
          a += l;
          break;
      }
    }
  }
  return {
    finishedGoods: s,
    rawMaterials: r,
    workforceConsumables: o,
    otherItems: a
  };
}), rt = n(() => I.value?.finishedGoods), ot = n(() => I.value?.rawMaterials), st = n(() => I.value?.workforceConsumables), nt = n(() => {
  const t = A.all.value;
  if (!t)
    return;
  const e = /* @__PURE__ */ new Set();
  for (const s of t) {
    const r = v(s.address);
    r !== void 0 && e.add(r);
  }
  return e;
}), at = n(() => {
  const t = nt.value, e = u.all.value;
  if (!(!t || !e))
    return e.filter((s) => it(s, t));
});
function it(t, e) {
  if (t.type !== "WAREHOUSE_STORE")
    return !1;
  const s = p.getById(t.addressableId);
  if (!s)
    return !0;
  const r = s.address;
  if (B(r))
    return !1;
  if (!J(r))
    return !0;
  const o = v(r);
  return o === void 0 || !e.has(o);
}
const ut = n(() => h(at.value)), lt = n(
  () => S(I.value?.otherItems, K.value, ut.value)
), ct = n(() => u.all.value?.filter(dt));
function dt(t) {
  return t.type === "STL_FUEL_STORE" || t.type === "FTL_FUEL_STORE";
}
const mt = n(() => h(ct.value)), ft = n(() => u.all.value?.filter(vt));
function vt(t) {
  return t.type === "SHIP_STORE";
}
const pt = n(() => h(ft.value)), yt = n(
  () => S(pt.value, x(C))
), It = n(
  () => S(G(C), D(H))
), _t = {
  byLocation: Q,
  cxListedMaterials: Y,
  cxInventory: g,
  mmMaterialsTotal: tt,
  cxInventoryTotal: et,
  materialsInTransit: yt,
  finishedGoods: rt,
  workInProgress: j,
  rawMaterials: ot,
  workforceConsumables: st,
  otherItems: lt,
  fuelTanks: mt,
  materialsReceivable: It
};
export {
  _t as inventory
};
