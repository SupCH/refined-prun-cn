import { ddmmyyyy as i, fixed0 as d } from "./format.js";
import { defineComponent as $, computed as f, createElementBlock as t, openBlock as l, createElementVNode as a, createCommentVNode as k, Fragment as y, renderList as m } from "./runtime-core.esm-bundler.js";
import { normalizeClass as n, toDisplayString as c } from "./shared.esm-bundler.js";
import { unref as r } from "./reactivity.esm-bundler.js";
const B = /* @__PURE__ */ $({
  __name: "DateRow",
  props: {
    date: {},
    hideTotals: { type: Boolean },
    totals: {}
  },
  setup(o) {
    const u = f(() => Object.keys(o.totals).sort().map((e) => ({
      currency: e,
      purchases: o.totals[e].purchases,
      sales: o.totals[e].sales,
      total: o.totals[e].sales - o.totals[e].purchases
    })));
    return (e, p) => (l(), t("tr", null, [
      a("td", {
        colspan: "2",
        class: n(e.$style.column)
      }, [
        a("span", null, c(r(i)(e.date)), 1)
      ], 2),
      p[0] || (p[0] = a("td", { style: { display: "none" } }, null, -1)),
      a("td", {
        colspan: "5",
        class: n(e.$style.column)
      }, [
        e.hideTotals ? k("", !0) : (l(), t("div", {
          key: 0,
          class: n(e.$style.totals)
        }, [
          a("div", {
            class: n(e.$style.totalsColumn)
          }, [
            (l(!0), t(y, null, m(r(u), (s) => (l(), t("span", {
              key: s.currency
            }, c(r(d)(s.sales)), 1))), 128))
          ], 2),
          a("div", {
            class: n([e.$style.totalsColumn, e.$style.totalsSeparator])
          }, [
            (l(!0), t(y, null, m(r(u).length, (s) => (l(), t("span", { key: s }, "-"))), 128))
          ], 2),
          a("div", {
            class: n(e.$style.totalsColumn)
          }, [
            (l(!0), t(y, null, m(r(u), (s) => (l(), t("span", {
              key: s.currency
            }, c(r(d)(s.purchases)), 1))), 128))
          ], 2),
          a("div", {
            class: n([e.$style.totalsColumn, e.$style.totalsSeparator])
          }, [
            (l(!0), t(y, null, m(r(u).length, (s) => (l(), t("span", { key: s }, "="))), 128))
          ], 2),
          a("div", {
            class: n(e.$style.totalsColumn)
          }, [
            (l(!0), t(y, null, m(r(u), (s) => (l(), t("span", {
              key: s.currency
            }, c(r(d)(s.total)) + " " + c(s.currency), 1))), 128))
          ], 2)
        ], 2))
      ], 2)
    ]));
  }
});
export {
  B as default
};
