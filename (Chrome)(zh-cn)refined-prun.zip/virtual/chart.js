import { aG as st, d as I, a3 as yt, ac as Ki, ad as Gi, k as z, ae as Me, af as Se, Q as T, F as P, ag as De, a7 as te, ah as qi, Y as be, $ as xe, C as ye, j as vt, h as Ut, ai as Xt, aj as Ji, q as Qi, w as Zi, an as ts, ao as es, ap as is, av as fe, aM as ss, g as it, t as at, b as J, E as G, a0 as V, Z as Tt, a1 as ve, aF as ns, ay as bt, aA as xt, i as F, aw as Kt, aB as Mi, aD as Si, v as O, S as U, ab as jt, aP as os, _ as as, D as Di, p as Gt, ak as gt, T as X, a2 as W, aC as rs, a5 as ls, a6 as Ce, a8 as Ae, M as Ci, r as hs, z as ft, u as Pe, l as cs, f as qt, x as Rt, aq as ds, ar as us, as as fs, aH as gs, o as Ai, P as Y, O as Q, R as ps, U as ms, V as Oe, W as _s, X as dt, aQ as bs, m as xs, n as ys, aE as vs, a9 as ks, aa as ws, G as Ms, I as Pi, s as Jt, aI as Le, aJ as Ss, aK as se, a as It, e as Te, H as et, a4 as Ds, J as Re, L as Oi, at as Cs, au as As, aL as Ee, c as ze, N as Ps, al as ne, A as Os, B as ge, am as Ls, K as Ts, ax as Rs } from "./helpers.dataset.js";
/*!
 * Chart.js v4.5.0
 * https://www.chartjs.org
 * (c) 2025 Chart.js Contributors
 * Released under the MIT License
 */
class Es {
  constructor() {
    this._request = null, this._charts = /* @__PURE__ */ new Map(), this._running = !1, this._lastDate = void 0;
  }
  _notify(t, e, i, s) {
    const n = e.listeners[s], a = e.duration;
    n.forEach((r) => r({
      chart: t,
      initial: e.initial,
      numSteps: a,
      currentStep: Math.min(i - e.start, a)
    }));
  }
  _refresh() {
    this._request || (this._running = !0, this._request = hs.call(window, () => {
      this._update(), this._request = null, this._running && this._refresh();
    }));
  }
  _update(t = Date.now()) {
    let e = 0;
    this._charts.forEach((i, s) => {
      if (!i.running || !i.items.length)
        return;
      const n = i.items;
      let a = n.length - 1, r = !1, l;
      for (; a >= 0; --a)
        l = n[a], l._active ? (l._total > i.duration && (i.duration = l._total), l.tick(t), r = !0) : (n[a] = n[n.length - 1], n.pop());
      r && (s.draw(), this._notify(s, i, t, "progress")), n.length || (i.running = !1, this._notify(s, i, t, "complete"), i.initial = !1), e += n.length;
    }), this._lastDate = t, e === 0 && (this._running = !1);
  }
  _getAnims(t) {
    const e = this._charts;
    let i = e.get(t);
    return i || (i = {
      running: !1,
      initial: !0,
      items: [],
      listeners: {
        complete: [],
        progress: []
      }
    }, e.set(t, i)), i;
  }
  listen(t, e, i) {
    this._getAnims(t).listeners[e].push(i);
  }
  add(t, e) {
    !e || !e.length || this._getAnims(t).items.push(...e);
  }
  has(t) {
    return this._getAnims(t).items.length > 0;
  }
  start(t) {
    const e = this._charts.get(t);
    e && (e.running = !0, e.start = Date.now(), e.duration = e.items.reduce((i, s) => Math.max(i, s._duration), 0), this._refresh());
  }
  running(t) {
    if (!this._running)
      return !1;
    const e = this._charts.get(t);
    return !(!e || !e.running || !e.items.length);
  }
  stop(t) {
    const e = this._charts.get(t);
    if (!e || !e.items.length)
      return;
    const i = e.items;
    let s = i.length - 1;
    for (; s >= 0; --s)
      i[s].cancel();
    e.items = [], this._notify(t, e, Date.now(), "complete");
  }
  remove(t) {
    return this._charts.delete(t);
  }
}
var nt = /* @__PURE__ */ new Es();
const Ie = "transparent", zs = {
  boolean(o, t, e) {
    return e > 0.5 ? t : o;
  },
  color(o, t, e) {
    const i = ze(o || Ie), s = i.valid && ze(t || Ie);
    return s && s.valid ? s.mix(i, e).hexString() : t;
  },
  number(o, t, e) {
    return o + (t - o) * e;
  }
};
class Is {
  constructor(t, e, i, s) {
    const n = e[i];
    s = It([
      t.to,
      s,
      n,
      t.from
    ]);
    const a = It([
      t.from,
      n,
      s
    ]);
    this._active = !0, this._fn = t.fn || zs[t.type || typeof a], this._easing = Te[t.easing] || Te.linear, this._start = Math.floor(Date.now() + (t.delay || 0)), this._duration = this._total = Math.floor(t.duration), this._loop = !!t.loop, this._target = e, this._prop = i, this._from = a, this._to = s, this._promises = void 0;
  }
  active() {
    return this._active;
  }
  update(t, e, i) {
    if (this._active) {
      this._notify(!1);
      const s = this._target[this._prop], n = i - this._start, a = this._duration - n;
      this._start = i, this._duration = Math.floor(Math.max(a, t.duration)), this._total += n, this._loop = !!t.loop, this._to = It([
        t.to,
        e,
        s,
        t.from
      ]), this._from = It([
        t.from,
        s,
        e
      ]);
    }
  }
  cancel() {
    this._active && (this.tick(Date.now()), this._active = !1, this._notify(!1));
  }
  tick(t) {
    const e = t - this._start, i = this._duration, s = this._prop, n = this._from, a = this._loop, r = this._to;
    let l;
    if (this._active = n !== r && (a || e < i), !this._active) {
      this._target[s] = r, this._notify(!0);
      return;
    }
    if (e < 0) {
      this._target[s] = n;
      return;
    }
    l = e / i % 2, l = a && l > 1 ? 2 - l : l, l = this._easing(Math.min(1, Math.max(0, l))), this._target[s] = this._fn(n, r, l);
  }
  wait() {
    const t = this._promises || (this._promises = []);
    return new Promise((e, i) => {
      t.push({
        res: e,
        rej: i
      });
    });
  }
  _notify(t) {
    const e = t ? "res" : "rej", i = this._promises || [];
    for (let s = 0; s < i.length; s++)
      i[s][e]();
  }
}
class Li {
  constructor(t, e) {
    this._chart = t, this._properties = /* @__PURE__ */ new Map(), this.configure(e);
  }
  configure(t) {
    if (!F(t))
      return;
    const e = Object.keys(I.animation), i = this._properties;
    Object.getOwnPropertyNames(t).forEach((s) => {
      const n = t[s];
      if (!F(n))
        return;
      const a = {};
      for (const r of e)
        a[r] = n[r];
      (J(n.properties) && n.properties || [
        s
      ]).forEach((r) => {
        (r === s || !i.has(r)) && i.set(r, a);
      });
    });
  }
  _animateOptions(t, e) {
    const i = e.options, s = Bs(t, i);
    if (!s)
      return [];
    const n = this._createAnimations(s, i);
    return i.$shared && Fs(t.options.$animations, i).then(() => {
      t.options = i;
    }, () => {
    }), n;
  }
  _createAnimations(t, e) {
    const i = this._properties, s = [], n = t.$animations || (t.$animations = {}), a = Object.keys(e), r = Date.now();
    let l;
    for (l = a.length - 1; l >= 0; --l) {
      const h = a[l];
      if (h.charAt(0) === "$")
        continue;
      if (h === "options") {
        s.push(...this._animateOptions(t, e));
        continue;
      }
      const c = e[h];
      let d = n[h];
      const u = i.get(h);
      if (d)
        if (u && d.active()) {
          d.update(u, c, r);
          continue;
        } else
          d.cancel();
      if (!u || !u.duration) {
        t[h] = c;
        continue;
      }
      n[h] = d = new Is(u, t, h, c), s.push(d);
    }
    return s;
  }
  update(t, e) {
    if (this._properties.size === 0) {
      Object.assign(t, e);
      return;
    }
    const i = this._createAnimations(t, e);
    if (i.length)
      return nt.add(this._chart, i), !0;
  }
}
function Fs(o, t) {
  const e = [], i = Object.keys(t);
  for (let s = 0; s < i.length; s++) {
    const n = o[i[s]];
    n && n.active() && e.push(n.wait());
  }
  return Promise.all(e);
}
function Bs(o, t) {
  if (!t)
    return;
  let e = o.options;
  if (!e) {
    o.options = t;
    return;
  }
  return e.$shared && (o.options = e = Object.assign({}, e, {
    $shared: !1,
    $animations: {}
  })), e;
}
function Fe(o, t) {
  const e = o && o.options || {}, i = e.reverse, s = e.min === void 0 ? t : 0, n = e.max === void 0 ? t : 0;
  return {
    start: i ? n : s,
    end: i ? s : n
  };
}
function Hs(o, t, e) {
  if (e === !1)
    return !1;
  const i = Fe(o, e), s = Fe(t, e);
  return {
    top: s.end,
    right: i.end,
    bottom: s.start,
    left: i.start
  };
}
function Ws(o) {
  let t, e, i, s;
  return F(o) ? (t = o.top, e = o.right, i = o.bottom, s = o.left) : t = e = i = s = o, {
    top: t,
    right: e,
    bottom: i,
    left: s,
    disabled: o === !1
  };
}
function Ti(o, t) {
  const e = [], i = o._getSortedDatasetMetas(t);
  let s, n;
  for (s = 0, n = i.length; s < n; ++s)
    e.push(i[s].index);
  return e;
}
function Be(o, t, e, i = {}) {
  const s = o.keys, n = i.mode === "single";
  let a, r, l, h;
  if (t === null)
    return;
  let c = !1;
  for (a = 0, r = s.length; a < r; ++a) {
    if (l = +s[a], l === e) {
      if (c = !0, i.all)
        continue;
      break;
    }
    h = o.values[l], it(h) && (n || t === 0 || Jt(t) === Jt(h)) && (t += h);
  }
  return !c && !i.all ? 0 : t;
}
function Vs(o, t) {
  const { iScale: e, vScale: i } = t, s = e.axis === "x" ? "x" : "y", n = i.axis === "x" ? "x" : "y", a = Object.keys(o), r = new Array(a.length);
  let l, h, c;
  for (l = 0, h = a.length; l < h; ++l)
    c = a[l], r[l] = {
      [s]: c,
      [n]: o[c]
    };
  return r;
}
function oe(o, t) {
  const e = o && o.options.stacked;
  return e || e === void 0 && t.stack !== void 0;
}
function Ns(o, t, e) {
  return `${o.id}.${t.id}.${e.stack || e.type}`;
}
function js(o) {
  const { min: t, max: e, minDefined: i, maxDefined: s } = o.getUserBounds();
  return {
    min: i ? t : Number.NEGATIVE_INFINITY,
    max: s ? e : Number.POSITIVE_INFINITY
  };
}
function $s(o, t, e) {
  const i = o[t] || (o[t] = {});
  return i[e] || (i[e] = {});
}
function He(o, t, e, i) {
  for (const s of t.getMatchingVisibleMetas(i).reverse()) {
    const n = o[s.index];
    if (e && n > 0 || !e && n < 0)
      return s.index;
  }
  return null;
}
function We(o, t) {
  const { chart: e, _cachedMeta: i } = o, s = e._stacks || (e._stacks = {}), { iScale: n, vScale: a, index: r } = i, l = n.axis, h = a.axis, c = Ns(n, a, i), d = t.length;
  let u;
  for (let f = 0; f < d; ++f) {
    const g = t[f], { [l]: p, [h]: _ } = g, m = g._stacks || (g._stacks = {});
    u = m[h] = $s(s, c, p), u[r] = _, u._top = He(u, a, !0, i.type), u._bottom = He(u, a, !1, i.type);
    const x = u._visualValues || (u._visualValues = {});
    x[r] = _;
  }
}
function ae(o, t) {
  const e = o.scales;
  return Object.keys(e).filter((i) => e[i].axis === t).shift();
}
function Ys(o, t) {
  return vt(o, {
    active: !1,
    dataset: void 0,
    datasetIndex: t,
    index: t,
    mode: "default",
    type: "dataset"
  });
}
function Us(o, t, e) {
  return vt(o, {
    active: !1,
    dataIndex: t,
    parsed: void 0,
    raw: void 0,
    element: e,
    index: t,
    mode: "default",
    type: "data"
  });
}
function St(o, t) {
  const e = o.controller.index, i = o.vScale && o.vScale.axis;
  if (i) {
    t = t || o._parsed;
    for (const s of t) {
      const n = s._stacks;
      if (!n || n[i] === void 0 || n[i][e] === void 0)
        return;
      delete n[i][e], n[i]._visualValues !== void 0 && n[i]._visualValues[e] !== void 0 && delete n[i]._visualValues[e];
    }
  }
}
const re = (o) => o === "reset" || o === "none", Ve = (o, t) => t ? o : Object.assign({}, o), Xs = (o, t, e) => o && !t.hidden && t._stacked && {
  keys: Ti(e, !0),
  values: null
};
class ke {
  static defaults = {};
  static datasetElementType = null;
  static dataElementType = null;
  constructor(t, e) {
    this.chart = t, this._ctx = t.ctx, this.index = e, this._cachedDataOpts = {}, this._cachedMeta = this.getMeta(), this._type = this._cachedMeta.type, this.options = void 0, this._parsing = !1, this._data = void 0, this._objectData = void 0, this._sharedOptions = void 0, this._drawStart = void 0, this._drawCount = void 0, this.enableOptionSharing = !1, this.supportsDecimation = !1, this.$context = void 0, this._syncList = [], this.datasetElementType = new.target.datasetElementType, this.dataElementType = new.target.dataElementType, this.initialize();
  }
  initialize() {
    const t = this._cachedMeta;
    this.configure(), this.linkScales(), t._stacked = oe(t.vScale, t), this.addElements(), this.options.fill && !this.chart.isPluginEnabled("filler") && console.warn("Tried to use the 'fill' option without the 'Filler' plugin enabled. Please import and register the 'Filler' plugin and make sure it is not disabled in the options");
  }
  updateIndex(t) {
    this.index !== t && St(this._cachedMeta), this.index = t;
  }
  linkScales() {
    const t = this.chart, e = this._cachedMeta, i = this.getDataset(), s = (d, u, f, g) => d === "x" ? u : d === "r" ? g : f, n = e.xAxisID = O(i.xAxisID, ae(t, "x")), a = e.yAxisID = O(i.yAxisID, ae(t, "y")), r = e.rAxisID = O(i.rAxisID, ae(t, "r")), l = e.indexAxis, h = e.iAxisID = s(l, n, a, r), c = e.vAxisID = s(l, a, n, r);
    e.xScale = this.getScaleForId(n), e.yScale = this.getScaleForId(a), e.rScale = this.getScaleForId(r), e.iScale = this.getScaleForId(h), e.vScale = this.getScaleForId(c);
  }
  getDataset() {
    return this.chart.data.datasets[this.index];
  }
  getMeta() {
    return this.chart.getDatasetMeta(this.index);
  }
  getScaleForId(t) {
    return this.chart.scales[t];
  }
  _getOtherScale(t) {
    const e = this._cachedMeta;
    return t === e.iScale ? e.vScale : e.iScale;
  }
  reset() {
    this._update("reset");
  }
  _destroy() {
    const t = this._cachedMeta;
    this._data && Pe(this._data, this), t._stacked && St(t);
  }
  _dataCheck() {
    const t = this.getDataset(), e = t.data || (t.data = []), i = this._data;
    if (F(e)) {
      const s = this._cachedMeta;
      this._data = Vs(e, s);
    } else if (i !== e) {
      if (i) {
        Pe(i, this);
        const s = this._cachedMeta;
        St(s), s._parsed = [];
      }
      e && Object.isExtensible(e) && cs(e, this), this._syncList = [], this._data = e;
    }
  }
  addElements() {
    const t = this._cachedMeta;
    this._dataCheck(), this.datasetElementType && (t.dataset = new this.datasetElementType());
  }
  buildOrUpdateElements(t) {
    const e = this._cachedMeta, i = this.getDataset();
    let s = !1;
    this._dataCheck();
    const n = e._stacked;
    e._stacked = oe(e.vScale, e), e.stack !== i.stack && (s = !0, St(e), e.stack = i.stack), this._resyncElements(t), (s || n !== e._stacked) && (We(this, e._parsed), e._stacked = oe(e.vScale, e));
  }
  configure() {
    const t = this.chart.config, e = t.datasetScopeKeys(this._type), i = t.getOptionScopes(this.getDataset(), e, !0);
    this.options = t.createResolver(i, this.getContext()), this._parsing = this.options.parsing, this._cachedDataOpts = {};
  }
  parse(t, e) {
    const { _cachedMeta: i, _data: s } = this, { iScale: n, _stacked: a } = i, r = n.axis;
    let l = t === 0 && e === s.length ? !0 : i._sorted, h = t > 0 && i._parsed[t - 1], c, d, u;
    if (this._parsing === !1)
      i._parsed = s, i._sorted = !0, u = s;
    else {
      J(s[t]) ? u = this.parseArrayData(i, s, t, e) : F(s[t]) ? u = this.parseObjectData(i, s, t, e) : u = this.parsePrimitiveData(i, s, t, e);
      const f = () => d[r] === null || h && d[r] < h[r];
      for (c = 0; c < e; ++c)
        i._parsed[c + t] = d = u[c], l && (f() && (l = !1), h = d);
      i._sorted = l;
    }
    a && We(this, u);
  }
  parsePrimitiveData(t, e, i, s) {
    const { iScale: n, vScale: a } = t, r = n.axis, l = a.axis, h = n.getLabels(), c = n === a, d = new Array(s);
    let u, f, g;
    for (u = 0, f = s; u < f; ++u)
      g = u + i, d[u] = {
        [r]: c || n.parse(h[g], g),
        [l]: a.parse(e[g], g)
      };
    return d;
  }
  parseArrayData(t, e, i, s) {
    const { xScale: n, yScale: a } = t, r = new Array(s);
    let l, h, c, d;
    for (l = 0, h = s; l < h; ++l)
      c = l + i, d = e[c], r[l] = {
        x: n.parse(d[0], c),
        y: a.parse(d[1], c)
      };
    return r;
  }
  parseObjectData(t, e, i, s) {
    const { xScale: n, yScale: a } = t, { xAxisKey: r = "x", yAxisKey: l = "y" } = this._parsing, h = new Array(s);
    let c, d, u, f;
    for (c = 0, d = s; c < d; ++c)
      u = c + i, f = e[u], h[c] = {
        x: n.parse(qt(f, r), u),
        y: a.parse(qt(f, l), u)
      };
    return h;
  }
  getParsed(t) {
    return this._cachedMeta._parsed[t];
  }
  getDataElement(t) {
    return this._cachedMeta.data[t];
  }
  applyStack(t, e, i) {
    const s = this.chart, n = this._cachedMeta, a = e[t.axis], r = {
      keys: Ti(s, !0),
      values: e._stacks[t.axis]._visualValues
    };
    return Be(r, a, n.index, {
      mode: i
    });
  }
  updateRangeFromParsed(t, e, i, s) {
    const n = i[e.axis];
    let a = n === null ? NaN : n;
    const r = s && i._stacks[e.axis];
    s && r && (s.values = r, a = Be(s, n, this._cachedMeta.index)), t.min = Math.min(t.min, a), t.max = Math.max(t.max, a);
  }
  getMinMax(t, e) {
    const i = this._cachedMeta, s = i._parsed, n = i._sorted && t === i.iScale, a = s.length, r = this._getOtherScale(t), l = Xs(e, i, this.chart), h = {
      min: Number.POSITIVE_INFINITY,
      max: Number.NEGATIVE_INFINITY
    }, { min: c, max: d } = js(r);
    let u, f;
    function g() {
      f = s[u];
      const p = f[r.axis];
      return !it(f[t.axis]) || c > p || d < p;
    }
    for (u = 0; u < a && !(!g() && (this.updateRangeFromParsed(h, t, f, l), n)); ++u)
      ;
    if (n) {
      for (u = a - 1; u >= 0; --u)
        if (!g()) {
          this.updateRangeFromParsed(h, t, f, l);
          break;
        }
    }
    return h;
  }
  getAllParsedValues(t) {
    const e = this._cachedMeta._parsed, i = [];
    let s, n, a;
    for (s = 0, n = e.length; s < n; ++s)
      a = e[s][t.axis], it(a) && i.push(a);
    return i;
  }
  getMaxOverflow() {
    return !1;
  }
  getLabelAndValue(t) {
    const e = this._cachedMeta, i = e.iScale, s = e.vScale, n = this.getParsed(t);
    return {
      label: i ? "" + i.getLabelForValue(n[i.axis]) : "",
      value: s ? "" + s.getLabelForValue(n[s.axis]) : ""
    };
  }
  _update(t) {
    const e = this._cachedMeta;
    this.update(t || "default"), e._clip = Ws(O(this.options.clip, Hs(e.xScale, e.yScale, this.getMaxOverflow())));
  }
  update(t) {
  }
  draw() {
    const t = this._ctx, e = this.chart, i = this._cachedMeta, s = i.data || [], n = e.chartArea, a = [], r = this._drawStart || 0, l = this._drawCount || s.length - r, h = this.options.drawActiveElementsOnTop;
    let c;
    for (i.dataset && i.dataset.draw(t, n, r, l), c = r; c < r + l; ++c) {
      const d = s[c];
      d.hidden || (d.active && h ? a.push(d) : d.draw(t, n));
    }
    for (c = 0; c < a.length; ++c)
      a[c].draw(t, n);
  }
  getStyle(t, e) {
    const i = e ? "active" : "default";
    return t === void 0 && this._cachedMeta.dataset ? this.resolveDatasetElementOptions(i) : this.resolveDataElementOptions(t || 0, i);
  }
  getContext(t, e, i) {
    const s = this.getDataset();
    let n;
    if (t >= 0 && t < this._cachedMeta.data.length) {
      const a = this._cachedMeta.data[t];
      n = a.$context || (a.$context = Us(this.getContext(), t, a)), n.parsed = this.getParsed(t), n.raw = s.data[t], n.index = n.dataIndex = t;
    } else
      n = this.$context || (this.$context = Ys(this.chart.getContext(), this.index)), n.dataset = s, n.index = n.datasetIndex = this.index;
    return n.active = !!e, n.mode = i, n;
  }
  resolveDatasetElementOptions(t) {
    return this._resolveElementOptions(this.datasetElementType.id, t);
  }
  resolveDataElementOptions(t, e) {
    return this._resolveElementOptions(this.dataElementType.id, e, t);
  }
  _resolveElementOptions(t, e = "default", i) {
    const s = e === "active", n = this._cachedDataOpts, a = t + "-" + e, r = n[a], l = this.enableOptionSharing && Ut(i);
    if (r)
      return Ve(r, l);
    const h = this.chart.config, c = h.datasetElementScopeKeys(this._type, t), d = s ? [
      `${t}Hover`,
      "hover",
      t,
      ""
    ] : [
      t,
      ""
    ], u = h.getOptionScopes(this.getDataset(), c), f = Object.keys(I.elements[t]), g = () => this.getContext(i, s, e), p = h.resolveNamedOptions(u, f, g, d);
    return p.$shared && (p.$shared = l, n[a] = Object.freeze(Ve(p, l))), p;
  }
  _resolveAnimations(t, e, i) {
    const s = this.chart, n = this._cachedDataOpts, a = `animation-${e}`, r = n[a];
    if (r)
      return r;
    let l;
    if (s.options.animation !== !1) {
      const c = this.chart.config, d = c.datasetAnimationScopeKeys(this._type, e), u = c.getOptionScopes(this.getDataset(), d);
      l = c.createResolver(u, this.getContext(t, i, e));
    }
    const h = new Li(s, l && l.animations);
    return l && l._cacheable && (n[a] = Object.freeze(h)), h;
  }
  getSharedOptions(t) {
    if (t.$shared)
      return this._sharedOptions || (this._sharedOptions = Object.assign({}, t));
  }
  includeOptions(t, e) {
    return !e || re(t) || this.chart._animationsDisabled;
  }
  _getSharedOptions(t, e) {
    const i = this.resolveDataElementOptions(t, e), s = this._sharedOptions, n = this.getSharedOptions(i), a = this.includeOptions(e, n) || n !== s;
    return this.updateSharedOptions(n, e, i), {
      sharedOptions: n,
      includeOptions: a
    };
  }
  updateElement(t, e, i, s) {
    re(s) ? Object.assign(t, i) : this._resolveAnimations(e, s).update(t, i);
  }
  updateSharedOptions(t, e, i) {
    t && !re(e) && this._resolveAnimations(void 0, e).update(t, i);
  }
  _setStyle(t, e, i, s) {
    t.active = s;
    const n = this.getStyle(e, s);
    this._resolveAnimations(e, i, s).update(t, {
      options: !s && this.getSharedOptions(n) || n
    });
  }
  removeHoverStyle(t, e, i) {
    this._setStyle(t, i, "active", !1);
  }
  setHoverStyle(t, e, i) {
    this._setStyle(t, i, "active", !0);
  }
  _removeDatasetHoverStyle() {
    const t = this._cachedMeta.dataset;
    t && this._setStyle(t, void 0, "active", !1);
  }
  _setDatasetHoverStyle() {
    const t = this._cachedMeta.dataset;
    t && this._setStyle(t, void 0, "active", !0);
  }
  _resyncElements(t) {
    const e = this._data, i = this._cachedMeta.data;
    for (const [r, l, h] of this._syncList)
      this[r](l, h);
    this._syncList = [];
    const s = i.length, n = e.length, a = Math.min(n, s);
    a && this.parse(0, a), n > s ? this._insertElements(s, n - s, t) : n < s && this._removeElements(n, s - n);
  }
  _insertElements(t, e, i = !0) {
    const s = this._cachedMeta, n = s.data, a = t + e;
    let r;
    const l = (h) => {
      for (h.length += e, r = h.length - 1; r >= a; r--)
        h[r] = h[r - e];
    };
    for (l(n), r = t; r < a; ++r)
      n[r] = new this.dataElementType();
    this._parsing && l(s._parsed), this.parse(t, e), i && this.updateElements(n, t, e, "reset");
  }
  updateElements(t, e, i, s) {
  }
  _removeElements(t, e) {
    const i = this._cachedMeta;
    if (this._parsing) {
      const s = i._parsed.splice(t, e);
      i._stacked && St(i, s);
    }
    i.data.splice(t, e);
  }
  _sync(t) {
    if (this._parsing)
      this._syncList.push(t);
    else {
      const [e, i, s] = t;
      this[e](i, s);
    }
    this.chart._dataChanges.push([
      this.index,
      ...t
    ]);
  }
  _onDataPush() {
    const t = arguments.length;
    this._sync([
      "_insertElements",
      this.getDataset().data.length - t,
      t
    ]);
  }
  _onDataPop() {
    this._sync([
      "_removeElements",
      this._cachedMeta.data.length - 1,
      1
    ]);
  }
  _onDataShift() {
    this._sync([
      "_removeElements",
      0,
      1
    ]);
  }
  _onDataSplice(t, e) {
    e && this._sync([
      "_removeElements",
      t,
      e
    ]);
    const i = arguments.length - 2;
    i && this._sync([
      "_insertElements",
      t,
      i
    ]);
  }
  _onDataUnshift() {
    this._sync([
      "_insertElements",
      0,
      arguments.length
    ]);
  }
}
function Ks(o, t, e) {
  let i = 1, s = 1, n = 0, a = 0;
  if (t < X) {
    const r = o, l = r + t, h = Math.cos(r), c = Math.sin(r), d = Math.cos(l), u = Math.sin(l), f = (v, y, b) => Gt(v, r, l, !0) ? 1 : Math.max(y, y * e, b, b * e), g = (v, y, b) => Gt(v, r, l, !0) ? -1 : Math.min(y, y * e, b, b * e), p = f(0, h, d), _ = f(et, c, u), m = g(Y, h, d), x = g(Y + et, c, u);
    i = (p - m) / 2, s = (_ - x) / 2, n = -(p + m) / 2, a = -(_ + x) / 2;
  }
  return {
    ratioX: i,
    ratioY: s,
    offsetX: n,
    offsetY: a
  };
}
class Gs extends ke {
  static id = "doughnut";
  static defaults = {
    datasetElementType: !1,
    dataElementType: "arc",
    animation: {
      animateRotate: !0,
      animateScale: !1
    },
    animations: {
      numbers: {
        type: "number",
        properties: [
          "circumference",
          "endAngle",
          "innerRadius",
          "outerRadius",
          "startAngle",
          "x",
          "y",
          "offset",
          "borderWidth",
          "spacing"
        ]
      }
    },
    cutout: "50%",
    rotation: 0,
    circumference: 360,
    radius: "100%",
    spacing: 0,
    indexAxis: "r"
  };
  static descriptors = {
    _scriptable: (t) => t !== "spacing",
    _indexable: (t) => t !== "spacing" && !t.startsWith("borderDash") && !t.startsWith("hoverBorderDash")
  };
  static overrides = {
    aspectRatio: 1,
    plugins: {
      legend: {
        labels: {
          generateLabels(t) {
            const e = t.data;
            if (e.labels.length && e.datasets.length) {
              const { labels: { pointStyle: i, color: s } } = t.legend.options;
              return e.labels.map((n, a) => {
                const l = t.getDatasetMeta(0).controller.getStyle(a);
                return {
                  text: n,
                  fillStyle: l.backgroundColor,
                  strokeStyle: l.borderColor,
                  fontColor: s,
                  lineWidth: l.borderWidth,
                  pointStyle: i,
                  hidden: !t.getDataVisibility(a),
                  index: a
                };
              });
            }
            return [];
          }
        },
        onClick(t, e, i) {
          i.chart.toggleDataVisibility(e.index), i.chart.update();
        }
      }
    }
  };
  constructor(t, e) {
    super(t, e), this.enableOptionSharing = !0, this.innerRadius = void 0, this.outerRadius = void 0, this.offsetX = void 0, this.offsetY = void 0;
  }
  linkScales() {
  }
  parse(t, e) {
    const i = this.getDataset().data, s = this._cachedMeta;
    if (this._parsing === !1)
      s._parsed = i;
    else {
      let n = (l) => +i[l];
      if (F(i[t])) {
        const { key: l = "value" } = this._parsing;
        n = (h) => +qt(i[h], l);
      }
      let a, r;
      for (a = t, r = t + e; a < r; ++a)
        s._parsed[a] = n(a);
    }
  }
  _getRotation() {
    return at(this.options.rotation - 90);
  }
  _getCircumference() {
    return at(this.options.circumference);
  }
  _getRotationExtents() {
    let t = X, e = -X;
    for (let i = 0; i < this.chart.data.datasets.length; ++i)
      if (this.chart.isDatasetVisible(i) && this.chart.getDatasetMeta(i).type === this._type) {
        const s = this.chart.getDatasetMeta(i).controller, n = s._getRotation(), a = s._getCircumference();
        t = Math.min(t, n), e = Math.max(e, n + a);
      }
    return {
      rotation: t,
      circumference: e - t
    };
  }
  update(t) {
    const e = this.chart, { chartArea: i } = e, s = this._cachedMeta, n = s.data, a = this.getMaxBorderWidth() + this.getMaxOffset(n) + this.options.spacing, r = Math.max((Math.min(i.width, i.height) - a) / 2, 0), l = Math.min(xs(this.options.cutout, r), 1), h = this._getRingWeight(this.index), { circumference: c, rotation: d } = this._getRotationExtents(), { ratioX: u, ratioY: f, offsetX: g, offsetY: p } = Ks(d, c, l), _ = (i.width - a) / u, m = (i.height - a) / f, x = Math.max(Math.min(_, m) / 2, 0), v = ys(this.options.radius, x), y = Math.max(v * l, 0), b = (v - y) / this._getVisibleDatasetWeightTotal();
    this.offsetX = g * v, this.offsetY = p * v, s.total = this.calculateTotal(), this.outerRadius = v - b * this._getRingWeightOffset(this.index), this.innerRadius = Math.max(this.outerRadius - b * h, 0), this.updateElements(n, 0, n.length, t);
  }
  _circumference(t, e) {
    const i = this.options, s = this._cachedMeta, n = this._getCircumference();
    return e && i.animation.animateRotate || !this.chart.getDataVisibility(t) || s._parsed[t] === null || s.data[t].hidden ? 0 : this.calculateCircumference(s._parsed[t] * n / X);
  }
  updateElements(t, e, i, s) {
    const n = s === "reset", a = this.chart, r = a.chartArea, h = a.options.animation, c = (r.left + r.right) / 2, d = (r.top + r.bottom) / 2, u = n && h.animateScale, f = u ? 0 : this.innerRadius, g = u ? 0 : this.outerRadius, { sharedOptions: p, includeOptions: _ } = this._getSharedOptions(e, s);
    let m = this._getRotation(), x;
    for (x = 0; x < e; ++x)
      m += this._circumference(x, n);
    for (x = e; x < e + i; ++x) {
      const v = this._circumference(x, n), y = t[x], b = {
        x: c + this.offsetX,
        y: d + this.offsetY,
        startAngle: m,
        endAngle: m + v,
        circumference: v,
        outerRadius: g,
        innerRadius: f
      };
      _ && (b.options = p || this.resolveDataElementOptions(x, y.active ? "active" : s)), m += v, this.updateElement(y, x, b, s);
    }
  }
  calculateTotal() {
    const t = this._cachedMeta, e = t.data;
    let i = 0, s;
    for (s = 0; s < e.length; s++) {
      const n = t._parsed[s];
      n !== null && !isNaN(n) && this.chart.getDataVisibility(s) && !e[s].hidden && (i += Math.abs(n));
    }
    return i;
  }
  calculateCircumference(t) {
    const e = this._cachedMeta.total;
    return e > 0 && !isNaN(t) ? X * (Math.abs(t) / e) : 0;
  }
  getLabelAndValue(t) {
    const e = this._cachedMeta, i = this.chart, s = i.data.labels || [], n = Ai(e._parsed[t], i.options.locale);
    return {
      label: s[t] || "",
      value: n
    };
  }
  getMaxBorderWidth(t) {
    let e = 0;
    const i = this.chart;
    let s, n, a, r, l;
    if (!t) {
      for (s = 0, n = i.data.datasets.length; s < n; ++s)
        if (i.isDatasetVisible(s)) {
          a = i.getDatasetMeta(s), t = a.data, r = a.controller;
          break;
        }
    }
    if (!t)
      return 0;
    for (s = 0, n = t.length; s < n; ++s)
      l = r.resolveDataElementOptions(s), l.borderAlign !== "inner" && (e = Math.max(e, l.borderWidth || 0, l.hoverBorderWidth || 0));
    return e;
  }
  getMaxOffset(t) {
    let e = 0;
    for (let i = 0, s = t.length; i < s; ++i) {
      const n = this.resolveDataElementOptions(i);
      e = Math.max(e, n.offset || 0, n.hoverOffset || 0);
    }
    return e;
  }
  _getRingWeightOffset(t) {
    let e = 0;
    for (let i = 0; i < t; ++i)
      this.chart.isDatasetVisible(i) && (e += this._getRingWeight(i));
    return e;
  }
  _getRingWeight(t) {
    return Math.max(O(this.chart.data.datasets[t].weight, 1), 0);
  }
  _getVisibleDatasetWeightTotal() {
    return this._getRingWeightOffset(this.chart.data.datasets.length) || 1;
  }
}
class qo extends ke {
  static id = "line";
  static defaults = {
    datasetElementType: "line",
    dataElementType: "point",
    showLine: !0,
    spanGaps: !1
  };
  static overrides = {
    scales: {
      _index_: {
        type: "category"
      },
      _value_: {
        type: "linear"
      }
    }
  };
  initialize() {
    this.enableOptionSharing = !0, this.supportsDecimation = !0, super.initialize();
  }
  update(t) {
    const e = this._cachedMeta, { dataset: i, data: s = [], _dataset: n } = e, a = this.chart._animationsDisabled;
    let { start: r, count: l } = Qi(e, s, a);
    this._drawStart = r, this._drawCount = l, Zi(e) && (r = 0, l = s.length), i._chart = this.chart, i._datasetIndex = this.index, i._decimated = !!n._decimated, i.points = s;
    const h = this.resolveDatasetElementOptions(t);
    this.options.showLine || (h.borderWidth = 0), h.segment = this.options.segment, this.updateElement(i, void 0, {
      animated: !a,
      options: h
    }, t), this.updateElements(s, r, l, t);
  }
  updateElements(t, e, i, s) {
    const n = s === "reset", { iScale: a, vScale: r, _stacked: l, _dataset: h } = this._cachedMeta, { sharedOptions: c, includeOptions: d } = this._getSharedOptions(e, s), u = a.axis, f = r.axis, { spanGaps: g, segment: p } = this.options, _ = Rt(g) ? g : Number.POSITIVE_INFINITY, m = this.chart._animationsDisabled || n || s === "none", x = e + i, v = t.length;
    let y = e > 0 && this.getParsed(e - 1);
    for (let b = 0; b < v; ++b) {
      const k = t[b], w = m ? k : {};
      if (b < e || b >= x) {
        w.skip = !0;
        continue;
      }
      const M = this.getParsed(b), S = z(M[f]), C = w[u] = a.getPixelForValue(M[u], b), D = w[f] = n || S ? r.getBasePixel() : r.getPixelForValue(l ? this.applyStack(r, M, l) : M[f], b);
      w.skip = isNaN(C) || isNaN(D) || S, w.stop = b > 0 && Math.abs(M[u] - y[u]) > _, p && (w.parsed = M, w.raw = h.data[b]), d && (w.options = c || this.resolveDataElementOptions(b, k.active ? "active" : s)), m || this.updateElement(k, b, w, s), y = M;
    }
  }
  getMaxOverflow() {
    const t = this._cachedMeta, e = t.dataset, i = e.options && e.options.borderWidth || 0, s = t.data || [];
    if (!s.length)
      return i;
    const n = s[0].size(this.resolveDataElementOptions(0)), a = s[s.length - 1].size(this.resolveDataElementOptions(s.length - 1));
    return Math.max(i, n, a) / 2;
  }
  draw() {
    const t = this._cachedMeta;
    t.dataset.updateControlPoints(this.chart.chartArea, t.iScale.axis), super.draw();
  }
}
class Jo extends Gs {
  static id = "pie";
  static defaults = {
    cutout: 0,
    rotation: 0,
    circumference: 360,
    radius: "100%"
  };
}
function ut() {
  throw new Error("This method is not implemented: Check that a complete date adapter is provided.");
}
class we {
  /**
  * Override default date adapter methods.
  * Accepts type parameter to define options type.
  * @example
  * Chart._adapters._date.override<{myAdapterOption: string}>({
  *   init() {
  *     console.log(this.options.myAdapterOption);
  *   }
  * })
  */
  static override(t) {
    Object.assign(we.prototype, t);
  }
  options;
  constructor(t) {
    this.options = t || {};
  }
  // eslint-disable-next-line @typescript-eslint/no-empty-function
  init() {
  }
  formats() {
    return ut();
  }
  parse() {
    return ut();
  }
  format() {
    return ut();
  }
  add() {
    return ut();
  }
  diff() {
    return ut();
  }
  startOf() {
    return ut();
  }
  endOf() {
    return ut();
  }
}
var qs = {
  _date: we
};
function Js(o, t, e, i) {
  const { controller: s, data: n, _sorted: a } = o, r = s._cachedMeta.iScale, l = o.dataset && o.dataset.options ? o.dataset.options.spanGaps : null;
  if (r && t === r.axis && t !== "r" && a && n.length) {
    const h = r._reversePixels ? Os : ge;
    if (i) {
      if (s._sharedOptions) {
        const c = n[0], d = typeof c.getRange == "function" && c.getRange(t);
        if (d) {
          const u = h(n, t, e - d), f = h(n, t, e + d);
          return {
            lo: u.lo,
            hi: f.hi
          };
        }
      }
    } else {
      const c = h(n, t, e);
      if (l) {
        const { vScale: d } = s._cachedMeta, { _parsed: u } = o, f = u.slice(0, c.lo + 1).reverse().findIndex((p) => !z(p[d.axis]));
        c.lo -= Math.max(0, f);
        const g = u.slice(c.hi).findIndex((p) => !z(p[d.axis]));
        c.hi += Math.max(0, g);
      }
      return c;
    }
  }
  return {
    lo: 0,
    hi: n.length - 1
  };
}
function ee(o, t, e, i, s) {
  const n = o.getSortedVisibleDatasetMetas(), a = e[t];
  for (let r = 0, l = n.length; r < l; ++r) {
    const { index: h, data: c } = n[r], { lo: d, hi: u } = Js(n[r], t, a, s);
    for (let f = d; f <= u; ++f) {
      const g = c[f];
      g.skip || i(g, h, f);
    }
  }
}
function Qs(o) {
  const t = o.indexOf("x") !== -1, e = o.indexOf("y") !== -1;
  return function(i, s) {
    const n = t ? Math.abs(i.x - s.x) : 0, a = e ? Math.abs(i.y - s.y) : 0;
    return Math.sqrt(Math.pow(n, 2) + Math.pow(a, 2));
  };
}
function le(o, t, e, i, s) {
  const n = [];
  return !s && !o.isPointInArea(t) || ee(o, e, t, function(r, l, h) {
    !s && !ye(r, o.chartArea, 0) || r.inRange(t.x, t.y, i) && n.push({
      element: r,
      datasetIndex: l,
      index: h
    });
  }, !0), n;
}
function Zs(o, t, e, i) {
  let s = [];
  function n(a, r, l) {
    const { startAngle: h, endAngle: c } = a.getProps([
      "startAngle",
      "endAngle"
    ], i), { angle: d } = Di(a, {
      x: t.x,
      y: t.y
    });
    Gt(d, h, c) && s.push({
      element: a,
      datasetIndex: r,
      index: l
    });
  }
  return ee(o, e, t, n), s;
}
function tn(o, t, e, i, s, n) {
  let a = [];
  const r = Qs(e);
  let l = Number.POSITIVE_INFINITY;
  function h(c, d, u) {
    const f = c.inRange(t.x, t.y, s);
    if (i && !f)
      return;
    const g = c.getCenterPoint(s);
    if (!(!!n || o.isPointInArea(g)) && !f)
      return;
    const _ = r(t, g);
    _ < l ? (a = [
      {
        element: c,
        datasetIndex: d,
        index: u
      }
    ], l = _) : _ === l && a.push({
      element: c,
      datasetIndex: d,
      index: u
    });
  }
  return ee(o, e, t, h), a;
}
function he(o, t, e, i, s, n) {
  return !n && !o.isPointInArea(t) ? [] : e === "r" && !i ? Zs(o, t, e, s) : tn(o, t, e, i, s, n);
}
function Ne(o, t, e, i, s) {
  const n = [], a = e === "x" ? "inXRange" : "inYRange";
  let r = !1;
  return ee(o, e, t, (l, h, c) => {
    l[a] && l[a](t[e], s) && (n.push({
      element: l,
      datasetIndex: h,
      index: c
    }), r = r || l.inRange(t.x, t.y, s));
  }), i && !r ? [] : n;
}
var en = {
  modes: {
    index(o, t, e, i) {
      const s = ft(t, o), n = e.axis || "x", a = e.includeInvisible || !1, r = e.intersect ? le(o, s, n, i, a) : he(o, s, n, !1, i, a), l = [];
      return r.length ? (o.getSortedVisibleDatasetMetas().forEach((h) => {
        const c = r[0].index, d = h.data[c];
        d && !d.skip && l.push({
          element: d,
          datasetIndex: h.index,
          index: c
        });
      }), l) : [];
    },
    dataset(o, t, e, i) {
      const s = ft(t, o), n = e.axis || "xy", a = e.includeInvisible || !1;
      let r = e.intersect ? le(o, s, n, i, a) : he(o, s, n, !1, i, a);
      if (r.length > 0) {
        const l = r[0].datasetIndex, h = o.getDatasetMeta(l).data;
        r = [];
        for (let c = 0; c < h.length; ++c)
          r.push({
            element: h[c],
            datasetIndex: l,
            index: c
          });
      }
      return r;
    },
    point(o, t, e, i) {
      const s = ft(t, o), n = e.axis || "xy", a = e.includeInvisible || !1;
      return le(o, s, n, i, a);
    },
    nearest(o, t, e, i) {
      const s = ft(t, o), n = e.axis || "xy", a = e.includeInvisible || !1;
      return he(o, s, n, e.intersect, i, a);
    },
    x(o, t, e, i) {
      const s = ft(t, o);
      return Ne(o, s, "x", e.intersect, i);
    },
    y(o, t, e, i) {
      const s = ft(t, o);
      return Ne(o, s, "y", e.intersect, i);
    }
  }
};
const Ri = [
  "left",
  "top",
  "right",
  "bottom"
];
function Dt(o, t) {
  return o.filter((e) => e.pos === t);
}
function je(o, t) {
  return o.filter((e) => Ri.indexOf(e.pos) === -1 && e.box.axis === t);
}
function Ct(o, t) {
  return o.sort((e, i) => {
    const s = t ? i : e, n = t ? e : i;
    return s.weight === n.weight ? s.index - n.index : s.weight - n.weight;
  });
}
function sn(o) {
  const t = [];
  let e, i, s, n, a, r;
  for (e = 0, i = (o || []).length; e < i; ++e)
    s = o[e], { position: n, options: { stack: a, stackWeight: r = 1 } } = s, t.push({
      index: e,
      box: s,
      pos: n,
      horizontal: s.isHorizontal(),
      weight: s.weight,
      stack: a && n + a,
      stackWeight: r
    });
  return t;
}
function nn(o) {
  const t = {};
  for (const e of o) {
    const { stack: i, pos: s, stackWeight: n } = e;
    if (!i || !Ri.includes(s))
      continue;
    const a = t[i] || (t[i] = {
      count: 0,
      placed: 0,
      weight: 0,
      size: 0
    });
    a.count++, a.weight += n;
  }
  return t;
}
function on(o, t) {
  const e = nn(o), { vBoxMaxWidth: i, hBoxMaxHeight: s } = t;
  let n, a, r;
  for (n = 0, a = o.length; n < a; ++n) {
    r = o[n];
    const { fullSize: l } = r.box, h = e[r.stack], c = h && r.stackWeight / h.weight;
    r.horizontal ? (r.width = c ? c * i : l && t.availableWidth, r.height = s) : (r.width = i, r.height = c ? c * s : l && t.availableHeight);
  }
  return e;
}
function an(o) {
  const t = sn(o), e = Ct(t.filter((h) => h.box.fullSize), !0), i = Ct(Dt(t, "left"), !0), s = Ct(Dt(t, "right")), n = Ct(Dt(t, "top"), !0), a = Ct(Dt(t, "bottom")), r = je(t, "x"), l = je(t, "y");
  return {
    fullSize: e,
    leftAndTop: i.concat(n),
    rightAndBottom: s.concat(l).concat(a).concat(r),
    chartArea: Dt(t, "chartArea"),
    vertical: i.concat(s).concat(l),
    horizontal: n.concat(a).concat(r)
  };
}
function $e(o, t, e, i) {
  return Math.max(o[e], t[e]) + Math.max(o[i], t[i]);
}
function Ei(o, t) {
  o.top = Math.max(o.top, t.top), o.left = Math.max(o.left, t.left), o.bottom = Math.max(o.bottom, t.bottom), o.right = Math.max(o.right, t.right);
}
function rn(o, t, e, i) {
  const { pos: s, box: n } = e, a = o.maxPadding;
  if (!F(s)) {
    e.size && (o[s] -= e.size);
    const d = i[e.stack] || {
      size: 0,
      count: 1
    };
    d.size = Math.max(d.size, e.horizontal ? n.height : n.width), e.size = d.size / d.count, o[s] += e.size;
  }
  n.getPadding && Ei(a, n.getPadding());
  const r = Math.max(0, t.outerWidth - $e(a, o, "left", "right")), l = Math.max(0, t.outerHeight - $e(a, o, "top", "bottom")), h = r !== o.w, c = l !== o.h;
  return o.w = r, o.h = l, e.horizontal ? {
    same: h,
    other: c
  } : {
    same: c,
    other: h
  };
}
function ln(o) {
  const t = o.maxPadding;
  function e(i) {
    const s = Math.max(t[i] - o[i], 0);
    return o[i] += s, s;
  }
  o.y += e("top"), o.x += e("left"), e("right"), e("bottom");
}
function hn(o, t) {
  const e = t.maxPadding;
  function i(s) {
    const n = {
      left: 0,
      top: 0,
      right: 0,
      bottom: 0
    };
    return s.forEach((a) => {
      n[a] = Math.max(t[a], e[a]);
    }), n;
  }
  return i(o ? [
    "left",
    "right"
  ] : [
    "top",
    "bottom"
  ]);
}
function Ot(o, t, e, i) {
  const s = [];
  let n, a, r, l, h, c;
  for (n = 0, a = o.length, h = 0; n < a; ++n) {
    r = o[n], l = r.box, l.update(r.width || t.w, r.height || t.h, hn(r.horizontal, t));
    const { same: d, other: u } = rn(t, e, r, i);
    h |= d && s.length, c = c || u, l.fullSize || s.push(r);
  }
  return h && Ot(s, t, e, i) || c;
}
function Ft(o, t, e, i, s) {
  o.top = e, o.left = t, o.right = t + i, o.bottom = e + s, o.width = i, o.height = s;
}
function Ye(o, t, e, i) {
  const s = e.padding;
  let { x: n, y: a } = t;
  for (const r of o) {
    const l = r.box, h = i[r.stack] || {
      placed: 0,
      weight: 1
    }, c = r.stackWeight / h.weight || 1;
    if (r.horizontal) {
      const d = t.w * c, u = h.size || l.height;
      Ut(h.start) && (a = h.start), l.fullSize ? Ft(l, s.left, a, e.outerWidth - s.right - s.left, u) : Ft(l, t.left + h.placed, a, d, u), h.start = a, h.placed += d, a = l.bottom;
    } else {
      const d = t.h * c, u = h.size || l.width;
      Ut(h.start) && (n = h.start), l.fullSize ? Ft(l, n, s.top, u, e.outerHeight - s.bottom - s.top) : Ft(l, n, t.top + h.placed, u, d), h.start = n, h.placed += d, n = l.right;
    }
  }
  t.x = n, t.y = a;
}
var K = {
  addBox(o, t) {
    o.boxes || (o.boxes = []), t.fullSize = t.fullSize || !1, t.position = t.position || "top", t.weight = t.weight || 0, t._layers = t._layers || function() {
      return [
        {
          z: 0,
          draw(e) {
            t.draw(e);
          }
        }
      ];
    }, o.boxes.push(t);
  },
  removeBox(o, t) {
    const e = o.boxes ? o.boxes.indexOf(t) : -1;
    e !== -1 && o.boxes.splice(e, 1);
  },
  configure(o, t, e) {
    t.fullSize = e.fullSize, t.position = e.position, t.weight = e.weight;
  },
  update(o, t, e, i) {
    if (!o)
      return;
    const s = G(o.options.layout.padding), n = Math.max(t - s.width, 0), a = Math.max(e - s.height, 0), r = an(o.boxes), l = r.vertical, h = r.horizontal;
    P(o.boxes, (p) => {
      typeof p.beforeLayout == "function" && p.beforeLayout();
    });
    const c = l.reduce((p, _) => _.box.options && _.box.options.display === !1 ? p : p + 1, 0) || 1, d = Object.freeze({
      outerWidth: t,
      outerHeight: e,
      padding: s,
      availableWidth: n,
      availableHeight: a,
      vBoxMaxWidth: n / 2 / c,
      hBoxMaxHeight: a / 2
    }), u = Object.assign({}, s);
    Ei(u, G(i));
    const f = Object.assign({
      maxPadding: u,
      w: n,
      h: a,
      x: s.left,
      y: s.top
    }, s), g = on(l.concat(h), d);
    Ot(r.fullSize, f, d, g), Ot(l, f, d, g), Ot(h, f, d, g) && Ot(l, f, d, g), ln(f), Ye(r.leftAndTop, f, d, g), f.x += f.w, f.y += f.h, Ye(r.rightAndBottom, f, d, g), o.chartArea = {
      left: f.left,
      top: f.top,
      right: f.left + f.w,
      bottom: f.top + f.h,
      height: f.h,
      width: f.w
    }, P(r.chartArea, (p) => {
      const _ = p.box;
      Object.assign(_, o.chartArea), _.update(f.w, f.h, {
        left: 0,
        top: 0,
        right: 0,
        bottom: 0
      });
    });
  }
};
class zi {
  acquireContext(t, e) {
  }
  releaseContext(t) {
    return !1;
  }
  addEventListener(t, e, i) {
  }
  removeEventListener(t, e, i) {
  }
  getDevicePixelRatio() {
    return 1;
  }
  getMaximumSize(t, e, i, s) {
    return e = Math.max(0, e || t.width), i = i || t.height, {
      width: e,
      height: Math.max(0, s ? Math.floor(e / s) : i)
    };
  }
  isAttached(t) {
    return !0;
  }
  updateConfig(t) {
  }
}
class cn extends zi {
  acquireContext(t) {
    return t && t.getContext && t.getContext("2d") || null;
  }
  updateConfig(t) {
    t.options.animation = !1;
  }
}
const $t = "$chartjs", dn = {
  touchstart: "mousedown",
  touchmove: "mousemove",
  touchend: "mouseup",
  pointerenter: "mouseenter",
  pointerdown: "mousedown",
  pointermove: "mousemove",
  pointerup: "mouseup",
  pointerleave: "mouseout",
  pointerout: "mouseout"
}, Ue = (o) => o === null || o === "";
function un(o, t) {
  const e = o.style, i = o.getAttribute("height"), s = o.getAttribute("width");
  if (o[$t] = {
    initial: {
      height: i,
      width: s,
      style: {
        display: e.display,
        height: e.height,
        width: e.width
      }
    }
  }, e.display = e.display || "block", e.boxSizing = e.boxSizing || "border-box", Ue(s)) {
    const n = Re(o, "width");
    n !== void 0 && (o.width = n);
  }
  if (Ue(i))
    if (o.style.height === "")
      o.height = o.width / (t || 2);
    else {
      const n = Re(o, "height");
      n !== void 0 && (o.height = n);
    }
  return o;
}
const Ii = Ts ? {
  passive: !0
} : !1;
function fn(o, t, e) {
  o && o.addEventListener(t, e, Ii);
}
function gn(o, t, e) {
  o && o.canvas && o.canvas.removeEventListener(t, e, Ii);
}
function pn(o, t) {
  const e = dn[o.type] || o.type, { x: i, y: s } = ft(o, t);
  return {
    type: e,
    chart: t,
    native: o,
    x: i !== void 0 ? i : null,
    y: s !== void 0 ? s : null
  };
}
function Qt(o, t) {
  for (const e of o)
    if (e === t || e.contains(t))
      return !0;
}
function mn(o, t, e) {
  const i = o.canvas, s = new MutationObserver((n) => {
    let a = !1;
    for (const r of n)
      a = a || Qt(r.addedNodes, i), a = a && !Qt(r.removedNodes, i);
    a && e();
  });
  return s.observe(document, {
    childList: !0,
    subtree: !0
  }), s;
}
function _n(o, t, e) {
  const i = o.canvas, s = new MutationObserver((n) => {
    let a = !1;
    for (const r of n)
      a = a || Qt(r.removedNodes, i), a = a && !Qt(r.addedNodes, i);
    a && e();
  });
  return s.observe(document, {
    childList: !0,
    subtree: !0
  }), s;
}
const Et = /* @__PURE__ */ new Map();
let Xe = 0;
function Fi() {
  const o = window.devicePixelRatio;
  o !== Xe && (Xe = o, Et.forEach((t, e) => {
    e.currentDevicePixelRatio !== o && t();
  }));
}
function bn(o, t) {
  Et.size || window.addEventListener("resize", Fi), Et.set(o, t);
}
function xn(o) {
  Et.delete(o), Et.size || window.removeEventListener("resize", Fi);
}
function yn(o, t, e) {
  const i = o.canvas, s = i && Pi(i);
  if (!s)
    return;
  const n = Oi((r, l) => {
    const h = s.clientWidth;
    e(r, l), h < s.clientWidth && e();
  }, window), a = new ResizeObserver((r) => {
    const l = r[0], h = l.contentRect.width, c = l.contentRect.height;
    h === 0 && c === 0 || n(h, c);
  });
  return a.observe(s), bn(o, n), a;
}
function ce(o, t, e) {
  e && e.disconnect(), t === "resize" && xn(o);
}
function vn(o, t, e) {
  const i = o.canvas, s = Oi((n) => {
    o.ctx !== null && e(pn(n, o));
  }, o);
  return fn(i, t, s), s;
}
class kn extends zi {
  acquireContext(t, e) {
    const i = t && t.getContext && t.getContext("2d");
    return i && i.canvas === t ? (un(t, e), i) : null;
  }
  releaseContext(t) {
    const e = t.canvas;
    if (!e[$t])
      return !1;
    const i = e[$t].initial;
    [
      "height",
      "width"
    ].forEach((n) => {
      const a = i[n];
      z(a) ? e.removeAttribute(n) : e.setAttribute(n, a);
    });
    const s = i.style || {};
    return Object.keys(s).forEach((n) => {
      e.style[n] = s[n];
    }), e.width = e.width, delete e[$t], !0;
  }
  addEventListener(t, e, i) {
    this.removeEventListener(t, e);
    const s = t.$proxies || (t.$proxies = {}), a = {
      attach: mn,
      detach: _n,
      resize: yn
    }[e] || vn;
    s[e] = a(t, e, i);
  }
  removeEventListener(t, e) {
    const i = t.$proxies || (t.$proxies = {}), s = i[e];
    if (!s)
      return;
    ({
      attach: ce,
      detach: ce,
      resize: ce
    }[e] || gn)(t, e, s), i[e] = void 0;
  }
  getDevicePixelRatio() {
    return window.devicePixelRatio;
  }
  getMaximumSize(t, e, i, s) {
    return Ms(t, e, i, s);
  }
  isAttached(t) {
    const e = t && Pi(t);
    return !!(e && e.isConnected);
  }
}
function wn(o) {
  return !Ci() || typeof OffscreenCanvas < "u" && o instanceof OffscreenCanvas ? cn : kn;
}
class rt {
  static defaults = {};
  static defaultRoutes = void 0;
  x;
  y;
  active = !1;
  options;
  $animations;
  tooltipPosition(t) {
    const { x: e, y: i } = this.getProps([
      "x",
      "y"
    ], t);
    return {
      x: e,
      y: i
    };
  }
  hasValue() {
    return Rt(this.x) && Rt(this.y);
  }
  getProps(t, e) {
    const i = this.$animations;
    if (!e || !i)
      return this;
    const s = {};
    return t.forEach((n) => {
      s[n] = i[n] && i[n].active() ? i[n]._to : this[n];
    }), s;
  }
}
function Mn(o, t) {
  const e = o.options.ticks, i = Sn(o), s = Math.min(e.maxTicksLimit || i, i), n = e.major.enabled ? Cn(t) : [], a = n.length, r = n[0], l = n[a - 1], h = [];
  if (a > s)
    return An(t, h, n, a / s), h;
  const c = Dn(n, t, s);
  if (a > 0) {
    let d, u;
    const f = a > 1 ? Math.round((l - r) / (a - 1)) : null;
    for (Bt(t, h, c, z(f) ? 0 : r - f, r), d = 0, u = a - 1; d < u; d++)
      Bt(t, h, c, n[d], n[d + 1]);
    return Bt(t, h, c, l, z(f) ? t.length : l + f), h;
  }
  return Bt(t, h, c), h;
}
function Sn(o) {
  const t = o.options.offset, e = o._tickSize(), i = o._length / e + (t ? 0 : 1), s = o._maxLength / e;
  return Math.floor(Math.min(i, s));
}
function Dn(o, t, e) {
  const i = Pn(o), s = t.length / e;
  if (!i)
    return Math.max(s, 1);
  const n = Ps(i);
  for (let a = 0, r = n.length - 1; a < r; a++) {
    const l = n[a];
    if (l > s)
      return l;
  }
  return Math.max(s, 1);
}
function Cn(o) {
  const t = [];
  let e, i;
  for (e = 0, i = o.length; e < i; e++)
    o[e].major && t.push(e);
  return t;
}
function An(o, t, e, i) {
  let s = 0, n = e[0], a;
  for (i = Math.ceil(i), a = 0; a < o.length; a++)
    a === n && (t.push(o[a]), s++, n = e[s * i]);
}
function Bt(o, t, e, i, s) {
  const n = O(i, 0), a = Math.min(O(s, o.length), o.length);
  let r = 0, l, h, c;
  for (e = Math.ceil(e), s && (l = s - i, e = l / Math.floor(l / e)), c = n; c < 0; )
    r++, c = Math.round(n + r * e);
  for (h = Math.max(n, 0); h < a; h++)
    h === c && (t.push(o[h]), r++, c = Math.round(n + r * e));
}
function Pn(o) {
  const t = o.length;
  let e, i;
  if (t < 2)
    return !1;
  for (i = o[0], e = 1; e < t; ++e)
    if (o[e] - o[e - 1] !== i)
      return !1;
  return i;
}
const On = (o) => o === "left" ? "right" : o === "right" ? "left" : o, Ke = (o, t, e) => t === "top" || t === "left" ? o[t] + e : o[t] - e, Ge = (o, t) => Math.min(t || o, o);
function qe(o, t) {
  const e = [], i = o.length / t, s = o.length;
  let n = 0;
  for (; n < s; n += i)
    e.push(o[Math.floor(n)]);
  return e;
}
function Ln(o, t, e) {
  const i = o.ticks.length, s = Math.min(t, i - 1), n = o._startPixel, a = o._endPixel, r = 1e-6;
  let l = o.getPixelForTick(s), h;
  if (!(e && (i === 1 ? h = Math.max(l - n, a - l) : t === 0 ? h = (o.getPixelForTick(1) - l) / 2 : h = (l - o.getPixelForTick(s - 1)) / 2, l += s < t ? h : -h, l < n - r || l > a + r)))
    return l;
}
function Tn(o, t) {
  P(o, (e) => {
    const i = e.gc, s = i.length / 2;
    let n;
    if (s > t) {
      for (n = 0; n < s; ++n)
        delete e.data[i[n]];
      i.splice(0, s);
    }
  });
}
function At(o) {
  return o.drawTicks ? o.tickLength : 0;
}
function Je(o, t) {
  if (!o.display)
    return 0;
  const e = V(o.font, t), i = G(o.padding);
  return (J(o.text) ? o.text.length : 1) * e.lineHeight + i.height;
}
function Rn(o, t) {
  return vt(o, {
    scale: t,
    type: "scale"
  });
}
function En(o, t, e) {
  return vt(o, {
    tick: e,
    index: t,
    type: "tick"
  });
}
function zn(o, t, e) {
  let i = ve(o);
  return (e && t !== "right" || !e && t === "right") && (i = On(i)), i;
}
function In(o, t, e, i) {
  const { top: s, left: n, bottom: a, right: r, chart: l } = o, { chartArea: h, scales: c } = l;
  let d = 0, u, f, g;
  const p = a - s, _ = r - n;
  if (o.isHorizontal()) {
    if (f = W(i, n, r), F(e)) {
      const m = Object.keys(e)[0], x = e[m];
      g = c[m].getPixelForValue(x) + p - t;
    } else e === "center" ? g = (h.bottom + h.top) / 2 + p - t : g = Ke(o, e, t);
    u = r - n;
  } else {
    if (F(e)) {
      const m = Object.keys(e)[0], x = e[m];
      f = c[m].getPixelForValue(x) - _ + t;
    } else e === "center" ? f = (h.left + h.right) / 2 - _ + t : f = Ke(o, e, t);
    g = W(i, a, s), d = e === "left" ? -et : et;
  }
  return {
    titleX: f,
    titleY: g,
    maxWidth: u,
    rotation: d
  };
}
class kt extends rt {
  constructor(t) {
    super(), this.id = t.id, this.type = t.type, this.options = void 0, this.ctx = t.ctx, this.chart = t.chart, this.top = void 0, this.bottom = void 0, this.left = void 0, this.right = void 0, this.width = void 0, this.height = void 0, this._margins = {
      left: 0,
      right: 0,
      top: 0,
      bottom: 0
    }, this.maxWidth = void 0, this.maxHeight = void 0, this.paddingTop = void 0, this.paddingBottom = void 0, this.paddingLeft = void 0, this.paddingRight = void 0, this.axis = void 0, this.labelRotation = void 0, this.min = void 0, this.max = void 0, this._range = void 0, this.ticks = [], this._gridLineItems = null, this._labelItems = null, this._labelSizes = null, this._length = 0, this._maxLength = 0, this._longestTextCache = {}, this._startPixel = void 0, this._endPixel = void 0, this._reversePixels = !1, this._userMax = void 0, this._userMin = void 0, this._suggestedMax = void 0, this._suggestedMin = void 0, this._ticksLength = 0, this._borderValue = 0, this._cache = {}, this._dataLimitsCached = !1, this.$context = void 0;
  }
  init(t) {
    this.options = t.setContext(this.getContext()), this.axis = t.axis, this._userMin = this.parse(t.min), this._userMax = this.parse(t.max), this._suggestedMin = this.parse(t.suggestedMin), this._suggestedMax = this.parse(t.suggestedMax);
  }
  parse(t, e) {
    return t;
  }
  getUserBounds() {
    let { _userMin: t, _userMax: e, _suggestedMin: i, _suggestedMax: s } = this;
    return t = Q(t, Number.POSITIVE_INFINITY), e = Q(e, Number.NEGATIVE_INFINITY), i = Q(i, Number.POSITIVE_INFINITY), s = Q(s, Number.NEGATIVE_INFINITY), {
      min: Q(t, i),
      max: Q(e, s),
      minDefined: it(t),
      maxDefined: it(e)
    };
  }
  getMinMax(t) {
    let { min: e, max: i, minDefined: s, maxDefined: n } = this.getUserBounds(), a;
    if (s && n)
      return {
        min: e,
        max: i
      };
    const r = this.getMatchingVisibleMetas();
    for (let l = 0, h = r.length; l < h; ++l)
      a = r[l].controller.getMinMax(this, t), s || (e = Math.min(e, a.min)), n || (i = Math.max(i, a.max));
    return e = n && e > i ? i : e, i = s && e > i ? e : i, {
      min: Q(e, Q(i, e)),
      max: Q(i, Q(e, i))
    };
  }
  getPadding() {
    return {
      left: this.paddingLeft || 0,
      top: this.paddingTop || 0,
      right: this.paddingRight || 0,
      bottom: this.paddingBottom || 0
    };
  }
  getTicks() {
    return this.ticks;
  }
  getLabels() {
    const t = this.chart.data;
    return this.options.labels || (this.isHorizontal() ? t.xLabels : t.yLabels) || t.labels || [];
  }
  getLabelItems(t = this.chart.chartArea) {
    return this._labelItems || (this._labelItems = this._computeLabelItems(t));
  }
  beforeLayout() {
    this._cache = {}, this._dataLimitsCached = !1;
  }
  beforeUpdate() {
    T(this.options.beforeUpdate, [
      this
    ]);
  }
  update(t, e, i) {
    const { beginAtZero: s, grace: n, ticks: a } = this.options, r = a.sampleSize;
    this.beforeUpdate(), this.maxWidth = t, this.maxHeight = e, this._margins = i = Object.assign({
      left: 0,
      right: 0,
      top: 0,
      bottom: 0
    }, i), this.ticks = null, this._labelSizes = null, this._gridLineItems = null, this._labelItems = null, this.beforeSetDimensions(), this.setDimensions(), this.afterSetDimensions(), this._maxLength = this.isHorizontal() ? this.width + i.left + i.right : this.height + i.top + i.bottom, this._dataLimitsCached || (this.beforeDataLimits(), this.determineDataLimits(), this.afterDataLimits(), this._range = ps(this, n, s), this._dataLimitsCached = !0), this.beforeBuildTicks(), this.ticks = this.buildTicks() || [], this.afterBuildTicks();
    const l = r < this.ticks.length;
    this._convertTicksToLabels(l ? qe(this.ticks, r) : this.ticks), this.configure(), this.beforeCalculateLabelRotation(), this.calculateLabelRotation(), this.afterCalculateLabelRotation(), a.display && (a.autoSkip || a.source === "auto") && (this.ticks = Mn(this, this.ticks), this._labelSizes = null, this.afterAutoSkip()), l && this._convertTicksToLabels(this.ticks), this.beforeFit(), this.fit(), this.afterFit(), this.afterUpdate();
  }
  configure() {
    let t = this.options.reverse, e, i;
    this.isHorizontal() ? (e = this.left, i = this.right) : (e = this.top, i = this.bottom, t = !t), this._startPixel = e, this._endPixel = i, this._reversePixels = t, this._length = i - e, this._alignToPixels = this.options.alignToPixels;
  }
  afterUpdate() {
    T(this.options.afterUpdate, [
      this
    ]);
  }
  beforeSetDimensions() {
    T(this.options.beforeSetDimensions, [
      this
    ]);
  }
  setDimensions() {
    this.isHorizontal() ? (this.width = this.maxWidth, this.left = 0, this.right = this.width) : (this.height = this.maxHeight, this.top = 0, this.bottom = this.height), this.paddingLeft = 0, this.paddingTop = 0, this.paddingRight = 0, this.paddingBottom = 0;
  }
  afterSetDimensions() {
    T(this.options.afterSetDimensions, [
      this
    ]);
  }
  _callHooks(t) {
    this.chart.notifyPlugins(t, this.getContext()), T(this.options[t], [
      this
    ]);
  }
  beforeDataLimits() {
    this._callHooks("beforeDataLimits");
  }
  determineDataLimits() {
  }
  afterDataLimits() {
    this._callHooks("afterDataLimits");
  }
  beforeBuildTicks() {
    this._callHooks("beforeBuildTicks");
  }
  buildTicks() {
    return [];
  }
  afterBuildTicks() {
    this._callHooks("afterBuildTicks");
  }
  beforeTickToLabelConversion() {
    T(this.options.beforeTickToLabelConversion, [
      this
    ]);
  }
  generateTickLabels(t) {
    const e = this.options.ticks;
    let i, s, n;
    for (i = 0, s = t.length; i < s; i++)
      n = t[i], n.label = T(e.callback, [
        n.value,
        i,
        t
      ], this);
  }
  afterTickToLabelConversion() {
    T(this.options.afterTickToLabelConversion, [
      this
    ]);
  }
  beforeCalculateLabelRotation() {
    T(this.options.beforeCalculateLabelRotation, [
      this
    ]);
  }
  calculateLabelRotation() {
    const t = this.options, e = t.ticks, i = Ge(this.ticks.length, t.ticks.maxTicksLimit), s = e.minRotation || 0, n = e.maxRotation;
    let a = s, r, l, h;
    if (!this._isVisible() || !e.display || s >= n || i <= 1 || !this.isHorizontal()) {
      this.labelRotation = s;
      return;
    }
    const c = this._getLabelSizes(), d = c.widest.width, u = c.highest.height, f = U(this.chart.width - d, 0, this.maxWidth);
    r = t.offset ? this.maxWidth / i : f / (i - 1), d + 6 > r && (r = f / (i - (t.offset ? 0.5 : 1)), l = this.maxHeight - At(t.grid) - e.padding - Je(t.title, this.chart.options.font), h = Math.sqrt(d * d + u * u), a = ms(Math.min(Math.asin(U((c.highest.height + 6) / r, -1, 1)), Math.asin(U(l / h, -1, 1)) - Math.asin(U(u / h, -1, 1)))), a = Math.max(s, Math.min(n, a))), this.labelRotation = a;
  }
  afterCalculateLabelRotation() {
    T(this.options.afterCalculateLabelRotation, [
      this
    ]);
  }
  afterAutoSkip() {
  }
  beforeFit() {
    T(this.options.beforeFit, [
      this
    ]);
  }
  fit() {
    const t = {
      width: 0,
      height: 0
    }, { chart: e, options: { ticks: i, title: s, grid: n } } = this, a = this._isVisible(), r = this.isHorizontal();
    if (a) {
      const l = Je(s, e.options.font);
      if (r ? (t.width = this.maxWidth, t.height = At(n) + l) : (t.height = this.maxHeight, t.width = At(n) + l), i.display && this.ticks.length) {
        const { first: h, last: c, widest: d, highest: u } = this._getLabelSizes(), f = i.padding * 2, g = at(this.labelRotation), p = Math.cos(g), _ = Math.sin(g);
        if (r) {
          const m = i.mirror ? 0 : _ * d.width + p * u.height;
          t.height = Math.min(this.maxHeight, t.height + m + f);
        } else {
          const m = i.mirror ? 0 : p * d.width + _ * u.height;
          t.width = Math.min(this.maxWidth, t.width + m + f);
        }
        this._calculatePadding(h, c, _, p);
      }
    }
    this._handleMargins(), r ? (this.width = this._length = e.width - this._margins.left - this._margins.right, this.height = t.height) : (this.width = t.width, this.height = this._length = e.height - this._margins.top - this._margins.bottom);
  }
  _calculatePadding(t, e, i, s) {
    const { ticks: { align: n, padding: a }, position: r } = this.options, l = this.labelRotation !== 0, h = r !== "top" && this.axis === "x";
    if (this.isHorizontal()) {
      const c = this.getPixelForTick(0) - this.left, d = this.right - this.getPixelForTick(this.ticks.length - 1);
      let u = 0, f = 0;
      l ? h ? (u = s * t.width, f = i * e.height) : (u = i * t.height, f = s * e.width) : n === "start" ? f = e.width : n === "end" ? u = t.width : n !== "inner" && (u = t.width / 2, f = e.width / 2), this.paddingLeft = Math.max((u - c + a) * this.width / (this.width - c), 0), this.paddingRight = Math.max((f - d + a) * this.width / (this.width - d), 0);
    } else {
      let c = e.height / 2, d = t.height / 2;
      n === "start" ? (c = 0, d = t.height) : n === "end" && (c = e.height, d = 0), this.paddingTop = c + a, this.paddingBottom = d + a;
    }
  }
  _handleMargins() {
    this._margins && (this._margins.left = Math.max(this.paddingLeft, this._margins.left), this._margins.top = Math.max(this.paddingTop, this._margins.top), this._margins.right = Math.max(this.paddingRight, this._margins.right), this._margins.bottom = Math.max(this.paddingBottom, this._margins.bottom));
  }
  afterFit() {
    T(this.options.afterFit, [
      this
    ]);
  }
  isHorizontal() {
    const { axis: t, position: e } = this.options;
    return e === "top" || e === "bottom" || t === "x";
  }
  isFullSize() {
    return this.options.fullSize;
  }
  _convertTicksToLabels(t) {
    this.beforeTickToLabelConversion(), this.generateTickLabels(t);
    let e, i;
    for (e = 0, i = t.length; e < i; e++)
      z(t[e].label) && (t.splice(e, 1), i--, e--);
    this.afterTickToLabelConversion();
  }
  _getLabelSizes() {
    let t = this._labelSizes;
    if (!t) {
      const e = this.options.ticks.sampleSize;
      let i = this.ticks;
      e < i.length && (i = qe(i, e)), this._labelSizes = t = this._computeLabelSizes(i, i.length, this.options.ticks.maxTicksLimit);
    }
    return t;
  }
  _computeLabelSizes(t, e, i) {
    const { ctx: s, _longestTextCache: n } = this, a = [], r = [], l = Math.floor(e / Ge(e, i));
    let h = 0, c = 0, d, u, f, g, p, _, m, x, v, y, b;
    for (d = 0; d < e; d += l) {
      if (g = t[d].label, p = this._resolveTickFontOptions(d), s.font = _ = p.string, m = n[_] = n[_] || {
        data: {},
        gc: []
      }, x = p.lineHeight, v = y = 0, !z(g) && !J(g))
        v = Oe(s, m.data, m.gc, v, g), y = x;
      else if (J(g))
        for (u = 0, f = g.length; u < f; ++u)
          b = g[u], !z(b) && !J(b) && (v = Oe(s, m.data, m.gc, v, b), y += x);
      a.push(v), r.push(y), h = Math.max(v, h), c = Math.max(y, c);
    }
    Tn(n, e);
    const k = a.indexOf(h), w = r.indexOf(c), M = (S) => ({
      width: a[S] || 0,
      height: r[S] || 0
    });
    return {
      first: M(0),
      last: M(e - 1),
      widest: M(k),
      highest: M(w),
      widths: a,
      heights: r
    };
  }
  getLabelForValue(t) {
    return t;
  }
  getPixelForValue(t, e) {
    return NaN;
  }
  getValueForPixel(t) {
  }
  getPixelForTick(t) {
    const e = this.ticks;
    return t < 0 || t > e.length - 1 ? null : this.getPixelForValue(e[t].value);
  }
  getPixelForDecimal(t) {
    this._reversePixels && (t = 1 - t);
    const e = this._startPixel + t * this._length;
    return _s(this._alignToPixels ? dt(this.chart, e, 0) : e);
  }
  getDecimalForPixel(t) {
    const e = (t - this._startPixel) / this._length;
    return this._reversePixels ? 1 - e : e;
  }
  getBasePixel() {
    return this.getPixelForValue(this.getBaseValue());
  }
  getBaseValue() {
    const { min: t, max: e } = this;
    return t < 0 && e < 0 ? e : t > 0 && e > 0 ? t : 0;
  }
  getContext(t) {
    const e = this.ticks || [];
    if (t >= 0 && t < e.length) {
      const i = e[t];
      return i.$context || (i.$context = En(this.getContext(), t, i));
    }
    return this.$context || (this.$context = Rn(this.chart.getContext(), this));
  }
  _tickSize() {
    const t = this.options.ticks, e = at(this.labelRotation), i = Math.abs(Math.cos(e)), s = Math.abs(Math.sin(e)), n = this._getLabelSizes(), a = t.autoSkipPadding || 0, r = n ? n.widest.width + a : 0, l = n ? n.highest.height + a : 0;
    return this.isHorizontal() ? l * i > r * s ? r / i : l / s : l * s < r * i ? l / i : r / s;
  }
  _isVisible() {
    const t = this.options.display;
    return t !== "auto" ? !!t : this.getMatchingVisibleMetas().length > 0;
  }
  _computeGridLineItems(t) {
    const e = this.axis, i = this.chart, s = this.options, { grid: n, position: a, border: r } = s, l = n.offset, h = this.isHorizontal(), d = this.ticks.length + (l ? 1 : 0), u = At(n), f = [], g = r.setContext(this.getContext()), p = g.display ? g.width : 0, _ = p / 2, m = function(R) {
      return dt(i, R, p);
    };
    let x, v, y, b, k, w, M, S, C, D, A, B;
    if (a === "top")
      x = m(this.bottom), w = this.bottom - u, S = x - _, D = m(t.top) + _, B = t.bottom;
    else if (a === "bottom")
      x = m(this.top), D = t.top, B = m(t.bottom) - _, w = x + _, S = this.top + u;
    else if (a === "left")
      x = m(this.right), k = this.right - u, M = x - _, C = m(t.left) + _, A = t.right;
    else if (a === "right")
      x = m(this.left), C = t.left, A = m(t.right) - _, k = x + _, M = this.left + u;
    else if (e === "x") {
      if (a === "center")
        x = m((t.top + t.bottom) / 2 + 0.5);
      else if (F(a)) {
        const R = Object.keys(a)[0], E = a[R];
        x = m(this.chart.scales[R].getPixelForValue(E));
      }
      D = t.top, B = t.bottom, w = x + _, S = w + u;
    } else if (e === "y") {
      if (a === "center")
        x = m((t.left + t.right) / 2);
      else if (F(a)) {
        const R = Object.keys(a)[0], E = a[R];
        x = m(this.chart.scales[R].getPixelForValue(E));
      }
      k = x - _, M = k - u, C = t.left, A = t.right;
    }
    const $ = O(s.ticks.maxTicksLimit, d), L = Math.max(1, Math.ceil(d / $));
    for (v = 0; v < d; v += L) {
      const R = this.getContext(v), E = n.setContext(R), q = r.setContext(R), H = E.lineWidth, pt = E.color, zt = q.dash || [], mt = q.dashOffset, wt = E.tickWidth, ht = E.tickColor, Mt = E.tickBorderDash || [], ct = E.tickBorderDashOffset;
      y = Ln(this, v, l), y !== void 0 && (b = dt(i, y, H), h ? k = M = C = A = b : w = S = D = B = b, f.push({
        tx1: k,
        ty1: w,
        tx2: M,
        ty2: S,
        x1: C,
        y1: D,
        x2: A,
        y2: B,
        width: H,
        color: pt,
        borderDash: zt,
        borderDashOffset: mt,
        tickWidth: wt,
        tickColor: ht,
        tickBorderDash: Mt,
        tickBorderDashOffset: ct
      }));
    }
    return this._ticksLength = d, this._borderValue = x, f;
  }
  _computeLabelItems(t) {
    const e = this.axis, i = this.options, { position: s, ticks: n } = i, a = this.isHorizontal(), r = this.ticks, { align: l, crossAlign: h, padding: c, mirror: d } = n, u = At(i.grid), f = u + c, g = d ? -c : f, p = -at(this.labelRotation), _ = [];
    let m, x, v, y, b, k, w, M, S, C, D, A, B = "middle";
    if (s === "top")
      k = this.bottom - g, w = this._getXAxisLabelAlignment();
    else if (s === "bottom")
      k = this.top + g, w = this._getXAxisLabelAlignment();
    else if (s === "left") {
      const L = this._getYAxisLabelAlignment(u);
      w = L.textAlign, b = L.x;
    } else if (s === "right") {
      const L = this._getYAxisLabelAlignment(u);
      w = L.textAlign, b = L.x;
    } else if (e === "x") {
      if (s === "center")
        k = (t.top + t.bottom) / 2 + f;
      else if (F(s)) {
        const L = Object.keys(s)[0], R = s[L];
        k = this.chart.scales[L].getPixelForValue(R) + f;
      }
      w = this._getXAxisLabelAlignment();
    } else if (e === "y") {
      if (s === "center")
        b = (t.left + t.right) / 2 - f;
      else if (F(s)) {
        const L = Object.keys(s)[0], R = s[L];
        b = this.chart.scales[L].getPixelForValue(R);
      }
      w = this._getYAxisLabelAlignment(u).textAlign;
    }
    e === "y" && (l === "start" ? B = "top" : l === "end" && (B = "bottom"));
    const $ = this._getLabelSizes();
    for (m = 0, x = r.length; m < x; ++m) {
      v = r[m], y = v.label;
      const L = n.setContext(this.getContext(m));
      M = this.getPixelForTick(m) + n.labelOffset, S = this._resolveTickFontOptions(m), C = S.lineHeight, D = J(y) ? y.length : 1;
      const R = D / 2, E = L.color, q = L.textStrokeColor, H = L.textStrokeWidth;
      let pt = w;
      a ? (b = M, w === "inner" && (m === x - 1 ? pt = this.options.reverse ? "left" : "right" : m === 0 ? pt = this.options.reverse ? "right" : "left" : pt = "center"), s === "top" ? h === "near" || p !== 0 ? A = -D * C + C / 2 : h === "center" ? A = -$.highest.height / 2 - R * C + C : A = -$.highest.height + C / 2 : h === "near" || p !== 0 ? A = C / 2 : h === "center" ? A = $.highest.height / 2 - R * C : A = $.highest.height - D * C, d && (A *= -1), p !== 0 && !L.showLabelBackdrop && (b += C / 2 * Math.sin(p))) : (k = M, A = (1 - D) * C / 2);
      let zt;
      if (L.showLabelBackdrop) {
        const mt = G(L.backdropPadding), wt = $.heights[m], ht = $.widths[m];
        let Mt = A - mt.top, ct = 0 - mt.left;
        switch (B) {
          case "middle":
            Mt -= wt / 2;
            break;
          case "bottom":
            Mt -= wt;
            break;
        }
        switch (w) {
          case "center":
            ct -= ht / 2;
            break;
          case "right":
            ct -= ht;
            break;
          case "inner":
            m === x - 1 ? ct -= ht : m > 0 && (ct -= ht / 2);
            break;
        }
        zt = {
          left: ct,
          top: Mt,
          width: ht + mt.width,
          height: wt + mt.height,
          color: L.backdropColor
        };
      }
      _.push({
        label: y,
        font: S,
        textOffset: A,
        options: {
          rotation: p,
          color: E,
          strokeColor: q,
          strokeWidth: H,
          textAlign: pt,
          textBaseline: B,
          translation: [
            b,
            k
          ],
          backdrop: zt
        }
      });
    }
    return _;
  }
  _getXAxisLabelAlignment() {
    const { position: t, ticks: e } = this.options;
    if (-at(this.labelRotation))
      return t === "top" ? "left" : "right";
    let s = "center";
    return e.align === "start" ? s = "left" : e.align === "end" ? s = "right" : e.align === "inner" && (s = "inner"), s;
  }
  _getYAxisLabelAlignment(t) {
    const { position: e, ticks: { crossAlign: i, mirror: s, padding: n } } = this.options, a = this._getLabelSizes(), r = t + n, l = a.widest.width;
    let h, c;
    return e === "left" ? s ? (c = this.right + n, i === "near" ? h = "left" : i === "center" ? (h = "center", c += l / 2) : (h = "right", c += l)) : (c = this.right - r, i === "near" ? h = "right" : i === "center" ? (h = "center", c -= l / 2) : (h = "left", c = this.left)) : e === "right" ? s ? (c = this.left + n, i === "near" ? h = "right" : i === "center" ? (h = "center", c -= l / 2) : (h = "left", c -= l)) : (c = this.left + r, i === "near" ? h = "left" : i === "center" ? (h = "center", c += l / 2) : (h = "right", c = this.right)) : h = "right", {
      textAlign: h,
      x: c
    };
  }
  _computeLabelArea() {
    if (this.options.ticks.mirror)
      return;
    const t = this.chart, e = this.options.position;
    if (e === "left" || e === "right")
      return {
        top: 0,
        left: this.left,
        bottom: t.height,
        right: this.right
      };
    if (e === "top" || e === "bottom")
      return {
        top: this.top,
        left: 0,
        bottom: this.bottom,
        right: t.width
      };
  }
  drawBackground() {
    const { ctx: t, options: { backgroundColor: e }, left: i, top: s, width: n, height: a } = this;
    e && (t.save(), t.fillStyle = e, t.fillRect(i, s, n, a), t.restore());
  }
  getLineWidthForValue(t) {
    const e = this.options.grid;
    if (!this._isVisible() || !e.display)
      return 0;
    const s = this.ticks.findIndex((n) => n.value === t);
    return s >= 0 ? e.setContext(this.getContext(s)).lineWidth : 0;
  }
  drawGrid(t) {
    const e = this.options.grid, i = this.ctx, s = this._gridLineItems || (this._gridLineItems = this._computeGridLineItems(t));
    let n, a;
    const r = (l, h, c) => {
      !c.width || !c.color || (i.save(), i.lineWidth = c.width, i.strokeStyle = c.color, i.setLineDash(c.borderDash || []), i.lineDashOffset = c.borderDashOffset, i.beginPath(), i.moveTo(l.x, l.y), i.lineTo(h.x, h.y), i.stroke(), i.restore());
    };
    if (e.display)
      for (n = 0, a = s.length; n < a; ++n) {
        const l = s[n];
        e.drawOnChartArea && r({
          x: l.x1,
          y: l.y1
        }, {
          x: l.x2,
          y: l.y2
        }, l), e.drawTicks && r({
          x: l.tx1,
          y: l.ty1
        }, {
          x: l.tx2,
          y: l.ty2
        }, {
          color: l.tickColor,
          width: l.tickWidth,
          borderDash: l.tickBorderDash,
          borderDashOffset: l.tickBorderDashOffset
        });
      }
  }
  drawBorder() {
    const { chart: t, ctx: e, options: { border: i, grid: s } } = this, n = i.setContext(this.getContext()), a = i.display ? n.width : 0;
    if (!a)
      return;
    const r = s.setContext(this.getContext(0)).lineWidth, l = this._borderValue;
    let h, c, d, u;
    this.isHorizontal() ? (h = dt(t, this.left, a) - a / 2, c = dt(t, this.right, r) + r / 2, d = u = l) : (d = dt(t, this.top, a) - a / 2, u = dt(t, this.bottom, r) + r / 2, h = c = l), e.save(), e.lineWidth = n.width, e.strokeStyle = n.color, e.beginPath(), e.moveTo(h, d), e.lineTo(c, u), e.stroke(), e.restore();
  }
  drawLabels(t) {
    if (!this.options.ticks.display)
      return;
    const i = this.ctx, s = this._computeLabelArea();
    s && be(i, s);
    const n = this.getLabelItems(t);
    for (const a of n) {
      const r = a.options, l = a.font, h = a.label, c = a.textOffset;
      Tt(i, h, 0, c, l, r);
    }
    s && xe(i);
  }
  drawTitle() {
    const { ctx: t, options: { position: e, title: i, reverse: s } } = this;
    if (!i.display)
      return;
    const n = V(i.font), a = G(i.padding), r = i.align;
    let l = n.lineHeight / 2;
    e === "bottom" || e === "center" || F(e) ? (l += a.bottom, J(i.text) && (l += n.lineHeight * (i.text.length - 1))) : l += a.top;
    const { titleX: h, titleY: c, maxWidth: d, rotation: u } = In(this, l, e, r);
    Tt(t, i.text, 0, 0, n, {
      color: i.color,
      maxWidth: d,
      rotation: u,
      textAlign: zn(r, e, s),
      textBaseline: "middle",
      translation: [
        h,
        c
      ]
    });
  }
  draw(t) {
    this._isVisible() && (this.drawBackground(), this.drawGrid(t), this.drawBorder(), this.drawTitle(), this.drawLabels(t));
  }
  _layers() {
    const t = this.options, e = t.ticks && t.ticks.z || 0, i = O(t.grid && t.grid.z, -1), s = O(t.border && t.border.z, 0);
    return !this._isVisible() || this.draw !== kt.prototype.draw ? [
      {
        z: e,
        draw: (n) => {
          this.draw(n);
        }
      }
    ] : [
      {
        z: i,
        draw: (n) => {
          this.drawBackground(), this.drawGrid(n), this.drawTitle();
        }
      },
      {
        z: s,
        draw: () => {
          this.drawBorder();
        }
      },
      {
        z: e,
        draw: (n) => {
          this.drawLabels(n);
        }
      }
    ];
  }
  getMatchingVisibleMetas(t) {
    const e = this.chart.getSortedVisibleDatasetMetas(), i = this.axis + "AxisID", s = [];
    let n, a;
    for (n = 0, a = e.length; n < a; ++n) {
      const r = e[n];
      r[i] === this.id && (!t || r.type === t) && s.push(r);
    }
    return s;
  }
  _resolveTickFontOptions(t) {
    const e = this.options.ticks.setContext(this.getContext(t));
    return V(e.font);
  }
  _maxDigits() {
    const t = this._resolveTickFontOptions(0).lineHeight;
    return (this.isHorizontal() ? this.width : this.height) / t;
  }
}
class Ht {
  constructor(t, e, i) {
    this.type = t, this.scope = e, this.override = i, this.items = /* @__PURE__ */ Object.create(null);
  }
  isForType(t) {
    return Object.prototype.isPrototypeOf.call(this.type.prototype, t.prototype);
  }
  register(t) {
    const e = Object.getPrototypeOf(t);
    let i;
    Hn(e) && (i = this.register(e));
    const s = this.items, n = t.id, a = this.scope + "." + n;
    if (!n)
      throw new Error("class does not have id: " + t);
    return n in s || (s[n] = t, Fn(t, a, i), this.override && I.override(t.id, t.overrides)), a;
  }
  get(t) {
    return this.items[t];
  }
  unregister(t) {
    const e = this.items, i = t.id, s = this.scope;
    i in e && delete e[i], s && i in I[s] && (delete I[s][i], this.override && delete yt[i]);
  }
}
function Fn(o, t, e) {
  const i = Ds(/* @__PURE__ */ Object.create(null), [
    e ? I.get(e) : {},
    I.get(t),
    o.defaults
  ]);
  I.set(t, i), o.defaultRoutes && Bn(t, o.defaultRoutes), o.descriptors && I.describe(t, o.descriptors);
}
function Bn(o, t) {
  Object.keys(t).forEach((e) => {
    const i = e.split("."), s = i.pop(), n = [
      o
    ].concat(i).join("."), a = t[e].split("."), r = a.pop(), l = a.join(".");
    I.route(n, s, l, r);
  });
}
function Hn(o) {
  return "id" in o && "defaults" in o;
}
class Wn {
  constructor() {
    this.controllers = new Ht(ke, "datasets", !0), this.elements = new Ht(rt, "elements"), this.plugins = new Ht(Object, "plugins"), this.scales = new Ht(kt, "scales"), this._typedRegistries = [
      this.controllers,
      this.scales,
      this.elements
    ];
  }
  add(...t) {
    this._each("register", t);
  }
  remove(...t) {
    this._each("unregister", t);
  }
  addControllers(...t) {
    this._each("register", t, this.controllers);
  }
  addElements(...t) {
    this._each("register", t, this.elements);
  }
  addPlugins(...t) {
    this._each("register", t, this.plugins);
  }
  addScales(...t) {
    this._each("register", t, this.scales);
  }
  getController(t) {
    return this._get(t, this.controllers, "controller");
  }
  getElement(t) {
    return this._get(t, this.elements, "element");
  }
  getPlugin(t) {
    return this._get(t, this.plugins, "plugin");
  }
  getScale(t) {
    return this._get(t, this.scales, "scale");
  }
  removeControllers(...t) {
    this._each("unregister", t, this.controllers);
  }
  removeElements(...t) {
    this._each("unregister", t, this.elements);
  }
  removePlugins(...t) {
    this._each("unregister", t, this.plugins);
  }
  removeScales(...t) {
    this._each("unregister", t, this.scales);
  }
  _each(t, e, i) {
    [
      ...e
    ].forEach((s) => {
      const n = i || this._getRegistryForType(s);
      i || n.isForType(s) || n === this.plugins && s.id ? this._exec(t, n, s) : P(s, (a) => {
        const r = i || this._getRegistryForType(a);
        this._exec(t, r, a);
      });
    });
  }
  _exec(t, e, i) {
    const s = ls(t);
    T(i["before" + s], [], i), e[t](i), T(i["after" + s], [], i);
  }
  _getRegistryForType(t) {
    for (let e = 0; e < this._typedRegistries.length; e++) {
      const i = this._typedRegistries[e];
      if (i.isForType(t))
        return i;
    }
    return this.plugins;
  }
  _get(t, e, i) {
    const s = e.get(t);
    if (s === void 0)
      throw new Error('"' + t + '" is not a registered ' + i + ".");
    return s;
  }
}
var tt = /* @__PURE__ */ new Wn();
class Vn {
  constructor() {
    this._init = [];
  }
  notify(t, e, i, s) {
    e === "beforeInit" && (this._init = this._createDescriptors(t, !0), this._notify(this._init, t, "install"));
    const n = s ? this._descriptors(t).filter(s) : this._descriptors(t), a = this._notify(n, t, e, i);
    return e === "afterDestroy" && (this._notify(n, t, "stop"), this._notify(this._init, t, "uninstall")), a;
  }
  _notify(t, e, i, s) {
    s = s || {};
    for (const n of t) {
      const a = n.plugin, r = a[i], l = [
        e,
        s,
        n.options
      ];
      if (T(r, l, a) === !1 && s.cancelable)
        return !1;
    }
    return !0;
  }
  invalidate() {
    z(this._cache) || (this._oldCache = this._cache, this._cache = void 0);
  }
  _descriptors(t) {
    if (this._cache)
      return this._cache;
    const e = this._cache = this._createDescriptors(t);
    return this._notifyStateChanges(t), e;
  }
  _createDescriptors(t, e) {
    const i = t && t.config, s = O(i.options && i.options.plugins, {}), n = Nn(i);
    return s === !1 && !e ? [] : $n(t, n, s, e);
  }
  _notifyStateChanges(t) {
    const e = this._oldCache || [], i = this._cache, s = (n, a) => n.filter((r) => !a.some((l) => r.plugin.id === l.plugin.id));
    this._notify(s(e, i), t, "stop"), this._notify(s(i, e), t, "start");
  }
}
function Nn(o) {
  const t = {}, e = [], i = Object.keys(tt.plugins.items);
  for (let n = 0; n < i.length; n++)
    e.push(tt.getPlugin(i[n]));
  const s = o.plugins || [];
  for (let n = 0; n < s.length; n++) {
    const a = s[n];
    e.indexOf(a) === -1 && (e.push(a), t[a.id] = !0);
  }
  return {
    plugins: e,
    localIds: t
  };
}
function jn(o, t) {
  return !t && o === !1 ? null : o === !0 ? {} : o;
}
function $n(o, { plugins: t, localIds: e }, i, s) {
  const n = [], a = o.getContext();
  for (const r of t) {
    const l = r.id, h = jn(i[l], s);
    h !== null && n.push({
      plugin: r,
      options: Yn(o.config, {
        plugin: r,
        local: e[l]
      }, h, a)
    });
  }
  return n;
}
function Yn(o, { plugin: t, local: e }, i, s) {
  const n = o.pluginScopeKeys(t), a = o.getOptionScopes(i, n);
  return e && t.defaults && a.push(t.defaults), o.createResolver(a, s, [
    ""
  ], {
    scriptable: !1,
    indexable: !1,
    allKeys: !0
  });
}
function pe(o, t) {
  const e = I.datasets[o] || {};
  return ((t.datasets || {})[o] || {}).indexAxis || t.indexAxis || e.indexAxis || "x";
}
function Un(o, t) {
  let e = o;
  return o === "_index_" ? e = t : o === "_value_" && (e = t === "x" ? "y" : "x"), e;
}
function Xn(o, t) {
  return o === t ? "_index_" : "_value_";
}
function Qe(o) {
  if (o === "x" || o === "y" || o === "r")
    return o;
}
function Kn(o) {
  if (o === "top" || o === "bottom")
    return "x";
  if (o === "left" || o === "right")
    return "y";
}
function me(o, ...t) {
  if (Qe(o))
    return o;
  for (const e of t) {
    const i = e.axis || Kn(e.position) || o.length > 1 && Qe(o[0].toLowerCase());
    if (i)
      return i;
  }
  throw new Error(`Cannot determine type of '${o}' axis. Please provide 'axis' or 'position' option.`);
}
function Ze(o, t, e) {
  if (e[t + "AxisID"] === o)
    return {
      axis: t
    };
}
function Gn(o, t) {
  if (t.data && t.data.datasets) {
    const e = t.data.datasets.filter((i) => i.xAxisID === o || i.yAxisID === o);
    if (e.length)
      return Ze(o, "x", e[0]) || Ze(o, "y", e[0]);
  }
  return {};
}
function qn(o, t) {
  const e = yt[o.type] || {
    scales: {}
  }, i = t.scales || {}, s = pe(o.type, t), n = /* @__PURE__ */ Object.create(null);
  return Object.keys(i).forEach((a) => {
    const r = i[a];
    if (!F(r))
      return console.error(`Invalid scale configuration for scale: ${a}`);
    if (r._proxy)
      return console.warn(`Ignoring resolver passed as options for scale: ${a}`);
    const l = me(a, r, Gn(a, o), I.scales[r.type]), h = Xn(l, s), c = e.scales || {};
    n[a] = jt(/* @__PURE__ */ Object.create(null), [
      {
        axis: l
      },
      r,
      c[l],
      c[h]
    ]);
  }), o.data.datasets.forEach((a) => {
    const r = a.type || o.type, l = a.indexAxis || pe(r, t), c = (yt[r] || {}).scales || {};
    Object.keys(c).forEach((d) => {
      const u = Un(d, l), f = a[u + "AxisID"] || u;
      n[f] = n[f] || /* @__PURE__ */ Object.create(null), jt(n[f], [
        {
          axis: u
        },
        i[f],
        c[d]
      ]);
    });
  }), Object.keys(n).forEach((a) => {
    const r = n[a];
    jt(r, [
      I.scales[r.type],
      I.scale
    ]);
  }), n;
}
function Bi(o) {
  const t = o.options || (o.options = {});
  t.plugins = O(t.plugins, {}), t.scales = qn(o, t);
}
function Hi(o) {
  return o = o || {}, o.datasets = o.datasets || [], o.labels = o.labels || [], o;
}
function Jn(o) {
  return o = o || {}, o.data = Hi(o.data), Bi(o), o;
}
const ti = /* @__PURE__ */ new Map(), Wi = /* @__PURE__ */ new Set();
function Wt(o, t) {
  let e = ti.get(o);
  return e || (e = t(), ti.set(o, e), Wi.add(e)), e;
}
const Pt = (o, t, e) => {
  const i = qt(t, e);
  i !== void 0 && o.add(i);
};
class Qn {
  constructor(t) {
    this._config = Jn(t), this._scopeCache = /* @__PURE__ */ new Map(), this._resolverCache = /* @__PURE__ */ new Map();
  }
  get platform() {
    return this._config.platform;
  }
  get type() {
    return this._config.type;
  }
  set type(t) {
    this._config.type = t;
  }
  get data() {
    return this._config.data;
  }
  set data(t) {
    this._config.data = Hi(t);
  }
  get options() {
    return this._config.options;
  }
  set options(t) {
    this._config.options = t;
  }
  get plugins() {
    return this._config.plugins;
  }
  update() {
    const t = this._config;
    this.clearCache(), Bi(t);
  }
  clearCache() {
    this._scopeCache.clear(), this._resolverCache.clear();
  }
  datasetScopeKeys(t) {
    return Wt(t, () => [
      [
        `datasets.${t}`,
        ""
      ]
    ]);
  }
  datasetAnimationScopeKeys(t, e) {
    return Wt(`${t}.transition.${e}`, () => [
      [
        `datasets.${t}.transitions.${e}`,
        `transitions.${e}`
      ],
      [
        `datasets.${t}`,
        ""
      ]
    ]);
  }
  datasetElementScopeKeys(t, e) {
    return Wt(`${t}-${e}`, () => [
      [
        `datasets.${t}.elements.${e}`,
        `datasets.${t}`,
        `elements.${e}`,
        ""
      ]
    ]);
  }
  pluginScopeKeys(t) {
    const e = t.id, i = this.type;
    return Wt(`${i}-plugin-${e}`, () => [
      [
        `plugins.${e}`,
        ...t.additionalOptionScopes || []
      ]
    ]);
  }
  _cachedScopes(t, e) {
    const i = this._scopeCache;
    let s = i.get(t);
    return (!s || e) && (s = /* @__PURE__ */ new Map(), i.set(t, s)), s;
  }
  getOptionScopes(t, e, i) {
    const { options: s, type: n } = this, a = this._cachedScopes(t, i), r = a.get(e);
    if (r)
      return r;
    const l = /* @__PURE__ */ new Set();
    e.forEach((c) => {
      t && (l.add(t), c.forEach((d) => Pt(l, t, d))), c.forEach((d) => Pt(l, s, d)), c.forEach((d) => Pt(l, yt[n] || {}, d)), c.forEach((d) => Pt(l, I, d)), c.forEach((d) => Pt(l, Ce, d));
    });
    const h = Array.from(l);
    return h.length === 0 && h.push(/* @__PURE__ */ Object.create(null)), Wi.has(e) && a.set(e, h), h;
  }
  chartOptionScopes() {
    const { options: t, type: e } = this;
    return [
      t,
      yt[e] || {},
      I.datasets[e] || {},
      {
        type: e
      },
      I,
      Ce
    ];
  }
  resolveNamedOptions(t, e, i, s = [
    ""
  ]) {
    const n = {
      $shared: !0
    }, { resolver: a, subPrefixes: r } = ei(this._resolverCache, t, s);
    let l = a;
    if (to(a, e)) {
      n.$shared = !1, i = te(i) ? i() : i;
      const h = this.createResolver(t, i, r);
      l = Ae(a, i, h);
    }
    for (const h of e)
      n[h] = l[h];
    return n;
  }
  createResolver(t, e, i = [
    ""
  ], s) {
    const { resolver: n } = ei(this._resolverCache, t, i);
    return F(e) ? Ae(n, e, void 0, s) : n;
  }
}
function ei(o, t, e) {
  let i = o.get(t);
  i || (i = /* @__PURE__ */ new Map(), o.set(t, i));
  const s = e.join();
  let n = i.get(s);
  return n || (n = {
    resolver: ks(t, e),
    subPrefixes: e.filter((r) => !r.toLowerCase().includes("hover"))
  }, i.set(s, n)), n;
}
const Zn = (o) => F(o) && Object.getOwnPropertyNames(o).some((t) => te(o[t]));
function to(o, t) {
  const { isScriptable: e, isIndexable: i } = ws(o);
  for (const s of t) {
    const n = e(s), a = i(s), r = (a || n) && o[s];
    if (n && (te(r) || Zn(r)) || a && J(r))
      return !0;
  }
  return !1;
}
var eo = "4.5.0";
const io = [
  "top",
  "bottom",
  "left",
  "right",
  "chartArea"
];
function ii(o, t) {
  return o === "top" || o === "bottom" || io.indexOf(o) === -1 && t === "x";
}
function si(o, t) {
  return function(e, i) {
    return e[o] === i[o] ? e[t] - i[t] : e[o] - i[o];
  };
}
function ni(o) {
  const t = o.chart, e = t.options.animation;
  t.notifyPlugins("afterRender"), T(e && e.onComplete, [
    o
  ], t);
}
function so(o) {
  const t = o.chart, e = t.options.animation;
  T(e && e.onProgress, [
    o
  ], t);
}
function Vi(o) {
  return Ci() && typeof o == "string" ? o = document.getElementById(o) : o && o.length && (o = o[0]), o && o.canvas && (o = o.canvas), o;
}
const Yt = {}, oi = (o) => {
  const t = Vi(o);
  return Object.values(Yt).filter((e) => e.canvas === t).pop();
};
function no(o, t, e) {
  const i = Object.keys(o);
  for (const s of i) {
    const n = +s;
    if (n >= t) {
      const a = o[s];
      delete o[s], (e > 0 || n > t) && (o[n + e] = a);
    }
  }
}
function oo(o, t, e, i) {
  return !e || o.type === "mouseout" ? null : i ? t : o;
}
class ao {
  static defaults = I;
  static instances = Yt;
  static overrides = yt;
  static registry = tt;
  static version = eo;
  static getChart = oi;
  static register(...t) {
    tt.add(...t), ai();
  }
  static unregister(...t) {
    tt.remove(...t), ai();
  }
  constructor(t, e) {
    const i = this.config = new Qn(e), s = Vi(t), n = oi(s);
    if (n)
      throw new Error("Canvas is already in use. Chart with ID '" + n.id + "' must be destroyed before the canvas with ID '" + n.canvas.id + "' can be reused.");
    const a = i.createResolver(i.chartOptionScopes(), this.getContext());
    this.platform = new (i.platform || wn(s))(), this.platform.updateConfig(i);
    const r = this.platform.acquireContext(s, a.aspectRatio), l = r && r.canvas, h = l && l.height, c = l && l.width;
    if (this.id = Ki(), this.ctx = r, this.canvas = l, this.width = c, this.height = h, this._options = a, this._aspectRatio = this.aspectRatio, this._layers = [], this._metasets = [], this._stacks = void 0, this.boxes = [], this.currentDevicePixelRatio = void 0, this.chartArea = void 0, this._active = [], this._lastEvent = void 0, this._listeners = {}, this._responsiveListeners = void 0, this._sortedMetasets = [], this.scales = {}, this._plugins = new Vn(), this.$proxies = {}, this._hiddenIndices = {}, this.attached = !1, this._animationsDisabled = void 0, this.$context = void 0, this._doResize = Gi((d) => this.update(d), a.resizeDelay || 0), this._dataChanges = [], Yt[this.id] = this, !r || !l) {
      console.error("Failed to create chart: can't acquire context from the given item");
      return;
    }
    nt.listen(this, "complete", ni), nt.listen(this, "progress", so), this._initialize(), this.attached && this.update();
  }
  get aspectRatio() {
    const { options: { aspectRatio: t, maintainAspectRatio: e }, width: i, height: s, _aspectRatio: n } = this;
    return z(t) ? e && n ? n : s ? i / s : null : t;
  }
  get data() {
    return this.config.data;
  }
  set data(t) {
    this.config.data = t;
  }
  get options() {
    return this._options;
  }
  set options(t) {
    this.config.options = t;
  }
  get registry() {
    return tt;
  }
  _initialize() {
    return this.notifyPlugins("beforeInit"), this.options.responsive ? this.resize() : Me(this, this.options.devicePixelRatio), this.bindEvents(), this.notifyPlugins("afterInit"), this;
  }
  clear() {
    return Se(this.canvas, this.ctx), this;
  }
  stop() {
    return nt.stop(this), this;
  }
  resize(t, e) {
    nt.running(this) ? this._resizeBeforeDraw = {
      width: t,
      height: e
    } : this._resize(t, e);
  }
  _resize(t, e) {
    const i = this.options, s = this.canvas, n = i.maintainAspectRatio && this.aspectRatio, a = this.platform.getMaximumSize(s, t, e, n), r = i.devicePixelRatio || this.platform.getDevicePixelRatio(), l = this.width ? "resize" : "attach";
    this.width = a.width, this.height = a.height, this._aspectRatio = this.aspectRatio, Me(this, r, !0) && (this.notifyPlugins("resize", {
      size: a
    }), T(i.onResize, [
      this,
      a
    ], this), this.attached && this._doResize(l) && this.render());
  }
  ensureScalesHaveIDs() {
    const e = this.options.scales || {};
    P(e, (i, s) => {
      i.id = s;
    });
  }
  buildOrUpdateScales() {
    const t = this.options, e = t.scales, i = this.scales, s = Object.keys(i).reduce((a, r) => (a[r] = !1, a), {});
    let n = [];
    e && (n = n.concat(Object.keys(e).map((a) => {
      const r = e[a], l = me(a, r), h = l === "r", c = l === "x";
      return {
        options: r,
        dposition: h ? "chartArea" : c ? "bottom" : "left",
        dtype: h ? "radialLinear" : c ? "category" : "linear"
      };
    }))), P(n, (a) => {
      const r = a.options, l = r.id, h = me(l, r), c = O(r.type, a.dtype);
      (r.position === void 0 || ii(r.position, h) !== ii(a.dposition)) && (r.position = a.dposition), s[l] = !0;
      let d = null;
      if (l in i && i[l].type === c)
        d = i[l];
      else {
        const u = tt.getScale(c);
        d = new u({
          id: l,
          type: c,
          ctx: this.ctx,
          chart: this
        }), i[d.id] = d;
      }
      d.init(r, t);
    }), P(s, (a, r) => {
      a || delete i[r];
    }), P(i, (a) => {
      K.configure(this, a, a.options), K.addBox(this, a);
    });
  }
  _updateMetasets() {
    const t = this._metasets, e = this.data.datasets.length, i = t.length;
    if (t.sort((s, n) => s.index - n.index), i > e) {
      for (let s = e; s < i; ++s)
        this._destroyDatasetMeta(s);
      t.splice(e, i - e);
    }
    this._sortedMetasets = t.slice(0).sort(si("order", "index"));
  }
  _removeUnreferencedMetasets() {
    const { _metasets: t, data: { datasets: e } } = this;
    t.length > e.length && delete this._stacks, t.forEach((i, s) => {
      e.filter((n) => n === i._dataset).length === 0 && this._destroyDatasetMeta(s);
    });
  }
  buildOrUpdateControllers() {
    const t = [], e = this.data.datasets;
    let i, s;
    for (this._removeUnreferencedMetasets(), i = 0, s = e.length; i < s; i++) {
      const n = e[i];
      let a = this.getDatasetMeta(i);
      const r = n.type || this.config.type;
      if (a.type && a.type !== r && (this._destroyDatasetMeta(i), a = this.getDatasetMeta(i)), a.type = r, a.indexAxis = n.indexAxis || pe(r, this.options), a.order = n.order || 0, a.index = i, a.label = "" + n.label, a.visible = this.isDatasetVisible(i), a.controller)
        a.controller.updateIndex(i), a.controller.linkScales();
      else {
        const l = tt.getController(r), { datasetElementType: h, dataElementType: c } = I.datasets[r];
        Object.assign(l, {
          dataElementType: tt.getElement(c),
          datasetElementType: h && tt.getElement(h)
        }), a.controller = new l(this, i), t.push(a.controller);
      }
    }
    return this._updateMetasets(), t;
  }
  _resetElements() {
    P(this.data.datasets, (t, e) => {
      this.getDatasetMeta(e).controller.reset();
    }, this);
  }
  reset() {
    this._resetElements(), this.notifyPlugins("reset");
  }
  update(t) {
    const e = this.config;
    e.update();
    const i = this._options = e.createResolver(e.chartOptionScopes(), this.getContext()), s = this._animationsDisabled = !i.animation;
    if (this._updateScales(), this._checkEventBindings(), this._updateHiddenIndices(), this._plugins.invalidate(), this.notifyPlugins("beforeUpdate", {
      mode: t,
      cancelable: !0
    }) === !1)
      return;
    const n = this.buildOrUpdateControllers();
    this.notifyPlugins("beforeElementsUpdate");
    let a = 0;
    for (let h = 0, c = this.data.datasets.length; h < c; h++) {
      const { controller: d } = this.getDatasetMeta(h), u = !s && n.indexOf(d) === -1;
      d.buildOrUpdateElements(u), a = Math.max(+d.getMaxOverflow(), a);
    }
    a = this._minPadding = i.layout.autoPadding ? a : 0, this._updateLayout(a), s || P(n, (h) => {
      h.reset();
    }), this._updateDatasets(t), this.notifyPlugins("afterUpdate", {
      mode: t
    }), this._layers.sort(si("z", "_idx"));
    const { _active: r, _lastEvent: l } = this;
    l ? this._eventHandler(l, !0) : r.length && this._updateHoverStyles(r, r, !0), this.render();
  }
  _updateScales() {
    P(this.scales, (t) => {
      K.removeBox(this, t);
    }), this.ensureScalesHaveIDs(), this.buildOrUpdateScales();
  }
  _checkEventBindings() {
    const t = this.options, e = new Set(Object.keys(this._listeners)), i = new Set(t.events);
    (!De(e, i) || !!this._responsiveListeners !== t.responsive) && (this.unbindEvents(), this.bindEvents());
  }
  _updateHiddenIndices() {
    const { _hiddenIndices: t } = this, e = this._getUniformDataChanges() || [];
    for (const { method: i, start: s, count: n } of e) {
      const a = i === "_removeElements" ? -n : n;
      no(t, s, a);
    }
  }
  _getUniformDataChanges() {
    const t = this._dataChanges;
    if (!t || !t.length)
      return;
    this._dataChanges = [];
    const e = this.data.datasets.length, i = (n) => new Set(t.filter((a) => a[0] === n).map((a, r) => r + "," + a.splice(1).join(","))), s = i(0);
    for (let n = 1; n < e; n++)
      if (!De(s, i(n)))
        return;
    return Array.from(s).map((n) => n.split(",")).map((n) => ({
      method: n[1],
      start: +n[2],
      count: +n[3]
    }));
  }
  _updateLayout(t) {
    if (this.notifyPlugins("beforeLayout", {
      cancelable: !0
    }) === !1)
      return;
    K.update(this, this.width, this.height, t);
    const e = this.chartArea, i = e.width <= 0 || e.height <= 0;
    this._layers = [], P(this.boxes, (s) => {
      i && s.position === "chartArea" || (s.configure && s.configure(), this._layers.push(...s._layers()));
    }, this), this._layers.forEach((s, n) => {
      s._idx = n;
    }), this.notifyPlugins("afterLayout");
  }
  _updateDatasets(t) {
    if (this.notifyPlugins("beforeDatasetsUpdate", {
      mode: t,
      cancelable: !0
    }) !== !1) {
      for (let e = 0, i = this.data.datasets.length; e < i; ++e)
        this.getDatasetMeta(e).controller.configure();
      for (let e = 0, i = this.data.datasets.length; e < i; ++e)
        this._updateDataset(e, te(t) ? t({
          datasetIndex: e
        }) : t);
      this.notifyPlugins("afterDatasetsUpdate", {
        mode: t
      });
    }
  }
  _updateDataset(t, e) {
    const i = this.getDatasetMeta(t), s = {
      meta: i,
      index: t,
      mode: e,
      cancelable: !0
    };
    this.notifyPlugins("beforeDatasetUpdate", s) !== !1 && (i.controller._update(e), s.cancelable = !1, this.notifyPlugins("afterDatasetUpdate", s));
  }
  render() {
    this.notifyPlugins("beforeRender", {
      cancelable: !0
    }) !== !1 && (nt.has(this) ? this.attached && !nt.running(this) && nt.start(this) : (this.draw(), ni({
      chart: this
    })));
  }
  draw() {
    let t;
    if (this._resizeBeforeDraw) {
      const { width: i, height: s } = this._resizeBeforeDraw;
      this._resizeBeforeDraw = null, this._resize(i, s);
    }
    if (this.clear(), this.width <= 0 || this.height <= 0 || this.notifyPlugins("beforeDraw", {
      cancelable: !0
    }) === !1)
      return;
    const e = this._layers;
    for (t = 0; t < e.length && e[t].z <= 0; ++t)
      e[t].draw(this.chartArea);
    for (this._drawDatasets(); t < e.length; ++t)
      e[t].draw(this.chartArea);
    this.notifyPlugins("afterDraw");
  }
  _getSortedDatasetMetas(t) {
    const e = this._sortedMetasets, i = [];
    let s, n;
    for (s = 0, n = e.length; s < n; ++s) {
      const a = e[s];
      (!t || a.visible) && i.push(a);
    }
    return i;
  }
  getSortedVisibleDatasetMetas() {
    return this._getSortedDatasetMetas(!0);
  }
  _drawDatasets() {
    if (this.notifyPlugins("beforeDatasetsDraw", {
      cancelable: !0
    }) === !1)
      return;
    const t = this.getSortedVisibleDatasetMetas();
    for (let e = t.length - 1; e >= 0; --e)
      this._drawDataset(t[e]);
    this.notifyPlugins("afterDatasetsDraw");
  }
  _drawDataset(t) {
    const e = this.ctx, i = {
      meta: t,
      index: t.index,
      cancelable: !0
    }, s = qi(this, t);
    this.notifyPlugins("beforeDatasetDraw", i) !== !1 && (s && be(e, s), t.controller.draw(), s && xe(e), i.cancelable = !1, this.notifyPlugins("afterDatasetDraw", i));
  }
  isPointInArea(t) {
    return ye(t, this.chartArea, this._minPadding);
  }
  getElementsAtEventForMode(t, e, i, s) {
    const n = en.modes[e];
    return typeof n == "function" ? n(this, t, i, s) : [];
  }
  getDatasetMeta(t) {
    const e = this.data.datasets[t], i = this._metasets;
    let s = i.filter((n) => n && n._dataset === e).pop();
    return s || (s = {
      type: null,
      data: [],
      dataset: null,
      controller: null,
      hidden: null,
      xAxisID: null,
      yAxisID: null,
      order: e && e.order || 0,
      index: t,
      _dataset: e,
      _parsed: [],
      _sorted: !1
    }, i.push(s)), s;
  }
  getContext() {
    return this.$context || (this.$context = vt(null, {
      chart: this,
      type: "chart"
    }));
  }
  getVisibleDatasetCount() {
    return this.getSortedVisibleDatasetMetas().length;
  }
  isDatasetVisible(t) {
    const e = this.data.datasets[t];
    if (!e)
      return !1;
    const i = this.getDatasetMeta(t);
    return typeof i.hidden == "boolean" ? !i.hidden : !e.hidden;
  }
  setDatasetVisibility(t, e) {
    const i = this.getDatasetMeta(t);
    i.hidden = !e;
  }
  toggleDataVisibility(t) {
    this._hiddenIndices[t] = !this._hiddenIndices[t];
  }
  getDataVisibility(t) {
    return !this._hiddenIndices[t];
  }
  _updateVisibility(t, e, i) {
    const s = i ? "show" : "hide", n = this.getDatasetMeta(t), a = n.controller._resolveAnimations(void 0, s);
    Ut(e) ? (n.data[e].hidden = !i, this.update()) : (this.setDatasetVisibility(t, i), a.update(n, {
      visible: i
    }), this.update((r) => r.datasetIndex === t ? s : void 0));
  }
  hide(t, e) {
    this._updateVisibility(t, e, !1);
  }
  show(t, e) {
    this._updateVisibility(t, e, !0);
  }
  _destroyDatasetMeta(t) {
    const e = this._metasets[t];
    e && e.controller && e.controller._destroy(), delete this._metasets[t];
  }
  _stop() {
    let t, e;
    for (this.stop(), nt.remove(this), t = 0, e = this.data.datasets.length; t < e; ++t)
      this._destroyDatasetMeta(t);
  }
  destroy() {
    this.notifyPlugins("beforeDestroy");
    const { canvas: t, ctx: e } = this;
    this._stop(), this.config.clearCache(), t && (this.unbindEvents(), Se(t, e), this.platform.releaseContext(e), this.canvas = null, this.ctx = null), delete Yt[this.id], this.notifyPlugins("afterDestroy");
  }
  toBase64Image(...t) {
    return this.canvas.toDataURL(...t);
  }
  bindEvents() {
    this.bindUserEvents(), this.options.responsive ? this.bindResponsiveEvents() : this.attached = !0;
  }
  bindUserEvents() {
    const t = this._listeners, e = this.platform, i = (n, a) => {
      e.addEventListener(this, n, a), t[n] = a;
    }, s = (n, a, r) => {
      n.offsetX = a, n.offsetY = r, this._eventHandler(n);
    };
    P(this.options.events, (n) => i(n, s));
  }
  bindResponsiveEvents() {
    this._responsiveListeners || (this._responsiveListeners = {});
    const t = this._responsiveListeners, e = this.platform, i = (l, h) => {
      e.addEventListener(this, l, h), t[l] = h;
    }, s = (l, h) => {
      t[l] && (e.removeEventListener(this, l, h), delete t[l]);
    }, n = (l, h) => {
      this.canvas && this.resize(l, h);
    };
    let a;
    const r = () => {
      s("attach", r), this.attached = !0, this.resize(), i("resize", n), i("detach", a);
    };
    a = () => {
      this.attached = !1, s("resize", n), this._stop(), this._resize(0, 0), i("attach", r);
    }, e.isAttached(this.canvas) ? r() : a();
  }
  unbindEvents() {
    P(this._listeners, (t, e) => {
      this.platform.removeEventListener(this, e, t);
    }), this._listeners = {}, P(this._responsiveListeners, (t, e) => {
      this.platform.removeEventListener(this, e, t);
    }), this._responsiveListeners = void 0;
  }
  updateHoverStyle(t, e, i) {
    const s = i ? "set" : "remove";
    let n, a, r, l;
    for (e === "dataset" && (n = this.getDatasetMeta(t[0].datasetIndex), n.controller["_" + s + "DatasetHoverStyle"]()), r = 0, l = t.length; r < l; ++r) {
      a = t[r];
      const h = a && this.getDatasetMeta(a.datasetIndex).controller;
      h && h[s + "HoverStyle"](a.element, a.datasetIndex, a.index);
    }
  }
  getActiveElements() {
    return this._active || [];
  }
  setActiveElements(t) {
    const e = this._active || [], i = t.map(({ datasetIndex: n, index: a }) => {
      const r = this.getDatasetMeta(n);
      if (!r)
        throw new Error("No dataset found at index " + n);
      return {
        datasetIndex: n,
        element: r.data[a],
        index: a
      };
    });
    !Xt(i, e) && (this._active = i, this._lastEvent = null, this._updateHoverStyles(i, e));
  }
  notifyPlugins(t, e, i) {
    return this._plugins.notify(this, t, e, i);
  }
  isPluginEnabled(t) {
    return this._plugins._cache.filter((e) => e.plugin.id === t).length === 1;
  }
  _updateHoverStyles(t, e, i) {
    const s = this.options.hover, n = (l, h) => l.filter((c) => !h.some((d) => c.datasetIndex === d.datasetIndex && c.index === d.index)), a = n(e, t), r = i ? t : n(t, e);
    a.length && this.updateHoverStyle(a, s.mode, !1), r.length && s.mode && this.updateHoverStyle(r, s.mode, !0);
  }
  _eventHandler(t, e) {
    const i = {
      event: t,
      replay: e,
      cancelable: !0,
      inChartArea: this.isPointInArea(t)
    }, s = (a) => (a.options.events || this.options.events).includes(t.native.type);
    if (this.notifyPlugins("beforeEvent", i, s) === !1)
      return;
    const n = this._handleEvent(t, e, i.inChartArea);
    return i.cancelable = !1, this.notifyPlugins("afterEvent", i, s), (n || i.changed) && this.render(), this;
  }
  _handleEvent(t, e, i) {
    const { _active: s = [], options: n } = this, a = e, r = this._getActiveElements(t, s, i, a), l = Ji(t), h = oo(t, this._lastEvent, i, l);
    i && (this._lastEvent = null, T(n.onHover, [
      t,
      r,
      this
    ], this), l && T(n.onClick, [
      t,
      r,
      this
    ], this));
    const c = !Xt(r, s);
    return (c || e) && (this._active = r, this._updateHoverStyles(r, s, e)), this._lastEvent = h, c;
  }
  _getActiveElements(t, e, i, s) {
    if (t.type === "mouseout")
      return [];
    if (!i)
      return e;
    const n = this.options.hover;
    return this.getElementsAtEventForMode(t, n.mode, n, s);
  }
}
function ai() {
  return P(ao.instances, (o) => o._plugins.invalidate());
}
function ro(o, t, e) {
  const { startAngle: i, x: s, y: n, outerRadius: a, innerRadius: r, options: l } = t, { borderWidth: h, borderJoinStyle: c } = l, d = Math.min(h / a, ne(i - e));
  if (o.beginPath(), o.arc(s, n, a - h / 2, i + d / 2, e - d / 2), r > 0) {
    const u = Math.min(h / r, ne(i - e));
    o.arc(s, n, r + h / 2, e - u / 2, i + u / 2, !0);
  } else {
    const u = Math.min(h / 2, a * ne(i - e));
    if (c === "round")
      o.arc(s, n, u, e - Y / 2, i + Y / 2, !0);
    else if (c === "bevel") {
      const f = 2 * u * u, g = -f * Math.cos(e + Y / 2) + s, p = -f * Math.sin(e + Y / 2) + n, _ = f * Math.cos(i + Y / 2) + s, m = f * Math.sin(i + Y / 2) + n;
      o.lineTo(g, p), o.lineTo(_, m);
    }
  }
  o.closePath(), o.moveTo(0, 0), o.rect(0, 0, o.canvas.width, o.canvas.height), o.clip("evenodd");
}
function lo(o, t, e) {
  const { startAngle: i, pixelMargin: s, x: n, y: a, outerRadius: r, innerRadius: l } = t;
  let h = s / r;
  o.beginPath(), o.arc(n, a, r, i - h, e + h), l > s ? (h = s / l, o.arc(n, a, l, e + h, i - h, !0)) : o.arc(n, a, s, e + et, i - et), o.closePath(), o.clip();
}
function ho(o) {
  return Ls(o, [
    "outerStart",
    "outerEnd",
    "innerStart",
    "innerEnd"
  ]);
}
function co(o, t, e, i) {
  const s = ho(o.options.borderRadius), n = (e - t) / 2, a = Math.min(n, i * t / 2), r = (l) => {
    const h = (e - Math.min(n, l)) * i / 2;
    return U(l, 0, Math.min(n, h));
  };
  return {
    outerStart: r(s.outerStart),
    outerEnd: r(s.outerEnd),
    innerStart: U(s.innerStart, 0, a),
    innerEnd: U(s.innerEnd, 0, a)
  };
}
function _t(o, t, e, i) {
  return {
    x: e + o * Math.cos(t),
    y: i + o * Math.sin(t)
  };
}
function Zt(o, t, e, i, s, n) {
  const { x: a, y: r, startAngle: l, pixelMargin: h, innerRadius: c } = t, d = Math.max(t.outerRadius + i + e - h, 0), u = c > 0 ? c + i + e + h : 0;
  let f = 0;
  const g = s - l;
  if (i) {
    const L = c > 0 ? c - i : 0, R = d > 0 ? d - i : 0, E = (L + R) / 2, q = E !== 0 ? g * E / (E + i) : g;
    f = (g - q) / 2;
  }
  const p = Math.max(1e-3, g * d - e / Y) / d, _ = (g - p) / 2, m = l + _ + f, x = s - _ - f, { outerStart: v, outerEnd: y, innerStart: b, innerEnd: k } = co(t, u, d, x - m), w = d - v, M = d - y, S = m + v / w, C = x - y / M, D = u + b, A = u + k, B = m + b / D, $ = x - k / A;
  if (o.beginPath(), n) {
    const L = (S + C) / 2;
    if (o.arc(a, r, d, S, L), o.arc(a, r, d, L, C), y > 0) {
      const H = _t(M, C, a, r);
      o.arc(H.x, H.y, y, C, x + et);
    }
    const R = _t(A, x, a, r);
    if (o.lineTo(R.x, R.y), k > 0) {
      const H = _t(A, $, a, r);
      o.arc(H.x, H.y, k, x + et, $ + Math.PI);
    }
    const E = (x - k / u + (m + b / u)) / 2;
    if (o.arc(a, r, u, x - k / u, E, !0), o.arc(a, r, u, E, m + b / u, !0), b > 0) {
      const H = _t(D, B, a, r);
      o.arc(H.x, H.y, b, B + Math.PI, m - et);
    }
    const q = _t(w, m, a, r);
    if (o.lineTo(q.x, q.y), v > 0) {
      const H = _t(w, S, a, r);
      o.arc(H.x, H.y, v, m - et, S);
    }
  } else {
    o.moveTo(a, r);
    const L = Math.cos(S) * d + a, R = Math.sin(S) * d + r;
    o.lineTo(L, R);
    const E = Math.cos(C) * d + a, q = Math.sin(C) * d + r;
    o.lineTo(E, q);
  }
  o.closePath();
}
function uo(o, t, e, i, s) {
  const { fullCircles: n, startAngle: a, circumference: r } = t;
  let l = t.endAngle;
  if (n) {
    Zt(o, t, e, i, l, s);
    for (let h = 0; h < n; ++h)
      o.fill();
    isNaN(r) || (l = a + (r % X || X));
  }
  return Zt(o, t, e, i, l, s), o.fill(), l;
}
function fo(o, t, e, i, s) {
  const { fullCircles: n, startAngle: a, circumference: r, options: l } = t, { borderWidth: h, borderJoinStyle: c, borderDash: d, borderDashOffset: u, borderRadius: f } = l, g = l.borderAlign === "inner";
  if (!h)
    return;
  o.setLineDash(d || []), o.lineDashOffset = u, g ? (o.lineWidth = h * 2, o.lineJoin = c || "round") : (o.lineWidth = h, o.lineJoin = c || "bevel");
  let p = t.endAngle;
  if (n) {
    Zt(o, t, e, i, p, s);
    for (let _ = 0; _ < n; ++_)
      o.stroke();
    isNaN(r) || (p = a + (r % X || X));
  }
  g && lo(o, t, p), l.selfJoin && p - a >= Y && f === 0 && c !== "miter" && ro(o, t, p), n || (Zt(o, t, e, i, p, s), o.stroke());
}
class Qo extends rt {
  static id = "arc";
  static defaults = {
    borderAlign: "center",
    borderColor: "#fff",
    borderDash: [],
    borderDashOffset: 0,
    borderJoinStyle: void 0,
    borderRadius: 0,
    borderWidth: 2,
    offset: 0,
    spacing: 0,
    angle: void 0,
    circular: !0,
    selfJoin: !1
  };
  static defaultRoutes = {
    backgroundColor: "backgroundColor"
  };
  static descriptors = {
    _scriptable: !0,
    _indexable: (t) => t !== "borderDash"
  };
  circumference;
  endAngle;
  fullCircles;
  innerRadius;
  outerRadius;
  pixelMargin;
  startAngle;
  constructor(t) {
    super(), this.options = void 0, this.circumference = void 0, this.startAngle = void 0, this.endAngle = void 0, this.innerRadius = void 0, this.outerRadius = void 0, this.pixelMargin = 0, this.fullCircles = 0, t && Object.assign(this, t);
  }
  inRange(t, e, i) {
    const s = this.getProps([
      "x",
      "y"
    ], i), { angle: n, distance: a } = Di(s, {
      x: t,
      y: e
    }), { startAngle: r, endAngle: l, innerRadius: h, outerRadius: c, circumference: d } = this.getProps([
      "startAngle",
      "endAngle",
      "innerRadius",
      "outerRadius",
      "circumference"
    ], i), u = (this.options.spacing + this.options.borderWidth) / 2, f = O(d, l - r), g = Gt(n, r, l) && r !== l, p = f >= X || g, _ = gt(a, h + u, c + u);
    return p && _;
  }
  getCenterPoint(t) {
    const { x: e, y: i, startAngle: s, endAngle: n, innerRadius: a, outerRadius: r } = this.getProps([
      "x",
      "y",
      "startAngle",
      "endAngle",
      "innerRadius",
      "outerRadius"
    ], t), { offset: l, spacing: h } = this.options, c = (s + n) / 2, d = (a + r + h + l) / 2;
    return {
      x: e + Math.cos(c) * d,
      y: i + Math.sin(c) * d
    };
  }
  tooltipPosition(t) {
    return this.getCenterPoint(t);
  }
  draw(t) {
    const { options: e, circumference: i } = this, s = (e.offset || 0) / 4, n = (e.spacing || 0) / 2, a = e.circular;
    if (this.pixelMargin = e.borderAlign === "inner" ? 0.33 : 0, this.fullCircles = i > X ? Math.floor(i / X) : 0, i === 0 || this.innerRadius < 0 || this.outerRadius < 0)
      return;
    t.save();
    const r = (this.startAngle + this.endAngle) / 2;
    t.translate(Math.cos(r) * s, Math.sin(r) * s);
    const l = 1 - Math.sin(Math.min(Y, i || 0)), h = s * l;
    t.fillStyle = e.backgroundColor, t.strokeStyle = e.borderColor, uo(t, this, h, n, a), fo(t, this, h, n, a), t.restore();
  }
}
function Ni(o, t, e = t) {
  o.lineCap = O(e.borderCapStyle, t.borderCapStyle), o.setLineDash(O(e.borderDash, t.borderDash)), o.lineDashOffset = O(e.borderDashOffset, t.borderDashOffset), o.lineJoin = O(e.borderJoinStyle, t.borderJoinStyle), o.lineWidth = O(e.borderWidth, t.borderWidth), o.strokeStyle = O(e.borderColor, t.borderColor);
}
function go(o, t, e) {
  o.lineTo(e.x, e.y);
}
function po(o) {
  return o.stepped ? Cs : o.tension || o.cubicInterpolationMode === "monotone" ? As : go;
}
function ji(o, t, e = {}) {
  const i = o.length, { start: s = 0, end: n = i - 1 } = e, { start: a, end: r } = t, l = Math.max(s, a), h = Math.min(n, r), c = s < a && n < a || s > r && n > r;
  return {
    count: i,
    start: l,
    loop: t.loop,
    ilen: h < l && !c ? i + h - l : h - l
  };
}
function mo(o, t, e, i) {
  const { points: s, options: n } = t, { count: a, start: r, loop: l, ilen: h } = ji(s, e, i), c = po(n);
  let { move: d = !0, reverse: u } = i || {}, f, g, p;
  for (f = 0; f <= h; ++f)
    g = s[(r + (u ? h - f : f)) % a], !g.skip && (d ? (o.moveTo(g.x, g.y), d = !1) : c(o, p, g, u, n.stepped), p = g);
  return l && (g = s[(r + (u ? h : 0)) % a], c(o, p, g, u, n.stepped)), !!l;
}
function _o(o, t, e, i) {
  const s = t.points, { count: n, start: a, ilen: r } = ji(s, e, i), { move: l = !0, reverse: h } = i || {};
  let c = 0, d = 0, u, f, g, p, _, m;
  const x = (y) => (a + (h ? r - y : y)) % n, v = () => {
    p !== _ && (o.lineTo(c, _), o.lineTo(c, p), o.lineTo(c, m));
  };
  for (l && (f = s[x(0)], o.moveTo(f.x, f.y)), u = 0; u <= r; ++u) {
    if (f = s[x(u)], f.skip)
      continue;
    const y = f.x, b = f.y, k = y | 0;
    k === g ? (b < p ? p = b : b > _ && (_ = b), c = (d * c + y) / ++d) : (v(), o.lineTo(y, b), g = k, d = 0, p = _ = b), m = b;
  }
  v();
}
function _e(o) {
  const t = o.options, e = t.borderDash && t.borderDash.length;
  return !o._decimated && !o._loop && !t.tension && t.cubicInterpolationMode !== "monotone" && !t.stepped && !e ? _o : mo;
}
function bo(o) {
  return o.stepped ? ds : o.tension || o.cubicInterpolationMode === "monotone" ? us : fs;
}
function xo(o, t, e, i) {
  let s = t._path;
  s || (s = t._path = new Path2D(), t.path(s, e, i) && s.closePath()), Ni(o, t.options), o.stroke(s);
}
function yo(o, t, e, i) {
  const { segments: s, options: n } = t, a = _e(t);
  for (const r of s)
    Ni(o, n, r.style), o.beginPath(), a(o, t, r, {
      start: e,
      end: e + i - 1
    }) && o.closePath(), o.stroke();
}
const vo = typeof Path2D == "function";
function ko(o, t, e, i) {
  vo && !t.options.segment ? xo(o, t, e, i) : yo(o, t, e, i);
}
class Zo extends rt {
  static id = "line";
  static defaults = {
    borderCapStyle: "butt",
    borderDash: [],
    borderDashOffset: 0,
    borderJoinStyle: "miter",
    borderWidth: 3,
    capBezierPoints: !0,
    cubicInterpolationMode: "default",
    fill: !1,
    spanGaps: !1,
    stepped: !1,
    tension: 0
  };
  static defaultRoutes = {
    backgroundColor: "backgroundColor",
    borderColor: "borderColor"
  };
  static descriptors = {
    _scriptable: !0,
    _indexable: (t) => t !== "borderDash" && t !== "fill"
  };
  constructor(t) {
    super(), this.animated = !0, this.options = void 0, this._chart = void 0, this._loop = void 0, this._fullLoop = void 0, this._path = void 0, this._points = void 0, this._segments = void 0, this._decimated = !1, this._pointsUpdated = !1, this._datasetIndex = void 0, t && Object.assign(this, t);
  }
  updateControlPoints(t, e) {
    const i = this.options;
    if ((i.tension || i.cubicInterpolationMode === "monotone") && !i.stepped && !this._pointsUpdated) {
      const s = i.spanGaps ? this._loop : this._fullLoop;
      ts(this._points, i, t, s, e), this._pointsUpdated = !0;
    }
  }
  set points(t) {
    this._points = t, delete this._segments, delete this._path, this._pointsUpdated = !1;
  }
  get points() {
    return this._points;
  }
  get segments() {
    return this._segments || (this._segments = es(this, this.options.segment));
  }
  first() {
    const t = this.segments, e = this.points;
    return t.length && e[t[0].start];
  }
  last() {
    const t = this.segments, e = this.points, i = t.length;
    return i && e[t[i - 1].end];
  }
  interpolate(t, e) {
    const i = this.options, s = t[e], n = this.points, a = is(this, {
      property: e,
      start: s,
      end: s
    });
    if (!a.length)
      return;
    const r = [], l = bo(i);
    let h, c;
    for (h = 0, c = a.length; h < c; ++h) {
      const { start: d, end: u } = a[h], f = n[d], g = n[u];
      if (f === g) {
        r.push(f);
        continue;
      }
      const p = Math.abs((s - f[e]) / (g[e] - f[e])), _ = l(f, g, p, i.stepped);
      _[e] = t[e], r.push(_);
    }
    return r.length === 1 ? r[0] : r;
  }
  pathSegment(t, e, i) {
    return _e(this)(t, this, e, i);
  }
  path(t, e, i) {
    const s = this.segments, n = _e(this);
    let a = this._loop;
    e = e || 0, i = i || this.points.length - e;
    for (const r of s)
      a &= n(t, this, r, {
        start: e,
        end: e + i - 1
      });
    return !!a;
  }
  draw(t, e, i, s) {
    const n = this.options || {};
    (this.points || []).length && n.borderWidth && (t.save(), ko(t, this, i, s), t.restore()), this.animated && (this._pointsUpdated = !1, this._path = void 0);
  }
}
function ri(o, t, e, i) {
  const s = o.options, { [e]: n } = o.getProps([
    e
  ], i);
  return Math.abs(t - n) < s.radius + s.hitRadius;
}
class ta extends rt {
  static id = "point";
  parsed;
  skip;
  stop;
  /**
  * @type {any}
  */
  static defaults = {
    borderWidth: 1,
    hitRadius: 1,
    hoverBorderWidth: 1,
    hoverRadius: 4,
    pointStyle: "circle",
    radius: 3,
    rotation: 0
  };
  /**
  * @type {any}
  */
  static defaultRoutes = {
    backgroundColor: "backgroundColor",
    borderColor: "borderColor"
  };
  constructor(t) {
    super(), this.options = void 0, this.parsed = void 0, this.skip = void 0, this.stop = void 0, t && Object.assign(this, t);
  }
  inRange(t, e, i) {
    const s = this.options, { x: n, y: a } = this.getProps([
      "x",
      "y"
    ], i);
    return Math.pow(t - n, 2) + Math.pow(e - a, 2) < Math.pow(s.hitRadius + s.radius, 2);
  }
  inXRange(t, e) {
    return ri(this, t, "x", e);
  }
  inYRange(t, e) {
    return ri(this, t, "y", e);
  }
  getCenterPoint(t) {
    const { x: e, y: i } = this.getProps([
      "x",
      "y"
    ], t);
    return {
      x: e,
      y: i
    };
  }
  size(t) {
    t = t || this.options || {};
    let e = t.radius || 0;
    e = Math.max(e, e && t.hoverRadius || 0);
    const i = e && t.borderWidth || 0;
    return (e + i) * 2;
  }
  draw(t, e) {
    const i = this.options;
    this.skip || i.radius < 0.1 || !ye(this, e, this.size(i) / 2) || (t.strokeStyle = i.borderColor, t.lineWidth = i.borderWidth, t.fillStyle = i.backgroundColor, fe(t, i, this.x, this.y));
  }
  getRange() {
    const t = this.options || {};
    return t.radius + t.hitRadius;
  }
}
function $i(o, t) {
  const { x: e, y: i, base: s, width: n, height: a } = o.getProps([
    "x",
    "y",
    "base",
    "width",
    "height"
  ], t);
  let r, l, h, c, d;
  return o.horizontal ? (d = a / 2, r = Math.min(e, s), l = Math.max(e, s), h = i - d, c = i + d) : (d = n / 2, r = e - d, l = e + d, h = Math.min(i, s), c = Math.max(i, s)), {
    left: r,
    top: h,
    right: l,
    bottom: c
  };
}
function lt(o, t, e, i) {
  return o ? 0 : U(t, e, i);
}
function wo(o, t, e) {
  const i = o.options.borderWidth, s = o.borderSkipped, n = Rs(i);
  return {
    t: lt(s.top, n.top, 0, e),
    r: lt(s.right, n.right, 0, t),
    b: lt(s.bottom, n.bottom, 0, e),
    l: lt(s.left, n.left, 0, t)
  };
}
function Mo(o, t, e) {
  const { enableBorderRadius: i } = o.getProps([
    "enableBorderRadius"
  ]), s = o.options.borderRadius, n = bt(s), a = Math.min(t, e), r = o.borderSkipped, l = i || F(s);
  return {
    topLeft: lt(!l || r.top || r.left, n.topLeft, 0, a),
    topRight: lt(!l || r.top || r.right, n.topRight, 0, a),
    bottomLeft: lt(!l || r.bottom || r.left, n.bottomLeft, 0, a),
    bottomRight: lt(!l || r.bottom || r.right, n.bottomRight, 0, a)
  };
}
function So(o) {
  const t = $i(o), e = t.right - t.left, i = t.bottom - t.top, s = wo(o, e / 2, i / 2), n = Mo(o, e / 2, i / 2);
  return {
    outer: {
      x: t.left,
      y: t.top,
      w: e,
      h: i,
      radius: n
    },
    inner: {
      x: t.left + s.l,
      y: t.top + s.t,
      w: e - s.l - s.r,
      h: i - s.t - s.b,
      radius: {
        topLeft: Math.max(0, n.topLeft - Math.max(s.t, s.l)),
        topRight: Math.max(0, n.topRight - Math.max(s.t, s.r)),
        bottomLeft: Math.max(0, n.bottomLeft - Math.max(s.b, s.l)),
        bottomRight: Math.max(0, n.bottomRight - Math.max(s.b, s.r))
      }
    }
  };
}
function de(o, t, e, i) {
  const s = t === null, n = e === null, r = o && !(s && n) && $i(o, i);
  return r && (s || gt(t, r.left, r.right)) && (n || gt(e, r.top, r.bottom));
}
function Do(o) {
  return o.topLeft || o.topRight || o.bottomLeft || o.bottomRight;
}
function Co(o, t) {
  o.rect(t.x, t.y, t.w, t.h);
}
function ue(o, t, e = {}) {
  const i = o.x !== e.x ? -t : 0, s = o.y !== e.y ? -t : 0, n = (o.x + o.w !== e.x + e.w ? t : 0) - i, a = (o.y + o.h !== e.y + e.h ? t : 0) - s;
  return {
    x: o.x + i,
    y: o.y + s,
    w: o.w + n,
    h: o.h + a,
    radius: o.radius
  };
}
class ea extends rt {
  static id = "bar";
  static defaults = {
    borderSkipped: "start",
    borderWidth: 0,
    borderRadius: 0,
    inflateAmount: "auto",
    pointStyle: void 0
  };
  static defaultRoutes = {
    backgroundColor: "backgroundColor",
    borderColor: "borderColor"
  };
  constructor(t) {
    super(), this.options = void 0, this.horizontal = void 0, this.base = void 0, this.width = void 0, this.height = void 0, this.inflateAmount = void 0, t && Object.assign(this, t);
  }
  draw(t) {
    const { inflateAmount: e, options: { borderColor: i, backgroundColor: s } } = this, { inner: n, outer: a } = So(this), r = Do(a.radius) ? Kt : Co;
    t.save(), (a.w !== n.w || a.h !== n.h) && (t.beginPath(), r(t, ue(a, e, n)), t.clip(), r(t, ue(n, -e, a)), t.fillStyle = i, t.fill("evenodd")), t.beginPath(), r(t, ue(n, e)), t.fillStyle = s, t.fill(), t.restore();
  }
  inRange(t, e, i) {
    return de(this, t, e, i);
  }
  inXRange(t, e) {
    return de(this, t, null, e);
  }
  inYRange(t, e) {
    return de(this, null, t, e);
  }
  getCenterPoint(t) {
    const { x: e, y: i, base: s, horizontal: n } = this.getProps([
      "x",
      "y",
      "base",
      "horizontal"
    ], t);
    return {
      x: n ? (e + s) / 2 : e,
      y: n ? i : (i + s) / 2
    };
  }
  getRange(t) {
    return t === "x" ? this.width / 2 : this.height / 2;
  }
}
const li = (o, t) => {
  let { boxHeight: e = t, boxWidth: i = t } = o;
  return o.usePointStyle && (e = Math.min(e, t), i = o.pointStyleWidth || Math.min(i, t)), {
    boxWidth: i,
    boxHeight: e,
    itemHeight: Math.max(t, e)
  };
}, Ao = (o, t) => o !== null && t !== null && o.datasetIndex === t.datasetIndex && o.index === t.index;
class hi extends rt {
  constructor(t) {
    super(), this._added = !1, this.legendHitBoxes = [], this._hoveredItem = null, this.doughnutMode = !1, this.chart = t.chart, this.options = t.options, this.ctx = t.ctx, this.legendItems = void 0, this.columnSizes = void 0, this.lineWidths = void 0, this.maxHeight = void 0, this.maxWidth = void 0, this.top = void 0, this.bottom = void 0, this.left = void 0, this.right = void 0, this.height = void 0, this.width = void 0, this._margins = void 0, this.position = void 0, this.weight = void 0, this.fullSize = void 0;
  }
  update(t, e, i) {
    this.maxWidth = t, this.maxHeight = e, this._margins = i, this.setDimensions(), this.buildLabels(), this.fit();
  }
  setDimensions() {
    this.isHorizontal() ? (this.width = this.maxWidth, this.left = this._margins.left, this.right = this.width) : (this.height = this.maxHeight, this.top = this._margins.top, this.bottom = this.height);
  }
  buildLabels() {
    const t = this.options.labels || {};
    let e = T(t.generateLabels, [
      this.chart
    ], this) || [];
    t.filter && (e = e.filter((i) => t.filter(i, this.chart.data))), t.sort && (e = e.sort((i, s) => t.sort(i, s, this.chart.data))), this.options.reverse && e.reverse(), this.legendItems = e;
  }
  fit() {
    const { options: t, ctx: e } = this;
    if (!t.display) {
      this.width = this.height = 0;
      return;
    }
    const i = t.labels, s = V(i.font), n = s.size, a = this._computeTitleHeight(), { boxWidth: r, itemHeight: l } = li(i, n);
    let h, c;
    e.font = s.string, this.isHorizontal() ? (h = this.maxWidth, c = this._fitRows(a, n, r, l) + 10) : (c = this.maxHeight, h = this._fitCols(a, s, r, l) + 10), this.width = Math.min(h, t.maxWidth || this.maxWidth), this.height = Math.min(c, t.maxHeight || this.maxHeight);
  }
  _fitRows(t, e, i, s) {
    const { ctx: n, maxWidth: a, options: { labels: { padding: r } } } = this, l = this.legendHitBoxes = [], h = this.lineWidths = [
      0
    ], c = s + r;
    let d = t;
    n.textAlign = "left", n.textBaseline = "middle";
    let u = -1, f = -c;
    return this.legendItems.forEach((g, p) => {
      const _ = i + e / 2 + n.measureText(g.text).width;
      (p === 0 || h[h.length - 1] + _ + 2 * r > a) && (d += c, h[h.length - (p > 0 ? 0 : 1)] = 0, f += c, u++), l[p] = {
        left: 0,
        top: f,
        row: u,
        width: _,
        height: s
      }, h[h.length - 1] += _ + r;
    }), d;
  }
  _fitCols(t, e, i, s) {
    const { ctx: n, maxHeight: a, options: { labels: { padding: r } } } = this, l = this.legendHitBoxes = [], h = this.columnSizes = [], c = a - t;
    let d = r, u = 0, f = 0, g = 0, p = 0;
    return this.legendItems.forEach((_, m) => {
      const { itemWidth: x, itemHeight: v } = Po(i, e, n, _, s);
      m > 0 && f + v + 2 * r > c && (d += u + r, h.push({
        width: u,
        height: f
      }), g += u + r, p++, u = f = 0), l[m] = {
        left: g,
        top: f,
        col: p,
        width: x,
        height: v
      }, u = Math.max(u, x), f += v + r;
    }), d += u, h.push({
      width: u,
      height: f
    }), d;
  }
  adjustHitBoxes() {
    if (!this.options.display)
      return;
    const t = this._computeTitleHeight(), { legendHitBoxes: e, options: { align: i, labels: { padding: s }, rtl: n } } = this, a = xt(n, this.left, this.width);
    if (this.isHorizontal()) {
      let r = 0, l = W(i, this.left + s, this.right - this.lineWidths[r]);
      for (const h of e)
        r !== h.row && (r = h.row, l = W(i, this.left + s, this.right - this.lineWidths[r])), h.top += this.top + t + s, h.left = a.leftForLtr(a.x(l), h.width), l += h.width + s;
    } else {
      let r = 0, l = W(i, this.top + t + s, this.bottom - this.columnSizes[r].height);
      for (const h of e)
        h.col !== r && (r = h.col, l = W(i, this.top + t + s, this.bottom - this.columnSizes[r].height)), h.top = l, h.left += this.left + s, h.left = a.leftForLtr(a.x(h.left), h.width), l += h.height + s;
    }
  }
  isHorizontal() {
    return this.options.position === "top" || this.options.position === "bottom";
  }
  draw() {
    if (this.options.display) {
      const t = this.ctx;
      be(t, this), this._draw(), xe(t);
    }
  }
  _draw() {
    const { options: t, columnSizes: e, lineWidths: i, ctx: s } = this, { align: n, labels: a } = t, r = I.color, l = xt(t.rtl, this.left, this.width), h = V(a.font), { padding: c } = a, d = h.size, u = d / 2;
    let f;
    this.drawTitle(), s.textAlign = l.textAlign("left"), s.textBaseline = "middle", s.lineWidth = 0.5, s.font = h.string;
    const { boxWidth: g, boxHeight: p, itemHeight: _ } = li(a, d), m = function(k, w, M) {
      if (isNaN(g) || g <= 0 || isNaN(p) || p < 0)
        return;
      s.save();
      const S = O(M.lineWidth, 1);
      if (s.fillStyle = O(M.fillStyle, r), s.lineCap = O(M.lineCap, "butt"), s.lineDashOffset = O(M.lineDashOffset, 0), s.lineJoin = O(M.lineJoin, "miter"), s.lineWidth = S, s.strokeStyle = O(M.strokeStyle, r), s.setLineDash(O(M.lineDash, [])), a.usePointStyle) {
        const C = {
          radius: p * Math.SQRT2 / 2,
          pointStyle: M.pointStyle,
          rotation: M.rotation,
          borderWidth: S
        }, D = l.xPlus(k, g / 2), A = w + u;
        vs(s, C, D, A, a.pointStyleWidth && g);
      } else {
        const C = w + Math.max((d - p) / 2, 0), D = l.leftForLtr(k, g), A = bt(M.borderRadius);
        s.beginPath(), Object.values(A).some((B) => B !== 0) ? Kt(s, {
          x: D,
          y: C,
          w: g,
          h: p,
          radius: A
        }) : s.rect(D, C, g, p), s.fill(), S !== 0 && s.stroke();
      }
      s.restore();
    }, x = function(k, w, M) {
      Tt(s, M.text, k, w + _ / 2, h, {
        strikethrough: M.hidden,
        textAlign: l.textAlign(M.textAlign)
      });
    }, v = this.isHorizontal(), y = this._computeTitleHeight();
    v ? f = {
      x: W(n, this.left + c, this.right - i[0]),
      y: this.top + c + y,
      line: 0
    } : f = {
      x: this.left + c,
      y: W(n, this.top + y + c, this.bottom - e[0].height),
      line: 0
    }, Mi(this.ctx, t.textDirection);
    const b = _ + c;
    this.legendItems.forEach((k, w) => {
      s.strokeStyle = k.fontColor, s.fillStyle = k.fontColor;
      const M = s.measureText(k.text).width, S = l.textAlign(k.textAlign || (k.textAlign = a.textAlign)), C = g + u + M;
      let D = f.x, A = f.y;
      l.setWidth(this.width), v ? w > 0 && D + C + c > this.right && (A = f.y += b, f.line++, D = f.x = W(n, this.left + c, this.right - i[f.line])) : w > 0 && A + b > this.bottom && (D = f.x = D + e[f.line].width + c, f.line++, A = f.y = W(n, this.top + y + c, this.bottom - e[f.line].height));
      const B = l.x(D);
      if (m(B, A, k), D = rs(S, D + g + u, v ? D + C : this.right, t.rtl), x(l.x(D), A, k), v)
        f.x += C + c;
      else if (typeof k.text != "string") {
        const $ = h.lineHeight;
        f.y += Yi(k, $) + c;
      } else
        f.y += b;
    }), Si(this.ctx, t.textDirection);
  }
  drawTitle() {
    const t = this.options, e = t.title, i = V(e.font), s = G(e.padding);
    if (!e.display)
      return;
    const n = xt(t.rtl, this.left, this.width), a = this.ctx, r = e.position, l = i.size / 2, h = s.top + l;
    let c, d = this.left, u = this.width;
    if (this.isHorizontal())
      u = Math.max(...this.lineWidths), c = this.top + h, d = W(t.align, d, this.right - u);
    else {
      const g = this.columnSizes.reduce((p, _) => Math.max(p, _.height), 0);
      c = h + W(t.align, this.top, this.bottom - g - t.labels.padding - this._computeTitleHeight());
    }
    const f = W(r, d, d + u);
    a.textAlign = n.textAlign(ve(r)), a.textBaseline = "middle", a.strokeStyle = e.color, a.fillStyle = e.color, a.font = i.string, Tt(a, e.text, f, c, i);
  }
  _computeTitleHeight() {
    const t = this.options.title, e = V(t.font), i = G(t.padding);
    return t.display ? e.lineHeight + i.height : 0;
  }
  _getLegendItemAt(t, e) {
    let i, s, n;
    if (gt(t, this.left, this.right) && gt(e, this.top, this.bottom)) {
      for (n = this.legendHitBoxes, i = 0; i < n.length; ++i)
        if (s = n[i], gt(t, s.left, s.left + s.width) && gt(e, s.top, s.top + s.height))
          return this.legendItems[i];
    }
    return null;
  }
  handleEvent(t) {
    const e = this.options;
    if (!To(t.type, e))
      return;
    const i = this._getLegendItemAt(t.x, t.y);
    if (t.type === "mousemove" || t.type === "mouseout") {
      const s = this._hoveredItem, n = Ao(s, i);
      s && !n && T(e.onLeave, [
        t,
        s,
        this
      ], this), this._hoveredItem = i, i && !n && T(e.onHover, [
        t,
        i,
        this
      ], this);
    } else i && T(e.onClick, [
      t,
      i,
      this
    ], this);
  }
}
function Po(o, t, e, i, s) {
  const n = Oo(i, o, t, e), a = Lo(s, i, t.lineHeight);
  return {
    itemWidth: n,
    itemHeight: a
  };
}
function Oo(o, t, e, i) {
  let s = o.text;
  return s && typeof s != "string" && (s = s.reduce((n, a) => n.length > a.length ? n : a)), t + e.size / 2 + i.measureText(s).width;
}
function Lo(o, t, e) {
  let i = o;
  return typeof t.text != "string" && (i = Yi(t, e)), i;
}
function Yi(o, t) {
  const e = o.text ? o.text.length : 0;
  return t * e;
}
function To(o, t) {
  return !!((o === "mousemove" || o === "mouseout") && (t.onHover || t.onLeave) || t.onClick && (o === "click" || o === "mouseup"));
}
var ia = {
  id: "legend",
  _element: hi,
  start(o, t, e) {
    const i = o.legend = new hi({
      ctx: o.ctx,
      options: e,
      chart: o
    });
    K.configure(o, i, e), K.addBox(o, i);
  },
  stop(o) {
    K.removeBox(o, o.legend), delete o.legend;
  },
  beforeUpdate(o, t, e) {
    const i = o.legend;
    K.configure(o, i, e), i.options = e;
  },
  afterUpdate(o) {
    const t = o.legend;
    t.buildLabels(), t.adjustHitBoxes();
  },
  afterEvent(o, t) {
    t.replay || o.legend.handleEvent(t.event);
  },
  defaults: {
    display: !0,
    position: "top",
    align: "center",
    fullSize: !0,
    reverse: !1,
    weight: 1e3,
    onClick(o, t, e) {
      const i = t.datasetIndex, s = e.chart;
      s.isDatasetVisible(i) ? (s.hide(i), t.hidden = !0) : (s.show(i), t.hidden = !1);
    },
    onHover: null,
    onLeave: null,
    labels: {
      color: (o) => o.chart.options.color,
      boxWidth: 40,
      padding: 10,
      generateLabels(o) {
        const t = o.data.datasets, { labels: { usePointStyle: e, pointStyle: i, textAlign: s, color: n, useBorderRadius: a, borderRadius: r } } = o.legend.options;
        return o._getSortedDatasetMetas().map((l) => {
          const h = l.controller.getStyle(e ? 0 : void 0), c = G(h.borderWidth);
          return {
            text: t[l.index].label,
            fillStyle: h.backgroundColor,
            fontColor: n,
            hidden: !l.visible,
            lineCap: h.borderCapStyle,
            lineDash: h.borderDash,
            lineDashOffset: h.borderDashOffset,
            lineJoin: h.borderJoinStyle,
            lineWidth: (c.width + c.height) / 4,
            strokeStyle: h.borderColor,
            pointStyle: i || h.pointStyle,
            rotation: h.rotation,
            textAlign: s || h.textAlign,
            borderRadius: a && (r || h.borderRadius),
            datasetIndex: l.index
          };
        }, this);
      }
    },
    title: {
      color: (o) => o.chart.options.color,
      display: !1,
      position: "center",
      text: ""
    }
  },
  descriptors: {
    _scriptable: (o) => !o.startsWith("on"),
    labels: {
      _scriptable: (o) => ![
        "generateLabels",
        "filter",
        "sort"
      ].includes(o)
    }
  }
};
class Ui extends rt {
  constructor(t) {
    super(), this.chart = t.chart, this.options = t.options, this.ctx = t.ctx, this._padding = void 0, this.top = void 0, this.bottom = void 0, this.left = void 0, this.right = void 0, this.width = void 0, this.height = void 0, this.position = void 0, this.weight = void 0, this.fullSize = void 0;
  }
  update(t, e) {
    const i = this.options;
    if (this.left = 0, this.top = 0, !i.display) {
      this.width = this.height = this.right = this.bottom = 0;
      return;
    }
    this.width = this.right = t, this.height = this.bottom = e;
    const s = J(i.text) ? i.text.length : 1;
    this._padding = G(i.padding);
    const n = s * V(i.font).lineHeight + this._padding.height;
    this.isHorizontal() ? this.height = n : this.width = n;
  }
  isHorizontal() {
    const t = this.options.position;
    return t === "top" || t === "bottom";
  }
  _drawArgs(t) {
    const { top: e, left: i, bottom: s, right: n, options: a } = this, r = a.align;
    let l = 0, h, c, d;
    return this.isHorizontal() ? (c = W(r, i, n), d = e + t, h = n - i) : (a.position === "left" ? (c = i + t, d = W(r, s, e), l = Y * -0.5) : (c = n - t, d = W(r, e, s), l = Y * 0.5), h = s - e), {
      titleX: c,
      titleY: d,
      maxWidth: h,
      rotation: l
    };
  }
  draw() {
    const t = this.ctx, e = this.options;
    if (!e.display)
      return;
    const i = V(e.font), n = i.lineHeight / 2 + this._padding.top, { titleX: a, titleY: r, maxWidth: l, rotation: h } = this._drawArgs(n);
    Tt(t, e.text, 0, 0, i, {
      color: e.color,
      maxWidth: l,
      rotation: h,
      textAlign: ve(e.align),
      textBaseline: "middle",
      translation: [
        a,
        r
      ]
    });
  }
}
function Ro(o, t) {
  const e = new Ui({
    ctx: o.ctx,
    options: t,
    chart: o
  });
  K.configure(o, e, t), K.addBox(o, e), o.titleBlock = e;
}
var sa = {
  id: "title",
  _element: Ui,
  start(o, t, e) {
    Ro(o, e);
  },
  stop(o) {
    const t = o.titleBlock;
    K.removeBox(o, t), delete o.titleBlock;
  },
  beforeUpdate(o, t, e) {
    const i = o.titleBlock;
    K.configure(o, i, e), i.options = e;
  },
  defaults: {
    align: "center",
    display: !1,
    font: {
      weight: "bold"
    },
    fullSize: !0,
    padding: 10,
    position: "top",
    text: "",
    weight: 2e3
  },
  defaultRoutes: {
    color: "color"
  },
  descriptors: {
    _scriptable: !0,
    _indexable: !1
  }
};
const Lt = {
  average(o) {
    if (!o.length)
      return !1;
    let t, e, i = /* @__PURE__ */ new Set(), s = 0, n = 0;
    for (t = 0, e = o.length; t < e; ++t) {
      const r = o[t].element;
      if (r && r.hasValue()) {
        const l = r.tooltipPosition();
        i.add(l.x), s += l.y, ++n;
      }
    }
    return n === 0 || i.size === 0 ? !1 : {
      x: [
        ...i
      ].reduce((r, l) => r + l) / i.size,
      y: s / n
    };
  },
  nearest(o, t) {
    if (!o.length)
      return !1;
    let e = t.x, i = t.y, s = Number.POSITIVE_INFINITY, n, a, r;
    for (n = 0, a = o.length; n < a; ++n) {
      const l = o[n].element;
      if (l && l.hasValue()) {
        const h = l.getCenterPoint(), c = ns(t, h);
        c < s && (s = c, r = l);
      }
    }
    if (r) {
      const l = r.tooltipPosition();
      e = l.x, i = l.y;
    }
    return {
      x: e,
      y: i
    };
  }
};
function Z(o, t) {
  return t && (J(t) ? Array.prototype.push.apply(o, t) : o.push(t)), o;
}
function ot(o) {
  return (typeof o == "string" || o instanceof String) && o.indexOf(`
`) > -1 ? o.split(`
`) : o;
}
function Eo(o, t) {
  const { element: e, datasetIndex: i, index: s } = t, n = o.getDatasetMeta(i).controller, { label: a, value: r } = n.getLabelAndValue(s);
  return {
    chart: o,
    label: a,
    parsed: n.getParsed(s),
    raw: o.data.datasets[i].data[s],
    formattedValue: r,
    dataset: n.getDataset(),
    dataIndex: s,
    datasetIndex: i,
    element: e
  };
}
function ci(o, t) {
  const e = o.chart.ctx, { body: i, footer: s, title: n } = o, { boxWidth: a, boxHeight: r } = t, l = V(t.bodyFont), h = V(t.titleFont), c = V(t.footerFont), d = n.length, u = s.length, f = i.length, g = G(t.padding);
  let p = g.height, _ = 0, m = i.reduce((y, b) => y + b.before.length + b.lines.length + b.after.length, 0);
  if (m += o.beforeBody.length + o.afterBody.length, d && (p += d * h.lineHeight + (d - 1) * t.titleSpacing + t.titleMarginBottom), m) {
    const y = t.displayColors ? Math.max(r, l.lineHeight) : l.lineHeight;
    p += f * y + (m - f) * l.lineHeight + (m - 1) * t.bodySpacing;
  }
  u && (p += t.footerMarginTop + u * c.lineHeight + (u - 1) * t.footerSpacing);
  let x = 0;
  const v = function(y) {
    _ = Math.max(_, e.measureText(y).width + x);
  };
  return e.save(), e.font = h.string, P(o.title, v), e.font = l.string, P(o.beforeBody.concat(o.afterBody), v), x = t.displayColors ? a + 2 + t.boxPadding : 0, P(i, (y) => {
    P(y.before, v), P(y.lines, v), P(y.after, v);
  }), x = 0, e.font = c.string, P(o.footer, v), e.restore(), _ += g.width, {
    width: _,
    height: p
  };
}
function zo(o, t) {
  const { y: e, height: i } = t;
  return e < i / 2 ? "top" : e > o.height - i / 2 ? "bottom" : "center";
}
function Io(o, t, e, i) {
  const { x: s, width: n } = i, a = e.caretSize + e.caretPadding;
  if (o === "left" && s + n + a > t.width || o === "right" && s - n - a < 0)
    return !0;
}
function Fo(o, t, e, i) {
  const { x: s, width: n } = e, { width: a, chartArea: { left: r, right: l } } = o;
  let h = "center";
  return i === "center" ? h = s <= (r + l) / 2 ? "left" : "right" : s <= n / 2 ? h = "left" : s >= a - n / 2 && (h = "right"), Io(h, o, t, e) && (h = "center"), h;
}
function di(o, t, e) {
  const i = e.yAlign || t.yAlign || zo(o, e);
  return {
    xAlign: e.xAlign || t.xAlign || Fo(o, t, e, i),
    yAlign: i
  };
}
function Bo(o, t) {
  let { x: e, width: i } = o;
  return t === "right" ? e -= i : t === "center" && (e -= i / 2), e;
}
function Ho(o, t, e) {
  let { y: i, height: s } = o;
  return t === "top" ? i += e : t === "bottom" ? i -= s + e : i -= s / 2, i;
}
function ui(o, t, e, i) {
  const { caretSize: s, caretPadding: n, cornerRadius: a } = o, { xAlign: r, yAlign: l } = e, h = s + n, { topLeft: c, topRight: d, bottomLeft: u, bottomRight: f } = bt(a);
  let g = Bo(t, r);
  const p = Ho(t, l, h);
  return l === "center" ? r === "left" ? g += h : r === "right" && (g -= h) : r === "left" ? g -= Math.max(c, u) + s : r === "right" && (g += Math.max(d, f) + s), {
    x: U(g, 0, i.width - t.width),
    y: U(p, 0, i.height - t.height)
  };
}
function Vt(o, t, e) {
  const i = G(e.padding);
  return t === "center" ? o.x + o.width / 2 : t === "right" ? o.x + o.width - i.right : o.x + i.left;
}
function fi(o) {
  return Z([], ot(o));
}
function Wo(o, t, e) {
  return vt(o, {
    tooltip: t,
    tooltipItems: e,
    type: "tooltip"
  });
}
function gi(o, t) {
  const e = t && t.dataset && t.dataset.tooltip && t.dataset.tooltip.callbacks;
  return e ? o.override(e) : o;
}
const Xi = {
  beforeTitle: st,
  title(o) {
    if (o.length > 0) {
      const t = o[0], e = t.chart.data.labels, i = e ? e.length : 0;
      if (this && this.options && this.options.mode === "dataset")
        return t.dataset.label || "";
      if (t.label)
        return t.label;
      if (i > 0 && t.dataIndex < i)
        return e[t.dataIndex];
    }
    return "";
  },
  afterTitle: st,
  beforeBody: st,
  beforeLabel: st,
  label(o) {
    if (this && this.options && this.options.mode === "dataset")
      return o.label + ": " + o.formattedValue || o.formattedValue;
    let t = o.dataset.label || "";
    t && (t += ": ");
    const e = o.formattedValue;
    return z(e) || (t += e), t;
  },
  labelColor(o) {
    const e = o.chart.getDatasetMeta(o.datasetIndex).controller.getStyle(o.dataIndex);
    return {
      borderColor: e.borderColor,
      backgroundColor: e.backgroundColor,
      borderWidth: e.borderWidth,
      borderDash: e.borderDash,
      borderDashOffset: e.borderDashOffset,
      borderRadius: 0
    };
  },
  labelTextColor() {
    return this.options.bodyColor;
  },
  labelPointStyle(o) {
    const e = o.chart.getDatasetMeta(o.datasetIndex).controller.getStyle(o.dataIndex);
    return {
      pointStyle: e.pointStyle,
      rotation: e.rotation
    };
  },
  afterLabel: st,
  afterBody: st,
  beforeFooter: st,
  footer: st,
  afterFooter: st
};
function N(o, t, e, i) {
  const s = o[t].call(e, i);
  return typeof s > "u" ? Xi[t].call(e, i) : s;
}
class pi extends rt {
  static positioners = Lt;
  constructor(t) {
    super(), this.opacity = 0, this._active = [], this._eventPosition = void 0, this._size = void 0, this._cachedAnimations = void 0, this._tooltipItems = [], this.$animations = void 0, this.$context = void 0, this.chart = t.chart, this.options = t.options, this.dataPoints = void 0, this.title = void 0, this.beforeBody = void 0, this.body = void 0, this.afterBody = void 0, this.footer = void 0, this.xAlign = void 0, this.yAlign = void 0, this.x = void 0, this.y = void 0, this.height = void 0, this.width = void 0, this.caretX = void 0, this.caretY = void 0, this.labelColors = void 0, this.labelPointStyles = void 0, this.labelTextColors = void 0;
  }
  initialize(t) {
    this.options = t, this._cachedAnimations = void 0, this.$context = void 0;
  }
  _resolveAnimations() {
    const t = this._cachedAnimations;
    if (t)
      return t;
    const e = this.chart, i = this.options.setContext(this.getContext()), s = i.enabled && e.options.animation && i.animations, n = new Li(this.chart, s);
    return s._cacheable && (this._cachedAnimations = Object.freeze(n)), n;
  }
  getContext() {
    return this.$context || (this.$context = Wo(this.chart.getContext(), this, this._tooltipItems));
  }
  getTitle(t, e) {
    const { callbacks: i } = e, s = N(i, "beforeTitle", this, t), n = N(i, "title", this, t), a = N(i, "afterTitle", this, t);
    let r = [];
    return r = Z(r, ot(s)), r = Z(r, ot(n)), r = Z(r, ot(a)), r;
  }
  getBeforeBody(t, e) {
    return fi(N(e.callbacks, "beforeBody", this, t));
  }
  getBody(t, e) {
    const { callbacks: i } = e, s = [];
    return P(t, (n) => {
      const a = {
        before: [],
        lines: [],
        after: []
      }, r = gi(i, n);
      Z(a.before, ot(N(r, "beforeLabel", this, n))), Z(a.lines, N(r, "label", this, n)), Z(a.after, ot(N(r, "afterLabel", this, n))), s.push(a);
    }), s;
  }
  getAfterBody(t, e) {
    return fi(N(e.callbacks, "afterBody", this, t));
  }
  getFooter(t, e) {
    const { callbacks: i } = e, s = N(i, "beforeFooter", this, t), n = N(i, "footer", this, t), a = N(i, "afterFooter", this, t);
    let r = [];
    return r = Z(r, ot(s)), r = Z(r, ot(n)), r = Z(r, ot(a)), r;
  }
  _createItems(t) {
    const e = this._active, i = this.chart.data, s = [], n = [], a = [];
    let r = [], l, h;
    for (l = 0, h = e.length; l < h; ++l)
      r.push(Eo(this.chart, e[l]));
    return t.filter && (r = r.filter((c, d, u) => t.filter(c, d, u, i))), t.itemSort && (r = r.sort((c, d) => t.itemSort(c, d, i))), P(r, (c) => {
      const d = gi(t.callbacks, c);
      s.push(N(d, "labelColor", this, c)), n.push(N(d, "labelPointStyle", this, c)), a.push(N(d, "labelTextColor", this, c));
    }), this.labelColors = s, this.labelPointStyles = n, this.labelTextColors = a, this.dataPoints = r, r;
  }
  update(t, e) {
    const i = this.options.setContext(this.getContext()), s = this._active;
    let n, a = [];
    if (!s.length)
      this.opacity !== 0 && (n = {
        opacity: 0
      });
    else {
      const r = Lt[i.position].call(this, s, this._eventPosition);
      a = this._createItems(i), this.title = this.getTitle(a, i), this.beforeBody = this.getBeforeBody(a, i), this.body = this.getBody(a, i), this.afterBody = this.getAfterBody(a, i), this.footer = this.getFooter(a, i);
      const l = this._size = ci(this, i), h = Object.assign({}, r, l), c = di(this.chart, i, h), d = ui(i, h, c, this.chart);
      this.xAlign = c.xAlign, this.yAlign = c.yAlign, n = {
        opacity: 1,
        x: d.x,
        y: d.y,
        width: l.width,
        height: l.height,
        caretX: r.x,
        caretY: r.y
      };
    }
    this._tooltipItems = a, this.$context = void 0, n && this._resolveAnimations().update(this, n), t && i.external && i.external.call(this, {
      chart: this.chart,
      tooltip: this,
      replay: e
    });
  }
  drawCaret(t, e, i, s) {
    const n = this.getCaretPosition(t, i, s);
    e.lineTo(n.x1, n.y1), e.lineTo(n.x2, n.y2), e.lineTo(n.x3, n.y3);
  }
  getCaretPosition(t, e, i) {
    const { xAlign: s, yAlign: n } = this, { caretSize: a, cornerRadius: r } = i, { topLeft: l, topRight: h, bottomLeft: c, bottomRight: d } = bt(r), { x: u, y: f } = t, { width: g, height: p } = e;
    let _, m, x, v, y, b;
    return n === "center" ? (y = f + p / 2, s === "left" ? (_ = u, m = _ - a, v = y + a, b = y - a) : (_ = u + g, m = _ + a, v = y - a, b = y + a), x = _) : (s === "left" ? m = u + Math.max(l, c) + a : s === "right" ? m = u + g - Math.max(h, d) - a : m = this.caretX, n === "top" ? (v = f, y = v - a, _ = m - a, x = m + a) : (v = f + p, y = v + a, _ = m + a, x = m - a), b = v), {
      x1: _,
      x2: m,
      x3: x,
      y1: v,
      y2: y,
      y3: b
    };
  }
  drawTitle(t, e, i) {
    const s = this.title, n = s.length;
    let a, r, l;
    if (n) {
      const h = xt(i.rtl, this.x, this.width);
      for (t.x = Vt(this, i.titleAlign, i), e.textAlign = h.textAlign(i.titleAlign), e.textBaseline = "middle", a = V(i.titleFont), r = i.titleSpacing, e.fillStyle = i.titleColor, e.font = a.string, l = 0; l < n; ++l)
        e.fillText(s[l], h.x(t.x), t.y + a.lineHeight / 2), t.y += a.lineHeight + r, l + 1 === n && (t.y += i.titleMarginBottom - r);
    }
  }
  _drawColorBox(t, e, i, s, n) {
    const a = this.labelColors[i], r = this.labelPointStyles[i], { boxHeight: l, boxWidth: h } = n, c = V(n.bodyFont), d = Vt(this, "left", n), u = s.x(d), f = l < c.lineHeight ? (c.lineHeight - l) / 2 : 0, g = e.y + f;
    if (n.usePointStyle) {
      const p = {
        radius: Math.min(h, l) / 2,
        pointStyle: r.pointStyle,
        rotation: r.rotation,
        borderWidth: 1
      }, _ = s.leftForLtr(u, h) + h / 2, m = g + l / 2;
      t.strokeStyle = n.multiKeyBackground, t.fillStyle = n.multiKeyBackground, fe(t, p, _, m), t.strokeStyle = a.borderColor, t.fillStyle = a.backgroundColor, fe(t, p, _, m);
    } else {
      t.lineWidth = F(a.borderWidth) ? Math.max(...Object.values(a.borderWidth)) : a.borderWidth || 1, t.strokeStyle = a.borderColor, t.setLineDash(a.borderDash || []), t.lineDashOffset = a.borderDashOffset || 0;
      const p = s.leftForLtr(u, h), _ = s.leftForLtr(s.xPlus(u, 1), h - 2), m = bt(a.borderRadius);
      Object.values(m).some((x) => x !== 0) ? (t.beginPath(), t.fillStyle = n.multiKeyBackground, Kt(t, {
        x: p,
        y: g,
        w: h,
        h: l,
        radius: m
      }), t.fill(), t.stroke(), t.fillStyle = a.backgroundColor, t.beginPath(), Kt(t, {
        x: _,
        y: g + 1,
        w: h - 2,
        h: l - 2,
        radius: m
      }), t.fill()) : (t.fillStyle = n.multiKeyBackground, t.fillRect(p, g, h, l), t.strokeRect(p, g, h, l), t.fillStyle = a.backgroundColor, t.fillRect(_, g + 1, h - 2, l - 2));
    }
    t.fillStyle = this.labelTextColors[i];
  }
  drawBody(t, e, i) {
    const { body: s } = this, { bodySpacing: n, bodyAlign: a, displayColors: r, boxHeight: l, boxWidth: h, boxPadding: c } = i, d = V(i.bodyFont);
    let u = d.lineHeight, f = 0;
    const g = xt(i.rtl, this.x, this.width), p = function(M) {
      e.fillText(M, g.x(t.x + f), t.y + u / 2), t.y += u + n;
    }, _ = g.textAlign(a);
    let m, x, v, y, b, k, w;
    for (e.textAlign = a, e.textBaseline = "middle", e.font = d.string, t.x = Vt(this, _, i), e.fillStyle = i.bodyColor, P(this.beforeBody, p), f = r && _ !== "right" ? a === "center" ? h / 2 + c : h + 2 + c : 0, y = 0, k = s.length; y < k; ++y) {
      for (m = s[y], x = this.labelTextColors[y], e.fillStyle = x, P(m.before, p), v = m.lines, r && v.length && (this._drawColorBox(e, t, y, g, i), u = Math.max(d.lineHeight, l)), b = 0, w = v.length; b < w; ++b)
        p(v[b]), u = d.lineHeight;
      P(m.after, p);
    }
    f = 0, u = d.lineHeight, P(this.afterBody, p), t.y -= n;
  }
  drawFooter(t, e, i) {
    const s = this.footer, n = s.length;
    let a, r;
    if (n) {
      const l = xt(i.rtl, this.x, this.width);
      for (t.x = Vt(this, i.footerAlign, i), t.y += i.footerMarginTop, e.textAlign = l.textAlign(i.footerAlign), e.textBaseline = "middle", a = V(i.footerFont), e.fillStyle = i.footerColor, e.font = a.string, r = 0; r < n; ++r)
        e.fillText(s[r], l.x(t.x), t.y + a.lineHeight / 2), t.y += a.lineHeight + i.footerSpacing;
    }
  }
  drawBackground(t, e, i, s) {
    const { xAlign: n, yAlign: a } = this, { x: r, y: l } = t, { width: h, height: c } = i, { topLeft: d, topRight: u, bottomLeft: f, bottomRight: g } = bt(s.cornerRadius);
    e.fillStyle = s.backgroundColor, e.strokeStyle = s.borderColor, e.lineWidth = s.borderWidth, e.beginPath(), e.moveTo(r + d, l), a === "top" && this.drawCaret(t, e, i, s), e.lineTo(r + h - u, l), e.quadraticCurveTo(r + h, l, r + h, l + u), a === "center" && n === "right" && this.drawCaret(t, e, i, s), e.lineTo(r + h, l + c - g), e.quadraticCurveTo(r + h, l + c, r + h - g, l + c), a === "bottom" && this.drawCaret(t, e, i, s), e.lineTo(r + f, l + c), e.quadraticCurveTo(r, l + c, r, l + c - f), a === "center" && n === "left" && this.drawCaret(t, e, i, s), e.lineTo(r, l + d), e.quadraticCurveTo(r, l, r + d, l), e.closePath(), e.fill(), s.borderWidth > 0 && e.stroke();
  }
  _updateAnimationTarget(t) {
    const e = this.chart, i = this.$animations, s = i && i.x, n = i && i.y;
    if (s || n) {
      const a = Lt[t.position].call(this, this._active, this._eventPosition);
      if (!a)
        return;
      const r = this._size = ci(this, t), l = Object.assign({}, a, this._size), h = di(e, t, l), c = ui(t, l, h, e);
      (s._to !== c.x || n._to !== c.y) && (this.xAlign = h.xAlign, this.yAlign = h.yAlign, this.width = r.width, this.height = r.height, this.caretX = a.x, this.caretY = a.y, this._resolveAnimations().update(this, c));
    }
  }
  _willRender() {
    return !!this.opacity;
  }
  draw(t) {
    const e = this.options.setContext(this.getContext());
    let i = this.opacity;
    if (!i)
      return;
    this._updateAnimationTarget(e);
    const s = {
      width: this.width,
      height: this.height
    }, n = {
      x: this.x,
      y: this.y
    };
    i = Math.abs(i) < 1e-3 ? 0 : i;
    const a = G(e.padding), r = this.title.length || this.beforeBody.length || this.body.length || this.afterBody.length || this.footer.length;
    e.enabled && r && (t.save(), t.globalAlpha = i, this.drawBackground(n, t, s, e), Mi(t, e.textDirection), n.y += a.top, this.drawTitle(n, t, e), this.drawBody(n, t, e), this.drawFooter(n, t, e), Si(t, e.textDirection), t.restore());
  }
  getActiveElements() {
    return this._active || [];
  }
  setActiveElements(t, e) {
    const i = this._active, s = t.map(({ datasetIndex: r, index: l }) => {
      const h = this.chart.getDatasetMeta(r);
      if (!h)
        throw new Error("Cannot find a dataset at index " + r);
      return {
        datasetIndex: r,
        element: h.data[l],
        index: l
      };
    }), n = !Xt(i, s), a = this._positionChanged(s, e);
    (n || a) && (this._active = s, this._eventPosition = e, this._ignoreReplayEvents = !0, this.update(!0));
  }
  handleEvent(t, e, i = !0) {
    if (e && this._ignoreReplayEvents)
      return !1;
    this._ignoreReplayEvents = !1;
    const s = this.options, n = this._active || [], a = this._getActiveElements(t, n, e, i), r = this._positionChanged(a, t), l = e || !Xt(a, n) || r;
    return l && (this._active = a, (s.enabled || s.external) && (this._eventPosition = {
      x: t.x,
      y: t.y
    }, this.update(!0, e))), l;
  }
  _getActiveElements(t, e, i, s) {
    const n = this.options;
    if (t.type === "mouseout")
      return [];
    if (!s)
      return e.filter((r) => this.chart.data.datasets[r.datasetIndex] && this.chart.getDatasetMeta(r.datasetIndex).controller.getParsed(r.index) !== void 0);
    const a = this.chart.getElementsAtEventForMode(t, n.mode, n, i);
    return n.reverse && a.reverse(), a;
  }
  _positionChanged(t, e) {
    const { caretX: i, caretY: s, options: n } = this, a = Lt[n.position].call(this, t, e);
    return a !== !1 && (i !== a.x || s !== a.y);
  }
}
var na = {
  id: "tooltip",
  _element: pi,
  positioners: Lt,
  afterInit(o, t, e) {
    e && (o.tooltip = new pi({
      chart: o,
      options: e
    }));
  },
  beforeUpdate(o, t, e) {
    o.tooltip && o.tooltip.initialize(e);
  },
  reset(o, t, e) {
    o.tooltip && o.tooltip.initialize(e);
  },
  afterDraw(o) {
    const t = o.tooltip;
    if (t && t._willRender()) {
      const e = {
        tooltip: t
      };
      if (o.notifyPlugins("beforeTooltipDraw", {
        ...e,
        cancelable: !0
      }) === !1)
        return;
      t.draw(o.ctx), o.notifyPlugins("afterTooltipDraw", e);
    }
  },
  afterEvent(o, t) {
    if (o.tooltip) {
      const e = t.replay;
      o.tooltip.handleEvent(t.event, e, t.inChartArea) && (t.changed = !0);
    }
  },
  defaults: {
    enabled: !0,
    external: null,
    position: "average",
    backgroundColor: "rgba(0,0,0,0.8)",
    titleColor: "#fff",
    titleFont: {
      weight: "bold"
    },
    titleSpacing: 2,
    titleMarginBottom: 6,
    titleAlign: "left",
    bodyColor: "#fff",
    bodySpacing: 2,
    bodyFont: {},
    bodyAlign: "left",
    footerColor: "#fff",
    footerSpacing: 2,
    footerMarginTop: 6,
    footerFont: {
      weight: "bold"
    },
    footerAlign: "left",
    padding: 6,
    caretPadding: 2,
    caretSize: 5,
    cornerRadius: 6,
    boxHeight: (o, t) => t.bodyFont.size,
    boxWidth: (o, t) => t.bodyFont.size,
    multiKeyBackground: "#fff",
    displayColors: !0,
    boxPadding: 0,
    borderColor: "rgba(0,0,0,0)",
    borderWidth: 0,
    animation: {
      duration: 400,
      easing: "easeOutQuart"
    },
    animations: {
      numbers: {
        type: "number",
        properties: [
          "x",
          "y",
          "width",
          "height",
          "caretX",
          "caretY"
        ]
      },
      opacity: {
        easing: "linear",
        duration: 200
      }
    },
    callbacks: Xi
  },
  defaultRoutes: {
    bodyFont: "font",
    footerFont: "font",
    titleFont: "font"
  },
  descriptors: {
    _scriptable: (o) => o !== "filter" && o !== "itemSort" && o !== "external",
    _indexable: !1,
    callbacks: {
      _scriptable: !1,
      _indexable: !1
    },
    animation: {
      _fallback: !1
    },
    animations: {
      _fallback: "animation"
    }
  },
  additionalOptionScopes: [
    "interaction"
  ]
};
const Vo = (o, t, e, i) => (typeof t == "string" ? (e = o.push(t) - 1, i.unshift({
  index: e,
  label: t
})) : isNaN(t) && (e = null), e);
function No(o, t, e, i) {
  const s = o.indexOf(t);
  if (s === -1)
    return Vo(o, t, e, i);
  const n = o.lastIndexOf(t);
  return s !== n ? e : s;
}
const jo = (o, t) => o === null ? null : U(Math.round(o), 0, t);
function mi(o) {
  const t = this.getLabels();
  return o >= 0 && o < t.length ? t[o] : o;
}
class oa extends kt {
  static id = "category";
  static defaults = {
    ticks: {
      callback: mi
    }
  };
  constructor(t) {
    super(t), this._startValue = void 0, this._valueRange = 0, this._addedLabels = [];
  }
  init(t) {
    const e = this._addedLabels;
    if (e.length) {
      const i = this.getLabels();
      for (const { index: s, label: n } of e)
        i[s] === n && i.splice(s, 1);
      this._addedLabels = [];
    }
    super.init(t);
  }
  parse(t, e) {
    if (z(t))
      return null;
    const i = this.getLabels();
    return e = isFinite(e) && i[e] === t ? e : No(i, t, O(e, t), this._addedLabels), jo(e, i.length - 1);
  }
  determineDataLimits() {
    const { minDefined: t, maxDefined: e } = this.getUserBounds();
    let { min: i, max: s } = this.getMinMax(!0);
    this.options.bounds === "ticks" && (t || (i = 0), e || (s = this.getLabels().length - 1)), this.min = i, this.max = s;
  }
  buildTicks() {
    const t = this.min, e = this.max, i = this.options.offset, s = [];
    let n = this.getLabels();
    n = t === 0 && e === n.length - 1 ? n : n.slice(t, e + 1), this._valueRange = Math.max(n.length - (i ? 0 : 1), 1), this._startValue = this.min - (i ? 0.5 : 0);
    for (let a = t; a <= e; a++)
      s.push({
        value: a
      });
    return s;
  }
  getLabelForValue(t) {
    return mi.call(this, t);
  }
  configure() {
    super.configure(), this.isHorizontal() || (this._reversePixels = !this._reversePixels);
  }
  getPixelForValue(t) {
    return typeof t != "number" && (t = this.parse(t)), t === null ? NaN : this.getPixelForDecimal((t - this._startValue) / this._valueRange);
  }
  getPixelForTick(t) {
    const e = this.ticks;
    return t < 0 || t > e.length - 1 ? null : this.getPixelForValue(e[t].value);
  }
  getValueForPixel(t) {
    return Math.round(this._startValue + this.getDecimalForPixel(t) * this._valueRange);
  }
  getBasePixel() {
    return this.bottom;
  }
}
function $o(o, t) {
  const e = [], { bounds: s, step: n, min: a, max: r, precision: l, count: h, maxTicks: c, maxDigits: d, includeBounds: u } = o, f = n || 1, g = c - 1, { min: p, max: _ } = t, m = !z(a), x = !z(r), v = !z(h), y = (_ - p) / (d + 1);
  let b = Le((_ - p) / g / f) * f, k, w, M, S;
  if (b < 1e-14 && !m && !x)
    return [
      {
        value: p
      },
      {
        value: _
      }
    ];
  S = Math.ceil(_ / b) - Math.floor(p / b), S > g && (b = Le(S * b / g / f) * f), z(l) || (k = Math.pow(10, l), b = Math.ceil(b * k) / k), s === "ticks" ? (w = Math.floor(p / b) * b, M = Math.ceil(_ / b) * b) : (w = p, M = _), m && x && n && Ss((r - a) / n, b / 1e3) ? (S = Math.round(Math.min((r - a) / b, c)), b = (r - a) / S, w = a, M = r) : v ? (w = m ? a : w, M = x ? r : M, S = h - 1, b = (M - w) / S) : (S = (M - w) / b, se(S, Math.round(S), b / 1e3) ? S = Math.round(S) : S = Math.ceil(S));
  const C = Math.max(Ee(b), Ee(w));
  k = Math.pow(10, z(l) ? C : l), w = Math.round(w * k) / k, M = Math.round(M * k) / k;
  let D = 0;
  for (m && (u && w !== a ? (e.push({
    value: a
  }), w < a && D++, se(Math.round((w + D * b) * k) / k, a, _i(a, y, o)) && D++) : w < a && D++); D < S; ++D) {
    const A = Math.round((w + D * b) * k) / k;
    if (x && A > r)
      break;
    e.push({
      value: A
    });
  }
  return x && u && M !== r ? e.length && se(e[e.length - 1].value, r, _i(r, y, o)) ? e[e.length - 1].value = r : e.push({
    value: r
  }) : (!x || M === r) && e.push({
    value: M
  }), e;
}
function _i(o, t, { horizontal: e, minRotation: i }) {
  const s = at(i), n = (e ? Math.sin(s) : Math.cos(s)) || 1e-3, a = 0.75 * t * ("" + o).length;
  return Math.min(t / n, a);
}
class Yo extends kt {
  constructor(t) {
    super(t), this.start = void 0, this.end = void 0, this._startValue = void 0, this._endValue = void 0, this._valueRange = 0;
  }
  parse(t, e) {
    return z(t) || (typeof t == "number" || t instanceof Number) && !isFinite(+t) ? null : +t;
  }
  handleTickRangeOptions() {
    const { beginAtZero: t } = this.options, { minDefined: e, maxDefined: i } = this.getUserBounds();
    let { min: s, max: n } = this;
    const a = (l) => s = e ? s : l, r = (l) => n = i ? n : l;
    if (t) {
      const l = Jt(s), h = Jt(n);
      l < 0 && h < 0 ? r(0) : l > 0 && h > 0 && a(0);
    }
    if (s === n) {
      let l = n === 0 ? 1 : Math.abs(n * 0.05);
      r(n + l), t || a(s - l);
    }
    this.min = s, this.max = n;
  }
  getTickLimit() {
    const t = this.options.ticks;
    let { maxTicksLimit: e, stepSize: i } = t, s;
    return i ? (s = Math.ceil(this.max / i) - Math.floor(this.min / i) + 1, s > 1e3 && (console.warn(`scales.${this.id}.ticks.stepSize: ${i} would result generating up to ${s} ticks. Limiting to 1000.`), s = 1e3)) : (s = this.computeTickLimit(), e = e || 11), e && (s = Math.min(e, s)), s;
  }
  computeTickLimit() {
    return Number.POSITIVE_INFINITY;
  }
  buildTicks() {
    const t = this.options, e = t.ticks;
    let i = this.getTickLimit();
    i = Math.max(2, i);
    const s = {
      maxTicks: i,
      bounds: t.bounds,
      min: t.min,
      max: t.max,
      precision: e.precision,
      step: e.stepSize,
      count: e.count,
      maxDigits: this._maxDigits(),
      horizontal: this.isHorizontal(),
      minRotation: e.minRotation || 0,
      includeBounds: e.includeBounds !== !1
    }, n = this._range || this, a = $o(s, n);
    return t.bounds === "ticks" && gs(a, this, "value"), t.reverse ? (a.reverse(), this.start = this.max, this.end = this.min) : (this.start = this.min, this.end = this.max), a;
  }
  configure() {
    const t = this.ticks;
    let e = this.min, i = this.max;
    if (super.configure(), this.options.offset && t.length) {
      const s = (i - e) / Math.max(t.length - 1, 1) / 2;
      e -= s, i += s;
    }
    this._startValue = e, this._endValue = i, this._valueRange = i - e;
  }
  getLabelForValue(t) {
    return Ai(t, this.chart.options.locale, this.options.ticks.format);
  }
}
class aa extends Yo {
  static id = "linear";
  static defaults = {
    ticks: {
      callback: ss.formatters.numeric
    }
  };
  determineDataLimits() {
    const { min: t, max: e } = this.getMinMax(!0);
    this.min = it(t) ? t : 0, this.max = it(e) ? e : 1, this.handleTickRangeOptions();
  }
  computeTickLimit() {
    const t = this.isHorizontal(), e = t ? this.width : this.height, i = at(this.options.ticks.minRotation), s = (t ? Math.sin(i) : Math.cos(i)) || 1e-3, n = this._resolveTickFontOptions(0);
    return Math.ceil(e / Math.min(40, n.lineHeight / s));
  }
  getPixelForValue(t) {
    return t === null ? NaN : this.getPixelForDecimal((t - this._startValue) / this._valueRange);
  }
  getValueForPixel(t) {
    return this._startValue + this.getDecimalForPixel(t) * this._valueRange;
  }
}
const ie = {
  millisecond: {
    common: !0,
    size: 1,
    steps: 1e3
  },
  second: {
    common: !0,
    size: 1e3,
    steps: 60
  },
  minute: {
    common: !0,
    size: 6e4,
    steps: 60
  },
  hour: {
    common: !0,
    size: 36e5,
    steps: 24
  },
  day: {
    common: !0,
    size: 864e5,
    steps: 30
  },
  week: {
    common: !1,
    size: 6048e5,
    steps: 4
  },
  month: {
    common: !0,
    size: 2628e6,
    steps: 12
  },
  quarter: {
    common: !1,
    size: 7884e6,
    steps: 4
  },
  year: {
    common: !0,
    size: 3154e7
  }
}, j = /* @__PURE__ */ Object.keys(ie);
function bi(o, t) {
  return o - t;
}
function xi(o, t) {
  if (z(t))
    return null;
  const e = o._adapter, { parser: i, round: s, isoWeekday: n } = o._parseOpts;
  let a = t;
  return typeof i == "function" && (a = i(a)), it(a) || (a = typeof i == "string" ? e.parse(a, i) : e.parse(a)), a === null ? null : (s && (a = s === "week" && (Rt(n) || n === !0) ? e.startOf(a, "isoWeek", n) : e.startOf(a, s)), +a);
}
function yi(o, t, e, i) {
  const s = j.length;
  for (let n = j.indexOf(o); n < s - 1; ++n) {
    const a = ie[j[n]], r = a.steps ? a.steps : Number.MAX_SAFE_INTEGER;
    if (a.common && Math.ceil((e - t) / (r * a.size)) <= i)
      return j[n];
  }
  return j[s - 1];
}
function Uo(o, t, e, i, s) {
  for (let n = j.length - 1; n >= j.indexOf(e); n--) {
    const a = j[n];
    if (ie[a].common && o._adapter.diff(s, i, a) >= t - 1)
      return a;
  }
  return j[e ? j.indexOf(e) : 0];
}
function Xo(o) {
  for (let t = j.indexOf(o) + 1, e = j.length; t < e; ++t)
    if (ie[j[t]].common)
      return j[t];
}
function vi(o, t, e) {
  if (!e)
    o[t] = !0;
  else if (e.length) {
    const { lo: i, hi: s } = bs(e, t), n = e[i] >= t ? e[i] : e[s];
    o[n] = !0;
  }
}
function Ko(o, t, e, i) {
  const s = o._adapter, n = +s.startOf(t[0].value, i), a = t[t.length - 1].value;
  let r, l;
  for (r = n; r <= a; r = +s.add(r, 1, i))
    l = e[r], l >= 0 && (t[l].major = !0);
  return t;
}
function ki(o, t, e) {
  const i = [], s = {}, n = t.length;
  let a, r;
  for (a = 0; a < n; ++a)
    r = t[a], s[r] = a, i.push({
      value: r,
      major: !1
    });
  return n === 0 || !e ? i : Ko(o, i, s, e);
}
class wi extends kt {
  static id = "time";
  static defaults = {
    bounds: "data",
    adapters: {},
    time: {
      parser: !1,
      unit: !1,
      round: !1,
      isoWeekday: !1,
      minUnit: "millisecond",
      displayFormats: {}
    },
    ticks: {
      source: "auto",
      callback: !1,
      major: {
        enabled: !1
      }
    }
  };
  constructor(t) {
    super(t), this._cache = {
      data: [],
      labels: [],
      all: []
    }, this._unit = "day", this._majorUnit = void 0, this._offsets = {}, this._normalized = !1, this._parseOpts = void 0;
  }
  init(t, e = {}) {
    const i = t.time || (t.time = {}), s = this._adapter = new qs._date(t.adapters.date);
    s.init(e), jt(i.displayFormats, s.formats()), this._parseOpts = {
      parser: i.parser,
      round: i.round,
      isoWeekday: i.isoWeekday
    }, super.init(t), this._normalized = e.normalized;
  }
  parse(t, e) {
    return t === void 0 ? null : xi(this, t);
  }
  beforeLayout() {
    super.beforeLayout(), this._cache = {
      data: [],
      labels: [],
      all: []
    };
  }
  determineDataLimits() {
    const t = this.options, e = this._adapter, i = t.time.unit || "day";
    let { min: s, max: n, minDefined: a, maxDefined: r } = this.getUserBounds();
    function l(h) {
      !a && !isNaN(h.min) && (s = Math.min(s, h.min)), !r && !isNaN(h.max) && (n = Math.max(n, h.max));
    }
    (!a || !r) && (l(this._getLabelBounds()), (t.bounds !== "ticks" || t.ticks.source !== "labels") && l(this.getMinMax(!1))), s = it(s) && !isNaN(s) ? s : +e.startOf(Date.now(), i), n = it(n) && !isNaN(n) ? n : +e.endOf(Date.now(), i) + 1, this.min = Math.min(s, n - 1), this.max = Math.max(s + 1, n);
  }
  _getLabelBounds() {
    const t = this.getLabelTimestamps();
    let e = Number.POSITIVE_INFINITY, i = Number.NEGATIVE_INFINITY;
    return t.length && (e = t[0], i = t[t.length - 1]), {
      min: e,
      max: i
    };
  }
  buildTicks() {
    const t = this.options, e = t.time, i = t.ticks, s = i.source === "labels" ? this.getLabelTimestamps() : this._generate();
    t.bounds === "ticks" && s.length && (this.min = this._userMin || s[0], this.max = this._userMax || s[s.length - 1]);
    const n = this.min, a = this.max, r = os(s, n, a);
    return this._unit = e.unit || (i.autoSkip ? yi(e.minUnit, this.min, this.max, this._getLabelCapacity(n)) : Uo(this, r.length, e.minUnit, this.min, this.max)), this._majorUnit = !i.major.enabled || this._unit === "year" ? void 0 : Xo(this._unit), this.initOffsets(s), t.reverse && r.reverse(), ki(this, r, this._majorUnit);
  }
  afterAutoSkip() {
    this.options.offsetAfterAutoskip && this.initOffsets(this.ticks.map((t) => +t.value));
  }
  initOffsets(t = []) {
    let e = 0, i = 0, s, n;
    this.options.offset && t.length && (s = this.getDecimalForValue(t[0]), t.length === 1 ? e = 1 - s : e = (this.getDecimalForValue(t[1]) - s) / 2, n = this.getDecimalForValue(t[t.length - 1]), t.length === 1 ? i = n : i = (n - this.getDecimalForValue(t[t.length - 2])) / 2);
    const a = t.length < 3 ? 0.5 : 0.25;
    e = U(e, 0, a), i = U(i, 0, a), this._offsets = {
      start: e,
      end: i,
      factor: 1 / (e + 1 + i)
    };
  }
  _generate() {
    const t = this._adapter, e = this.min, i = this.max, s = this.options, n = s.time, a = n.unit || yi(n.minUnit, e, i, this._getLabelCapacity(e)), r = O(s.ticks.stepSize, 1), l = a === "week" ? n.isoWeekday : !1, h = Rt(l) || l === !0, c = {};
    let d = e, u, f;
    if (h && (d = +t.startOf(d, "isoWeek", l)), d = +t.startOf(d, h ? "day" : a), t.diff(i, e, a) > 1e5 * r)
      throw new Error(e + " and " + i + " are too far apart with stepSize of " + r + " " + a);
    const g = s.ticks.source === "data" && this.getDataTimestamps();
    for (u = d, f = 0; u < i; u = +t.add(u, r, a), f++)
      vi(c, u, g);
    return (u === i || s.bounds === "ticks" || f === 1) && vi(c, u, g), Object.keys(c).sort(bi).map((p) => +p);
  }
  getLabelForValue(t) {
    const e = this._adapter, i = this.options.time;
    return i.tooltipFormat ? e.format(t, i.tooltipFormat) : e.format(t, i.displayFormats.datetime);
  }
  format(t, e) {
    const s = this.options.time.displayFormats, n = this._unit, a = e || s[n];
    return this._adapter.format(t, a);
  }
  _tickFormatFunction(t, e, i, s) {
    const n = this.options, a = n.ticks.callback;
    if (a)
      return T(a, [
        t,
        e,
        i
      ], this);
    const r = n.time.displayFormats, l = this._unit, h = this._majorUnit, c = l && r[l], d = h && r[h], u = i[e], f = h && d && u && u.major;
    return this._adapter.format(t, s || (f ? d : c));
  }
  generateTickLabels(t) {
    let e, i, s;
    for (e = 0, i = t.length; e < i; ++e)
      s = t[e], s.label = this._tickFormatFunction(s.value, e, t);
  }
  getDecimalForValue(t) {
    return t === null ? NaN : (t - this.min) / (this.max - this.min);
  }
  getPixelForValue(t) {
    const e = this._offsets, i = this.getDecimalForValue(t);
    return this.getPixelForDecimal((e.start + i) * e.factor);
  }
  getValueForPixel(t) {
    const e = this._offsets, i = this.getDecimalForPixel(t) / e.factor - e.end;
    return this.min + i * (this.max - this.min);
  }
  _getLabelSize(t) {
    const e = this.options.ticks, i = this.ctx.measureText(t).width, s = at(this.isHorizontal() ? e.maxRotation : e.minRotation), n = Math.cos(s), a = Math.sin(s), r = this._resolveTickFontOptions(0).size;
    return {
      w: i * n + r * a,
      h: i * a + r * n
    };
  }
  _getLabelCapacity(t) {
    const e = this.options.time, i = e.displayFormats, s = i[e.unit] || i.millisecond, n = this._tickFormatFunction(t, 0, ki(this, [
      t
    ], this._majorUnit), s), a = this._getLabelSize(n), r = Math.floor(this.isHorizontal() ? this.width / a.w : this.height / a.h) - 1;
    return r > 0 ? r : 1;
  }
  getDataTimestamps() {
    let t = this._cache.data || [], e, i;
    if (t.length)
      return t;
    const s = this.getMatchingVisibleMetas();
    if (this._normalized && s.length)
      return this._cache.data = s[0].controller.getAllParsedValues(this);
    for (e = 0, i = s.length; e < i; ++e)
      t = t.concat(s[e].controller.getAllParsedValues(this));
    return this._cache.data = this.normalize(t);
  }
  getLabelTimestamps() {
    const t = this._cache.labels || [];
    let e, i;
    if (t.length)
      return t;
    const s = this.getLabels();
    for (e = 0, i = s.length; e < i; ++e)
      t.push(xi(this, s[e]));
    return this._cache.labels = this._normalized ? t : this.normalize(t);
  }
  normalize(t) {
    return as(t.sort(bi));
  }
}
function Nt(o, t, e) {
  let i = 0, s = o.length - 1, n, a, r, l;
  e ? (t >= o[i].pos && t <= o[s].pos && ({ lo: i, hi: s } = ge(o, "pos", t)), { pos: n, time: r } = o[i], { pos: a, time: l } = o[s]) : (t >= o[i].time && t <= o[s].time && ({ lo: i, hi: s } = ge(o, "time", t)), { time: n, pos: r } = o[i], { time: a, pos: l } = o[s]);
  const h = a - n;
  return h ? r + (l - r) * (t - n) / h : r;
}
class ra extends wi {
  static id = "timeseries";
  static defaults = wi.defaults;
  constructor(t) {
    super(t), this._table = [], this._minPos = void 0, this._tableRange = void 0;
  }
  initOffsets() {
    const t = this._getTimestampsForTable(), e = this._table = this.buildLookupTable(t);
    this._minPos = Nt(e, this.min), this._tableRange = Nt(e, this.max) - this._minPos, super.initOffsets(t);
  }
  buildLookupTable(t) {
    const { min: e, max: i } = this, s = [], n = [];
    let a, r, l, h, c;
    for (a = 0, r = t.length; a < r; ++a)
      h = t[a], h >= e && h <= i && s.push(h);
    if (s.length < 2)
      return [
        {
          time: e,
          pos: 0
        },
        {
          time: i,
          pos: 1
        }
      ];
    for (a = 0, r = s.length; a < r; ++a)
      c = s[a + 1], l = s[a - 1], h = s[a], Math.round((c + l) / 2) !== h && n.push({
        time: h,
        pos: a / (r - 1)
      });
    return n;
  }
  _generate() {
    const t = this.min, e = this.max;
    let i = super.getDataTimestamps();
    return (!i.includes(t) || !i.length) && i.splice(0, 0, t), (!i.includes(e) || i.length === 1) && i.push(e), i.sort((s, n) => s - n);
  }
  _getTimestampsForTable() {
    let t = this._cache.all || [];
    if (t.length)
      return t;
    const e = this.getDataTimestamps(), i = this.getLabelTimestamps();
    return e.length && i.length ? t = this.normalize(e.concat(i)) : t = e.length ? e : i, t = this._cache.all = t, t;
  }
  getDecimalForValue(t) {
    return (Nt(this._table, t) - this._minPos) / this._tableRange;
  }
  getValueForPixel(t) {
    const e = this._offsets, i = this.getDecimalForPixel(t) / e.factor - e.end;
    return Nt(this._table, i * this._tableRange + this._minPos, !0);
  }
}
export {
  Is as Animation,
  Li as Animations,
  Qo as ArcElement,
  ea as BarElement,
  zi as BasePlatform,
  cn as BasicPlatform,
  oa as CategoryScale,
  ao as Chart,
  ke as DatasetController,
  kn as DomPlatform,
  Gs as DoughnutController,
  rt as Element,
  en as Interaction,
  ia as Legend,
  qo as LineController,
  Zo as LineElement,
  aa as LinearScale,
  Jo as PieController,
  ta as PointElement,
  kt as Scale,
  ss as Ticks,
  wi as TimeScale,
  ra as TimeSeriesScale,
  sa as Title,
  na as Tooltip,
  qs as _adapters,
  wn as _detectPlatform,
  nt as animator,
  I as defaults,
  K as layouts,
  tt as registry
};
