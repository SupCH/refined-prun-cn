import { $ as r } from "./select-dom.js";
import { C as e } from "./prun-css.js";
import { createFragmentApp as i } from "./vue-fragment-app.js";
import m from "./tiles.js";
import f from "./feature-registry.js";
import { showBuffer as n } from "./buffers.js";
import l from "./TileControlsButton.vue.js";
async function a(o) {
  const t = await r(o.frame, e.TileControls.splitControls);
  i(l, {
    icon: "",
    onClick: () => n(o.fullCommand, { force: !0 })
  }).before(t);
}
function p() {
  m.observeAll(a);
}
f.add(import.meta.url, p, "Adds a tile duplicate button to the buffer header.");
