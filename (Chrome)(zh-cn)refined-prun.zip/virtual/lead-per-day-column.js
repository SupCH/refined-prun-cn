import { subscribe as o } from "./subscribe-async-generator.js";
import { _$$ as b, $$ as r } from "./select-dom.js";
import { C as g } from "./prun-css.js";
import x from "./tiles.js";
import E from "./feature-registry.js";
import { refValue as A } from "./reactive-dom.js";
import { fixed0 as y, fixed01 as P, fixed02 as T } from "./format.js";
import { watchEffectWhileNodeAlive as I } from "./watch.js";
import { ref as L } from "./reactivity.esm-bundler.js";
import { computed as O } from "./runtime-core.esm-bundler.js";
async function S(c) {
  o(r(c.anchor, g.Leaderboard.leaderboardTypeSelect), () => {
    const u = b(c.anchor, "select"), i = u.find((e) => e.name === "type"), f = u.find((e) => e.name === "range");
    if (!i || !f)
      return;
    const s = L(i.value), C = b(c.anchor, "button");
    for (const e of C)
      e.addEventListener("click", () => s.value = i.value);
    const D = A(f), p = O(() => {
      if (s.value === "PRODUCTION")
        return parseInt(D.value.replace("DAYS_", ""), 10);
    });
    o(r(c.anchor, "table"), (e) => {
      o(r(e, "thead"), (d) => {
        o(r(d, "tr"), (n) => {
          if (n.children.length < 2)
            return;
          const t = document.createElement("th");
          t.textContent = "Per Day", I(n, () => {
            s.value === "PRODUCTION" ? n.children[1].after(t) : t.remove();
          });
        });
      }), o(r(e, "tbody"), (d) => {
        o(r(d, "tr"), (n) => {
          const t = n.children[1], l = t?.children[0];
          if (l === void 0 || p.value === void 0)
            return;
          const h = parseInt(l.textContent ?? "", 10);
          l.textContent = y(h);
          const v = h / p.value;
          if (!isFinite(v))
            return;
          const m = document.createElement("td");
          m.style.backgroundColor = t.style.backgroundColor, t.after(m);
          const a = Math.abs(v);
          m.textContent = a >= 1e3 ? y(a) : a >= 100 ? P(a) : T(a);
        });
      });
    });
  });
}
function $() {
  x.observe("LEAD", S);
}
E.add(
  import.meta.url,
  $,
  'LEAD: Adds a "Per Day" column to the "Commodity Production" leaderboard.'
);
