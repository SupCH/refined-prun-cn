const o = "rp-clickable-apex-logo__logo___63cd318", l = {
  logo: o
};
export {
  l as default,
  o as logo
};
