import { C as t } from "./prun-css.js";
import { showBuffer as f } from "./buffers.js";
import { defineComponent as d, computed as u, createElementBlock as m, openBlock as a, createElementVNode as i, createCommentVNode as b, createTextVNode as k } from "./runtime-core.esm-bundler.js";
import { unref as n } from "./reactivity.esm-bundler.js";
import { normalizeClass as s, toDisplayString as r } from "./shared.esm-bundler.js";
const h = /* @__PURE__ */ d({
  __name: "ContextControlsItem",
  props: {
    cmd: {},
    label: {}
  },
  setup(p) {
    const C = p, l = u(() => {
      const e = C.cmd.split(" ");
      let o = e.shift();
      return o === "XIT" && (o += " " + e.shift()), [o, e.join(" ")];
    }), c = [t.ContextControls.item, t.fonts.fontRegular, t.type.typeSmall];
    return (e, o) => (a(), m("div", {
      class: s(c),
      onClick: o[0] || (o[0] = () => n(f)(e.cmd))
    }, [
      i("span", null, [
        i("span", {
          class: s(("C" in e ? e.C : n(t)).ContextControls.cmd)
        }, r(n(l)[0]), 3),
        k(" " + r(n(l)[1]), 1)
      ]),
      e.label ? (a(), m("span", {
        key: 0,
        class: s(("C" in e ? e.C : n(t)).ContextControls.label)
      }, ": " + r(e.label), 3)) : b("", !0)
    ]));
  }
});
export {
  h as default
};
