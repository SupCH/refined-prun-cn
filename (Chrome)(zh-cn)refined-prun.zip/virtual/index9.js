import { __module as t } from "./index10.js";
import { __require as _ } from "./lexer.js";
import { __require as h } from "./token.js";
import { __require as m } from "./postfix.js";
import { __require as q } from "./postfix_evaluator.js";
import { __require as l } from "./functions.js";
var s;
function P() {
  if (s) return t.exports;
  s = 1;
  var i = _(), e = h(), u = m(), n = q(), a = l(), r = (function() {
    function o() {
      this.toPostfix = u.toPostfix, this.addToken = i.addToken, this.lex = i.lex, this.postfixEval = n.postfixEval, this.math = a.createMathFunctions(this), this.tokens = e.createTokens(this);
    }
    return o.prototype.eval = function(f, p, x) {
      return this.postfixEval(this.toPostfix(this.lex(f, p)), x);
    }, o;
  })();
  return r.TOKEN_TYPES = e.tokenTypes, r.tokenTypes = e.tokenTypes, t.exports = r, t.exports;
}
export {
  P as __require
};
