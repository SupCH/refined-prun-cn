const s = "rp-contd-upward-search-results__suggestions___ece5509", e = {
  suggestions: s
};
export {
  e as default,
  s as suggestions
};
