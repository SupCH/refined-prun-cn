const e = /* @__PURE__ */ Object.create(null);
e.open = "0";
e.close = "1";
e.ping = "2";
e.pong = "3";
e.message = "4";
e.upgrade = "5";
e.noop = "6";
const o = /* @__PURE__ */ Object.create(null);
Object.keys(e).forEach((r) => {
  o[e[r]] = r;
});
const t = { type: "error", data: "parser error" };
export {
  t as ERROR_PACKET,
  e as PACKET_TYPES,
  o as PACKET_TYPES_REVERSE
};
