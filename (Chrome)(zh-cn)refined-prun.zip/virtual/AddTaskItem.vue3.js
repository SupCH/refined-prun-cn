const _ = "rp-AddTaskItem__item___43d3125", t = "rp-AddTaskItem__checkmark___610406f", e = "rp-AddTaskItem__plus___6b7b078", s = "rp-AddTaskItem__plusHover___f4736e9", c = "rp-AddTaskItem__content___be4ccd9", d = {
  item: _,
  checkmark: t,
  plus: e,
  plusHover: s,
  content: c
};
export {
  t as checkmark,
  c as content,
  d as default,
  _ as item,
  e as plus,
  s as plusHover
};
