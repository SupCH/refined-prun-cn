const t = document.getElementById("refined-prun-js"), e = JSON.parse(t.textContent);
t.textContent = null;
export {
  e as default
};
