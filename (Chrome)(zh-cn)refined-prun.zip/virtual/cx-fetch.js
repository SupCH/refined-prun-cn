import { act as n } from "./act-registry.js";
import { t as r } from "./index5.js";
import { showBuffer as p } from "./buffers.js";
import { sleep as f } from "./sleep.js";
import m from "./Edit.vue4.js";
const h = n.addActionStep({
  type: "CX_FETCH_STEP",
  description: (e) => r("act.fetchPriceStep", e.exchange, (e.tickers || []).join(", ")),
  execute: async (e) => {
    const { data: t, complete: c } = e, s = t.tickers || [], a = `cx-fetch-${Date.now()}`;
    for (const i of s) {
      try {
        const o = await p(`CXPO ${i}.${t.exchange}`);
        o && o.setAttribute("data-cx-fetch-session", a);
      } catch (o) {
        console.error(`Failed to open CXPO window for ${i}`, o);
      }
      await f(300);
    }
    c();
  }
});
n.addAction({
  type: "CX Fetch",
  description: (e) => r("act.fetchPriceDescription", e.exchange, (e.tickers || []).length),
  editComponent: m,
  generateSteps: async (e) => {
    const { emitStep: t, data: c } = e;
    t(
      h({
        tickers: c.tickers || [],
        exchange: c.exchange || ""
      })
    );
  }
});
