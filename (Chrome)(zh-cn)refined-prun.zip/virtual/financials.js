import { nonCurrentAssets as a } from "./non-current-assets.js";
import { inventory as i } from "./inventory.js";
import { workInProgressByLocation as u } from "./orders2.js";
function f() {
  const r = [];
  function e(t) {
    let o = r.find((n) => n.name === t);
    return o || (o = {
      name: t,
      current: 0,
      nonCurrent: 0,
      total: 0
    }, r.push(o)), o;
  }
  if (i.byLocation.value) {
    for (const [t, o] of i.byLocation.value) {
      const n = e(t);
      n.current += o, n.total += o;
    }
    if (u.value) {
      for (const [t, o] of u.value) {
        const n = e(t);
        n.current += o, n.total += o;
      }
      if (a.buildingsNetValueByLocation.value) {
        for (const [t, o] of a.buildingsNetValueByLocation.value) {
          const n = e(t);
          n.nonCurrent += o, n.total += o;
        }
        return r.sort((t, o) => o.total - t.total), r;
      }
    }
  }
}
export {
  f as calculateLocationAssets
};
