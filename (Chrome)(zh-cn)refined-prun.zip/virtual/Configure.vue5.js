import f from "./Configure.vue.js";
export {
  f as default
};
