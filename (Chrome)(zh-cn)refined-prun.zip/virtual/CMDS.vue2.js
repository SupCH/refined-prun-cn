import f from "./CMDS.vue.js";
export {
  f as default
};
