import { PACKET_TYPES_REVERSE as s, ERROR_PACKET as n } from "./commons.js";
import { decode as u } from "./base64-arraybuffer.js";
const o = typeof ArrayBuffer == "function", a = (r, e) => {
  if (typeof r != "string")
    return {
      type: "message",
      data: f(r, e)
    };
  const t = r.charAt(0);
  return t === "b" ? {
    type: "message",
    data: i(r.substring(1), e)
  } : s[t] ? r.length > 1 ? {
    type: s[t],
    data: r.substring(1)
  } : {
    type: s[t]
  } : n;
}, i = (r, e) => {
  if (o) {
    const t = u(r);
    return f(t, e);
  } else
    return { base64: !0, data: r };
}, f = (r, e) => {
  switch (e) {
    case "blob":
      return r instanceof Blob ? r : new Blob([r]);
    case "arraybuffer":
    default:
      return r instanceof ArrayBuffer ? r : r.buffer;
  }
};
export {
  a as decodePacket
};
