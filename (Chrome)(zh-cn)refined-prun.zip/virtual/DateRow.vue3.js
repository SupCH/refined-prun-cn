const t = "rp-DateRow__column___6dae58c", o = "rp-DateRow__totals___c8bbf55", a = "rp-DateRow__totalsColumn___25ccac3", _ = "rp-DateRow__totalsSeparator___58002b1", l = {
  column: t,
  totals: o,
  totalsColumn: a,
  totalsSeparator: _
};
export {
  t as column,
  l as default,
  o as totals,
  a as totalsColumn,
  _ as totalsSeparator
};
