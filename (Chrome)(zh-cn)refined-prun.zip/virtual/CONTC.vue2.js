import f from "./CONTC.vue.js";
export {
  f as default
};
