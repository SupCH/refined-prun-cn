import { C as n } from "./prun-css.js";
import r from "./tiles.js";
import t from "./feature-registry.js";
import { UI_WINDOWS_REQUEST_FOCUS as i } from "./client-messages.js";
import { dispatchClientPrunMessage as m } from "./prun-api-listener.js";
async function d(o) {
  if (o.docked || o.command === "HQ")
    return;
  o.frame.closest(`.${n.Window.window}`)?.addEventListener("mousedown", () => {
    const e = i(o.id);
    m(e);
  });
}
function s() {
  r.observeAll(d);
}
t.add(import.meta.url, s, "Focuses buffers on click anywhere, not just the header.");
