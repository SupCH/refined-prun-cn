import { vModelText as a } from "./runtime-dom.esm-bundler.js";
import { defineComponent as d, useModel as n, createElementBlock as r, openBlock as u, withDirectives as m, createElementVNode as p } from "./runtime-core.esm-bundler.js";
const f = /* @__PURE__ */ d({
  __name: "DateInput",
  props: {
    modelValue: {},
    modelModifiers: {}
  },
  emits: ["update:modelValue"],
  setup(o) {
    const e = n(o, "modelValue");
    return (i, t) => (u(), r("div", null, [
      m(p("input", {
        "onUpdate:modelValue": t[0] || (t[0] = (l) => e.value = l),
        type: "date",
        autocomplete: "off",
        "data-1p-ignore": "true",
        "data-lpignore": "true"
      }, null, 512), [
        [a, e.value]
      ])
    ]));
  }
});
export {
  f as default
};
