const t = "rp-FIN__tooltip___13df833", o = {
  tooltip: t
};
export {
  o as default,
  t as tooltip
};
