import n from "./ShipmentIcon.vue.js";
import { defineComponent as o, createBlock as r, openBlock as t } from "./runtime-core.esm-bundler.js";
import { normalizeClass as s } from "./shared.esm-bundler.js";
const a = /* @__PURE__ */ o({
  __name: "LMShipmentIcon",
  setup(c) {
    return (e, i) => (t(), r(n, {
      size: "inline",
      class: s(e.$style.icon)
    }, null, 8, ["class"]));
  }
});
export {
  a as default
};
