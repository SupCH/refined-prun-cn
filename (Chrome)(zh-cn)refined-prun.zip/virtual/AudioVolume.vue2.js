import { C as n } from "./prun-css.js";
import s from "./RangeInput.vue.js";
import { percent0 as u } from "./format.js";
import { userData as a } from "./user-data.js";
import { playAudio as r } from "./audio-interceptor.js";
import { toDisplayString as p, normalizeClass as i } from "./shared.esm-bundler.js";
import { ref as d, unref as o, isRef as f } from "./reactivity.esm-bundler.js";
import { defineComponent as C, watch as V, createElementBlock as c, openBlock as g, createElementVNode as y, createVNode as k, Fragment as R } from "./runtime-core.esm-bundler.js";
const I = /* @__PURE__ */ C({
  __name: "AudioVolume",
  setup(v) {
    const l = d(a.settings.audioVolume);
    return V(l, (e) => {
      const t = typeof e == "number" ? e : parseFloat(e);
      isFinite(t) && (a.settings.audioVolume = t);
    }), (e, t) => (g(), c(R, null, [
      y("div", {
        class: i([("C" in e ? e.C : o(n)).RadioItem.value, ("C" in e ? e.C : o(n)).fonts.fontRegular, ("C" in e ? e.C : o(n)).type.typeSmall, e.$style.label])
      }, " Audio Volume: " + p(o(u)(o(a).settings.audioVolume)), 3),
      k(s, {
        modelValue: o(l),
        "onUpdate:modelValue": t[0] || (t[0] = (m) => f(l) ? l.value = m : null),
        class: i(e.$style.slider),
        min: 0,
        max: 1,
        step: 0.01,
        "on-change": o(r),
        onClick: o(r)
      }, null, 8, ["modelValue", "class", "on-change", "onClick"])
    ], 64));
  }
});
export {
  I as default
};
