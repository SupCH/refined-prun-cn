import { subscribe as i } from "./subscribe-async-generator.js";
import { $$ as m } from "./select-dom.js";
import { createFragmentApp as t } from "./vue-fragment-app.js";
import e from "./tiles.js";
import n from "./feature-registry.js";
import { refPrunId as p } from "./attributes.js";
import a from "./ShipCondition.vue.js";
import { reactive as f } from "./reactivity.esm-bundler.js";
function c(o) {
  i(m(o.anchor, "tr"), (r) => {
    t(
      a,
      f({
        id: p(r)
      })
    ).appendTo(r.children[1]);
  });
}
function d() {
  e.observe(["FLT", "FLTS", "FLTP"], c);
}
n.add(import.meta.url, d, 'FLT: Adds a ship condition label to the "Name" column.');
