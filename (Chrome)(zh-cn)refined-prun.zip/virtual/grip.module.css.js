const p = "rp-grip__grip___8f6617d", r = {
  grip: p
};
export {
  r as default,
  p as grip
};
