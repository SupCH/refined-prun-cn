import { createEntityStore as r } from "./create-entity-store.js";
import { onApiMessage as s } from "./api-messages.js";
import { castArray as a } from "./cast-array.js";
const e = r(), A = e.state;
s({
  DATA_DATA(t) {
    t.path[0] !== "localmarkets" || t.path[2] !== "ads" || (e.setMany(a(t.body)), e.setFetched());
  },
  DATA_DATA_REMOVED(t) {
    const o = t.path[3];
    t.path[0] !== "localmarkets" || t.path[2] !== "ads" || o === void 0 || e.removeOne(o);
  }
});
const i = {
  ...A
};
export {
  i as localAdsStore
};
