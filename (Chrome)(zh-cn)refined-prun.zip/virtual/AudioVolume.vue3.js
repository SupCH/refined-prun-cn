const l = "rp-AudioVolume__label___ac59d55", e = "rp-AudioVolume__slider___6f8988b", _ = {
  label: l,
  slider: e
};
export {
  _ as default,
  l as label,
  e as slider
};
