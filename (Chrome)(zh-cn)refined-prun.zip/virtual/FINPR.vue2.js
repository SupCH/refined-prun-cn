import { C as y } from "./prun-css.js";
import { sitesStore as b } from "./sites.js";
import C from "./FinHeader.vue.js";
import k from "./KeyFigures.vue.js";
import { calculateSiteProfitability as w } from "./profitability.js";
import { sumBy as u } from "./sum-by.js";
import { formatCurrency as m, percent2 as P, fixed0 as s } from "./format.js";
import { map as _ } from "./map-values.js";
import { defineComponent as F, computed as o, createElementBlock as p, openBlock as f, createVNode as d, createElementVNode as l, withCtx as R, createTextVNode as D, Fragment as M, renderList as S } from "./runtime-core.esm-bundler.js";
import { unref as a } from "./reactivity.esm-bundler.js";
import { toDisplayString as i, normalizeClass as h } from "./shared.esm-bundler.js";
const H = /* @__PURE__ */ F({
  __name: "FINPR",
  setup(E) {
    const n = o(() => b.all.value?.map((e) => w(e)).filter((e) => e !== void 0).sort((e, t) => t.profit - e.profit) ?? []), N = o(() => u(n.value, (e) => e.cost)), V = o(() => u(n.value, (e) => e.repairs)), v = o(() => u(n.value, (e) => e.revenue)), c = o(() => u(n.value, (e) => e.profit)), g = o(() => _(
      [v.value, c.value],
      (e, t) => e !== 0 ? t / e : 0
    )), x = o(() => [
      { name: "Daily Cost", value: m(N.value) },
      { name: "Daily Repairs", value: m(V.value) },
      { name: "Daily Revenue", value: m(v.value) },
      { name: "Daily Profit", value: m(c.value) },
      {
        name: "Daily Margin",
        value: g.value !== void 0 ? P(g.value) : "--"
      }
    ]);
    function B(e) {
      return {
        [y.ColoredValue.positive]: e > 0,
        [y.ColoredValue.negative]: e < 0
      };
    }
    return (e, t) => (f(), p("div", null, [
      d(C, null, {
        default: R(() => [...t[0] || (t[0] = [
          D("Production Overview", -1)
        ])]),
        _: 1
      }),
      d(k, { figures: a(x) }, null, 8, ["figures"]),
      d(C, null, {
        default: R(() => [...t[1] || (t[1] = [
          D("Breakdown by Planet", -1)
        ])]),
        _: 1
      }),
      l("table", null, [
        t[2] || (t[2] = l("colgroup", {
          span: "6",
          style: { width: "calc(100% / 6)" }
        }, null, -1)),
        t[3] || (t[3] = l("thead", null, [
          l("tr", null, [
            l("th", null, "Name"),
            l("th", null, "Cost"),
            l("th", null, "Repairs"),
            l("th", null, "Revenue"),
            l("th", null, "Profit"),
            l("th", null, "Margin")
          ])
        ], -1)),
        l("tbody", null, [
          (f(!0), p(M, null, S(a(n), (r) => (f(), p("tr", {
            key: r.name
          }, [
            l("td", null, i(r.name), 1),
            l("td", null, i(a(s)(r.cost)), 1),
            l("td", null, i(a(s)(r.repairs)), 1),
            l("td", null, i(a(s)(r.revenue)), 1),
            l("td", null, i(a(s)(r.profit)), 1),
            l("td", {
              class: h(B(r.margin))
            }, i(a(P)(r.margin)), 3)
          ]))), 128))
        ])
      ])
    ]));
  }
});
export {
  H as default
};
