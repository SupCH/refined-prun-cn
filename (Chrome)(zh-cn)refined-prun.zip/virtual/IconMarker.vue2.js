import { withModifiers as n } from "./runtime-dom.esm-bundler.js";
import d from "./font-awesome.module.css.js";
import { defineComponent as u, computed as f, createElementBlock as i, openBlock as s, createElementVNode as y, createCommentVNode as k } from "./runtime-core.esm-bundler.js";
import { normalizeStyle as l, normalizeClass as t, toDisplayString as v } from "./shared.esm-bundler.js";
import { unref as m } from "./reactivity.esm-bundler.js";
const P = /* @__PURE__ */ u({
  __name: "IconMarker",
  props: {
    color: {},
    marker: {},
    onNext: { type: Function },
    onPrevious: { type: Function }
  },
  setup(a) {
    const p = f(() => ({
      display: a.marker !== void 0 ? "block" : void 0
    }));
    return (e, o) => (s(), i("div", {
      class: t(e.$style.container),
      onClick: o[0] || (o[0] = n(
        //@ts-ignore
        (...r) => e.onNext && e.onNext(...r),
        ["left", "prevent", "stop"]
      )),
      onContextmenu: o[1] || (o[1] = n(
        //@ts-ignore
        (...r) => e.onPrevious && e.onPrevious(...r),
        ["right", "prevent", "stop"]
      ))
    }, [
      y("div", {
        class: t(e.$style.box),
        style: l(m(p))
      }, [
        e.marker ? (s(), i("div", {
          key: 0,
          class: t([m(d).solid, e.$style.icon]),
          style: l({ color: e.color })
        }, v(e.marker), 7)) : k("", !0)
      ], 6)
    ], 34));
  }
});
export {
  P as default
};
