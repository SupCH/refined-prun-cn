import { subscribe as n } from "./subscribe-async-generator.js";
import { $$ as i, _$$ as c } from "./select-dom.js";
import { C as s } from "./prun-css.js";
import f from "./tiles.js";
import m from "./feature-registry.js";
import { refTextContent as a } from "./reactive-dom.js";
import { watchEffectWhileNodeAlive as l } from "./watch.js";
import { observeDescendantListChanged as d } from "./mutation-observer.js";
function p(t) {
  n(i(t.anchor, s.LiquidAssetsPanel.row), (r) => {
    const e = a(r.children[0]);
    l(r, () => {
      r.style.display = e.value === "ECD" ? "none" : "";
    });
  }), n(i(t.anchor, "tbody"), (r) => {
    d(r, () => {
      const e = c(r, "tr");
      for (const o of e)
        if (o.children[0].textContent === "ECD") {
          o !== r.lastChild && r.appendChild(o);
          return;
        }
    });
  });
}
function u() {
  f.observe("FINLA", p);
}
m.add(import.meta.url, u, "FINLA: Hides the ECD row.");
