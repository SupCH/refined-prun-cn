import { useCssModule as k } from "./runtime-dom.esm-bundler.js";
import { C as o } from "./prun-css.js";
import M from "./ColoredIcon.vue.js";
import { materialsStore as v } from "./materials.js";
import { showBuffer as g } from "./buffers.js";
import { getMaterialName as y } from "./i18n.js";
import { fixed0 as c } from "./format.js";
import { defineComponent as z, computed as i, createElementBlock as s, openBlock as u, createVNode as I, createCommentVNode as p, createElementVNode as B } from "./runtime-core.esm-bundler.js";
import { unref as a } from "./reactivity.esm-bundler.js";
import { normalizeClass as r, toDisplayString as V } from "./shared.esm-bundler.js";
const j = /* @__PURE__ */ z({
  __name: "MaterialIcon",
  props: {
    amount: {},
    size: { default: "large" },
    ticker: {},
    warning: { type: Boolean }
  },
  setup(e) {
    const n = k(), d = i(() => v.getByTicker(e.ticker)), f = i(() => y(d.value) ?? "Unknown"), m = i(() => {
      if (e.amount !== void 0)
        return e.size === "medium" && e.amount >= 1e5 ? c(Math.round(e.amount / 1e3)) + "k" : c(e.amount);
    }), C = [
      o.MaterialIcon.indicator,
      o.MaterialIcon.neutral,
      o.MaterialIcon.typeVerySmall,
      {
        [o.ColoredValue.negative]: e.warning,
        [n.indicatorSmall]: e.size === "medium"
      }
    ], l = () => g(`MAT ${e.ticker.toUpperCase()}`);
    return (t, N) => (u(), s("div", {
      class: r([("C" in t ? t.C : a(o)).MaterialIcon.container, a(n).container])
    }, [
      I(M, {
        label: t.ticker,
        title: a(f),
        size: t.size,
        onClick: l
      }, null, 8, ["label", "title", "size"]),
      a(m) !== void 0 ? (u(), s("div", {
        key: 0,
        class: r(("C" in t ? t.C : a(o)).MaterialIcon.indicatorContainer),
        onClick: l
      }, [
        B("div", {
          class: r(C)
        }, V(a(m)), 1)
      ], 2)) : p("", !0)
    ], 2));
  }
});
export {
  j as default
};
