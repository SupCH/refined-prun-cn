import U from "./Header.vue.js";
import C from "./SectionHeader.vue.js";
import k from "./Commands.vue.js";
import d from "./PrunButton.vue.js";
import { showTileOverlay as g, showConfirmationOverlay as h } from "./tile-overlay.js";
import A from "./remove-array-element.js";
import { objectId as $ } from "./object-id.js";
import { act as w } from "./act-registry.js";
import { showBuffer as j } from "./buffers.js";
import E from "./EditMaterialGroup.vue.js";
import R from "./EditAction.vue.js";
import { downloadJson as H } from "./json-file.js";
import { deepToRaw as O } from "./deep-to-raw.js";
import P from "./RenameActionPackage.vue.js";
import { t as n } from "./index5.js";
import { defineComponent as z, createElementBlock as s, openBlock as p, createVNode as i, createElementVNode as l, withCtx as r, createTextVNode as m, Fragment as b, renderList as G } from "./runtime-core.esm-bundler.js";
import { normalizeClass as y, toDisplayString as o } from "./shared.esm-bundler.js";
import { unref as a } from "./reactivity.esm-bundler.js";
const F = { key: 0 }, J = { key: 1 }, X = { key: 0 }, q = { key: 1 }, se = /* @__PURE__ */ z({
  __name: "EditActionPackage",
  props: {
    pkg: {}
  },
  setup(u) {
    function V(e) {
      const t = {
        name: "",
        type: "Resupply"
      };
      g(e, E, {
        add: !0,
        group: t,
        onSave: () => u.pkg.groups.push(t)
      });
    }
    function D(e, t) {
      g(e, E, { group: t });
    }
    function M(e, t) {
      h(e, () => A(u.pkg.groups, t), {
        message: n("act.deleteGroupConfirm", t.name || "--"),
        confirmLabel: n("act.delete")
      });
    }
    function T(e) {
      const t = {
        name: "",
        type: "MTRA"
      };
      g(e, R, {
        add: !0,
        action: t,
        pkg: u.pkg,
        onSave: () => u.pkg.actions.push(t)
      });
    }
    function v(e, t) {
      g(e, R, { action: t, pkg: u.pkg });
    }
    function L(e, t) {
      h(e, () => A(u.pkg.actions, t), {
        message: n("act.deleteActionConfirm", t.name || "--"),
        confirmLabel: n("act.delete")
      });
    }
    function _(e) {
      const t = w.getMaterialGroupInfo(e.type);
      return t ? t.description(e) : "--";
    }
    function B(e) {
      const t = w.getActionInfo(e.type);
      return t ? t.description(e) : "--";
    }
    function I(e) {
      g(e, P, {
        name: u.pkg.global.name,
        onRename: (t) => u.pkg.global.name = t
      });
    }
    function N() {
      j(`XIT ACT_${u.pkg.global.name.replace(" ", "_")}`);
    }
    function S() {
      const e = O(u.pkg);
      H(e, `${u.pkg.global.name.replace(" ", "_")}-${Date.now()}.json`);
    }
    return (e, t) => (p(), s(b, null, [
      i(U, {
        modelValue: e.pkg.global.name,
        "onUpdate:modelValue": t[0] || (t[0] = (c) => e.pkg.global.name = c),
        editable: "",
        class: y(e.$style.header)
      }, null, 8, ["modelValue", "class"]),
      i(C, null, {
        default: r(() => [
          m(o(a(n)("act.group")), 1)
        ]),
        _: 1
      }),
      l("table", null, [
        l("thead", null, [
          l("tr", null, [
            l("th", null, o(a(n)("act.typeLabel")), 1),
            l("th", null, o(a(n)("act.name")), 1),
            l("th", null, o(a(n)("act.content")), 1),
            t[1] || (t[1] = l("th", null, null, -1))
          ])
        ]),
        e.pkg.groups.length === 0 ? (p(), s("tbody", F, [
          l("tr", null, [
            l("td", {
              colspan: "4",
              class: y(e.$style.emptyRow)
            }, o(a(n)("act.noGroups")), 3)
          ])
        ])) : (p(), s("tbody", J, [
          (p(!0), s(b, null, G(e.pkg.groups, (c) => (p(), s("tr", {
            key: a($)(c)
          }, [
            l("td", null, o(c.type), 1),
            l("td", null, o(c.name || "--"), 1),
            l("td", null, o(_(c)), 1),
            l("td", null, [
              i(d, {
                dark: "",
                inline: "",
                onClick: (f) => D(f, c)
              }, {
                default: r(() => [
                  m(o(a(n)("act.edit")), 1)
                ]),
                _: 2
              }, 1032, ["onClick"]),
              i(d, {
                dark: "",
                inline: "",
                onClick: (f) => M(f, c)
              }, {
                default: r(() => [
                  m(o(a(n)("act.delete")), 1)
                ]),
                _: 2
              }, 1032, ["onClick"])
            ])
          ]))), 128))
        ]))
      ]),
      l("form", {
        class: y(e.$style.sectionCommands)
      }, [
        i(k, null, {
          default: r(() => [
            i(d, {
              primary: "",
              onClick: V
            }, {
              default: r(() => [
                m(o(a(n)("act.add")), 1)
              ]),
              _: 1
            })
          ]),
          _: 1
        })
      ], 2),
      i(C, null, {
        default: r(() => [
          m(o(a(n)("act.action")), 1)
        ]),
        _: 1
      }),
      l("table", null, [
        l("thead", null, [
          l("tr", null, [
            l("th", null, o(a(n)("act.typeLabel")), 1),
            l("th", null, o(a(n)("act.name")), 1),
            l("th", null, o(a(n)("act.content")), 1),
            t[2] || (t[2] = l("th", null, null, -1))
          ])
        ]),
        e.pkg.actions.length === 0 ? (p(), s("tbody", X, [
          l("tr", null, [
            l("td", {
              colspan: "4",
              class: y(e.$style.emptyRow)
            }, o(a(n)("act.noActions")), 3)
          ])
        ])) : (p(), s("tbody", q, [
          (p(!0), s(b, null, G(e.pkg.actions, (c) => (p(), s("tr", {
            key: a($)(c)
          }, [
            l("td", null, o(c.type), 1),
            l("td", null, o(c.name || "--"), 1),
            l("td", null, o(B(c)), 1),
            l("td", null, [
              i(d, {
                dark: "",
                inline: "",
                onClick: (f) => v(f, c)
              }, {
                default: r(() => [
                  m(o(a(n)("act.edit")), 1)
                ]),
                _: 2
              }, 1032, ["onClick"]),
              i(d, {
                dark: "",
                inline: "",
                onClick: (f) => L(f, c)
              }, {
                default: r(() => [
                  m(o(a(n)("act.delete")), 1)
                ]),
                _: 2
              }, 1032, ["onClick"])
            ])
          ]))), 128))
        ]))
      ]),
      l("form", {
        class: y(e.$style.sectionCommands)
      }, [
        i(k, null, {
          default: r(() => [
            i(d, {
              primary: "",
              onClick: T
            }, {
              default: r(() => [
                m(o(a(n)("act.add")), 1)
              ]),
              _: 1
            })
          ]),
          _: 1
        })
      ], 2),
      i(C, null, {
        default: r(() => [
          m(o(a(n)("act.commands")), 1)
        ]),
        _: 1
      }),
      l("form", null, [
        i(k, {
          label: a(n)("act.rename")
        }, {
          default: r(() => [
            i(d, {
              primary: "",
              onClick: I
            }, {
              default: r(() => [
                m(o(a(n)("act.rename").toUpperCase()), 1)
              ]),
              _: 1
            })
          ]),
          _: 1
        }, 8, ["label"]),
        i(k, {
          label: a(n)("act.execute")
        }, {
          default: r(() => [
            i(d, {
              primary: "",
              onClick: N
            }, {
              default: r(() => [
                m(o(a(n)("act.execute").toUpperCase()), 1)
              ]),
              _: 1
            })
          ]),
          _: 1
        }, 8, ["label"]),
        i(k, {
          label: a(n)("act.export")
        }, {
          default: r(() => [
            i(d, {
              primary: "",
              onClick: S
            }, {
              default: r(() => [
                m(o(a(n)("act.export").toUpperCase()), 1)
              ]),
              _: 1
            })
          ]),
          _: 1
        }, 8, ["label"])
      ])
    ], 64));
  }
});
export {
  se as default
};
