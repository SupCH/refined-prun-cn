import { getDefaultExportFromCjs as r } from "./commonjsHelpers.js";
import { __require as o } from "./customParseFormat2.js";
var t = o();
const m = /* @__PURE__ */ r(t);
export {
  m as default
};
