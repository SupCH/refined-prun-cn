const o = "rp-lm-highlight-own-ads__ownAd___e546d51", d = {
  ownAd: o
};
export {
  d as default,
  o as ownAd
};
