import { applyCssRule as i } from "./refined-prun-css.js";
import { C as t } from "./prun-css.js";
import o from "./feature-registry.js";
import r from "./css-utils.module.css.js";
function e() {
  i(
    "BBL",
    `.${t.SectionList.section} .${t.SectionList.table} tr:nth-child(5)`,
    r.hidden
  );
}
o.add(import.meta.url, e, 'BBL: Hides the "Book value" row.');
