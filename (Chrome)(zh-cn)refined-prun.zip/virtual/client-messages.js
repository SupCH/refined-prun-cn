function S(_, e, E) {
  return {
    messageType: "UI_WINDOWS_UPDATE_SIZE",
    payload: {
      id: _,
      size: {
        width: e,
        height: E
      }
    }
  };
}
function n(_, e) {
  return {
    messageType: "UI_TILES_CHANGE_COMMAND",
    payload: {
      id: _,
      newCommand: e
    }
  };
}
function a(_) {
  return {
    messageType: "UI_WINDOWS_REQUEST_FOCUS",
    payload: {
      id: _
    }
  };
}
function I(_) {
  return {
    messageType: "WORLD_SECTORS",
    payload: {
      sectors: _
    }
  };
}
function O(_) {
  return {
    messageType: "COMEX_BROKER_PRICES",
    payload: _
  };
}
export {
  O as COMEX_BROKER_PRICES,
  n as UI_TILES_CHANGE_COMMAND,
  a as UI_WINDOWS_REQUEST_FOCUS,
  S as UI_WINDOWS_UPDATE_SIZE,
  I as WORLD_SECTORS
};
