import { getDefaultExportFromCjs as r } from "./commonjsHelpers.js";
import { __require as e } from "./hammer2.js";
var m = e();
const a = /* @__PURE__ */ r(m);
export {
  a as default
};
