import { C as a } from "./prun-css.js";
import { defineComponent as m, computed as l, createElementBlock as s, openBlock as d, createElementVNode as n } from "./runtime-core.esm-bundler.js";
import { normalizeClass as t, toDisplayString as c } from "./shared.esm-bundler.js";
import { unref as r } from "./reactivity.esm-bundler.js";
const H = /* @__PURE__ */ m({
  __name: "HeadItem",
  props: {
    active: { type: Boolean },
    label: {}
  },
  setup(i) {
    const o = l(() => ({
      [a.HeadItem.indicator]: !0,
      [a.HeadItem.indicatorPrimary]: !0,
      [a.HeadItem.indicatorPrimaryActive]: i.active,
      [a.effects.shadowPrimary]: i.active
    }));
    return (e, p) => (d(), s("div", {
      class: t([("C" in e ? e.C : r(a)).HeadItem.container, ("C" in e ? e.C : r(a)).fonts.fontRegular, ("C" in e ? e.C : r(a)).type.typeRegular, ("C" in e ? e.C : r(a)).HeadItem.link])
    }, [
      n("span", {
        class: t(("C" in e ? e.C : r(a)).HeadItem.label)
      }, c(e.label), 3),
      n("div", {
        class: t(r(o))
      }, null, 2)
    ], 2));
  }
});
export {
  H as default
};
