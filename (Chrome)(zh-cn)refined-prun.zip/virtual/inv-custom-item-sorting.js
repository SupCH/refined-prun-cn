import { subscribe as O } from "./subscribe-async-generator.js";
import { $$ as M, $ as C, _$$ as A, _$ as B } from "./select-dom.js";
import { C as d } from "./prun-css.js";
import { createFragmentApp as S, FragmentAppScope as R } from "./vue-fragment-app.js";
import { applyCssRule as z } from "./refined-prun-css.js";
import N from "./tiles.js";
import V from "./xit-registry.js";
import E from "./feature-registry.js";
import L from "./css-utils.module.css.js";
import b from "./inv-custom-item-sorting.module.css.js";
import { getPlanetBurn as P } from "./burn2.js";
import { storagesStore as D } from "./storage.js";
import w from "./CategoryHeader.vue.js";
import F from "./InventorySortControls.vue.js";
import { materialsStore as T } from "./materials.js";
import G from "./GridMaterialIcon.vue.js";
import H from "./SORT.vue.js";
import { showBuffer as j } from "./buffers.js";
import { sortMaterials as W, sortByMaterial as X } from "./sort-materials.js";
import { watchEffectWhileNodeAlive as $ } from "./watch.js";
import q from "./SortCriteria.vue.js";
import { getSortingData as J } from "./user-data-sorting.js";
import { getInvStore as K } from "./store-id.js";
import { reactive as _, toRef as Q } from "./reactivity.esm-bundler.js";
import { isEmpty as U } from "./is-empty.js";
import { computed as g } from "./runtime-core.esm-bundler.js";
function Y(c) {
  O(
    M(c.anchor, d.InventoryView.container),
    (l) => Z(c, l)
  );
}
async function Z(c, l) {
  const m = c.parameter;
  if (!m)
    return;
  const v = K(m), t = J(m), i = g({
    get: () => t.cat ?? !0,
    set: (r) => t.cat = r ? void 0 : !1
  }), s = g({
    get: () => t.reverse ?? !1,
    set: (r) => t.reverse = r ? !0 : void 0
  }), f = await C(l, d.InventorySortControls.controls), p = await C(l, d.InventoryView.grid), e = Array.from(f.children);
  for (let r = 1; r < e.length; r++) {
    const y = e[r];
    y.addEventListener("click", () => {
      t.active = void 0, i.value = !1;
    }), r === 2 && (S(
      q,
      _({
        label: y.textContent ?? "CAT",
        active: i,
        reverse: s,
        onClick: () => {
          i.value ? s.value = !s.value : (t.active = void 0, i.value = !0, s.value = !1);
        }
      })
    ).after(y), y.style.display = "none");
  }
  const a = g(() => P(D.getById(m)?.addressableId)), o = g(() => {
    const r = t.modes.slice();
    return a.value && r.push(te), r;
  });
  $(f, () => {
    t.active || i.value ? f.classList.add(b.custom) : f.classList.remove(b.custom);
  }), S(
    F,
    _({
      sorting: o,
      activeSort: Q(() => t.active),
      reverse: s,
      onModeClick: (r) => {
        t.active === r ? s.value = !s.value : (t.active = r, i.value = !1, s.value = !1);
      },
      onAddClick: () => j(`XIT SORT ${v?.id.substring(0, 8) ?? m}`)
    })
  ).appendTo(f);
  const u = g(() => o.value.find((r) => r.label === t.active)), n = new R(), I = () => {
    h.disconnect(), n.begin(), x(
      p,
      i.value ? ee : u.value,
      a.value?.burn,
      s.value
    ), n.end(), setTimeout(() => h.observe(p, { childList: !0, subtree: !0 }), 0);
  }, h = new MutationObserver(I);
  let k = !0;
  $(p, () => {
    if (t.reverse, t.active, t.cat, a.value, k) {
      k = !1, I();
      return;
    }
    setTimeout(I, 50);
  });
}
function x(c, l, m, v) {
  if (!l)
    return;
  const t = A(c, d.GridItemView.container).map((e) => ({
    div: e,
    ticker: B(e, d.ColoredIcon.label)?.textContent
  })), i = l.categories.slice();
  if (l.burn && m) {
    const e = Object.keys(m), a = new Set(e.filter((n) => m[n].type === "input")), o = new Set(e.filter((n) => m[n].type === "output" && !a.has(n))), u = e.filter(
      (n) => m[n].type === "workforce" && !a.has(n) && !o.has(n)
    );
    i.push({
      name: "Consumables",
      materials: u
    }), i.push({
      name: "Inputs",
      materials: [...a]
    }), i.push({
      name: "Outputs",
      materials: [...o]
    });
  }
  const s = /* @__PURE__ */ new Set(), f = new Set(t);
  v && i.reverse();
  for (const e of i) {
    let a = e.materials.filter((o) => !s.has(o)).map((o) => T.getByTicker(o)).filter((o) => o !== void 0);
    if (!U(a)) {
      S(w, { label: e.name }).appendTo(c), a = W(a), v && a.reverse();
      for (const o of a) {
        const u = t.find((n) => n.ticker === o.ticker);
        u ? (c.appendChild(u.div), f.delete(u)) : l.zero && S(G, {
          ticker: o.ticker,
          amount: 0,
          warning: !0
        }).appendTo(c), s.add(o.ticker);
      }
    }
  }
  if (f.size === 0)
    return;
  s.size > 0 && S(w, { label: "Other" }).appendTo(c);
  let p = [...f].map((e) => ({
    div: e.div,
    material: T.getByTicker(e.ticker)
  }));
  p = X(p, (e) => e.material), v && p.reverse();
  for (const e of p)
    c.appendChild(e.div);
}
const ee = {
  categories: [],
  burn: !1,
  zero: !1
}, te = {
  label: "BRN",
  categories: [],
  burn: !0,
  zero: !0
};
function re() {
  z(`.${b.custom} .${d.InventorySortControls.order} > div`, L.hidden), N.observe(["INV", "SHPI"], Y), V.add({
    command: "SORT",
    name: "SORTING MODES",
    description: "Sorting mode editor.",
    mandatoryParameters: "Inventory Identifier",
    component: () => H
  });
}
E.add(import.meta.url, re, "INV/SHPI: Adds custom sorting modes to inventories.");
