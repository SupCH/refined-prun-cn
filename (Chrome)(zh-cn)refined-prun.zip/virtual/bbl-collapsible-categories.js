import { subscribe as s } from "./subscribe-async-generator.js";
import { _$$ as m, $$ as c } from "./select-dom.js";
import { C as e } from "./prun-css.js";
import { createFragmentApp as n } from "./vue-fragment-app.js";
import { applyCssRule as r } from "./refined-prun-css.js";
import l from "./tiles.js";
import f from "./feature-registry.js";
import p from "./css-utils.module.css.js";
import u from "./bbl-collapsible-categories.module.css.js";
import { ref as v } from "./reactivity.esm-bundler.js";
import { computed as L, createVNode as B } from "./runtime-core.esm-bundler.js";
function $(a) {
  s(c(a.anchor, e.SectionList.container), (o) => {
    for (const t of m(o, e.SectionList.divider)) {
      const i = v(o.firstChild !== t);
      t.addEventListener("click", () => i.value = !i.value);
      const d = L(() => ({
        [e.RadioItem.indicator]: !0,
        [e.RadioItem.active]: i.value,
        [e.effects.shadowPrimary]: i.value
      }));
      n(() => B("div", {
        class: d.value
      }, null)).prependTo(t);
    }
  });
}
function b() {
  r("BBL", `.${e.SectionList.divider}:not(:has(.${e.RadioItem.active})) + div`, p.hidden), r("BBL", `.${e.SectionList.divider}`, u.divider), l.observe("BBL", $);
}
f.add(import.meta.url, b, 'BBL: Makes categories collapsible and collapses the "Infrastructure" category by default.');
