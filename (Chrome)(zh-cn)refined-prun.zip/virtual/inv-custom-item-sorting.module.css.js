const t = "rp-inv-custom-item-sorting__custom___b4657eb", s = {
  custom: t
};
export {
  t as custom,
  s as default
};
