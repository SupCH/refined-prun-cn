import f from "./EditTask.vue.js";
export {
  f as default
};
