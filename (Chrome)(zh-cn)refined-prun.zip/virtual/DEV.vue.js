import { prunStyleUpdated as V, C as m, mergedPrunStyles as P } from "./prun-css.js";
import { downloadFile as d } from "./util.js";
import l from "./DevButton.vue.js";
import { userData as w } from "./user-data.js";
import g from "./js.cookie.js";
import { isRecordingPrunLog as f, prunLog as c } from "./prun-api-listener.js";
import S from "./SectionHeader.vue.js";
import { relayUrl as p } from "./relay.js";
import E from "./Active.vue.js";
import L from "./TextInput.vue.js";
import { defineComponent as R, createElementBlock as y, openBlock as s, createVNode as r, createElementVNode as U, createBlock as k, withCtx as t, createTextVNode as n, createCommentVNode as B } from "./runtime-core.esm-bundler.js";
import { ref as N, isRef as $, unref as i } from "./reactivity.esm-bundler.js";
import { toDisplayString as j } from "./shared.esm-bundler.js";
const O = { style: { paddingTop: "4px" } }, T = { key: 0 }, Z = /* @__PURE__ */ R({
  __name: "DEV",
  setup(F) {
    function b() {
      console.log(w);
    }
    const u = N(g.get("pu-debug") === "true");
    function C() {
      g.set("pu-debug", (!u.value).toString()), u.value = !u.value;
    }
    function v() {
      f.value = !0;
    }
    function D() {
      f.value = !1, d(c.value, "prun-log.json", !0), c.value = [];
    }
    function _() {
      let o = `export {};
`;
      o += `declare global {
`, o += `  interface PrunCssClasses {
`;
      for (const e of Object.keys(m).sort()) {
        o += `    ${e}: {
`;
        for (const a of Object.keys(m[e]).sort())
          o += `      ${a}: string;
`;
        o += `    };
`;
      }
      o += `  }
`, o += `}
`, d(o, "prun-css.types.d.ts", !1);
    }
    function x() {
      d(P, "prun.css", !1);
    }
    return (o, e) => (s(), y("div", O, [
      r(S, null, {
        default: t(() => [...e[1] || (e[1] = [
          n("Warning: Messing with these can lead to unexpected behavior", -1)
        ])]),
        _: 1
      }),
      U("form", null, [
        r(E, { label: "Relay" }, {
          default: t(() => [
            r(L, {
              modelValue: i(p),
              "onUpdate:modelValue": e[0] || (e[0] = (a) => $(p) ? p.value = a : null)
            }, null, 8, ["modelValue"])
          ]),
          _: 1
        })
      ]),
      i(f) ? (s(), k(l, {
        key: 1,
        onClick: D
      }, {
        default: t(() => [...e[3] || (e[3] = [
          n("Stop Recording", -1)
        ])]),
        _: 1
      })) : (s(), k(l, {
        key: 0,
        onClick: v
      }, {
        default: t(() => [...e[2] || (e[2] = [
          n("Record PrUn Log", -1)
        ])]),
        _: 1
      })),
      r(l, { onClick: C }, {
        default: t(() => [
          n(j(i(u) ? "Disable" : "Enable") + " pu-debug ", 1)
        ]),
        _: 1
      }),
      r(l, { onClick: b }, {
        default: t(() => [...e[4] || (e[4] = [
          n("Log User Data", -1)
        ])]),
        _: 1
      }),
      r(l, { onClick: _ }, {
        default: t(() => [...e[5] || (e[5] = [
          n("Export prun-css.types.d.ts", -1)
        ])]),
        _: 1
      }),
      r(l, { onClick: x }, {
        default: t(() => [
          e[6] || (e[6] = n(" Export prun.css ", -1)),
          i(V) ? (s(), y("span", T, "(new!)")) : B("", !0)
        ]),
        _: 1
      })
    ]));
  }
});
export {
  Z as default
};
