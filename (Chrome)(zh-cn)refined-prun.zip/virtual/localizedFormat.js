import { getDefaultExportFromCjs as r } from "./commonjsHelpers.js";
import { __require as o } from "./localizedFormat2.js";
var t = o();
const m = /* @__PURE__ */ r(t);
export {
  m as default
};
