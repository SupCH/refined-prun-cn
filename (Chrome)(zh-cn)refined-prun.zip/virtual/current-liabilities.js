import { sumAccountsPayable as t, selfCurrentConditions as s, sumFactionProvisions as e, sumProvisions as n, sumDeliveries as r, sumLoanRepayments as i, sumLoanInterest as m } from "./contract-conditions.js";
import { sum as a } from "./sum.js";
import { computed as o } from "./runtime-core.esm-bundler.js";
const c = o(() => t(s)), u = o(
  () => a(
    r(s),
    n(s),
    e(s)
  )
), l = o(() => i(s)), b = o(() => m(s)), f = {
  accountsPayable: c,
  materialsPayable: u,
  shortTermDebt: l,
  interestPayable: b
};
export {
  f as currentLiabilities
};
