import o from "./BalanceSheetSection.vue2.js";
/* empty css                         */
import t from "./plugin-vue_export-helper.js";
const r = /* @__PURE__ */ t(o, [["__scopeId", "data-v-6f3fe4a2"]]);
export {
  r as default
};
