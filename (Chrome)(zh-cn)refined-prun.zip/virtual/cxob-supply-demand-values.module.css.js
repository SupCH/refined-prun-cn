const e = "rp-cxob-supply-demand-values__spread___de99b06", s = {
  spread: e
};
export {
  s as default,
  e as spread
};
