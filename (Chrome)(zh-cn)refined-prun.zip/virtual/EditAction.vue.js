import { C as B } from "./prun-css.js";
import E from "./PrunButton.vue.js";
import F from "./SectionHeader.vue.js";
import s from "./Active.vue.js";
import N from "./TextInput.vue.js";
import U from "./Commands.vue.js";
import $ from "./SelectInput.vue.js";
import { act as v } from "./act-registry.js";
import { t as l } from "./index5.js";
import { defineComponent as D, computed as T, useTemplateRef as I, createElementBlock as O, openBlock as y, createVNode as a, createElementVNode as R, withCtx as m, createTextVNode as C, createBlock as j, createCommentVNode as w, resolveDynamicComponent as z } from "./runtime-core.esm-bundler.js";
import { ref as f, unref as e, isRef as k } from "./reactivity.esm-bundler.js";
import { toDisplayString as V, normalizeClass as H } from "./shared.esm-bundler.js";
const h = /* @__PURE__ */ D({
  __name: "EditAction",
  props: {
    add: { type: Boolean },
    action: {},
    onSave: { type: Function },
    pkg: {}
  },
  emits: ["close"],
  setup(o, { emit: g }) {
    const b = g, i = f(o.action.name || ""), c = f(!1), S = v.getActionTypes(), r = f(o.action.type), p = T(() => v.getActionInfo(r.value)?.editComponent), d = I("editForm");
    function A() {
      let t = d.value.validate();
      if (c.value = i.value.length === 0, t &&= !c.value, !!t) {
        for (const n of Object.keys(o.action))
          delete o.action[n];
        d.value.save(), o.action.name = i.value, o.action.type = r.value, o.onSave?.(), b("close");
      }
    }
    return (t, n) => (y(), O("div", {
      class: H(("C" in t ? t.C : e(B)).DraftConditionEditor.form)
    }, [
      a(F, null, {
        default: m(() => [
          C(V(t.add ? e(l)("act.addAction") : e(l)("act.editAction")), 1)
        ]),
        _: 1
      }),
      R("form", null, [
        a(s, {
          label: e(l)("act.typeLabel")
        }, {
          default: m(() => [
            a($, {
              modelValue: e(r),
              "onUpdate:modelValue": n[0] || (n[0] = (u) => k(r) ? r.value = u : null),
              options: e(S)
            }, null, 8, ["modelValue", "options"])
          ]),
          _: 1
        }, 8, ["label"]),
        a(s, {
          label: e(l)("act.name"),
          error: e(c)
        }, {
          default: m(() => [
            a(N, {
              modelValue: e(i),
              "onUpdate:modelValue": n[1] || (n[1] = (u) => k(i) ? i.value = u : null)
            }, null, 8, ["modelValue"])
          ]),
          _: 1
        }, 8, ["label", "error"]),
        e(p) ? (y(), j(z(e(p)), {
          key: 0,
          ref_key: "editForm",
          ref: d,
          action: t.action,
          pkg: t.pkg
        }, null, 8, ["action", "pkg"])) : w("", !0),
        a(U, null, {
          default: m(() => [
            a(E, {
              primary: "",
              onClick: A
            }, {
              default: m(() => [
                C(V(t.add ? e(l)("act.add").toUpperCase() : e(l)("act.save").toUpperCase()), 1)
              ]),
              _: 1
            })
          ]),
          _: 1
        })
      ])
    ], 2));
  }
});
export {
  h as default
};
