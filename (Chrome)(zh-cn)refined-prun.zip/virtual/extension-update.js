import o from "./config.js";
import { C as e } from "./prun-css.js";
import { createFragmentApp as a } from "./vue-fragment-app.js";
import { fetchJson as s } from "./fetch.js";
import { createVNode as t, createTextVNode as c } from "./runtime-core.esm-bundler.js";
{
  const r = document.getElementById("container"), i = setInterval(async () => {
    const n = await s(o.url.manifest);
    !n.version || o.version === n.version || (setTimeout(() => window.location.reload(), 3e3), clearInterval(i), e.Connecting !== void 0 && a(() => t("div", {
      class: [e.Connecting.processing, e.Connecting.overlay],
      style: {
        zIndex: "999999"
      }
    }, [t("span", {
      class: [e.Connecting.message, e.fonts.fontRegular, e.type.typeLarger]
    }, [c("Reloading (zh-cn)refined-prun...")])])).appendTo(r));
  }, 1e3);
}
