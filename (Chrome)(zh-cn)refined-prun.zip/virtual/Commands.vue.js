import { C as o } from "./prun-css.js";
import { defineComponent as a, createElementBlock as l, openBlock as C, createElementVNode as r, renderSlot as s } from "./runtime-core.esm-bundler.js";
import { normalizeClass as m, toDisplayString as i } from "./shared.esm-bundler.js";
import { unref as n } from "./reactivity.esm-bundler.js";
const g = /* @__PURE__ */ a({
  __name: "Commands",
  props: {
    label: { default: "CMD" }
  },
  setup(p) {
    return (e, f) => (C(), l("div", {
      class: m([("C" in e ? e.C : n(o)).FormComponent.containerCommand, ("C" in e ? e.C : n(o)).forms.cmd, ("C" in e ? e.C : n(o)).forms.formComponent])
    }, [
      r("label", {
        class: m([("C" in e ? e.C : n(o)).FormComponent.label, ("C" in e ? e.C : n(o)).fonts.fontRegular, ("C" in e ? e.C : n(o)).type.typeRegular])
      }, [
        r("span", null, i(e.label), 1)
      ], 2),
      r("div", {
        class: m([("C" in e ? e.C : n(o)).FormComponent.input, ("C" in e ? e.C : n(o)).forms.input])
      }, [
        s(e.$slots, "default")
      ], 2)
    ], 2));
  }
});
export {
  g as default
};
