import { C as n } from "./prun-css.js";
import { $ as m } from "./select-dom.js";
import f from "./tiles.js";
import c from "./feature-registry.js";
import { matchBufferSize as d } from "./buffer-sizes.js";
import { setBufferSize as p } from "./buffers.js";
const i = /* @__PURE__ */ new WeakSet();
async function u(t) {
  if (t.docked)
    return;
  if (!i.has(t.container)) {
    i.add(t.container);
    return;
  }
  const e = d(t.fullCommand) ?? [450, 300], o = t.frame.closest(`.${n.Window.window}`);
  if (!o)
    return;
  const r = await m(o, n.Window.body), a = parseInt(r.style.width.replace("px", ""), 10), s = parseInt(r.style.height.replace("px", ""), 10);
  p(t.id, Math.max(e[0], a), Math.max(e[1], s));
}
function h() {
  f.observeAll(u);
}
c.add(import.meta.url, h, "Automatically resizes the buffer size on command change.");
