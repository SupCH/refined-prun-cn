import { subscribe as n } from "./subscribe-async-generator.js";
import { $$ as m, _$ as p } from "./select-dom.js";
import { C as a } from "./prun-css.js";
import { createFragmentApp as u } from "./vue-fragment-app.js";
import D from "./tiles.js";
import { applyCssRule as v } from "./refined-prun-css.js";
import J from "./feature-registry.js";
import d from "./hide-system-chat-messages.module.css.js";
import C from "./css-utils.module.css.js";
import { watchEffectWhileNodeAlive as $ } from "./watch.js";
import { observeDescendantListChanged as L } from "./mutation-observer.js";
import M from "./SelectButton.vue.js";
import { userData as l } from "./user-data.js";
import b from "./remove-array-element.js";
import { computed as f } from "./runtime-core.esm-bundler.js";
import { reactive as y } from "./reactivity.esm-bundler.js";
function g(t) {
  const o = f(
    () => l.systemMessages.find((e) => e.chat.toUpperCase() === t.fullCommand.toUpperCase())
  ), r = f(() => o.value?.hideJoined ?? !0), c = f(() => o.value?.hideDeleted ?? !0);
  function h(e) {
    let i = o.value;
    i || (i = {
      chat: t.fullCommand,
      hideJoined: !0,
      hideDeleted: !0
    }), e(i);
    const s = !i.hideJoined || !i.hideDeleted;
    s && !o.value && l.systemMessages.push(i), !s && o.value && b(l.systemMessages, o.value);
  }
  n(m(t.anchor, a.Channel.controls), (e) => {
    u(
      M,
      y({
        label: "hide joined",
        selected: r,
        set: (i) => h((s) => s.hideJoined = i)
      })
    ).appendTo(e), u(
      M,
      y({
        label: "hide deleted",
        selected: c,
        set: (i) => h((s) => s.hideDeleted = i)
      })
    ).appendTo(e);
  }), n(m(t.anchor, a.MessageList.messages), (e) => {
    $(e, () => {
      e.classList.remove(d.hideJoined, d.hideDeleted), r.value && e.classList.add(d.hideJoined), c.value && e.classList.add(d.hideDeleted);
    }), n(m(e, a.Message.message), j);
  });
}
function j(t) {
  L(t, () => {
    const o = p(t, a.Message.system), r = p(t, a.Message.name);
    !o || !r || (r.children.length > 0 ? t.classList.add(d.deleted) : t.classList.add(d.joined));
  });
}
function A() {
  D.observe(["COMG", "COMP", "COMU"], g), v(`.${d.hideJoined} .${d.joined}`, C.hidden), v(`.${d.hideDeleted} .${d.deleted}`, C.hidden);
}
J.add(import.meta.url, A, "Hides system messages in chats.");
