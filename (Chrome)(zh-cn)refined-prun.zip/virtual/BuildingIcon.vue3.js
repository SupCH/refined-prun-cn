const n = "rp-BuildingIcon__container___aed8f37", t = {
  container: n
};
export {
  n as container,
  t as default
};
