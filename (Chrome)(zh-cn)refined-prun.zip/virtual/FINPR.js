import t from "./xit-registry.js";
import m from "./FINPR.vue.js";
t.add({
  command: ["FINPR"],
  name: "Profitability Report",
  description: "Base profitability report.",
  contextItems: () => [
    { cmd: "XIT FIN" },
    { cmd: "XIT FINBS" },
    { cmd: "XIT FINCH" },
    { cmd: "XIT SET FIN" }
  ],
  component: () => m
});
