import c from "./index11.js";
const n = /* @__PURE__ */ new WeakMap(), s = (e, a = {}) => {
  if (typeof e != "function")
    throw new TypeError("Expected a function");
  let r, o = 0;
  const i = e.displayName || e.name || "<anonymous>", t = function(...l) {
    if (n.set(t, ++o), o === 1)
      r = e.apply(this, l), e = void 0;
    else if (a.throw === !0)
      throw new Error(`Function \`${i}\` can only be called once`);
    return r;
  };
  return c(t, e), n.set(t, o), t;
};
s.callCount = (e) => {
  if (!n.has(e))
    throw new Error(`The given function \`${e.name}\` is not wrapped by the \`onetime\` package`);
  return n.get(e);
};
export {
  s as default
};
