import d from "./Active.vue.js";
import $ from "./TextInput.vue.js";
import { objectId as b } from "./object-id.js";
import A from "./Commands.vue.js";
import v from "./PrunButton.vue.js";
import x from "./NumberInput.vue.js";
import { materialsStore as y } from "./materials.js";
import { defineComponent as C, createElementBlock as i, openBlock as u, createVNode as o, Fragment as f, renderList as M, withCtx as a, createTextVNode as T } from "./runtime-core.esm-bundler.js";
import { ref as U, unref as s } from "./reactivity.esm-bundler.js";
const w = /* @__PURE__ */ C({
  __name: "Edit",
  props: {
    group: {}
  },
  setup(r, { expose: p }) {
    const n = U(_());
    function _() {
      const l = r.group.materials ?? {};
      return Object.keys(l).map((e) => [e, l[e]]);
    }
    function k() {
      n.value.push(["", 0]);
    }
    function V() {
      return !0;
    }
    function g() {
      r.group.materials = {};
      for (let [l, e] of n.value) {
        const t = y.getByTicker(l);
        !t || e === 0 || !isFinite(e) || (r.group.materials[t.ticker] = e);
      }
    }
    return p({ validate: V, save: g }), (l, e) => (u(), i(f, null, [
      (u(!0), i(f, null, M(s(n), (t, c) => (u(), i(f, {
        key: s(b)(t)
      }, [
        o(d, {
          label: `Material Ticker #${c + 1}`
        }, {
          default: a(() => [
            o($, {
              modelValue: t[0],
              "onUpdate:modelValue": (m) => t[0] = m
            }, null, 8, ["modelValue", "onUpdate:modelValue"])
          ]),
          _: 2
        }, 1032, ["label"]),
        o(d, {
          label: `Material Amount #${c + 1}`
        }, {
          default: a(() => [
            o(x, {
              modelValue: t[1],
              "onUpdate:modelValue": (m) => t[1] = m
            }, null, 8, ["modelValue", "onUpdate:modelValue"])
          ]),
          _: 2
        }, 1032, ["label"])
      ], 64))), 128)),
      o(A, null, {
        default: a(() => [
          o(v, {
            primary: "",
            onClick: k
          }, {
            default: a(() => [...e[0] || (e[0] = [
              T("ADD MATERIAL", -1)
            ])]),
            _: 1
          })
        ]),
        _: 1
      })
    ], 64));
  }
});
export {
  w as default
};
