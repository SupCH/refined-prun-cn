function e(n) {
  return n != null;
}
export {
  e as isPresent
};
