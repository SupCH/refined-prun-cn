import t from "./SectionHeader.vue.js";
import { defineComponent as o, createBlock as r, openBlock as a, withCtx as p, createTextVNode as n } from "./runtime-core.esm-bundler.js";
import { toDisplayString as i } from "./shared.esm-bundler.js";
const d = /* @__PURE__ */ o({
  __name: "CategoryHeader",
  props: {
    label: {}
  },
  setup(l) {
    return (e, c) => (a(), r(t, { style: { width: "100%" } }, {
      default: p(() => [
        n(i(e.label), 1)
      ]),
      _: 1
    }));
  }
});
export {
  d as default
};
