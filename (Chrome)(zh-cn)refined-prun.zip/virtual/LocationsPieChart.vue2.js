import f from "./LocationsPieChart.vue.js";
export {
  f as default
};
