import { useXitParameters as d } from "./use-xit-parameters.js";
import { userData as s } from "./user-data.js";
import p from "./PrunButton.vue.js";
import { createId as f } from "./create-id.js";
import u from "./CommandLists.vue.js";
import C from "./CommandList.vue.js";
import { isEmpty as y } from "./is-empty.js";
import { defineComponent as k, computed as L, createBlock as i, createElementBlock as _, openBlock as n, createElementVNode as E, createVNode as B, withCtx as N, createTextVNode as V } from "./runtime-core.esm-bundler.js";
import { unref as o } from "./reactivity.esm-bundler.js";
import { toDisplayString as D, normalizeClass as c } from "./shared.esm-bundler.js";
const A = /* @__PURE__ */ k({
  __name: "CMDL",
  setup($) {
    const r = d(), m = r.join(" "), a = L(() => {
      const e = s.commandLists.find((t) => t.id.startsWith(r[0]));
      return e || s.commandLists.find((t) => t.name === m);
    });
    function l() {
      s.commandLists.push({
        id: f(),
        name: m,
        commands: []
      });
    }
    return (e, t) => o(y)(o(r)) ? (n(), i(u, { key: 0 })) : o(a) ? (n(), i(C, {
      key: 1,
      list: o(a)
    }, null, 8, ["list"])) : (n(), _("div", {
      key: 2,
      class: c(e.$style.create)
    }, [
      E("span", null, 'Command List "' + D(o(m)) + '" not found.', 1),
      B(p, {
        primary: "",
        class: c(e.$style.button),
        onClick: l
      }, {
        default: N(() => [...t[0] || (t[0] = [
          V("CREATE", -1)
        ])]),
        _: 1
      }, 8, ["class"])
    ], 2));
  }
});
export {
  A as default
};
