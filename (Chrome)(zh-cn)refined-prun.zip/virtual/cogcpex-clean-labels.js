import { subscribe as n } from "./subscribe-async-generator.js";
import { $$ as o } from "./select-dom.js";
import { C as i } from "./prun-css.js";
import r from "./tiles.js";
import a from "./feature-registry.js";
function m(e) {
  n(o(e.anchor, i.Button.darkInline), (t) => {
    t.textContent = "vote";
  }), n(o(e.anchor, i.Link.link), (t) => {
    t.textContent && (t.textContent = t.textContent.replace("Advertising Campaign: ", "").replace("Education Events: ", ""));
  });
}
function p() {
  r.observe("COGCPEX", m);
}
a.add(
  import.meta.url,
  p,
  'COGCPEX: Hides "Advertising Campaign:" and "Education Events:" parts of the campaign labels.'
);
