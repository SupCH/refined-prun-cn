import { applyCssRule as t } from "./refined-prun-css.js";
import { C as e } from "./prun-css.js";
import o from "./feature-registry.js";
import s from "./align-chat-delete-button.module.css.js";
function r() {
  t(`.${e.Message.controlsAndText}`, s.container), t(`.${e.Message.controls}`, s.delete), t(
    `.${e.Message.message}:has(.${e.Message.controlsAndText} .${e.Message.controls}) .${e.Sender.name}`,
    s.username
  );
}
o.add(
  import.meta.url,
  r,
  'Moves the "delete" button to prevent chat message layout shift.'
);
