import { materialsStore as r } from "./materials.js";
const t = /* @__PURE__ */ new Set(["CXM", "CXOB", "CXP", "CXPC", "CXPO", "MAT"]);
function C(e) {
  if (!t.has(e[0].toUpperCase()))
    return;
  r.getByTicker(e[1]) && (e[1] = e[1].toUpperCase());
}
export {
  C as correctMaterialCommand
};
