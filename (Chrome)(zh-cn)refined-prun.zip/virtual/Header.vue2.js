import { vModelText as k, withKeys as g } from "./runtime-dom.esm-bundler.js";
import { C as f } from "./prun-css.js";
import { defineComponent as V, mergeModels as b, useModel as h, useTemplateRef as B, createElementBlock as n, openBlock as a, renderSlot as M, Fragment as $, createCommentVNode as p, withDirectives as E, nextTick as H } from "./runtime-core.esm-bundler.js";
import { ref as d, unref as t, isRef as R } from "./reactivity.esm-bundler.js";
import { normalizeClass as r, toDisplayString as T } from "./shared.esm-bundler.js";
const F = /* @__PURE__ */ V({
  __name: "Header",
  props: /* @__PURE__ */ b({
    editable: { type: Boolean, default: !1 }
  }, {
    modelValue: {},
    modelModifiers: {}
  }),
  emits: ["update:modelValue"],
  setup(m) {
    const u = h(m, "modelValue"), i = B("input"), l = d(""), o = d(!1);
    function y() {
      o.value = !0, l.value = u.value ?? "", H(() => i.value?.focus());
    }
    function v() {
      l.value.length > 0 && (u.value = l.value), i.value?.blur();
    }
    function c() {
      o.value = !1;
    }
    return (e, s) => (a(), n("div", {
      class: r([e.$style.heading, ("C" in e ? e.C : t(f)).fonts.fontHeaders, ("C" in e ? e.C : t(f)).type.typeVeryLarge])
    }, [
      e.editable ? (a(), n($, { key: 0 }, [
        t(o) ? p("", !0) : (a(), n("span", {
          key: 0,
          class: r(e.$style.editable),
          onClick: y
        }, T(u.value), 3)),
        t(o) ? E((a(), n("input", {
          key: 1,
          ref: "input",
          "onUpdate:modelValue": s[0] || (s[0] = (C) => R(l) ? l.value = C : null),
          class: r(e.$style.input),
          autocomplete: "off",
          type: "text",
          placeholder: "",
          onKeyup: g(v, ["enter"]),
          onBlur: c
        }, null, 34)), [
          [k, t(l)]
        ]) : p("", !0)
      ], 64)) : M(e.$slots, "default", { key: 1 })
    ], 2));
  }
});
export {
  F as default
};
