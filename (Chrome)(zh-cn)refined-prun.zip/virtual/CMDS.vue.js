import p from "./xit-registry.js";
import { t as m } from "./index5.js";
import { castArray as a } from "./cast-array.js";
import c from "./PrunLink.vue.js";
import { objectId as f } from "./object-id.js";
import { defineComponent as y, createElementBlock as l, openBlock as d, createElementVNode as r, Fragment as h, renderList as b, createVNode as k, withCtx as B, createTextVNode as C } from "./runtime-core.esm-bundler.js";
import { toDisplayString as n } from "./shared.esm-bundler.js";
import { unref as e } from "./reactivity.esm-bundler.js";
const S = /* @__PURE__ */ y({
  __name: "CMDS",
  setup(N) {
    const s = p.registry.sort((t, i) => {
      const o = a(t.command)[0], u = a(i.command)[0];
      return o.localeCompare(u);
    });
    return (t, i) => (d(), l("table", null, [
      r("thead", null, [
        r("tr", null, [
          r("th", null, n(("t" in t ? t.t : e(m))("cmds.command")), 1),
          r("th", null, n(("t" in t ? t.t : e(m))("cmds.description")), 1),
          r("th", null, n(("t" in t ? t.t : e(m))("cmds.mandatory")), 1),
          r("th", null, n(("t" in t ? t.t : e(m))("cmds.optional")), 1)
        ])
      ]),
      r("tbody", null, [
        (d(!0), l(h, null, b(e(s), (o) => (d(), l("tr", {
          key: e(f)(o)
        }, [
          r("td", null, [
            k(c, {
              command: "XIT " + e(a)(o.command)[0],
              "auto-submit": !o.mandatoryParameters
            }, {
              default: B(() => [
                C(n(e(a)(o.command)[0]), 1)
              ]),
              _: 2
            }, 1032, ["command", "auto-submit"])
          ]),
          r("td", null, n(("t" in t ? t.t : e(m))("commands." + e(a)(o.command)[0])), 1),
          r("td", null, n(o.mandatoryParameters), 1),
          r("td", null, n(o.optionalParameters), 1)
        ]))), 128))
      ])
    ]));
  }
});
export {
  S as default
};
