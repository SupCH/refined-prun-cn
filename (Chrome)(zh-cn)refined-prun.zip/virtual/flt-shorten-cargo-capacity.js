import { subscribe as i } from "./subscribe-async-generator.js";
import { $$ as n } from "./select-dom.js";
import { C as a } from "./prun-css.js";
import m from "./tiles.js";
import c from "./feature-registry.js";
function l(o) {
  i(n(o.anchor, a.ShipStore.store), (e) => {
    const t = e.children[2];
    t !== void 0 && (t.textContent = (t.textContent || "").replace(/(t|m³)/g, "").replace(/(\d+)([,.]?000)/g, (f, r) => `${r}k`));
  });
}
function p() {
  m.observe(["FLT", "FLTS", "FLTP"], l);
}
c.add(
  import.meta.url,
  p,
  'FLT: Removes "t" and "m³" and converts cargo capacity label to k-notation.'
);
