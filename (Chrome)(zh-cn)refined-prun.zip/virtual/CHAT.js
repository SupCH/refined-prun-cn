import a from "./xit-registry.js";
import e from "./CHAT.vue.js";
a.add({
  command: "CHAT",
  name: "FIO CHAT",
  description: "Provides read-only access to a planet chat.",
  mandatoryParameters: "Planet Identifier",
  component: () => e
});
