import i from "./font-awesome.module.css.js";
import { showTileOverlay as l } from "./tile-overlay.js";
import m from "./EditTask.vue.js";
import { createId as n } from "./create-id.js";
import { defineComponent as c, createElementBlock as d, openBlock as p, createElementVNode as t } from "./runtime-core.esm-bundler.js";
import { normalizeClass as s, toDisplayString as f } from "./shared.esm-bundler.js";
import { unref as k } from "./reactivity.esm-bundler.js";
const B = /* @__PURE__ */ c({
  __name: "AddTaskItem",
  props: {
    list: {}
  },
  setup(r) {
    function a(e) {
      const o = {
        id: n(),
        type: "Text"
      };
      l(e, m, {
        task: o,
        onSave: () => r.list.tasks.push(o)
      });
    }
    return (e, o) => (p(), d("div", {
      class: s(e.$style.item),
      onClick: a
    }, [
      t("div", {
        class: s([k(i).solid, e.$style.checkmark])
      }, [
        t("div", {
          class: s(e.$style.plus)
        }, "+", 2),
        t("div", {
          class: s(e.$style.plusHover)
        }, f(""), 2)
      ], 2),
      t("div", {
        class: s([e.$style.content])
      }, "Add task", 2)
    ], 2));
  }
});
export {
  B as default
};
