import f from "./BurnSection.vue.js";
export {
  f as default
};
