import { applyCssRule as r } from "./refined-prun-css.js";
import n from "./feature-registry.js";
import o from "./css-utils.module.css.js";
import e from "./hide-form-errors.module.css.js";
function m() {
  r(".FormComponent__containerError___pN__L1Q", e.containerError), r(".FormComponent__containerError___jKoukmU", e.containerError), r(".FormComponent__errorMessage___mBdvpz5", o.hidden), r(".FormComponent__errorMessage___R2eGj1h", o.hidden);
}
n.add(import.meta.url, m, "Hides error labels from form fields with incorrect input.");
