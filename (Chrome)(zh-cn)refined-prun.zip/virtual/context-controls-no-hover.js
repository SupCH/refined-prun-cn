import { applyCssRule as t } from "./refined-prun-css.js";
import { C as o } from "./prun-css.js";
import r from "./feature-registry.js";
import e from "./css-utils.module.css.js";
function i() {
  t(`.${o.ContextControls.item}:hover .${o.ContextControls.label}`, e.hidden);
}
r.add(
  import.meta.url,
  i,
  "Prevents the context controls from displaying description while hovering over."
);
