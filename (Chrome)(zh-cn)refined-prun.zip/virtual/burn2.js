import { productionStore as p } from "./production.js";
import { workforcesStore as y } from "./workforces.js";
import { storagesStore as v } from "./storage.js";
import { sitesStore as d } from "./sites.js";
import { getEntityNaturalIdFromAddress as g, getEntityNameFromAddress as B } from "./addresses.js";
import { sumBy as I } from "./sum-by.js";
import { getRecurringOrders as k } from "./orders.js";
import { computed as l } from "./runtime-core.esm-bundler.js";
const A = l(() => {
  if (!d.all.value)
    return;
  const i = /* @__PURE__ */ new Map();
  for (const r of d.all.value)
    i.set(
      r.siteId,
      l(() => {
        const a = r.siteId, n = y.getById(a)?.workforces, s = p.getBySiteId(a), o = v.getByAddressableId(a);
        if (!(!n || !s))
          return {
            storeId: o?.[0]?.id,
            planetName: B(r.address),
            naturalId: g(r.address),
            burn: b(s, n, o ?? [])
          };
      })
    );
  return i;
});
function L(i) {
  const r = typeof i == "string" ? d.getById(i) : i;
  if (r)
    return A.value?.get(r.siteId)?.value;
}
function b(i, r, a) {
  const n = {};
  function s(o) {
    return n[o] === void 0 && (n[o] = {
      input: 0,
      output: 0,
      workforce: 0,
      dailyAmount: 0,
      inventory: 0,
      daysLeft: 0,
      type: "output"
    }), n[o];
  }
  if (i)
    for (const o of i) {
      const t = o.capacity, u = k(o);
      let e = I(u, (c) => c.duration?.millis ?? 1 / 0);
      e /= 864e5;
      for (const c of u) {
        for (const f of c.outputs) {
          const m = s(f.material.ticker);
          m.output += f.amount * t / e;
        }
        for (const f of c.inputs) {
          const m = s(f.material.ticker);
          m.input += f.amount * t / e;
        }
      }
    }
  if (r) {
    for (const o of r)
      if (!(o.population <= 1) && o.capacity !== 0)
        for (const t of o.needs) {
          const u = s(t.material.ticker);
          u.workforce += t.unitsPerInterval;
        }
  }
  for (const o of Object.keys(n)) {
    const t = n[o];
    t.dailyAmount = t.output, t.type = "output", t.dailyAmount -= t.workforce, t.workforce > 0 && t.dailyAmount <= 0 && (t.type = "workforce"), t.dailyAmount -= t.input, t.input > 0 && t.dailyAmount <= 0 && (t.type = "input");
  }
  if (a)
    for (const o of a)
      for (const t of o.items) {
        const u = t.quantity;
        if (!u)
          continue;
        const e = n[u.material.ticker];
        e !== void 0 && (e.inventory += u.amount, u.amount != 0 && (e.daysLeft = e.dailyAmount > 0 ? 1e3 : Math.floor(-e.inventory / e.dailyAmount)));
      }
  return n;
}
export {
  b as calculatePlanetBurn,
  L as getPlanetBurn
};
