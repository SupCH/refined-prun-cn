const e = "rp-item-icons__container___8e5388f", n = "rp-item-icons__label___0de7df1", t = {
  container: e,
  label: n
};
export {
  e as container,
  t as default,
  n as label
};
