import { C as O } from "./prun-css.js";
import C from "./PrunButton.vue.js";
import J from "./SectionHeader.vue.js";
import T from "./Active.vue.js";
import P from "./TextInput.vue.js";
import S from "./Commands.vue.js";
import _ from "./SelectInput.vue.js";
import { uploadJson as b } from "./json-file.js";
import { isPresent as U } from "./is-present.js";
import { defineComponent as g, createElementBlock as B, openBlock as u, createVNode as m, createElementVNode as X, withCtx as l, createTextVNode as f, createBlock as p, createCommentVNode as s } from "./runtime-core.esm-bundler.js";
import { ref as d, isRef as V, unref as t } from "./reactivity.esm-bundler.js";
import { normalizeClass as $ } from "./shared.esm-bundler.js";
const G = /* @__PURE__ */ g({
  __name: "ImportActionPackage",
  props: {
    onImport: { type: Function }
  },
  emits: ["close"],
  setup(c, { emit: y }) {
    const k = y, I = [
      {
        label: "Paste JSON",
        value: "TEXT"
      },
      {
        label: "Upload JSON",
        value: "FILE"
      }
    ], r = d("TEXT"), n = d(""), a = d(!1);
    function E() {
      if (n.value.length === 0) {
        a.value = !0;
        return;
      }
      try {
        const e = JSON.parse(n.value);
        if (!v(e)) {
          a.value = !0;
          return;
        }
        c.onImport(e), k("close");
      } catch {
        a.value = !0;
      }
    }
    function N() {
      b((e) => {
        if (!v(e)) {
          a.value = !0;
          return;
        }
        c.onImport(e), k("close");
      });
    }
    function v(e) {
      return U(e.global?.name);
    }
    return (e, o) => (u(), B("div", {
      class: $(("C" in e ? e.C : t(O)).DraftConditionEditor.form)
    }, [
      m(J, null, {
        default: l(() => [...o[2] || (o[2] = [
          f("Import Action Package", -1)
        ])]),
        _: 1
      }),
      X("form", null, [
        m(T, { label: "Type" }, {
          default: l(() => [
            m(_, {
              modelValue: t(r),
              "onUpdate:modelValue": o[0] || (o[0] = (i) => V(r) ? r.value = i : null),
              options: I
            }, null, 8, ["modelValue"])
          ]),
          _: 1
        }),
        t(r) === "TEXT" ? (u(), p(T, {
          key: 0,
          label: "JSON",
          error: t(a)
        }, {
          default: l(() => [
            m(P, {
              modelValue: t(n),
              "onUpdate:modelValue": o[1] || (o[1] = (i) => V(n) ? n.value = i : null),
              "focus-on-mount": ""
            }, null, 8, ["modelValue"])
          ]),
          _: 1
        }, 8, ["error"])) : s("", !0),
        m(S, null, {
          default: l(() => [
            t(r) === "FILE" ? (u(), p(C, {
              key: 0,
              primary: "",
              onClick: N
            }, {
              default: l(() => [...o[3] || (o[3] = [
                f("UPLOAD", -1)
              ])]),
              _: 1
            })) : s("", !0),
            t(r) === "TEXT" ? (u(), p(C, {
              key: 1,
              primary: "",
              onClick: E
            }, {
              default: l(() => [...o[4] || (o[4] = [
                f("IMPORT", -1)
              ])]),
              _: 1
            })) : s("", !0)
          ]),
          _: 1
        })
      ])
    ], 2));
  }
});
export {
  G as default
};
