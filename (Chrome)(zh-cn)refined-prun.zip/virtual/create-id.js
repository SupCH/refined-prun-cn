import e from "./v4.js";
const o = () => e().replaceAll("-", "");
export {
  o as createId
};
