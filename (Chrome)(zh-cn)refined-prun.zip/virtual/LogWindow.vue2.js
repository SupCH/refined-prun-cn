import { useCssModule as m } from "./runtime-dom.esm-bundler.js";
import { C as g } from "./prun-css.js";
import { objectId as f } from "./object-id.js";
import { defineComponent as p, useTemplateRef as d, watch as C, createElementBlock as o, openBlock as s, Fragment as h, renderList as v, createCommentVNode as N, createElementVNode as E, nextTick as R } from "./runtime-core.esm-bundler.js";
import { normalizeClass as c, toDisplayString as i } from "./shared.esm-bundler.js";
import { unref as l } from "./reactivity.esm-bundler.js";
const b = /* @__PURE__ */ p({
  __name: "LogWindow",
  props: {
    messages: {},
    scrolling: { type: Boolean }
  },
  setup(n) {
    const r = m(), a = d("log");
    C(
      () => n.messages,
      () => {
        n.messages.length === 0 || !n.scrolling || a.value && R(
          () => a.value.scrollTo({ top: a.value.scrollHeight, behavior: "smooth" })
        );
      },
      { deep: !0 }
    );
    function u(e) {
      switch (e) {
        case "ACTION":
        case "SUCCESS":
          return r.success;
        case "WARNING":
        case "SKIP":
          return r.warning;
        case "ERROR":
        case "CANCEL":
          return r.failure;
      }
    }
    return (e, k) => (s(), o("div", {
      ref: "log",
      class: c([l(r).log, ("C" in e ? e.C : l(g)).fonts.fontRegular])
    }, [
      (s(!0), o(h, null, v(e.messages, (t) => (s(), o("div", {
        key: l(f)(t)
      }, [
        t.tag ? (s(), o("b", {
          key: 0,
          class: c(u(t.tag))
        }, i(t.tag) + ": ", 3)) : N("", !0),
        E("span", null, i(t.message), 1)
      ]))), 128))
    ], 2));
  }
});
export {
  b as default
};
