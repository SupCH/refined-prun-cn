const s = "rp-item-ticker-shadow__shadow___d0df755", d = {
  shadow: s
};
export {
  d as default,
  s as shadow
};
