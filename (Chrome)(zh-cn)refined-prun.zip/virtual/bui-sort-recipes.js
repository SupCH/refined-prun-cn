import { subscribe as d } from "./subscribe-async-generator.js";
import { _$$ as p, $$ as C, _$ as c } from "./select-dom.js";
import { C as e } from "./prun-css.js";
import h from "./tiles.js";
import g from "./feature-registry.js";
import { compareMaterials as m } from "./sort-materials.js";
import { materialsStore as M } from "./materials.js";
function I(t) {
  d(C(t.anchor, e.BuildingInformation.recipeList), (r) => {
    const n = p(r, e.BuildingInformation.recipe).map(B);
    n.sort($);
    for (const o of n) {
      if (r.appendChild(o.element), o.inputsContainer)
        for (const u of o.inputs ?? [])
          o.inputsContainer.appendChild(u.element);
      if (o.outputsContainer)
        for (const u of o.outputs ?? [])
          o.outputsContainer.appendChild(u.element);
    }
  });
}
function B(t) {
  const r = c(t, e.BuildingInformation.inputs);
  if (!r)
    return {
      element: t
    };
  const i = p(t, e.MaterialIcon.container), n = p(r, e.MaterialIcon.container), o = i.filter((a) => !n.includes(a)), u = o[0]?.parentElement ?? void 0;
  return {
    element: t,
    inputsContainer: r,
    inputs: n.map(l).sort((a, s) => m(a.material, s.material)),
    outputsContainer: u,
    outputs: o.map(l).sort((a, s) => m(a.material, s.material))
  };
}
function l(t) {
  const r = M.getByTicker(c(t, e.ColoredIcon.label)?.textContent), i = Number(c(t, e.MaterialIcon.indicator)?.textContent ?? 0);
  return { element: t, material: r, amount: i };
}
function $(t, r) {
  if (!t.outputs && !r.outputs)
    return 0;
  if (!t.outputs)
    return 1;
  if (!r.outputs)
    return -1;
  const i = f(t.outputs, r.outputs);
  return i !== 0 ? i : f(t.inputs ?? [], r.inputs ?? []);
}
function f(t, r) {
  const i = Math.min(t.length, r.length);
  for (let n = 0; n < i; n++) {
    if (t.length <= n)
      return -1;
    if (r.length <= n)
      return 1;
    const o = m(t[n].material, r[n].material);
    if (o !== 0)
      return o;
    if (t[n].amount < r[n].amount)
      return -1;
    if (t[n].amount > r[n].amount)
      return 1;
  }
  return 0;
}
function y() {
  h.observe("BUI", I);
}
g.add(
  import.meta.url,
  y,
  "BUI: Sorts the recipes and materials by category/ticker/amount sort order."
);
