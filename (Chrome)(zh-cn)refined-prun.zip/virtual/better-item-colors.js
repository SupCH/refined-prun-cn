import { applyCssRule as l } from "./refined-prun-css.js";
import o from "./feature-registry.js";
import s from "./better-item-colors.module.css.js";
import { sanitizeCategoryName as t } from "./item-tracker.js";
function u() {
  i("agricultural products", s.agriculturalProducts), i("consumables (basic)", s.consumablesBasic), i("consumables (luxury)", s.consumablesLuxury), i("fuels", s.fuels), i("liquids", s.liquids), i("plastics", s.plastics), i("ship shields", s.shipShields);
}
function i(r, e) {
  l(`.rp-category-${t(r)}`, e);
}
o.add(import.meta.url, u, "Alters item colors to be more easily recognized.");
