import { createEntityStore as r } from "./create-entity-store.js";
import { onApiMessage as s } from "./api-messages.js";
import { createMapGetter as c } from "./create-map-getter.js";
const e = r(), o = e.state;
s({
  FOREX_BROKER_DATA(t) {
    e.setOne(t), e.setFetched();
  }
});
const a = c(o.all, (t) => t.ticker), p = {
  ...o,
  getByTicker: a
};
export {
  p as fxobStore
};
