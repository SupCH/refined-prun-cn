const t = "rp-BuildingCountSection__list___fb252cf", s = {
  list: t
};
export {
  s as default,
  t as list
};
