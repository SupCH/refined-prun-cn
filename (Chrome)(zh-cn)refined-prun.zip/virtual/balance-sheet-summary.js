import { map as e } from "./map-values.js";
import { sum as T } from "./sum.js";
function t(n, ...a) {
  if (n !== void 0)
    return n.total !== void 0 ? n.total : n.total ?? c(...a.map((r) => r(n)));
}
function i(n) {
  return n !== void 0 ? -n : n;
}
function d(n) {
  return t(
    n.assets?.current?.cashAndCashEquivalents?.deposits,
    (a) => a.cx,
    (a) => a.fx
  );
}
function l(n) {
  return t(
    n.assets?.current?.cashAndCashEquivalents,
    (a) => a.cash,
    () => d(n),
    (a) => a.mmMaterials
  );
}
function u(n) {
  return t(
    n.assets?.current?.loansReceivable,
    (a) => a.principal,
    (a) => a.interest
  );
}
function p(n) {
  return t(
    n.assets?.current?.inventory?.baseInventory,
    (a) => a.finishedGoods,
    (a) => a.workInProgress,
    (a) => a.rawMaterials,
    (a) => a.workforceConsumables,
    (a) => a.otherItems
  );
}
function v(n) {
  return t(
    n.assets?.current?.inventory,
    (a) => a.cxListedMaterials,
    (a) => a.cxInventory,
    (a) => a.materialsInTransit,
    () => p(n),
    (a) => a.fuelTanks,
    (a) => a.materialsReceivable
  );
}
function y(n) {
  return t(
    n.assets?.current,
    () => l(n),
    (a) => a.accountsReceivable,
    () => u(n),
    () => v(n)
  );
}
function C(n) {
  return t(
    n.assets?.nonCurrent?.buildings?.marketValue,
    (a) => a.infrastructure,
    (a) => a.resourceExtraction,
    (a) => a.production
  );
}
function g(n) {
  return t(
    n.assets?.nonCurrent?.buildings,
    () => C(n),
    (a) => i(a.accumulatedDepreciation)
  );
}
function s(n) {
  return t(
    n.assets?.nonCurrent?.ships,
    (a) => a.marketValue,
    (a) => i(a.accumulatedDepreciation)
  );
}
function P(n) {
  return t(
    n.assets?.nonCurrent?.longTermReceivables,
    (a) => a.accountsReceivable,
    (a) => a.materialsInTransit,
    (a) => a.materialsReceivable,
    (a) => a.loansPrincipal
  );
}
function o(n) {
  return t(
    n.assets?.nonCurrent?.intangibleAssets,
    (a) => a.hqUpgrades,
    (a) => a.arc
  );
}
function R(n) {
  return t(
    n.assets?.nonCurrent,
    () => g(n),
    () => s(n),
    () => P(n),
    () => o(n)
  );
}
function f(n) {
  return t(
    n.assets,
    () => y(n),
    () => R(n)
  );
}
function b(n) {
  return t(
    n.liabilities?.current?.loansPayable,
    (a) => a.principal,
    (a) => a.interest
  );
}
function A(n) {
  return t(
    n.liabilities?.current,
    (a) => a.accountsPayable,
    (a) => a.materialsPayable,
    () => b(n)
  );
}
function L(n) {
  return t(
    n.liabilities?.nonCurrent?.longTermPayables,
    (a) => a.accountsPayable,
    (a) => a.materialsPayable,
    (a) => a.loansPrincipal
  );
}
function I(n) {
  return t(n.liabilities?.nonCurrent, () => L(n));
}
function m(n) {
  return t(
    n.liabilities,
    () => A(n),
    () => I(n)
  );
}
function k(n) {
  return n.equity ?? c(f(n), i(m(n)));
}
function M(n) {
  return c(
    k(n),
    i(s(n)),
    i(o(n))
  );
}
function q(n) {
  return c(
    l(n),
    u(n),
    n?.assets?.current?.accountsReceivable
  );
}
function x(n) {
  return c(b(n), n?.liabilities?.current?.accountsPayable);
}
function V(n) {
  return e([q(n), x(n)], (a, r) => a / r);
}
function w(n) {
  return e([m(n), f(n)], (a, r) => a / r);
}
function c(...n) {
  return e(n, T);
}
export {
  V as calcAcidTestRatio,
  w as calcDebtRatio,
  k as calcEquity,
  M as calcLiquidationValue,
  q as calcQuickAssets,
  x as calcQuickLiabilities,
  f as calcTotalAssets,
  p as calcTotalBaseInventory,
  g as calcTotalBuildings,
  C as calcTotalBuildingsMarketValue,
  l as calcTotalCashAndCashEquivalents,
  y as calcTotalCurrentAssets,
  A as calcTotalCurrentLiabilities,
  d as calcTotalDeposits,
  o as calcTotalIntangibleAssets,
  v as calcTotalInventory,
  m as calcTotalLiabilities,
  b as calcTotalLoansPayable,
  u as calcTotalLoansReceivable,
  L as calcTotalLongTermPayables,
  P as calcTotalLongTermReceivables,
  R as calcTotalNonCurrentAssets,
  I as calcTotalNonCurrentLiabilities,
  s as calcTotalShips
};
