import { sumBy as f } from "./sum-by.js";
import { balancesStore as v } from "./balances.js";
import { cxosStore as d } from "./cxos.js";
import { fxosStore as y } from "./fxos.js";
import { sumLoanInterest as x, sumAccountsPayable as b, sumLoanRepayments as L, partnerCurrentConditions as i } from "./contract-conditions.js";
import { sumMapValues as c } from "./utils.js";
import { inventory as D } from "./inventory.js";
import { sum as S } from "./sum.js";
import { computed as o } from "./runtime-core.esm-bundler.js";
const T = o(() => f(v.all.value, (r) => r.amount)), m = o(() => {
  const r = d.active.value;
  if (!r)
    return;
  const s = /* @__PURE__ */ new Map(), e = r.filter((t) => t.type === "BUYING");
  for (const t of e) {
    const n = t.limit.amount * t.amount, a = t.limit.currency;
    s.set(a, (s.get(a) ?? 0) + n);
  }
  return s;
}), u = o(() => c(m.value)), l = o(() => {
  const r = y.active.value;
  if (!r)
    return;
  const s = /* @__PURE__ */ new Map();
  for (const e of r) {
    let t, n;
    e.type === "SELLING" ? (t = e.amount.amount, n = e.limit.base) : (t = e.amount.amount * e.limit.rate, n = e.limit.quote), s.set(n, (s.get(n) ?? 0) + t);
  }
  return s;
}), p = o(() => c(l.value));
o(() => S(u.value, p.value));
const I = o(() => x(i)), M = o(() => b(i)), R = o(() => L(i)), E = {
  cashTotal: T,
  cxDeposits: m,
  cxDepositsTotal: u,
  fxDeposits: l,
  fxDepositsTotal: p,
  interestReceivable: I,
  accountsReceivable: M,
  shortTermLoans: R,
  inventory: D
};
export {
  E as currentAssets
};
