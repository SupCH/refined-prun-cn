import { diffDays as f } from "./time-diff.js";
import { userData as u } from "./user-data.js";
import { balancesStore as d } from "./balances.js";
import { userDataStore as l } from "./user-data2.js";
import { isPresent as F } from "./is-present.js";
import { computed as o } from "./runtime-core.esm-bundler.js";
const g = o(() => {
  switch (u.settings.time) {
    case "24H":
      return !1;
    case "12H":
      return !0;
    case "DEFAULT":
      return;
  }
}), a = o(() => {
  let t = l.preferredLocale;
  if (t)
    return t = t.replace("_", "-"), navigator.language.startsWith(t) ? navigator.language : t;
});
function m(t) {
  const i = o(() => new Intl.DateTimeFormat(
    a.value,
    typeof t == "function" ? t() : t
  ));
  return (e) => i.value.format(e);
}
function r(t) {
  const i = o(() => new Intl.NumberFormat(a.value, typeof t == "function" ? t() : t));
  return (e) => i.value.format(e);
}
const T = o(() => new Intl.DateTimeFormat(a.value, { hour: "2-digit" }).format), p = m(() => ({
  hour: "2-digit",
  minute: "2-digit",
  hour12: g.value
}));
m(() => ({
  hour: "2-digit",
  minute: "2-digit",
  second: "2-digit",
  hour12: g.value
}));
const b = m({
  month: "2-digit",
  day: "2-digit"
}), w = m({
  month: "2-digit",
  day: "2-digit",
  year: "numeric"
}), D = r({
  maximumFractionDigits: 0
}), I = r({
  minimumFractionDigits: 0,
  maximumFractionDigits: 2
}), L = r({
  minimumFractionDigits: 1,
  maximumFractionDigits: 1
}), H = r({
  minimumFractionDigits: 0,
  maximumFractionDigits: 1
}), U = r({
  minimumFractionDigits: 2,
  maximumFractionDigits: 2
}), P = r({
  style: "percent",
  maximumFractionDigits: 0
}), _ = r({
  style: "percent",
  minimumFractionDigits: 1,
  maximumFractionDigits: 1
}), M = r({
  style: "percent",
  minimumFractionDigits: 2,
  maximumFractionDigits: 2
});
function N(t, i) {
  let e = p(i);
  const n = f(t, i);
  return n > 0 && (e += ` +${n}d`), e;
}
function R(t, i) {
  if (!F(t))
    return "--";
  i ??= D;
  const e = u.settings.currency, n = h(e), s = e.preset === "DEFAULT" ? "HAS_SPACE" : e.spacing;
  if ((e.preset === "DEFAULT" ? "AFTER" : e.position) === "AFTER")
    return s === "HAS_SPACE" ? i(t) + " " + n : i(t) + n;
  const c = t < 0 ? "-" : "";
  return s === "HAS_SPACE" ? c + n + " " + i(Math.abs(t)) : c + n + i(Math.abs(t));
}
function h(t) {
  switch (t.preset) {
    case "DEFAULT":
      return d.ownCurrency.value;
    case "AIC":
      return "₳";
    case "ICA":
      return "ǂ";
    case "CIS":
      return "₡";
    case "NCC":
      return "₦";
    case "CUSTOM":
      return t.custom;
  }
}
export {
  b as ddmm,
  w as ddmmyyyy,
  D as fixed0,
  H as fixed01,
  I as fixed02,
  L as fixed1,
  U as fixed2,
  R as formatCurrency,
  N as formatEta,
  T as hhForXitSet,
  p as hhmm,
  P as percent0,
  _ as percent1,
  M as percent2
};
