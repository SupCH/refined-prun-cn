import { subscribe as n } from "./subscribe-async-generator.js";
import { $$ as e } from "./select-dom.js";
import s from "./tiles.js";
import c from "./feature-registry.js";
import d from "./link.module.css.js";
import { showBuffer as f } from "./buffers.js";
import { isPresent as l } from "./is-present.js";
function u(m) {
  n(e(m.anchor, "tbody"), (a) => {
    n(e(a, "tr"), (t) => {
      const o = t.children[0], r = o?.textContent, i = t.children[2];
      !l(r) || i === void 0 || (o.classList.add(d.link), o.addEventListener("click", () => {
        f(r, { autoSubmit: (i.textContent ?? "") === "" });
      }));
    });
  });
}
function p() {
  s.observe("CMDS", u);
}
c.add(import.meta.url, p, "CMDS: Makes commands clickable.");
