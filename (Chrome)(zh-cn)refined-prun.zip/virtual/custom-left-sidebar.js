import { applyCssRule as s } from "./refined-prun-css.js";
import { subscribe as c } from "./subscribe-async-generator.js";
import { _$$ as n, _$ as p, $$ as f } from "./select-dom.js";
import { C as o } from "./prun-css.js";
import { createFragmentApp as d } from "./vue-fragment-app.js";
import l from "./feature-registry.js";
import u from "./css-utils.module.css.js";
import g from "./SidebarButtons.vue.js";
import { refAttributeValue as _ } from "./reactive-dom.js";
import { ref as v, reactive as F } from "./reactivity.esm-bundler.js";
import { computed as b } from "./runtime-core.esm-bundler.js";
function A() {
  s("#TOUR_TARGET_SIDEBAR_LEFT_02", u.hidden), c(f(document, o.Frame.sidebar), (t) => {
    const r = n(t, o.Frame.toggle).find((a) => a.textContent === "COM"), e = r ? p(r, o.Frame.toggleIndicator) : void 0, m = e ? _(e, "class") : v(void 0), i = b(() => m.value?.includes(o.Frame.toggleIndicatorPulseActive));
    d(g, F({ comPulse: i })).appendTo(t);
  });
}
l.add(import.meta.url, A, "Makes the sidebar on the left customizable via settings.");
