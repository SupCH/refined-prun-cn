import f from "./FinHeader.vue.js";
export {
  f as default
};
