import n from "./SortCriteria.vue.js";
import { objectId as i } from "./object-id.js";
import { defineComponent as c, createElementBlock as l, openBlock as o, createVNode as a, Fragment as t, renderList as p, createBlock as s } from "./runtime-core.esm-bundler.js";
import { unref as u } from "./reactivity.esm-bundler.js";
const y = /* @__PURE__ */ c({
  __name: "InventorySortControls",
  props: {
    activeSort: {},
    onAddClick: { type: Function },
    onModeClick: { type: Function },
    reverse: { type: Boolean },
    sorting: {}
  },
  setup(k) {
    return (e, m) => (o(), l(t, null, [
      (o(!0), l(t, null, p(e.sorting, (r) => (o(), s(n, {
        key: u(i)(r),
        label: r.label,
        active: r.label === e.activeSort,
        reverse: e.reverse,
        onClick: (v) => e.onModeClick(r.label)
      }, null, 8, ["label", "active", "reverse", "onClick"]))), 128)),
      a(n, {
        label: "+",
        onClick: e.onAddClick
      }, null, 8, ["onClick"])
    ], 64));
  }
});
export {
  y as default
};
