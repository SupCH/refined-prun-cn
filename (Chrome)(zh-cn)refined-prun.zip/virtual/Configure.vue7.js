import f from "./Configure.vue4.js";
export {
  f as default
};
