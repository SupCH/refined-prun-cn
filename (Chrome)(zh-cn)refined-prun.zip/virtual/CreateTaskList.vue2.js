import f from "./CreateTaskList.vue.js";
export {
  f as default
};
