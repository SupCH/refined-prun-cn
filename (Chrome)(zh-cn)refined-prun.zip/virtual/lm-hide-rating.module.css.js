const t = "rp-lm-hide-rating__text___ddd6143", e = {
  text: t
};
export {
  e as default,
  t as text
};
