import { $ as i } from "./select-dom.js";
import { C as o } from "./prun-css.js";
import { createFragmentApp as l } from "./vue-fragment-app.js";
import m from "./tiles.js";
import s from "./feature-registry.js";
import f from "./TileControlsButton.vue.js";
import { computedTileState as c, getTileState as p } from "./user-data-tiles.js";
import { watchEffectWhileNodeAlive as u } from "./watch.js";
import d from "./css-utils.module.css.js";
import C from "./font-awesome.module.css.js";
import { createVNode as e, Fragment as g, computed as T } from "./runtime-core.esm-bundler.js";
function v(t) {
  return T(() => p(t));
}
async function h(t) {
  const r = await i(t.frame, o.ContextControls.container), n = c(v(t), "minimizeContextControls", !1);
  u(t.anchor, () => {
    r.classList.toggle(d.hidden, n.value);
  });
  const a = await i(t.frame, o.TileFrame.controls);
  l(() => n.value ? e(f, {
    icon: "",
    marginTop: 4,
    onClick: () => n.value = !1
  }, null) : null).prependTo(a), l(() => e(g, null, [e("div", {
    class: [o.ContextControls.item, o.fonts.fontRegular, o.type.typeSmall],
    onClick: () => {
      n.value = !0;
    }
  }, [e("i", {
    class: [C.solid]
  }, [""])]), e("div", {
    style: {
      flexGrow: "1"
    }
  }, null)])).prependTo(r);
}
function x() {
  m.observeAll(h);
}
s.add(import.meta.url, x, "Adds buttons to hide and show context controls for tiles containing them.");
