import { subscribe as s } from "./subscribe-async-generator.js";
import { $$ as a, _$$ as f, $ as p } from "./select-dom.js";
import { C as n } from "./prun-css.js";
import u from "./tiles.js";
import l from "./feature-registry.js";
import { contractDraftsStore as h } from "./contract-drafts.js";
import { getEntityNameFromAddress as v } from "./addresses.js";
import { computed as x } from "./runtime-core.esm-bundler.js";
function C(i) {
  const m = x(() => h.getByNaturalId(i.parameter));
  let o;
  s(a(i.anchor, n.Draft.conditions), (d) => s(a(d, "tr"), (r) => {
    const t = r.children[0]?.textContent, e = f(r, n.Button.btn)[0];
    !t || e === void 0 || e.addEventListener("click", () => {
      const c = parseInt(t.replace("#", ""));
      isFinite(c) && (o = c - 1);
    });
  })), s(a(i.anchor, n.DraftConditionEditor.form), async (d) => {
    if (o === void 0)
      return;
    const r = m.value?.conditions[o]?.address, t = v(r);
    if (o = void 0, t) {
      const e = await p(d, n.AddressSelector.input);
      e.placeholder = t;
    }
  });
}
function D() {
  u.observe("CONTD", C);
}
l.add(
  import.meta.url,
  D,
  "CONTD: Sets the current address as the placeholder for the address field of the condition editor."
);
