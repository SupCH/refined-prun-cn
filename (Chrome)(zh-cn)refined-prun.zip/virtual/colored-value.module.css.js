const e = "rp-colored-value__warning___8e5e695", n = {
  warning: e
};
export {
  n as default,
  e as warning
};
