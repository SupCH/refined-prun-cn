import { subscribe as f } from "./subscribe-async-generator.js";
import { _$$ as l, $$ as c } from "./select-dom.js";
import { C as n } from "./prun-css.js";
import p from "./tiles.js";
import d from "./feature-registry.js";
import { watchEffectWhileNodeAlive as u } from "./watch.js";
import { refValue as g } from "./reactive-dom.js";
function h(t) {
  t.parameter && f(c(t.anchor, n.Site.info), (s) => {
    const r = l(s, n.FormComponent.containerPassive);
    if (r.length < 2)
      return;
    const o = r[0];
    o.style.display = "none";
    const e = o.getElementsByTagName("progress")[0];
    if (e === void 0)
      return;
    const a = e.cloneNode(!0), m = g(e);
    u(e, () => a.value = m.value);
    const i = r[1].getElementsByTagName("div")[0];
    i.insertBefore(a, i.lastChild);
  });
}
function v() {
  p.observe("BS", h);
}
d.add(
  import.meta.url,
  v,
  "BS: Merges the area progress bar field with the detailed area stats row."
);
