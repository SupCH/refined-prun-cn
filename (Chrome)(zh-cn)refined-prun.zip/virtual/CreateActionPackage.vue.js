import { C as v } from "./prun-css.js";
import V from "./PrunButton.vue.js";
import k from "./SectionHeader.vue.js";
import g from "./Active.vue.js";
import N from "./TextInput.vue.js";
import E from "./Commands.vue.js";
import { isValidPackageName as i } from "./utils8.js";
import { t as l } from "./index5.js";
import { defineComponent as $, watch as y, createElementBlock as B, openBlock as P, createVNode as r, createElementVNode as b, withCtx as t, createTextVNode as f } from "./runtime-core.esm-bundler.js";
import { ref as c, unref as o, isRef as h } from "./reactivity.esm-bundler.js";
import { toDisplayString as u, normalizeClass as w } from "./shared.esm-bundler.js";
const q = /* @__PURE__ */ $({
  __name: "CreateActionPackage",
  props: {
    onCreate: { type: Function }
  },
  emits: ["close"],
  setup(s, { emit: p }) {
    const d = p, e = c(""), a = c(!1);
    y(e, () => a.value = !i(e.value));
    function C() {
      if (e.value.length === 0 || !i(e.value)) {
        a.value = !0;
        return;
      }
      s.onCreate(e.value), d("close");
    }
    return (m, n) => (P(), B("div", {
      class: w(("C" in m ? m.C : o(v)).DraftConditionEditor.form)
    }, [
      r(k, null, {
        default: t(() => [
          f(u(o(l)("act.createPackage")), 1)
        ]),
        _: 1
      }),
      b("form", null, [
        r(g, {
          label: o(l)("act.name"),
          error: o(a)
        }, {
          default: t(() => [
            r(N, {
              modelValue: o(e),
              "onUpdate:modelValue": n[0] || (n[0] = (_) => h(e) ? e.value = _ : null)
            }, null, 8, ["modelValue"])
          ]),
          _: 1
        }, 8, ["label", "error"]),
        r(E, null, {
          default: t(() => [
            r(V, {
              primary: "",
              onClick: C
            }, {
              default: t(() => [
                f(u(o(l)("act.add").toUpperCase()), 1)
              ]),
              _: 1
            })
          ]),
          _: 1
        })
      ])
    ], 2));
  }
});
export {
  q as default
};
