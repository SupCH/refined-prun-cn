import { mergeMaterialAmounts as a } from "./sort-materials.js";
import { sumMaterialAmountPrice as o } from "./cx.js";
function m(t) {
  return t > 180 ? 0 : 1 - t / 180;
}
function s(t) {
  return t.module.type === "RESOURCES" || t.module.type === "PRODUCTION";
}
function u(t, i) {
  const r = i.buildOptions.options.find(
    (n) => n.ticker === t.module.reactorTicker
  );
  if (r)
    return r.materials.quantities;
  const e = t.reclaimableMaterials.concat(t.repairMaterials);
  return a(e);
}
function p(t, i) {
  return o(u(t, i));
}
export {
  m as calcBuildingCondition,
  p as calcBuildingMarketValue,
  u as getBuildingBuildMaterials,
  s as isRepairableBuilding
};
