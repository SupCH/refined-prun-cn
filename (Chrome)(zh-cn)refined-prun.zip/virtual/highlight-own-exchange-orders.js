import { subscribe as a } from "./subscribe-async-generator.js";
import { $$ as O } from "./select-dom.js";
import m from "./tiles.js";
import p from "./feature-registry.js";
import g from "./link.module.css.js";
import v from "./highlight-own-exchange-orders.module.css.js";
import { companyStore as c } from "./company.js";
import { refPrunId as w } from "./attributes.js";
import { watchEffectWhileNodeAlive as b } from "./watch.js";
import { cxobStore as B } from "./cxob.js";
import { showBuffer as h } from "./buffers.js";
import { fxobStore as k } from "./fxob.js";
import { computed as f } from "./runtime-core.esm-bundler.js";
function u(r, o, i) {
  const l = f(() => {
    const e = /* @__PURE__ */ new Map(), n = o(r.parameter);
    if (!n)
      return e;
    for (const t of n)
      e.set(t.id, t);
    return e;
  });
  a(O(r.anchor, "tr"), (e) => {
    const n = w(e), t = f(() => l.value.get(n.value ?? "")), s = e.children[1];
    s !== void 0 && (s.addEventListener("click", () => {
      t.value && h(`${i} ${t.value.id.substring(0, 8)}`);
    }), b(e, () => {
      const d = t.value !== void 0;
      e.classList.toggle(v.ownOrder, d), s.classList.toggle(g.link, d);
    }));
  });
}
function y(r) {
  const o = B.getByTicker(r);
  if (o)
    return [...o.sellingOrders, ...o.buyingOrders].filter(
      (i) => i.trader.id === c.value?.id
    );
}
function X(r) {
  const o = k.getByTicker(r);
  if (o)
    return [...o.sellingOrders, ...o.buyingOrders].filter(
      (i) => i.trader.id === c.value?.id
    );
}
function C() {
  m.observe("CXOB", (r) => u(r, y, "CXO")), m.observe("FXOB", (r) => u(r, X, "FXO"));
}
p.add(import.meta.url, C, "Highlights own orders in CXOB and FXOB.");
