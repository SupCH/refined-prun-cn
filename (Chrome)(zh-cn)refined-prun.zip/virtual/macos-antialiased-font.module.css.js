const o = "rp-macos-antialiased-font__body___5e3f4e6", t = {
  body: o
};
export {
  o as body,
  t as default
};
