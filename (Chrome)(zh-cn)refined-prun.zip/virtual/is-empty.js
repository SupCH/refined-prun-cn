function n(t) {
  return t.length === 0;
}
export {
  n as isEmpty
};
