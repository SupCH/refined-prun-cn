import f from "./Edit.vue6.js";
export {
  f as default
};
