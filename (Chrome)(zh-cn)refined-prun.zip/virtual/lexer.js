import { __exports as w } from "./lexer2.js";
import { __require as q } from "./token.js";
var W;
function j() {
  if (W) return w;
  W = 1, Object.defineProperty(w, "__esModule", { value: !0 });
  var e = q();
  function T(n, r) {
    for (var t = 0; t < n.length; t++) n[t] += r;
    return n;
  }
  var y = { 0: !0, 1: !0, 3: !0, 4: !0, 6: !0, 8: !0, 9: !0, 12: !0, 13: !0, 14: !0 }, I = { 0: !0, 1: !0, 2: !0, 3: !0, 4: !0, 5: !0, 6: !0, 7: !0, 8: !0, 9: !0, 10: !0, 11: !0, 12: !0, 13: !0 }, b = { 0: !0, 3: !0, 4: !0, 8: !0, 12: !0, 13: !0 }, _ = {}, c = { 0: !0, 1: !0, 3: !0, 4: !0, 6: !0, 8: !0, 12: !0, 13: !0 }, m = { 1: !0 }, N = [[], ["1", "2", "3", "7", "8", "9", "4", "5", "6", "+", "-", "*", "/", "(", ")", "^", "!", "P", "C", "e", "0", ".", ",", "n", " ", "&"], ["pi", "ln", "Pi"], ["sin", "cos", "tan", "Del", "int", "Mod", "log", "pow"], ["asin", "acos", "atan", "cosh", "root", "tanh", "sinh"], ["acosh", "atanh", "asinh", "Sigma"]];
  function x(n, r, t, k) {
    for (var a = 0; a < k; a++) if (n[t + a] !== r[a]) return !1;
    return !0;
  }
  function L(n, r) {
    for (var t = 0; t < r.length; t++) if (r[t].token === n) return t;
    return -1;
  }
  return w.addToken = function(n) {
    for (var r = 0; r < n.length; r++) {
      var t = n[r].token.length, k = -1;
      n[r].type === e.tokenTypes.FUNCTION_WITH_N_ARGS && n[r].numberOfArguments === void 0 && (n[r].numberOfArguments = 2), N[t] = N[t] || [];
      for (var a = 0; a < N[t].length; a++) if (n[r].token === N[t][a]) {
        k = L(N[t][a], this.tokens);
        break;
      }
      k === -1 ? (this.tokens.push(n[r]), n[r].precedence = e.preced[n[r].type], N.length <= n[r].token.length && (N[n[r].token.length] = []), N[n[r].token.length].push(n[r].token)) : (this.tokens[k] = n[r], n[r].precedence = e.preced[n[r].type]);
    }
  }, w.lex = function(n, r) {
    var t, k = { value: this.math.changeSign, type: e.tokenTypes.FUNCTION_WITH_ONE_ARG, precedence: 4, show: "-" }, a = { value: ")", show: ")", type: e.tokenTypes.CLOSING_PARENTHESIS, precedence: 0 }, S = { value: "(", type: e.tokenTypes.OPENING_PARENTHESIS, precedence: 0, show: "(" }, u = [S], s = [], Y = n, h = y, U = 0, E = _, D = "";
    r !== void 0 && this.addToken(r);
    var l = (function(F, f) {
      for (var v, A, P, B = [], H = f.length, O = 0; O < H; O++) if (!(O < H - 1 && f[O] === " " && f[O + 1] === " ")) {
        for (v = "", A = f.length - O > N.length - 2 ? N.length - 1 : f.length - O; A > 0; A--) if (N[A] !== void 0) for (P = 0; P < N[A].length; P++) x(f, N[A][P], O, A) && (v = N[A][P], P = N[A].length, A = 0);
        if (O += v.length - 1, v === "") throw new Error("Can't understand after " + f.slice(O));
        B.push(F.tokens[L(v, F.tokens)]);
      }
      return B;
    })(this, Y);
    for (t = 0; t < l.length; t++) {
      var R = l[t];
      if (R.type !== 14) {
        var g, G = R.token, o = R.type, C = R.value, d = R.precedence, M = R.show, p = u[u.length - 1];
        for (g = s.length; g-- && s[g] === 0; ) if ([e.tokenTypes.FUNCTION_WITH_ONE_ARG, e.tokenTypes.BINARY_OPERATOR_HIGH_PRECENDENCE, e.tokenTypes.CONSTANT, e.tokenTypes.OPENING_PARENTHESIS, e.tokenTypes.CLOSING_PARENTHESIS, e.tokenTypes.BINARY_OPERATOR_LOW_PRECENDENCE, e.tokenTypes.BINARY_OPERATOR_PERMUTATION, e.tokenTypes.COMMA, e.tokenTypes.EVALUATED_FUNCTION, e.tokenTypes.EVALUATED_FUNCTION_PARAMETER].indexOf(o) !== -1) {
          if (h[o] !== !0) throw new Error(G + " is not allowed after " + D);
          u.push(a), h = I, E = c, s.pop();
        }
        if (h[o] !== !0) throw new Error(G + " is not allowed after " + D);
        E[o] === !0 && (o = e.tokenTypes.BINARY_OPERATOR_HIGH_PRECENDENCE, C = this.math.mul, M = "&times;", d = 3, t -= 1);
        var i = { value: C, type: o, precedence: d, show: M, numberOfArguments: R.numberOfArguments };
        if (o === e.tokenTypes.FUNCTION_WITH_ONE_ARG) h = y, E = _, T(s, 1), u.push(i), l[t + 1].type !== e.tokenTypes.OPENING_PARENTHESIS && (u.push(S), s.push(2));
        else if (o === e.tokenTypes.NUMBER) p.type === e.tokenTypes.NUMBER ? (p.value += C, T(s, 1)) : u.push(i), h = I, E = b;
        else if (o === e.tokenTypes.BINARY_OPERATOR_HIGH_PRECENDENCE) h = y, E = _, T(s, 2), u.push(i);
        else if (o === e.tokenTypes.CONSTANT) u.push(i), h = I, E = c;
        else if (o === e.tokenTypes.OPENING_PARENTHESIS) T(s, 1), U++, h = y, E = _, u.push(i);
        else if (o === e.tokenTypes.CLOSING_PARENTHESIS) {
          if (!U) throw new Error("Closing parenthesis are more than opening one, wait What!!!");
          U--, h = I, E = c, u.push(i), T(s, 1);
        } else if (o === e.tokenTypes.DECIMAL) {
          if (p.hasDec) throw new Error("Two decimals are not allowed in one number");
          p.type !== e.tokenTypes.NUMBER && (p = { show: "0", value: 0, type: e.tokenTypes.NUMBER, precedence: 0 }, u.push(p), T(s, -1)), h = m, T(s, 1), E = _, p.value += C, p.hasDec = !0;
        } else o === e.tokenTypes.POSTFIX_FUNCTION_WITH_ONE_ARG && (h = I, E = c, T(s, 1), u.push(i));
        o === e.tokenTypes.FUNCTION_WITH_N_ARGS ? (h = y, E = _, T(s, R.numberOfArguments + 2), u.push(i), l[t + 1].type !== e.tokenTypes.OPENING_PARENTHESIS && (u.push(S), s.push(R.numberOfArguments + 2))) : o === e.tokenTypes.BINARY_OPERATOR_LOW_PRECENDENCE ? (p.type === e.tokenTypes.BINARY_OPERATOR_LOW_PRECENDENCE ? p.value === this.math.add ? (p.value = C, p.show = M, T(s, 1)) : p.value === this.math.sub && M === "-" && (p.value = this.math.add, p.show = "+", T(s, 1)) : p.type !== e.tokenTypes.CLOSING_PARENTHESIS && p.type !== e.tokenTypes.POSTFIX_FUNCTION_WITH_ONE_ARG && p.type !== e.tokenTypes.NUMBER && p.type !== e.tokenTypes.CONSTANT && p.type !== e.tokenTypes.EVALUATED_FUNCTION_PARAMETER ? G === "-" && (h = y, E = _, T(s, 1), s.push(2), u.push(k), u.push(S)) : (u.push(i), T(s, 2)), h = y, E = _) : o === e.tokenTypes.BINARY_OPERATOR_PERMUTATION ? (h = y, E = _, T(s, 2), u.push(i)) : o === e.tokenTypes.COMMA ? (h = y, E = _, u.push(i)) : o === e.tokenTypes.EVALUATED_FUNCTION ? (h = y, E = _, T(s, 6), u.push(i), l[t + 1].type !== e.tokenTypes.OPENING_PARENTHESIS && (u.push(S), s.push(6))) : o === e.tokenTypes.EVALUATED_FUNCTION_PARAMETER && (h = I, E = c, u.push(i)), T(s, -1), D = G;
      } else if (t > 0 && t < l.length - 1 && l[t + 1].type === 1 && (l[t - 1].type === 1 || l[t - 1].type === 6)) throw new Error("Unexpected Space");
    }
    for (g = s.length; g--; ) u.push(a);
    if (h[5] !== !0) throw new Error("complete the expression");
    for (; U--; ) u.push(a);
    return u.push(a), u;
  }, w;
}
export {
  j as __require
};
