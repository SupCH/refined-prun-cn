import { showTileOverlay as E, showConfirmationOverlay as $ } from "./tile-overlay.js";
import D from "./CreateCommandListOverlay.vue.js";
import p from "./PrunButton.vue.js";
import k from "./ActionBar.vue.js";
import { showBuffer as w } from "./buffers.js";
import { userData as m } from "./user-data.js";
import { vDraggable as N } from "./vue-draggable-plus.js";
import c from "./grip.module.css.js";
import b from "./font-awesome.module.css.js";
import v from "./PrunLink.vue.js";
import { createId as T } from "./create-id.js";
import { defineComponent as B, createElementBlock as a, openBlock as l, createVNode as i, createElementVNode as t, withCtx as s, createTextVNode as f, withDirectives as V, Fragment as g, renderList as I } from "./runtime-core.esm-bundler.js";
import { ref as O, unref as o } from "./reactivity.esm-bundler.js";
import { normalizeClass as C, toDisplayString as d } from "./shared.esm-bundler.js";
const K = /* @__PURE__ */ B({
  __name: "CommandLists",
  setup(x) {
    function L(r) {
      E(r, D, {
        onCreate: (e) => {
          const n = T();
          return m.commandLists.push({
            id: n,
            name: e,
            commands: []
          }), w(`XIT CMDL ${n.substring(0, 8)}`);
        }
      });
    }
    function h(r, e) {
      $(
        r,
        () => m.commandLists = m.commandLists.filter((n) => n !== e),
        {
          message: `Are you sure you want to delete the list "${e.name}"?`
        }
      );
    }
    const u = O(!1), y = {
      animation: 150,
      handle: `.${c.grip}`,
      onStart: () => u.value = !0,
      onEnd: () => u.value = !1
    };
    return (r, e) => (l(), a(g, null, [
      i(k, null, {
        default: s(() => [
          i(p, {
            primary: "",
            onClick: L
          }, {
            default: s(() => [...e[0] || (e[0] = [
              f("CREATE NEW", -1)
            ])]),
            _: 1
          })
        ]),
        _: 1
      }),
      t("table", null, [
        e[2] || (e[2] = t("thead", null, [
          t("tr", null, [
            t("th", null, "Name"),
            t("th", null, "Length"),
            t("th")
          ])
        ], -1)),
        V((l(), a("tbody", {
          class: C(o(u) ? r.$style.dragging : null)
        }, [
          (l(!0), a(g, null, I(o(m).commandLists, (n) => (l(), a("tr", {
            key: n.id
          }, [
            t("td", null, [
              t("span", {
                class: C([o(c).grip, o(b).solid, r.$style.grip])
              }, d(""), 2),
              i(v, {
                inline: "",
                command: `XIT CMDL ${n.id.substring(0, 8)}`
              }, {
                default: s(() => [
                  f(d(n.name), 1)
                ]),
                _: 2
              }, 1032, ["command"])
            ]),
            t("td", null, [
              t("span", null, d(n.commands.length) + " command" + d(n.commands.length !== 1 ? "s" : ""), 1)
            ]),
            t("td", null, [
              i(p, {
                danger: "",
                onClick: (_) => h(_, n)
              }, {
                default: s(() => [...e[1] || (e[1] = [
                  f("DELETE", -1)
                ])]),
                _: 2
              }, 1032, ["onClick"])
            ])
          ]))), 128))
        ], 2)), [
          [o(N), [o(m).commandLists, y]]
        ])
      ])
    ], 64));
  }
});
export {
  K as default
};
