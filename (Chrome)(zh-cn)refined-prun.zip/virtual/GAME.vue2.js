import { t as a } from "./index5.js";
import p from "./PrunButton.vue.js";
import V from "./SectionHeader.vue.js";
import I from "./Tooltip.vue.js";
import E from "./TextInput.vue.js";
import d from "./Active.vue.js";
import B from "./NumberInput.vue.js";
import S from "./Commands.vue.js";
import { showConfirmationOverlay as T } from "./tile-overlay.js";
import { userData as m, initialUserData as c } from "./user-data.js";
import { exportUserData as q, downloadBackup as J, importUserData as K, saveUserData as $, restoreBackup as Q, resetUserData as Y } from "./user-data-serializer.js";
import C from "./SelectInput.vue.js";
import { objectId as _ } from "./object-id.js";
import { getUserDataBackups as x, deleteUserDataBackup as ee } from "./user-data-backup.js";
import { hhForXitSet as le, ddmmyyyy as ae, hhmm as te } from "./format.js";
import oe from "./dayjs.min.js";
import { defineComponent as ne, computed as g, createElementBlock as w, openBlock as f, createVNode as t, createElementVNode as b, createCommentVNode as D, withCtx as n, createTextVNode as i, createBlock as U, Fragment as A, renderList as L } from "./runtime-core.esm-bundler.js";
import { toDisplayString as s, normalizeClass as k } from "./shared.esm-bundler.js";
import { unref as l } from "./reactivity.esm-bundler.js";
const Ae = /* @__PURE__ */ ne({
  __name: "GAME",
  setup(re) {
    const N = g(() => le.value(oe.duration(12, "hours").asMilliseconds()) === "13"), O = g(() => [
      {
        label: N.value ? a("game.formats.default24") : a("game.formats.default12"),
        value: "DEFAULT"
      },
      {
        label: a("game.formats.h24"),
        value: "24H"
      },
      {
        label: a("game.formats.h12"),
        value: "12H"
      }
    ]), R = g(() => [
      {
        label: a("game.formats.smooth"),
        value: "SMOOTH"
      },
      {
        label: a("game.formats.aligned"),
        value: "ALIGNED"
      },
      {
        label: a("game.formats.raw"),
        value: "RAW"
      }
    ]), u = g(() => m.settings.currency), H = g(() => [
      {
        label: a("game.formats.default"),
        value: "DEFAULT"
      },
      {
        label: "₳",
        value: "AIC"
      },
      {
        label: "₡",
        value: "CIS"
      },
      {
        label: "ǂ",
        value: "ICA"
      },
      {
        label: "₦",
        value: "NCC"
      },
      {
        label: a("game.formats.custom"),
        value: "CUSTOM"
      }
    ]), M = g(() => [
      {
        label: a("game.formats.after"),
        value: "AFTER"
      },
      {
        label: a("game.formats.before"),
        value: "BEFORE"
      }
    ]), P = g(() => [
      {
        label: a("game.formats.hasSpace"),
        value: "HAS_SPACE"
      },
      {
        label: a("game.formats.noSpace"),
        value: "NO_SPACE"
      }
    ]), F = g(() => x());
    function j() {
      m.settings.sidebar.push(["SET", "XIT SET"]);
    }
    function G(e) {
      m.settings.sidebar.splice(e, 1);
    }
    function X(e) {
      T(e, () => {
        m.settings.sidebar = structuredClone(c.settings.sidebar);
      });
    }
    function h() {
      K(async () => {
        await $(), window.location.reload();
      });
    }
    async function z(e, r) {
      T(
        e,
        async () => {
          Q(r), await $(), window.location.reload();
        },
        {
          message: "Are you sure you want to restore this backup? This will overwrite your current data."
        }
      );
    }
    function W(e, r) {
      T(e, () => ee(r));
    }
    function Z(e) {
      T(e, async () => {
        Y(), await $(), window.location.reload();
      });
    }
    return (e, r) => (f(), w(A, null, [
      t(V, null, {
        default: n(() => [
          i(s(("t" in e ? e.t : l(a))("game.appearance")), 1)
        ]),
        _: 1
      }),
      b("form", null, [
        t(d, {
          label: ("t" in e ? e.t : l(a))("game.timeFormat")
        }, {
          default: n(() => [
            t(C, {
              modelValue: l(m).settings.time,
              "onUpdate:modelValue": r[0] || (r[0] = (o) => l(m).settings.time = o),
              options: l(O)
            }, null, 8, ["modelValue", "options"])
          ]),
          _: 1
        }, 8, ["label"]),
        t(d, {
          label: ("t" in e ? e.t : l(a))("game.defaultChartType")
        }, {
          default: n(() => [
            t(C, {
              modelValue: l(m).settings.defaultChartType,
              "onUpdate:modelValue": r[1] || (r[1] = (o) => l(m).settings.defaultChartType = o),
              options: l(R)
            }, null, 8, ["modelValue", "options"])
          ]),
          _: 1
        }, 8, ["label"])
      ]),
      t(V, null, {
        default: n(() => [
          i(s(("t" in e ? e.t : l(a))("game.currencySymbol")) + " ", 1),
          t(I, {
            class: k(e.$style.tooltip),
            tooltip: ("t" in e ? e.t : l(a))("game.currencyTooltip")
          }, null, 8, ["class", "tooltip"])
        ]),
        _: 1
      }),
      b("form", null, [
        t(d, {
          label: ("t" in e ? e.t : l(a))("game.symbol")
        }, {
          default: n(() => [
            t(C, {
              modelValue: l(u).preset,
              "onUpdate:modelValue": r[2] || (r[2] = (o) => l(u).preset = o),
              options: l(H)
            }, null, 8, ["modelValue", "options"])
          ]),
          _: 1
        }, 8, ["label"]),
        l(u).preset === "CUSTOM" ? (f(), U(d, {
          key: 0,
          label: ("t" in e ? e.t : l(a))("game.customSymbol")
        }, {
          default: n(() => [
            t(E, {
              modelValue: l(u).custom,
              "onUpdate:modelValue": r[3] || (r[3] = (o) => l(u).custom = o)
            }, null, 8, ["modelValue"])
          ]),
          _: 1
        }, 8, ["label"])) : D("", !0),
        l(u).preset !== "DEFAULT" ? (f(), U(d, {
          key: 1,
          label: ("t" in e ? e.t : l(a))("game.position")
        }, {
          default: n(() => [
            t(C, {
              modelValue: l(u).position,
              "onUpdate:modelValue": r[4] || (r[4] = (o) => l(u).position = o),
              options: l(M)
            }, null, 8, ["modelValue", "options"])
          ]),
          _: 1
        }, 8, ["label"])) : D("", !0),
        l(u).preset !== "DEFAULT" ? (f(), U(d, {
          key: 2,
          label: ("t" in e ? e.t : l(a))("game.spacing"),
          tooltip: ("t" in e ? e.t : l(a))("game.spacingTooltip")
        }, {
          default: n(() => [
            t(C, {
              modelValue: l(u).spacing,
              "onUpdate:modelValue": r[5] || (r[5] = (o) => l(u).spacing = o),
              options: l(P)
            }, null, 8, ["modelValue", "options"])
          ]),
          _: 1
        }, 8, ["label", "tooltip"])) : D("", !0)
      ]),
      t(V, null, {
        default: n(() => [
          i(s(("t" in e ? e.t : l(a))("game.burnSettings")), 1)
        ]),
        _: 1
      }),
      b("form", null, [
        t(d, {
          label: ("t" in e ? e.t : l(a))("game.redLabel"),
          tooltip: ("t" in e ? e.t : l(a))("game.redTooltip")
        }, {
          default: n(() => [
            t(B, {
              modelValue: l(m).settings.burn.red,
              "onUpdate:modelValue": r[6] || (r[6] = (o) => l(m).settings.burn.red = o)
            }, null, 8, ["modelValue"])
          ]),
          _: 1
        }, 8, ["label", "tooltip"]),
        t(d, {
          label: ("t" in e ? e.t : l(a))("game.yellowLabel"),
          tooltip: ("t" in e ? e.t : l(a))("game.yellowTooltip")
        }, {
          default: n(() => [
            t(B, {
              modelValue: l(m).settings.burn.yellow,
              "onUpdate:modelValue": r[7] || (r[7] = (o) => l(m).settings.burn.yellow = o)
            }, null, 8, ["modelValue"])
          ]),
          _: 1
        }, 8, ["label", "tooltip"]),
        t(d, {
          label: ("t" in e ? e.t : l(a))("game.resupplyLabel"),
          tooltip: ("t" in e ? e.t : l(a))("game.resupplyTooltip")
        }, {
          default: n(() => [
            t(B, {
              modelValue: l(m).settings.burn.resupply,
              "onUpdate:modelValue": r[8] || (r[8] = (o) => l(m).settings.burn.resupply = o)
            }, null, 8, ["modelValue"])
          ]),
          _: 1
        }, 8, ["label", "tooltip"])
      ]),
      t(V, null, {
        default: n(() => [
          i(s(("t" in e ? e.t : l(a))("game.sidebarButtons")) + " ", 1),
          t(I, {
            class: k(e.$style.tooltip),
            tooltip: ("t" in e ? e.t : l(a))("game.sidebarTooltip")
          }, null, 8, ["class", "tooltip"])
        ]),
        _: 1
      }),
      b("form", null, [
        (f(!0), w(A, null, L(l(m).settings.sidebar, (o, y) => (f(), U(d, {
          key: l(_)(o),
          label: ("t" in e ? e.t : l(a))("game.buttonLabel", y + 1)
        }, {
          default: n(() => [
            b("div", {
              class: k(e.$style.sidebarInputPair)
            }, [
              t(E, {
                modelValue: o[0],
                "onUpdate:modelValue": (v) => o[0] = v,
                class: k(e.$style.sidebarInput)
              }, null, 8, ["modelValue", "onUpdate:modelValue", "class"]),
              t(E, {
                modelValue: o[1],
                "onUpdate:modelValue": (v) => o[1] = v,
                class: k(e.$style.sidebarInput)
              }, null, 8, ["modelValue", "onUpdate:modelValue", "class"]),
              t(p, {
                danger: "",
                onClick: (v) => G(y)
              }, {
                default: n(() => [...r[9] || (r[9] = [
                  i("x", -1)
                ])]),
                _: 2
              }, 1032, ["onClick"])
            ], 2)
          ]),
          _: 2
        }, 1032, ["label"]))), 128)),
        t(S, null, {
          default: n(() => [
            t(p, {
              primary: "",
              onClick: X
            }, {
              default: n(() => [
                i(s(("t" in e ? e.t : l(a))("game.resetSidebar")), 1)
              ]),
              _: 1
            }),
            t(p, {
              primary: "",
              onClick: j
            }, {
              default: n(() => [
                i(s(("t" in e ? e.t : l(a))("game.addNew")), 1)
              ]),
              _: 1
            })
          ]),
          _: 1
        })
      ]),
      t(V, null, {
        default: n(() => [
          i(s(("t" in e ? e.t : l(a))("game.importExport")), 1)
        ]),
        _: 1
      }),
      b("form", null, [
        t(S, null, {
          default: n(() => [
            t(p, {
              primary: "",
              onClick: h
            }, {
              default: n(() => [
                i(s(("t" in e ? e.t : l(a))("game.importData")), 1)
              ]),
              _: 1
            }),
            t(p, {
              primary: "",
              onClick: l(q)
            }, {
              default: n(() => [
                i(s(("t" in e ? e.t : l(a))("game.exportData")), 1)
              ]),
              _: 1
            }, 8, ["onClick"])
          ]),
          _: 1
        })
      ]),
      l(F).length > 0 ? (f(), w(A, { key: 0 }, [
        t(V, null, {
          default: n(() => [
            i(s(("t" in e ? e.t : l(a))("game.backups")), 1)
          ]),
          _: 1
        }),
        b("form", null, [
          (f(!0), w(A, null, L(l(F), (o) => (f(), U(S, {
            key: o.timestamp,
            label: l(ae)(o.timestamp) + " " + l(te)(o.timestamp)
          }, {
            default: n(() => [
              t(p, {
                primary: "",
                onClick: (y) => l(J)(o.data, o.timestamp)
              }, {
                default: n(() => [
                  i(s(("t" in e ? e.t : l(a))("game.export")), 1)
                ]),
                _: 2
              }, 1032, ["onClick"]),
              t(p, {
                primary: "",
                onClick: (y) => z(y, o.data)
              }, {
                default: n(() => [
                  i(s(("t" in e ? e.t : l(a))("game.restore")), 1)
                ]),
                _: 2
              }, 1032, ["onClick"]),
              t(p, {
                danger: "",
                onClick: (y) => W(y, o)
              }, {
                default: n(() => [
                  i(s(("t" in e ? e.t : l(a))("game.delete")), 1)
                ]),
                _: 2
              }, 1032, ["onClick"])
            ]),
            _: 2
          }, 1032, ["label"]))), 128))
        ])
      ], 64)) : D("", !0),
      t(V, null, {
        default: n(() => [
          i(s(("t" in e ? e.t : l(a))("game.dangerZone")), 1)
        ]),
        _: 1
      }),
      b("form", null, [
        t(S, null, {
          default: n(() => [
            t(p, {
              danger: "",
              onClick: Z
            }, {
              default: n(() => [
                i(s(("t" in e ? e.t : l(a))("game.resetAllData")), 1)
              ]),
              _: 1
            })
          ]),
          _: 1
        })
      ])
    ], 64));
  }
});
export {
  Ae as default
};
