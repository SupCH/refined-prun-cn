const _ = "rp-LogWindow__log___95b382d", o = "rp-LogWindow__success___10c20c1", s = "rp-LogWindow__failure___ebc9057", n = "rp-LogWindow__warning___3991891", c = {
  log: _,
  success: o,
  failure: s,
  warning: n
};
export {
  c as default,
  s as failure,
  _ as log,
  o as success,
  n as warning
};
