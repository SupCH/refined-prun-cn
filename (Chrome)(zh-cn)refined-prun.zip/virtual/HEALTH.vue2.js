import f from "./HEALTH.vue.js";
export {
  f as default
};
