import f from "./ContractLink.vue2.js";
export {
  f as default
};
