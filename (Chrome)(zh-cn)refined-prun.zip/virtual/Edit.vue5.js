import p from "./Active.vue.js";
import { sitesStore as D } from "./sites.js";
import { getEntityNameFromAddress as h } from "./addresses.js";
import E from "./SelectInput.vue.js";
import g from "./NumberInput.vue.js";
import { comparePlanets as x } from "./util.js";
import { configurableValue as I } from "./shared-types.js";
import { defineComponent as w, computed as T, createElementBlock as U, openBlock as k, createVNode as t, withCtx as f, Fragment as A } from "./runtime-core.esm-bundler.js";
import { ref as d, unref as o, isRef as v } from "./reactivity.esm-bundler.js";
const j = /* @__PURE__ */ w({
  __name: "Edit",
  props: {
    group: {}
  },
  setup(e, { expose: y }) {
    const c = T(() => {
      const a = (D.all.value ?? []).map((l) => h(l.address)).filter((l) => l !== void 0).sort(x);
      return a.unshift(I), a;
    }), r = d(e.group.planet ?? c.value[0]), s = d(!1), i = d(typeof e.group.days == "string" ? parseInt(e.group.days || "0") : e.group.days), n = d(
      typeof e.group.advanceDays == "string" ? parseInt(e.group.advanceDays || "0") : e.group.advanceDays ?? 0
    ), m = d(!1);
    function V() {
      let a = !0;
      return s.value = !r.value, a &&= !s.value, m.value = n.value < 0, a &&= !m.value, a;
    }
    function b() {
      e.group.planet = r.value, e.group.days = i.value, e.group.advanceDays = n.value;
    }
    return y({ validate: V, save: b }), (a, l) => (k(), U(A, null, [
      t(p, {
        label: "Planet",
        error: o(s)
      }, {
        default: f(() => [
          t(E, {
            modelValue: o(r),
            "onUpdate:modelValue": l[0] || (l[0] = (u) => v(r) ? r.value = u : null),
            options: o(c)
          }, null, 8, ["modelValue", "options"])
        ]),
        _: 1
      }, 8, ["error"]),
      t(p, {
        label: "Day Threshold",
        tooltip: `All buildings older than this threshold will be repaired.
     If no number is provided all buildings are repaired.`
      }, {
        default: f(() => [
          t(g, {
            modelValue: o(i),
            "onUpdate:modelValue": l[1] || (l[1] = (u) => v(i) ? i.value = u : null),
            optional: ""
          }, null, 8, ["modelValue"])
        ]),
        _: 1
      }),
      t(p, {
        label: "Time Offset",
        tooltip: "The number of days in the future this repair will be conducted.",
        error: o(m)
      }, {
        default: f(() => [
          t(g, {
            modelValue: o(n),
            "onUpdate:modelValue": l[2] || (l[2] = (u) => v(n) ? n.value = u : null)
          }, null, 8, ["modelValue"])
        ]),
        _: 1
      }, 8, ["error"])
    ], 64));
  }
});
export {
  j as default
};
