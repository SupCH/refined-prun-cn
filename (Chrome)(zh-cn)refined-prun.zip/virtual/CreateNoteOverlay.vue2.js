import f from "./CreateNoteOverlay.vue.js";
export {
  f as default
};
