const text = "rp-lm-hide-rating__text___ddd6143";
const $style = {
  text
};
export {
  $style as default,
  text
};
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibG0taGlkZS1yYXRpbmcubW9kdWxlLmNzcy5qcyIsInNvdXJjZXMiOltdLCJzb3VyY2VzQ29udGVudCI6W10sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7In0=
