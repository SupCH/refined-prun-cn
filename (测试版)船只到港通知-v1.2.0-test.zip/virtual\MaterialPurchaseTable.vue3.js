const expand = "rp-MaterialPurchaseTable__expand___17bacee";
const total = "rp-MaterialPurchaseTable__total___07955f3";
const materialCell = "rp-MaterialPurchaseTable__materialCell___d6750c9";
const fakeRow = "rp-MaterialPurchaseTable__fakeRow___fe9ce32";
const style0 = {
  expand,
  total,
  materialCell,
  fakeRow
};
export {
  style0 as default,
  expand,
  fakeRow,
  materialCell,
  total
};
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiTWF0ZXJpYWxQdXJjaGFzZVRhYmxlLnZ1ZTMuanMiLCJzb3VyY2VzIjpbXSwic291cmNlc0NvbnRlbnQiOltdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7OyJ9
