const shadow = "rp-item-ticker-shadow__shadow___d0df755";
const $style = {
  shadow
};
export {
  $style as default,
  shadow
};
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaXRlbS10aWNrZXItc2hhZG93Lm1vZHVsZS5jc3MuanMiLCJzb3VyY2VzIjpbXSwic291cmNlc0NvbnRlbnQiOltdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7OyJ9
