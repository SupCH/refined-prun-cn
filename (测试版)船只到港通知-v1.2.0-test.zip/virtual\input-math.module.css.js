const inputContainer = "rp-input-math__inputContainer___c8a05e0";
const functionIcon = "rp-input-math__functionIcon___efb146b";
const functionIconDynamic = "rp-input-math__functionIconDynamic___e7c50c0";
const $style = {
  inputContainer,
  functionIcon,
  functionIconDynamic
};
export {
  $style as default,
  functionIcon,
  functionIconDynamic,
  inputContainer
};
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5wdXQtbWF0aC5tb2R1bGUuY3NzLmpzIiwic291cmNlcyI6W10sInNvdXJjZXNDb250ZW50IjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7In0=
