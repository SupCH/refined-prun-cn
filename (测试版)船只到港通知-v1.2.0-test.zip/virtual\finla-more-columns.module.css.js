const row = "rp-finla-more-columns__row___845c4e0";
const $style = {
  row
};
export {
  $style as default,
  row
};
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZmlubGEtbW9yZS1jb2x1bW5zLm1vZHVsZS5jc3MuanMiLCJzb3VyY2VzIjpbXSwic291cmNlc0NvbnRlbnQiOltdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7OyJ9
