const list = "rp-BuildingCountSection__list___fb252cf";
const style0 = {
  list
};
export {
  style0 as default,
  list
};
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiQnVpbGRpbmdDb3VudFNlY3Rpb24udnVlMy5qcyIsInNvdXJjZXMiOltdLCJzb3VyY2VzQ29udGVudCI6W10sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7In0=
