const custom = "rp-inv-custom-item-sorting__custom___b4657eb";
const $style = {
  custom
};
export {
  custom,
  $style as default
};
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW52LWN1c3RvbS1pdGVtLXNvcnRpbmcubW9kdWxlLmNzcy5qcyIsInNvdXJjZXMiOltdLCJzb3VyY2VzQ29udGVudCI6W10sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7In0=
