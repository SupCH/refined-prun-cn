import _sfc_main from "./FEAT.vue2.js";
import style0 from "./FEAT.vue3.js";
import _export_sfc from "./plugin-vue_export-helper.js";
const cssModules = {
  "$style": style0
};
const FEAT = /* @__PURE__ */ _export_sfc(_sfc_main, [["__cssModules", cssModules]]);
export {
  FEAT as default
};
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiRkVBVC52dWUuanMiLCJzb3VyY2VzIjpbXSwic291cmNlc0NvbnRlbnQiOltdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7OyJ9
