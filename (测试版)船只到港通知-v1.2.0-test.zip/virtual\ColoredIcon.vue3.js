const large = "rp-ColoredIcon__large___faa6371";
const medium = "rp-ColoredIcon__medium___4b4e2e9";
const small = "rp-ColoredIcon__small___3005653";
const inline = "rp-ColoredIcon__inline___9807fdd";
const inlineTable = "rp-ColoredIcon__inlineTable___ef5b1f1";
const mediumSubLabel = "rp-ColoredIcon__mediumSubLabel___6536266";
const style0 = {
  large,
  medium,
  small,
  inline,
  inlineTable,
  mediumSubLabel
};
export {
  style0 as default,
  inline,
  inlineTable,
  large,
  medium,
  mediumSubLabel,
  small
};
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiQ29sb3JlZEljb24udnVlMy5qcyIsInNvdXJjZXMiOltdLCJzb3VyY2VzQ29udGVudCI6W10sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7OyJ9
