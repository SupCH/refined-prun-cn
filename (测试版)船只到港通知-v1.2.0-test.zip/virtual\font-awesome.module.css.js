const solid = "rp-font-awesome__solid___33343de";
const regular = "rp-font-awesome__regular___638eb05";
const fa = {
  solid,
  regular
};
export {
  fa as default,
  regular,
  solid
};
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZm9udC1hd2Vzb21lLm1vZHVsZS5jc3MuanMiLCJzb3VyY2VzIjpbXSwic291cmNlc0NvbnRlbnQiOltdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7In0=
