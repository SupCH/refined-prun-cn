const tooltip = "rp-GAME__tooltip___74e4fdf";
const sidebarInputPair = "rp-GAME__sidebarInputPair___76840bf";
const sidebarInput = "rp-GAME__sidebarInput___41eca58";
const style0 = {
  tooltip,
  sidebarInputPair,
  sidebarInput
};
export {
  style0 as default,
  sidebarInput,
  sidebarInputPair,
  tooltip
};
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiR0FNRS52dWUzLmpzIiwic291cmNlcyI6W10sInNvdXJjZXNDb250ZW50IjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7In0=
