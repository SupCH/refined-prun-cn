const divider = "rp-bbl-collapsible-categories__divider___b0465ea";
const $style = {
  divider
};
export {
  $style as default,
  divider
};
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYmJsLWNvbGxhcHNpYmxlLWNhdGVnb3JpZXMubW9kdWxlLmNzcy5qcyIsInNvdXJjZXMiOltdLCJzb3VyY2VzQ29udGVudCI6W10sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7In0=
