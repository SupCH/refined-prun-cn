const container = "rp-item-icons__container___8e5388f";
const label = "rp-item-icons__label___0de7df1";
const $style = {
  container,
  label
};
export {
  container,
  $style as default,
  label
};
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaXRlbS1pY29ucy5tb2R1bGUuY3NzLmpzIiwic291cmNlcyI6W10sInNvdXJjZXNDb250ZW50IjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7OyJ9
