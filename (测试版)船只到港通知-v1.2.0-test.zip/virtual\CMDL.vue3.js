const create = "rp-CMDL__create___7052d84";
const button = "rp-CMDL__button___64cc033";
const style0 = {
  create,
  button
};
export {
  button,
  create,
  style0 as default
};
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiQ01ETC52dWUzLmpzIiwic291cmNlcyI6W10sInNvdXJjZXNDb250ZW50IjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7OyJ9
