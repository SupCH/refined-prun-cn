import _sfc_main from "./Checkmark.vue2.js";
import style0 from "./Checkmark.vue3.js";
import _export_sfc from "./plugin-vue_export-helper.js";
const cssModules = {
  "$style": style0
};
const Checkmark = /* @__PURE__ */ _export_sfc(_sfc_main, [["__cssModules", cssModules]]);
export {
  Checkmark as default
};
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiQ2hlY2ttYXJrLnZ1ZS5qcyIsInNvdXJjZXMiOltdLCJzb3VyY2VzQ29udGVudCI6W10sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7In0=
