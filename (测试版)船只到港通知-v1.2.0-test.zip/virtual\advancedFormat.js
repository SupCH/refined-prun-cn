import { getDefaultExportFromCjs } from "./commonjsHelpers.js";
import { __require as requireAdvancedFormat } from "./advancedFormat2.js";
var advancedFormatExports = requireAdvancedFormat();
const AdvancedFormat = /* @__PURE__ */ getDefaultExportFromCjs(advancedFormatExports);
export {
  AdvancedFormat as default
};
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYWR2YW5jZWRGb3JtYXQuanMiLCJzb3VyY2VzIjpbXSwic291cmNlc0NvbnRlbnQiOltdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7OyJ9
