import { useCssModule as f } from "./runtime-dom.esm-bundler.js";
import u from "./font-awesome.module.css.js";
import { friendlyConditionText as L } from "./utils5.js";
import { defineComponent as p, computed as c, createElementBlock as E, openBlock as F, createElementVNode as s, createTextVNode as I } from "./runtime-core.esm-bundler.js";
import { normalizeClass as a, toDisplayString as r } from "./shared.esm-bundler.js";
import { unref as t } from "./reactivity.esm-bundler.js";
const P = /* @__PURE__ */ p({
  __name: "ConditionItem",
  props: {
    condition: {},
    contract: {}
  },
  setup(n) {
    const e = f(), d = c(() => {
      switch (n.condition.status) {
        case "PENDING": {
          for (const o of n.condition.dependencies) {
            const i = n.contract.conditions.find((m) => m.id === o);
            if (!i || i.status !== "FULFILLED")
              return e.unavailable;
          }
          return e.pending;
        }
        case "IN_PROGRESS":
        case "PARTLY_FULFILLED":
          return e.pending;
        case "FULFILLMENT_ATTEMPTED":
        case "VIOLATED":
          return e.failed;
        case "FULFILLED":
          return e.fulfilled;
      }
    }), l = c(() => n.condition.status === "FULFILLED" ? "" : "");
    return (o, i) => (F(), E("div", null, [
      s("span", {
        class: a(t(d))
      }, [
        s("span", {
          class: a([t(u).solid])
        }, r(t(l)), 3),
        I(" " + r(t(L)(o.condition.type)), 1)
      ], 2)
    ]));
  }
});
export {
  P as default
};
