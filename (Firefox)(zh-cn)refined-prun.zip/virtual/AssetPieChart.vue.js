import t from "./PieChart.vue.js";
import { liveBalanceSummary as r } from "./balance-sheet-live.js";
import { defineComponent as n, createBlock as a, openBlock as o } from "./runtime-core.esm-bundler.js";
import { unref as e } from "./reactivity.esm-bundler.js";
const _ = /* @__PURE__ */ n({
  __name: "AssetPieChart",
  setup(m) {
    return (s, c) => (o(), a(t, {
      "label-data": ["Current", "Non-Current"],
      "numerical-data": [
        e(r).currentAssets ?? 0,
        e(r).nonCurrentAssets ?? 0
      ]
    }, null, 8, ["numerical-data"]));
  }
});
export {
  _ as default
};
