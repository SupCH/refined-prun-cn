import { formatChange as h, formatAmount as C } from "./utils7.js";
import y from "./RowExpandButton.vue.js";
import R from "./Tooltip.vue.js";
import { defineComponent as N, resolveComponent as $, createElementBlock as s, openBlock as t, Fragment as i, createElementVNode as l, createCommentVNode as d, createVNode as g, createTextVNode as k, createBlock as f, renderList as B } from "./runtime-core.esm-bundler.js";
import { ref as S, unref as c, isRef as E } from "./reactivity.esm-bundler.js";
import { normalizeClass as w, toDisplayString as a } from "./shared.esm-bundler.js";
const T = /* @__PURE__ */ N({
  __name: "BalanceSheetRow",
  props: {
    current: {},
    indent: {},
    last: {},
    previous: {},
    row: {}
  },
  setup(v) {
    const u = S(!1);
    function m(e, o) {
      const r = p(e, o.value);
      if (r === void 0)
        return "--";
      const n = C(r);
      return o.less ? `(${n})` : n;
    }
    function p(e, o) {
      return e !== void 0 ? o(e) : void 0;
    }
    function V(e) {
      const o = p(v.last, e), r = p(v.previous, e);
      if (!(o === void 0 || r === void 0 || r === 0))
        return (o - r) / r;
    }
    return (e, o) => {
      const r = $("BalanceSheetRow", !0);
      return t(), s(i, null, [
        l("tr", null, [
          l("td", null, [
            e.indent > 0 ? (t(!0), s(i, { key: 0 }, B(e.indent, (n) => (t(), f(y, {
              key: n,
              class: w(e.$style.hidden)
            }, null, 8, ["class"]))), 128)) : d("", !0),
            g(y, {
              modelValue: c(u),
              "onUpdate:modelValue": o[0] || (o[0] = (n) => E(u) ? u.value = n : null),
              class: w(e.row.children ? null : e.$style.hidden)
            }, null, 8, ["modelValue", "class"]),
            e.row.less ? (t(), s(i, { key: 1 }, [
              k(" Less:")
            ], 64)) : d("", !0),
            k(" " + a(e.row.name) + " ", 1),
            e.row.tooltip ? (t(), f(R, {
              key: 2,
              tooltip: e.row.tooltip,
              class: w(e.$style.tooltip)
            }, null, 8, ["tooltip", "class"])) : d("", !0)
          ]),
          l("td", null, a(m(e.current, e.row)), 1),
          l("td", null, a(m(e.last, e.row)), 1),
          l("td", null, a(m(e.previous, e.row)), 1),
          l("td", null, a(c(h)(V(e.row.value))), 1)
        ]),
        e.row.children && c(u) ? (t(!0), s(i, { key: 0 }, B(e.row.children, (n) => (t(), f(r, {
          key: n.name,
          current: e.current,
          last: e.last,
          previous: e.previous,
          row: n,
          indent: e.indent + 1
        }, null, 8, ["current", "last", "previous", "row", "indent"]))), 128)) : d("", !0)
      ], 64);
    };
  }
});
export {
  T as default
};
