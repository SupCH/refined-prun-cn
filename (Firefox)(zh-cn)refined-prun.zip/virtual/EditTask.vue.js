import { C as z } from "./prun-css.js";
import H from "./SectionHeader.vue.js";
import s from "./Active.vue.js";
import O from "./TextInput.vue.js";
import x from "./SelectInput.vue.js";
import A from "./NumberInput.vue.js";
import Y from "./Commands.vue.js";
import S from "./PrunButton.vue.js";
import q from "./DateInput.vue.js";
import { sitesStore as p, getBuildingLastRepair as G } from "./sites.js";
import { getEntityNaturalIdFromAddress as J, getEntityNameFromAddress as R } from "./addresses.js";
import { getPlanetBurn as B } from "./burn2.js";
import { createId as N } from "./create-id.js";
import { fixed0 as I } from "./format.js";
import { isRepairableBuilding as K } from "./buildings.js";
import { sortMaterialAmounts as Q, mergeMaterialAmounts as W } from "./sort-materials.js";
import { defineComponent as X, computed as Z, watchEffect as h, createElementBlock as T, openBlock as y, createVNode as n, createElementVNode as _, withCtx as o, createTextVNode as C, createBlock as U, createCommentVNode as D, Fragment as w } from "./runtime-core.esm-bundler.js";
import { ref as f, isRef as m, unref as u } from "./reactivity.esm-bundler.js";
import { normalizeClass as ee } from "./shared.esm-bundler.js";
const pe = /* @__PURE__ */ X({
  __name: "EditTask",
  props: {
    onDelete: { type: Function },
    onSave: { type: Function },
    task: {}
  },
  emits: ["close"],
  setup(e, { emit: F }) {
    const E = F, P = ["Text", "Resupply", "Repair"], i = f(e.task.type), g = f(e.task.text), k = f(M(e.task.dueDate)), v = f(e.task.recurring), b = f(e.task.days), V = f(e.task.buildingAge);
    function M(l) {
      if (l === void 0)
        return;
      const t = new Date(l), a = t.getFullYear(), r = String(t.getMonth() + 1).padStart(2, "0"), $ = String(t.getDate()).padStart(2, "0");
      return `${a}-${r}-${$}`;
    }
    const c = Z(() => (p.all.value ?? []).map((l) => ({
      label: R(l.address),
      value: J(l.address)
    }))), d = f(
      c.value.find((l) => l.value === e.task.planet)?.value ?? c.value[0]?.value
    );
    h(() => {
      const l = p.getByPlanetNaturalId(d.value);
      B(l);
    });
    function L() {
      if (e.task.type = i.value, k.value) {
        const [l, t, a] = k.value.split("-").map(($) => parseInt($, 10)), r = new Date(l, t - 1, a);
        e.task.dueDate = r.getTime();
      } else
        delete e.task.dueDate;
      if (e.task.recurring = v.value, delete e.task.text, delete e.task.planet, delete e.task.days, delete e.task.buildingAge, delete e.task.subtasks, i.value === "Text" && (e.task.text = g.value), i.value === "Resupply") {
        e.task.planet = d.value, e.task.days = b.value ?? 7;
        const l = p.getByPlanetNaturalId(e.task.planet);
        e.task.text = `Supply [[p:${R(l.address)}]] with ${e.task.days} ${e.task.days === 1 ? "day" : "days"} of consumables.`;
        const t = B(l)?.burn;
        if (t) {
          e.task.subtasks = [];
          for (const a of Object.keys(t)) {
            const r = t[a].dailyAmount;
            r < 0 && e.task.subtasks.push({
              id: N(),
              type: "Text",
              text: `${I(-r * e.task.days)} [[m:${a}]]`
            });
          }
        }
      }
      if (i.value === "Repair") {
        e.task.planet = d.value, e.task.buildingAge = V.value ?? 50;
        const l = p.getByPlanetNaturalId(e.task.planet);
        e.task.text = `Repair buildings on [[p:${R(l.address)}]] older than ${e.task.buildingAge} ${e.task.days === 1 ? "day" : "days"}`;
        let t = [];
        e.task.subtasks = [];
        for (const a of l.platforms)
          K(a) && Date.now() - G(a) > e.task.buildingAge * 864e5 && t.push(...a.repairMaterials);
        t = Q(W(t));
        for (let a of t)
          e.task.subtasks.push({
            id: N(),
            type: "Text",
            text: `${I(a.amount)} [[m:${a.material.ticker}]]`
          });
      }
      e.onSave?.(), E("close");
    }
    function j() {
      e.onDelete?.(), E("close");
    }
    return (l, t) => (y(), T("div", {
      class: ee(("C" in l ? l.C : u(z)).DraftConditionEditor.form)
    }, [
      n(H, null, {
        default: o(() => [...t[8] || (t[8] = [
          C("Edit task", -1)
        ])]),
        _: 1
      }),
      _("form", null, [
        n(s, { label: "Type" }, {
          default: o(() => [
            n(x, {
              modelValue: u(i),
              "onUpdate:modelValue": t[0] || (t[0] = (a) => m(i) ? i.value = a : null),
              options: P
            }, null, 8, ["modelValue"])
          ]),
          _: 1
        }),
        n(s, { label: "Due Date" }, {
          default: o(() => [
            n(q, {
              modelValue: u(k),
              "onUpdate:modelValue": t[1] || (t[1] = (a) => m(k) ? k.value = a : null)
            }, null, 8, ["modelValue"])
          ]),
          _: 1
        }),
        n(s, {
          label: "Recurring period",
          tooltip: "An amount of days the due date will advance on task completion."
        }, {
          default: o(() => [
            n(A, {
              modelValue: u(v),
              "onUpdate:modelValue": t[2] || (t[2] = (a) => m(v) ? v.value = a : null)
            }, null, 8, ["modelValue"])
          ]),
          _: 1
        }),
        u(i) === "Text" ? (y(), U(s, {
          key: 0,
          label: "Text"
        }, {
          default: o(() => [
            n(O, {
              modelValue: u(g),
              "onUpdate:modelValue": t[3] || (t[3] = (a) => m(g) ? g.value = a : null)
            }, null, 8, ["modelValue"])
          ]),
          _: 1
        })) : D("", !0),
        u(i) === "Resupply" ? (y(), T(w, { key: 1 }, [
          n(s, { label: "Planet" }, {
            default: o(() => [
              n(x, {
                modelValue: u(d),
                "onUpdate:modelValue": t[4] || (t[4] = (a) => m(d) ? d.value = a : null),
                options: u(c)
              }, null, 8, ["modelValue", "options"])
            ]),
            _: 1
          }),
          n(s, {
            label: "Days",
            tooltip: "The number of days of supplies."
          }, {
            default: o(() => [
              n(A, {
                modelValue: u(b),
                "onUpdate:modelValue": t[5] || (t[5] = (a) => m(b) ? b.value = a : null)
              }, null, 8, ["modelValue"])
            ]),
            _: 1
          })
        ], 64)) : D("", !0),
        u(i) === "Repair" ? (y(), T(w, { key: 2 }, [
          n(s, { label: "Planet" }, {
            default: o(() => [
              n(x, {
                modelValue: u(d),
                "onUpdate:modelValue": t[6] || (t[6] = (a) => m(d) ? d.value = a : null),
                options: u(c)
              }, null, 8, ["modelValue", "options"])
            ]),
            _: 1
          }),
          n(s, {
            label: "Building age",
            tooltip: "The minimum building age to be included in the list."
          }, {
            default: o(() => [
              n(A, {
                modelValue: u(V),
                "onUpdate:modelValue": t[7] || (t[7] = (a) => m(V) ? V.value = a : null)
              }, null, 8, ["modelValue"])
            ]),
            _: 1
          })
        ], 64)) : D("", !0),
        n(Y, null, {
          default: o(() => [
            n(S, {
              primary: "",
              onClick: L
            }, {
              default: o(() => [...t[9] || (t[9] = [
                C("SAVE", -1)
              ])]),
              _: 1
            }),
            l.onDelete ? (y(), U(S, {
              key: 0,
              danger: "",
              onClick: j
            }, {
              default: o(() => [...t[10] || (t[10] = [
                C("DELETE", -1)
              ])]),
              _: 1
            })) : D("", !0)
          ]),
          _: 1
        })
      ])
    ], 2));
  }
});
export {
  pe as default
};
