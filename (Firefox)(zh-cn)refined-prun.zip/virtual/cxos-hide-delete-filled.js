import { applyCssRule as e } from "./refined-prun-css.js";
import { C as t } from "./prun-css.js";
import i from "./feature-registry.js";
import r from "./css-utils.module.css.js";
function o() {
  e("CXOS", `.${t.Button.btn} + .${t.ActionBar.container}`, r.hidden);
}
i.add(
  import.meta.url,
  o,
  'CXOS: Hides the "Delete Filled" button when filters are hidden.'
);
