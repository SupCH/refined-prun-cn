import { subscribe as c } from "./subscribe-async-generator.js";
import { _$$ as i, $$ as s } from "./select-dom.js";
import { C as m } from "./prun-css.js";
import { createFragmentApp as d } from "./vue-fragment-app.js";
import l from "./tiles.js";
import u from "./feature-registry.js";
import b from "./OrderBook.vue.js";
import { changeInputValue as a } from "./util.js";
import { increaseDefaultBufferSize as C } from "./buffer-sizes.js";
import { fixed02 as x, fixed0 as O } from "./format.js";
function h(t) {
  t.parameter && c(s(t.anchor, m.ComExPlaceOrderForm.form), (o) => {
    const n = o.parentElement;
    n.style.display = "flex", o.style.flex = "1";
    for (const r of i(o, m.FormComponent.label))
      r.style.minWidth = "120px";
    for (const r of i(o, m.Tooltip.container))
      r.setAttribute("data-tooltip-position", "right");
    const p = i(o, "input");
    function f(r, e) {
      a(p[1], x(r)), e !== void 0 && e > 0 && a(p[0], O(e));
    }
    d(b, { ticker: t.parameter, onOrderClick: f }).appendTo(n);
  });
}
function P() {
  C("CXPO", { width: 60 }), l.observe("CXPO", h);
}
u.add(import.meta.url, P, "CXPO: Adds a compact order book.");
