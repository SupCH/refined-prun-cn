import { C as n } from "./prun-css.js";
import C from "./PrunButton.vue.js";
import { defineComponent as f, createElementBlock as p, openBlock as d, createElementVNode as a, createVNode as s, withCtx as l, createTextVNode as m } from "./runtime-core.esm-bundler.js";
import { normalizeClass as i, toDisplayString as t } from "./shared.esm-bundler.js";
import { unref as o } from "./reactivity.esm-bundler.js";
const b = /* @__PURE__ */ f({
  __name: "ActionConfirmationOverlay",
  props: {
    confirmLabel: { default: "Confirm" },
    message: {},
    onClose: { type: Function },
    onConfirm: { type: Function }
  },
  setup(u) {
    return (e, r) => (d(), p("div", {
      class: i([("C" in e ? e.C : o(n)).ActionConfirmationOverlay.container, ("C" in e ? e.C : o(n)).ActionFeedback.overlay])
    }, [
      a("div", {
        class: i([
          ("C" in e ? e.C : o(n)).ActionConfirmationOverlay.message,
          ("C" in e ? e.C : o(n)).ActionFeedback.message,
          ("C" in e ? e.C : o(n)).fonts.fontRegular,
          ("C" in e ? e.C : o(n)).type.typeLarger
        ])
      }, [
        a("span", {
          class: i([
            ("C" in e ? e.C : o(n)).ActionConfirmationOverlay.message,
            ("C" in e ? e.C : o(n)).ActionFeedback.message,
            ("C" in e ? e.C : o(n)).fonts.fontRegular,
            ("C" in e ? e.C : o(n)).type.typeLarger
          ])
        }, "Confirmation required", 2),
        a("span", {
          class: i([
            ("C" in e ? e.C : o(n)).ActionConfirmationOverlay.text,
            ("C" in e ? e.C : o(n)).ActionFeedback.text,
            ("C" in e ? e.C : o(n)).fonts.fontRegular,
            ("C" in e ? e.C : o(n)).type.typeRegular
          ])
        }, t(e.message), 3),
        a("div", {
          class: i([("C" in e ? e.C : o(n)).ActionConfirmationOverlay.buttons])
        }, [
          s(C, {
            neutral: "",
            onClick: e.onClose
          }, {
            default: l(() => [...r[0] || (r[0] = [
              m("Cancel", -1)
            ])]),
            _: 1
          }, 8, ["onClick"]),
          s(C, {
            danger: "",
            onClick: e.onConfirm
          }, {
            default: l(() => [
              m(t(e.confirmLabel), 1)
            ]),
            _: 1
          }, 8, ["onClick"])
        ], 2)
      ], 2)
    ], 2));
  }
});
export {
  b as default
};
