var e = { exports: {} };
export {
  e as __module
};
