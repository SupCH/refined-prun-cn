import i from "./config.js";
import a from "./SelectInput.vue.js";
import f from "./Active.vue.js";
import { sitesStore as p } from "./sites.js";
import { getEntityNameFromAddress as s } from "./addresses.js";
import { comparePlanets as u } from "./util.js";
import { defineComponent as d, computed as c, createElementBlock as g, openBlock as V, createVNode as l, withCtx as v } from "./runtime-core.esm-bundler.js";
import { unref as e } from "./reactivity.esm-bundler.js";
const w = /* @__PURE__ */ d({
  __name: "Configure",
  props: {
    data: {},
    config: {}
  },
  setup(t) {
    const n = c(
      () => (p.all.value ?? []).map((o) => s(o.address)).filter((o) => o !== void 0).sort(u)
    );
    return t.config.planet || (t.config.planet = n.value[0]), (o, r) => (V(), g("form", null, [
      l(f, { label: "Planet" }, {
        default: v(() => [
          l(a, {
            modelValue: ("config" in o ? o.config : e(i)).planet,
            "onUpdate:modelValue": r[0] || (r[0] = (m) => ("config" in o ? o.config : e(i)).planet = m),
            options: e(n)
          }, null, 8, ["modelValue", "options"])
        ]),
        _: 1
      })
    ]));
  }
});
export {
  w as default
};
