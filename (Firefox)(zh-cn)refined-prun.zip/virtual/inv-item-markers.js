import { subscribe as f } from "./subscribe-async-generator.js";
import { $$ as p, $ as v } from "./select-dom.js";
import { C as u } from "./prun-css.js";
import { createFragmentApp as d } from "./vue-fragment-app.js";
import h from "./tiles.js";
import k from "./feature-registry.js";
import C from "./IconMarker.vue.js";
import { computedTileState as I } from "./user-data-tiles.js";
import { refTextContent as g } from "./reactive-dom.js";
import { getTileState as S } from "./tile-state4.js";
import { computed as m } from "./runtime-core.esm-bundler.js";
import { reactive as T } from "./reactivity.esm-bundler.js";
function b(r) {
  f(p(r.anchor, u.StoreView.container), (i) => {
    f(p(i, u.GridItemView.image), (a) => {
      a.children[1] === void 0 && w(a, r);
    });
  });
}
const c = [
  { character: "", color: "#CC220E" },
  { character: "", color: "#F7A601" },
  { character: "", color: "#088DBF" },
  { character: "", color: "#C9C9C9" },
  { character: "", color: "#3A8018" }
];
async function w(r, i) {
  const a = await v(r, u.ColoredIcon.label), t = g(a), l = I(S(i), "markers", {}), e = m({
    get: () => (t.value !== null ? l.value[t.value] : 0) ?? 0,
    set: (o) => {
      if (t.value === null)
        return;
      const n = { ...l.value };
      o === 0 ? delete n[t.value] : n[t.value] = o, l.value = n;
    }
  }), s = (o) => o < 0 ? c.length : o > c.length ? 0 : o;
  r.style.position = "relative", d(
    C,
    T({
      marker: m(() => c[e.value - 1]?.character),
      color: m(() => c[e.value - 1]?.color),
      onNext: () => e.value = s(e.value + 1),
      onPrevious: () => e.value = s(e.value - 1)
    })
  ).appendTo(r);
}
function A() {
  h.observe(["INV", "SHPI"], b);
}
k.add(import.meta.url, A, "INV/SHPI: Adds bottom-left item markers.");
