import e from "./xit-registry.js";
import "./cx-buy.js";
import "./mtra.js";
import "./refuel.js";
import "./cx-fetch.js";
import "./repair.js";
import "./resupply.js";
import "./manual.js";
import r from "./ACT.vue.js";
import { t as o } from "./index5.js";
e.add({
  command: ["ACT", "ACTION"],
  name: (t) => t.length === 0 ? o("act.title") : t[0].toUpperCase() == "GEN" || t[0].toUpperCase() == "EDIT" ? o("act.editPackage") : o("act.executePackage"),
  description: "Allows to automate certain tasks.",
  optionalParameters: "GEN and/or Action Name",
  contextItems: (t) => t.length > 0 ? [{ cmd: "XIT ACT" }] : [],
  component: () => r
});
