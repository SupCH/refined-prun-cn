const t = "rp-inv-search__inputText___5702997", e = {
  inputText: t
};
export {
  e as default,
  t as inputText
};
