import { isSelfCondition as l } from "./utils5.js";
import I from "./ShipmentIcon.vue.js";
import f from "./MaterialIcon.vue.js";
import { objectId as h } from "./object-id.js";
import { defineComponent as y, computed as k, createElementBlock as n, openBlock as o, Fragment as m, renderList as _, createCommentVNode as c, createVNode as s } from "./runtime-core.esm-bundler.js";
import { unref as a } from "./reactivity.esm-bundler.js";
const E = {
  key: 0,
  style: { marginBottom: "4px" }
}, M = {
  key: 1,
  style: { marginBottom: "4px" }
}, A = /* @__PURE__ */ y({
  __name: "MaterialList",
  props: {
    contract: {}
  },
  setup(r) {
    const u = k(() => {
      const i = [];
      for (const e of r.contract.conditions) {
        switch (e.type) {
          case "DELIVERY_SHIPMENT": {
            if (l(r.contract, e)) {
              i.push({ type: "SHIPMENT", shipmentId: e.shipmentItemId });
              continue;
            }
            break;
          }
          case "PROVISION":
          case "PICKUP_SHIPMENT":
            continue;
        }
        const t = e.quantity;
        if (!t?.material)
          continue;
        const p = t.amount, d = t.material.ticker;
        i.push({ type: "MATERIAL", ticker: d, amount: p });
      }
      return i;
    });
    return (i, e) => (o(), n("div", null, [
      (o(!0), n(m, null, _(a(u), (t) => (o(), n(m, {
        key: a(h)(t)
      }, [
        t.type === "SHIPMENT" ? (o(), n("div", E, [
          s(I, {
            size: "medium",
            "shipment-id": t.shipmentId
          }, null, 8, ["shipment-id"])
        ])) : c("", !0),
        t.type === "MATERIAL" ? (o(), n("div", M, [
          s(f, {
            size: "medium",
            ticker: t.ticker,
            amount: t.amount
          }, null, 8, ["ticker", "amount"])
        ])) : c("", !0)
      ], 64))), 128))
    ]));
  }
});
export {
  A as default
};
