import { subscribe as i } from "./subscribe-async-generator.js";
import { $ as o, $$ as s } from "./select-dom.js";
import { C as e } from "./prun-css.js";
import { createFragmentApp as l } from "./vue-fragment-app.js";
import f from "./tiles.js";
import p from "./feature-registry.js";
import { PrunI18N as u } from "./i18n.js";
import c from "./Passive.vue.js";
import { createVNode as a } from "./runtime-core.esm-bundler.js";
function b(r) {
  const m = u["CompanyPanel.data.bases"]?.[0]?.value;
  i(s(r.anchor, e.FormComponent.containerPassive), async (t) => {
    if ((await o(t, "label")).textContent !== m)
      return;
    const n = await o(t, e.StaticInput.static);
    l(() => a(c, {
      label: "Base Count"
    }, {
      default: () => [a("span", null, [n.childElementCount])]
    })).before(t);
  });
}
function d() {
  f.observe("CO", b);
}
p.add(import.meta.url, d, 'CO: Adds a "Base Count" row.');
