import f from "./EditAction.vue.js";
export {
  f as default
};
