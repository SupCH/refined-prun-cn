import { createEntityStore as s } from "./create-entity-store.js";
import { onApiMessage as r } from "./api-messages.js";
const c = s((e) => e.brokerId), i = c.state;
r({
  COMEX_BROKER_PRICES(e) {
    c.setOne(e), c.setFetched();
    for (const o of t)
      o(e);
  }
});
const t = [], f = {
  ...i,
  onPricesReceived(e) {
    t.push(e);
  },
  offPricesReceived(e) {
    t.splice(t.indexOf(e), 1);
  }
};
export {
  f as cxpcStore
};
