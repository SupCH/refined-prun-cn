import { Emitter as h } from "./index14.js";
import { deconstructPacket as f, reconstructPacket as N } from "./binary.js";
import { isBinary as E, hasBinary as d } from "./is-binary.js";
const A = [
  "connect",
  "connect_error",
  "disconnect",
  "disconnecting",
  "newListener",
  "removeListener"
  // used by the Node.js EventEmitter
];
var r;
(function(n) {
  n[n.CONNECT = 0] = "CONNECT", n[n.DISCONNECT = 1] = "DISCONNECT", n[n.EVENT = 2] = "EVENT", n[n.ACK = 3] = "ACK", n[n.CONNECT_ERROR = 4] = "CONNECT_ERROR", n[n.BINARY_EVENT = 5] = "BINARY_EVENT", n[n.BINARY_ACK = 6] = "BINARY_ACK";
})(r || (r = {}));
class y {
  /**
   * Encoder constructor
   *
   * @param {function} replacer - custom replacer to pass down to JSON.parse
   */
  constructor(t) {
    this.replacer = t;
  }
  /**
   * Encode a packet as a single string if non-binary, or as a
   * buffer sequence, depending on packet type.
   *
   * @param {Object} obj - packet object
   */
  encode(t) {
    return (t.type === r.EVENT || t.type === r.ACK) && d(t) ? this.encodeAsBinary({
      type: t.type === r.EVENT ? r.BINARY_EVENT : r.BINARY_ACK,
      nsp: t.nsp,
      data: t.data,
      id: t.id
    }) : [this.encodeAsString(t)];
  }
  /**
   * Encode packet as string.
   */
  encodeAsString(t) {
    let e = "" + t.type;
    return (t.type === r.BINARY_EVENT || t.type === r.BINARY_ACK) && (e += t.attachments + "-"), t.nsp && t.nsp !== "/" && (e += t.nsp + ","), t.id != null && (e += t.id), t.data != null && (e += JSON.stringify(t.data, this.replacer)), e;
  }
  /**
   * Encode packet as 'buffer sequence' by removing blobs, and
   * deconstructing packet into object with placeholders and
   * a list of buffers.
   */
  encodeAsBinary(t) {
    const e = f(t), s = this.encodeAsString(e.packet), o = e.buffers;
    return o.unshift(s), o;
  }
}
function a(n) {
  return Object.prototype.toString.call(n) === "[object Object]";
}
class u extends h {
  /**
   * Decoder constructor
   *
   * @param {function} reviver - custom reviver to pass down to JSON.stringify
   */
  constructor(t) {
    super(), this.reviver = t;
  }
  /**
   * Decodes an encoded packet string into packet JSON.
   *
   * @param {String} obj - encoded packet
   */
  add(t) {
    let e;
    if (typeof t == "string") {
      if (this.reconstructor)
        throw new Error("got plaintext data when reconstructing a packet");
      e = this.decodeString(t);
      const s = e.type === r.BINARY_EVENT;
      s || e.type === r.BINARY_ACK ? (e.type = s ? r.EVENT : r.ACK, this.reconstructor = new l(e), e.attachments === 0 && super.emitReserved("decoded", e)) : super.emitReserved("decoded", e);
    } else if (E(t) || t.base64)
      if (this.reconstructor)
        e = this.reconstructor.takeBinaryData(t), e && (this.reconstructor = null, super.emitReserved("decoded", e));
      else
        throw new Error("got binary data when not reconstructing a packet");
    else
      throw new Error("Unknown type: " + t);
  }
  /**
   * Decode a packet String (JSON data)
   *
   * @param {String} str
   * @return {Object} packet
   */
  decodeString(t) {
    let e = 0;
    const s = {
      type: Number(t.charAt(0))
    };
    if (r[s.type] === void 0)
      throw new Error("unknown packet type " + s.type);
    if (s.type === r.BINARY_EVENT || s.type === r.BINARY_ACK) {
      const i = e + 1;
      for (; t.charAt(++e) !== "-" && e != t.length; )
        ;
      const c = t.substring(i, e);
      if (c != Number(c) || t.charAt(e) !== "-")
        throw new Error("Illegal attachments");
      s.attachments = Number(c);
    }
    if (t.charAt(e + 1) === "/") {
      const i = e + 1;
      for (; ++e && !(t.charAt(e) === "," || e === t.length); )
        ;
      s.nsp = t.substring(i, e);
    } else
      s.nsp = "/";
    const o = t.charAt(e + 1);
    if (o !== "" && Number(o) == o) {
      const i = e + 1;
      for (; ++e; ) {
        const c = t.charAt(e);
        if (c == null || Number(c) != c) {
          --e;
          break;
        }
        if (e === t.length)
          break;
      }
      s.id = Number(t.substring(i, e + 1));
    }
    if (t.charAt(++e)) {
      const i = this.tryParse(t.substr(e));
      if (u.isPayloadValid(s.type, i))
        s.data = i;
      else
        throw new Error("invalid payload");
    }
    return s;
  }
  tryParse(t) {
    try {
      return JSON.parse(t, this.reviver);
    } catch {
      return !1;
    }
  }
  static isPayloadValid(t, e) {
    switch (t) {
      case r.CONNECT:
        return a(e);
      case r.DISCONNECT:
        return e === void 0;
      case r.CONNECT_ERROR:
        return typeof e == "string" || a(e);
      case r.EVENT:
      case r.BINARY_EVENT:
        return Array.isArray(e) && (typeof e[0] == "number" || typeof e[0] == "string" && A.indexOf(e[0]) === -1);
      case r.ACK:
      case r.BINARY_ACK:
        return Array.isArray(e);
    }
  }
  /**
   * Deallocates a parser's resources
   */
  destroy() {
    this.reconstructor && (this.reconstructor.finishedReconstruction(), this.reconstructor = null);
  }
}
class l {
  constructor(t) {
    this.packet = t, this.buffers = [], this.reconPack = t;
  }
  /**
   * Method to be called when binary data received from connection
   * after a BINARY_EVENT packet.
   *
   * @param {Buffer | ArrayBuffer} binData - the raw binary data received
   * @return {null | Object} returns null if more binary data is expected or
   *   a reconstructed packet object if all buffers have been received.
   */
  takeBinaryData(t) {
    if (this.buffers.push(t), this.buffers.length === this.reconPack.attachments) {
      const e = N(this.reconPack, this.buffers);
      return this.finishedReconstruction(), e;
    }
    return null;
  }
  /**
   * Cleans up binary packet reconstruction variables.
   */
  finishedReconstruction() {
    this.reconPack = null, this.buffers = [];
  }
}
export {
  u as Decoder,
  y as Encoder,
  r as PacketType
};
