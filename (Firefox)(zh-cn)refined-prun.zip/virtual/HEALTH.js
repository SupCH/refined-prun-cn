import o from "./xit-registry.js";
import t from "./HEALTH.vue.js";
o.add({
  command: "HEALTH",
  name: "DATA HEALTH",
  description: "Shows statistics on collected data.",
  component: () => t
});
