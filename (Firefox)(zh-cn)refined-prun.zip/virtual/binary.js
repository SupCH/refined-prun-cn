import { isBinary as i } from "./is-binary.js";
function s(e) {
  const r = [], n = e.data, t = e;
  return t.data = o(n, r), t.attachments = r.length, { packet: t, buffers: r };
}
function o(e, r) {
  if (!e)
    return e;
  if (i(e)) {
    const n = { _placeholder: !0, num: r.length };
    return r.push(e), n;
  } else if (Array.isArray(e)) {
    const n = new Array(e.length);
    for (let t = 0; t < e.length; t++)
      n[t] = o(e[t], r);
    return n;
  } else if (typeof e == "object" && !(e instanceof Date)) {
    const n = {};
    for (const t in e)
      Object.prototype.hasOwnProperty.call(e, t) && (n[t] = o(e[t], r));
    return n;
  }
  return e;
}
function u(e, r) {
  return e.data = c(e.data, r), delete e.attachments, e;
}
function c(e, r) {
  if (!e)
    return e;
  if (e && e._placeholder === !0) {
    if (typeof e.num == "number" && e.num >= 0 && e.num < r.length)
      return r[e.num];
    throw new Error("illegal attachments");
  } else if (Array.isArray(e))
    for (let n = 0; n < e.length; n++)
      e[n] = c(e[n], r);
  else if (typeof e == "object")
    for (const n in e)
      Object.prototype.hasOwnProperty.call(e, n) && (e[n] = c(e[n], r));
  return e;
}
export {
  s as deconstructPacket,
  u as reconstructPacket
};
