import { computed as r } from "./runtime-core.esm-bundler.js";
const a = (e) => e.toUpperCase();
function d(e, i, o) {
  o ??= a;
  const p = r(() => {
    if (e.value === void 0)
      return;
    const t = /* @__PURE__ */ new Map();
    for (const n of e.value)
      t.set(o(i(n)), n);
    return t;
  });
  return (t) => p.value !== void 0 && t ? p.value.get(o(t)) : void 0;
}
function s(e, i, o) {
  o ??= a;
  const p = r(() => {
    if (e.value === void 0)
      return;
    const t = /* @__PURE__ */ new Map();
    for (const n of e.value) {
      const c = o(i(n));
      let u = t.get(c);
      u || (u = [], t.set(c, u)), u.push(n);
    }
    return t;
  });
  return (t) => p.value !== void 0 && t ? p.value.get(o(t)) : void 0;
}
export {
  s as createGroupMapGetter,
  d as createMapGetter
};
