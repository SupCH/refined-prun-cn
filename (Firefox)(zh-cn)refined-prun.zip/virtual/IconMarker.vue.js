import o from "./IconMarker.vue2.js";
import s from "./IconMarker.vue3.js";
import r from "./plugin-vue_export-helper.js";
const t = {
  $style: s
}, f = /* @__PURE__ */ r(o, [["__cssModules", t]]);
export {
  f as default
};
