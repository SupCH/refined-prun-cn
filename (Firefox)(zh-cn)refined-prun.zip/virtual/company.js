import { onApiMessage as e } from "./api-messages.js";
import { shallowRef as r } from "./reactivity.esm-bundler.js";
const m = r(void 0);
e({
  COMPANY_DATA(o) {
    m.value = o;
  }
});
export {
  m as companyStore
};
