import { subscribe as d } from "./subscribe-async-generator.js";
import { $ as f, _$$ as l, $$ as m } from "./select-dom.js";
import { C as a } from "./prun-css.js";
import p from "./tiles.js";
import x from "./feature-registry.js";
import { getPrunId as u } from "./attributes.js";
import { localAdsStore as I } from "./local-ads.js";
import { extractPlanetName as C } from "./util.js";
function y(e) {
  d(m(e.anchor, a.CommodityAd.container), async (n) => {
    const o = await f(n, a.CommodityAd.text), s = u(n), i = I.getById(s);
    if (!i)
      return;
    const r = i.type, c = i.quantity;
    if (r === "COMMODITY_SHIPPING") {
      const t = l(o, a.Link.link);
      t.length === 2 && (t[0].textContent = C(t[0].textContent), t[0].previousSibling.textContent = " ", t[0].nextSibling.textContent = " → ", t[1].textContent = C(t[1].textContent));
    }
    if ((r === "COMMODITY_BUYING" || r === "COMMODITY_SELLING") && c) {
      const t = c.amount;
      o.childNodes[1].textContent = ` ${t} @ `;
    }
    for (const t of Array.from(o.childNodes))
      t.textContent && (t.textContent.endsWith(".00") && (t.textContent = t.textContent.replace(".00", "")), t.textContent.endsWith(",00") && (t.textContent = t.textContent.replace(",00", "")), t.textContent = t.textContent.replace(" for ", "").replace("delivery", "").replace("collection", "").replace(" within ", " in ").replace("for delivery within", "in"), t.textContent = t.textContent.replace(/(\d+)\s+days*/i, "$1d"));
    M(o, i);
  });
}
function M(e, n) {
  if (e.firstChild)
    switch (n.type) {
      case "COMMODITY_SHIPPING":
        e.firstChild.textContent = "";
        break;
      case "COMMODITY_BUYING":
        e.firstChild.textContent = "BUY";
        break;
      case "COMMODITY_SELLING":
        e.firstChild.textContent = "SELL";
        break;
    }
}
function h() {
  p.observe("LM", y);
}
x.add(import.meta.url, h, "LM: Hides redundant information from ads.");
