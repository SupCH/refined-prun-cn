const e = "rp-highlight-own-exchange-orders__ownOrder___95825be", r = {
  ownOrder: e
};
export {
  r as default,
  e as ownOrder
};
