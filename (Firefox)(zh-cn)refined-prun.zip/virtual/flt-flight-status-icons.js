import { subscribe as d } from "./subscribe-async-generator.js";
import { $$ as m } from "./select-dom.js";
import v from "./tiles.js";
import p from "./feature-registry.js";
import { refPrunId as T } from "./attributes.js";
import { shipsStore as h } from "./ships.js";
import { flightsStore as g } from "./flights.js";
import { isEmpty as E } from "./is-empty.js";
import { computed as s } from "./runtime-core.esm-bundler.js";
function b(f) {
  d(m(f.anchor, "tr"), (o) => {
    const a = T(o), u = s(() => h.getById(a.value)), i = s(() => g.getById(u.value?.flightId)), c = {
      TAKE_OFF: "↑",
      DEPARTURE: "↗",
      CHARGE: "±",
      JUMP: "⟿",
      TRANSIT: "⟶",
      APPROACH: "↘",
      LANDING: "↓"
    }, n = s(() => {
      if (!u.value)
        return;
      if (!i.value)
        return "⦁";
      const t = i.value.segments[i.value.currentSegmentIndex];
      if (t !== void 0)
        return c[t.type] ?? void 0;
    });
    function l() {
      if (n.value === void 0)
        return;
      const t = o.children[3];
      if (t === void 0)
        return;
      const r = Array.from(t.childNodes).filter(
        (e) => e.nodeType === Node.TEXT_NODE || e.nodeType === Node.ELEMENT_NODE
      );
      if (!E(r)) {
        t.style.textAlign !== "center" && (t.style.textAlign = "center"), r[0].textContent !== n.value && (r[0].textContent = n.value);
        for (const e of r.slice(1))
          e.textContent && (e.textContent = "");
      }
    }
    l(), new MutationObserver(l).observe(o, { childList: !0, subtree: !0, characterData: !0 });
  });
}
function y() {
  v.observe(["FLT", "FLTS", "FLTP"], b);
}
p.add(import.meta.url, y, "FLT: Replaces the flight status text with arrow icons.");
