import { createEntityStore as r } from "./create-entity-store.js";
import { onApiMessage as o } from "./api-messages.js";
import { createMapGetter as l } from "./create-map-getter.js";
const t = r(), a = t.state;
o({
  WORLD_MATERIAL_CATEGORIES(e) {
    t.setAll(e.categories), t.setFetched();
  }
});
const s = (e) => e.replaceAll("(", "").replaceAll(")", "").toUpperCase(), i = l(a.all, (e) => e.name, s), n = {
  ...a,
  getBySerializableName: i
};
export {
  n as materialCategoriesStore,
  s as toSerializableCategoryName
};
