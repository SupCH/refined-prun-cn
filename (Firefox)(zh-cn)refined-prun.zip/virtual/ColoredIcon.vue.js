import o from "./ColoredIcon.vue2.js";
import s from "./ColoredIcon.vue3.js";
import t from "./plugin-vue_export-helper.js";
const r = {
  $style: s
}, f = /* @__PURE__ */ t(o, [["__cssModules", r]]);
export {
  f as default
};
