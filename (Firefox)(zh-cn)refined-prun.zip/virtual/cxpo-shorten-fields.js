import { subscribe as a } from "./subscribe-async-generator.js";
import { $$ as n, $ as c } from "./select-dom.js";
import { C as i } from "./prun-css.js";
import s from "./tiles.js";
import m from "./feature-registry.js";
function l(t) {
  a(n(t.anchor, i.ComExPlaceOrderForm.form), (r) => {
    const e = t.parameter.split(".");
    o(r.children[0], e[1]), o(r.children[1], e[0]);
  });
}
async function o(t, r) {
  const e = await c(t, i.StaticInput.static);
  e.textContent = r;
}
function p() {
  s.observe("CXPO", l);
}
m.add(
  import.meta.url,
  p,
  'CXPO: Replaces values of "Exchange" and "Material" fields with corresponding tickers.'
);
