import { subscribe as a } from "./subscribe-async-generator.js";
import { $ as e, $$ as n } from "./select-dom.js";
import { C as r } from "./prun-css.js";
import d from "./tiles.js";
import s from "./feature-registry.js";
import c from "./lm-highlight-own-ads.module.css.js";
import { companyStore as f } from "./company.js";
import { getPrunId as p } from "./attributes.js";
import { localAdsStore as l } from "./local-ads.js";
function u(t) {
  a(n(t.anchor, r.LocalMarket.item), async (o) => {
    const i = await e(o, r.CommodityAd.container), m = p(i);
    l.getById(m)?.creator.id === f.value?.id && o.classList.add(c.ownAd);
  });
}
function y() {
  d.observe("LM", u);
}
s.add(import.meta.url, y, "LM: Highlights own ads.");
