import { createEntityStore as o } from "./create-entity-store.js";
import { onApiMessage as s } from "./api-messages.js";
const e = o((t) => t.missionId), r = e.state;
s({
  SHIP_FLIGHT_MISSION(t) {
    e.setOne(t), e.setFetched();
  }
});
const a = {
  ...r
};
export {
  a as flightPlansStore
};
