import { subscribe as n } from "./subscribe-async-generator.js";
import { $$ as a } from "./select-dom.js";
import m from "./tiles.js";
import s from "./feature-registry.js";
import { refPrunId as f } from "./attributes.js";
import { storagesStore as c } from "./storage.js";
import { watchEffectWhileNodeAlive as u } from "./watch.js";
import { computed as p } from "./runtime-core.esm-bundler.js";
function d(r) {
  r.parameter || n(a(r.anchor, "tr"), (t) => {
    const i = f(t), o = p(() => {
      switch (c.getById(i.value)?.type) {
        case "STORE":
          return "Base";
        case "WAREHOUSE_STORE":
          return "WAR";
        case "SHIP_STORE":
          return "Ship";
        case "STL_FUEL_STORE":
          return "STL";
        case "FTL_FUEL_STORE":
          return "FTL";
        default:
          return;
      }
    });
    u(t, () => {
      const e = t.firstChild?.firstChild;
      e && o.value !== void 0 && (e.textContent = o.value);
    });
  });
}
function l() {
  m.observe("INV", d);
}
s.add(
  import.meta.url,
  l,
  "INV: Shortens storage type names in the first column of the main INV command."
);
