import { subscribe as m } from "./subscribe-async-generator.js";
import { _$$ as c, $$ as s } from "./select-dom.js";
import { C as n } from "./prun-css.js";
import p from "./tiles.js";
import f from "./feature-registry.js";
import { cxpcStore as a } from "./cxpc.js";
import { cxobStore as u } from "./cxob.js";
import { computed as d } from "./runtime-core.esm-bundler.js";
function l(t) {
  m(s(t.anchor, n.ChartContainer.settings), async (i) => {
    await h(t.parameter);
    const e = c(i, n.RadioGroup.container);
    if (e.length === 0)
      return;
    const r = e[0], o = c(r, n.RadioItem.container);
    if (o.length === 0)
      return;
    o[o.length - 1]?.click();
  });
}
async function h(t) {
  const i = d(() => u.getByTicker(t));
  await new Promise((e) => {
    const r = (o) => {
      o.brokerId === i.value?.id && (e(), a.offPricesReceived(r));
    };
    a.onPricesReceived(r);
  });
}
function C() {
  p.observe("CXPC", l);
}
f.add(import.meta.url, C, "CXPC: Selects the 1y chart on open.");
