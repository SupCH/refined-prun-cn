import f from "./DaysCell.vue.js";
export {
  f as default
};
