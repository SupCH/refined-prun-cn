import { createEntityStore as r } from "./create-entity-store.js";
import { onApiMessage as s } from "./api-messages.js";
import { createMapGetter as i } from "./create-map-getter.js";
const e = r((t) => t.siteId), o = e.state;
s({
  EXPERTS_EXPERTS(t) {
    e.setOne(t), e.setFetched();
  }
});
const a = i(o.all, (t) => t.siteId), m = {
  ...o,
  getBySiteId: a
};
export {
  m as expertsStore
};
