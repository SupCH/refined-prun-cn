import { refAttributeValue as r } from "./reactive-dom.js";
function e(t) {
  return t.getAttribute("data-prun-id");
}
function n(t) {
  return r(t, "data-prun-id");
}
export {
  e as getPrunId,
  n as refPrunId
};
