import { loadPrunCss as r } from "./prun-css.js";
import { loadRefinedPrunCss as i } from "./refined-prun-css.js";
import { loadPrunI18N as o } from "./i18n.js";
import { trackItemTickers as t } from "./item-tracker.js";
import { initTileDataExport as m } from "./tile-data-export.js";
async function s() {
  await r(), o(), i(), t(), m();
}
export {
  s as initializeUI
};
