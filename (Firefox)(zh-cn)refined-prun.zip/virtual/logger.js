class o {
  constructor(e) {
    this.logMessage = e;
  }
  label(e) {
    this.logMessage(null, e);
  }
  info(e) {
    this.logMessage("INFO", e);
  }
  action(e) {
    this.logMessage("ACTION", e);
  }
  success(e) {
    this.logMessage("SUCCESS", e);
  }
  error(e) {
    this.logMessage("ERROR", e);
  }
  skip(e) {
    this.logMessage("SKIP", e);
  }
  warning(e) {
    this.logMessage("WARNING", e);
  }
  cancel(e) {
    this.logMessage("CANCEL", e);
  }
  runtimeError(e) {
    if (console.error(e), e instanceof Error)
      if (e.stack)
        for (const s of e.stack.split(`
`))
          this.error(s);
      else
        this.error(e.message);
    else
      this.error(e);
    this.error("Action Package execution failed due to a runtime error"), this.error("Please report this error to the extension developer");
  }
}
export {
  o as Logger
};
