import { C as W } from "./prun-css.js";
import A from "./RadioItem.vue.js";
import { getPlanetBurn as X } from "./burn2.js";
import { comparePlanets as G } from "./util.js";
import H from "./BurnSection.vue.js";
import { useTileState as h } from "./tile-state5.js";
import T from "./Tooltip.vue.js";
import J from "./LoadingSpinner.vue.js";
import K from "./MaterialRow.vue.js";
import { materialsStore as Y } from "./materials.js";
import { useXitParameters as Z } from "./use-xit-parameters.js";
import { sitesStore as V } from "./sites.js";
import { countDays as z } from "./utils4.js";
import D from "./InlineFlex.vue.js";
import { findWithQuery as ee } from "./find-with-query.js";
import { convertToPlanetNaturalId as le } from "./planet-natural-id.js";
import te from "./PrunButton.vue.js";
import ne from "./QuickPurchaseDialog.vue.js";
import { showTileOverlay as re } from "./tile-overlay.js";
import { userData as oe } from "./user-data.js";
import { t as a } from "./index5.js";
import { defineComponent as ae, computed as B, createBlock as $, createElementBlock as x, openBlock as p, createElementVNode as u, createVNode as m, withCtx as f, createTextVNode as c, Fragment as E, renderList as ue } from "./runtime-core.esm-bundler.js";
import { unref as r, isRef as O } from "./reactivity.esm-bundler.js";
import { toDisplayString as i, normalizeClass as N } from "./shared.esm-bundler.js";
const ie = { key: 1 }, Te = /* @__PURE__ */ ae({
  __name: "BURN",
  setup(se) {
    const S = Z(), y = {}, k = B(() => {
      if (!V.all.value)
        return;
      const l = V.all.value;
      if (S.length === 0)
        return {
          sites: l,
          includeOverall: !0,
          overallOnly: !1
        };
      const e = ee(S, U);
      let t = e.include;
      e.includeAll && (t = l), e.excludeAll && (t = []), t = t.filter((b) => !e.exclude.has(b));
      const n = t.filter((b) => b !== y), o = n.length > 1 || t.length !== n.length || e.includeAll, d = e.exclude.has(y) || e.excludeAll;
      let v = o && !d, I = !1, R = l;
      return t.length === 1 && t[0] === y && !d && (R = l.filter((b) => !e.exclude.has(b)), v = !0, I = !0), {
        sites: I ? R : n,
        includeOverall: v,
        overallOnly: I
      };
    });
    function U(l, e) {
      if (l === "all")
        return V.all.value;
      if (l === "overall")
        return y;
      const t = le(l, e);
      return V.getByPlanetNaturalId(t);
    }
    const s = B(() => {
      if (k.value === void 0)
        return;
      const l = k.value.sites.filter((n) => n !== y).map(X).filter((n) => n !== void 0);
      if (l.length <= 1)
        return l;
      l.sort((n, o) => {
        const d = z(n.burn), v = z(o.burn);
        return d !== v ? d - v : G(n.naturalId, o.naturalId);
      });
      const e = {};
      for (const n of l)
        for (const o of Object.keys(n.burn))
          e[o] ? (e[o].dailyAmount += n.burn[o].dailyAmount, e[o].inventory += n.burn[o].inventory) : (e[o] = {}, e[o].dailyAmount = n.burn[o].dailyAmount, e[o].inventory = n.burn[o].inventory);
      for (const n of Object.keys(e))
        e[n].dailyAmount >= 0 ? e[n].daysLeft = 1e3 : e[n].daysLeft = -e[n].inventory / e[n].dailyAmount;
      const t = {
        burn: e,
        planetName: a("burn.overall"),
        naturalId: "",
        storeId: ""
      };
      return k.value.overallOnly ? [t] : (k.value.includeOverall && l.push(t), l);
    }), P = h("red"), _ = h("yellow"), C = h("green"), w = h("inf"), L = {
      dailyAmount: -1e5,
      daysLeft: 10,
      inventory: 1e5,
      type: "input",
      input: 1e5,
      output: 0,
      workforce: 0
    }, j = Y.getByTicker("RAT"), g = h("expand"), Q = B(() => g.value.length > 0);
    function q() {
      g.value.length > 0 ? g.value = [] : g.value = s.value?.map((l) => l.naturalId) ?? [];
    }
    const M = B(() => {
      if (!s.value)
        return {};
      const l = oe.settings.burn.resupply, e = {};
      for (const t of s.value)
        for (const [n, o] of Object.entries(t.burn)) {
          if (o.dailyAmount >= 0)
            continue;
          const d = Math.max(0, l * -o.dailyAmount - o.inventory);
          d > 0 && (e[n] = (e[n] || 0) + d);
        }
      return e;
    });
    function F(l) {
      !s.value || s.value.length === 0 || re(l, ne, {
        rawBurnData: s.value,
        packageNamePrefix: "BURN Quick Purchase"
      });
    }
    return (l, e) => r(s) === void 0 ? (p(), $(J, { key: 0 })) : (p(), x(E, { key: 1 }, [
      u("div", {
        class: N(("C" in l ? l.C : r(W)).ComExOrdersPanel.filter)
      }, [
        m(A, {
          modelValue: r(P),
          "onUpdate:modelValue": e[0] || (e[0] = (t) => O(P) ? P.value = t : null),
          horizontal: ""
        }, {
          default: f(() => [
            c(i(r(a)("burn.red")), 1)
          ]),
          _: 1
        }, 8, ["modelValue"]),
        m(A, {
          modelValue: r(_),
          "onUpdate:modelValue": e[1] || (e[1] = (t) => O(_) ? _.value = t : null),
          horizontal: ""
        }, {
          default: f(() => [
            c(i(r(a)("burn.yellow")), 1)
          ]),
          _: 1
        }, 8, ["modelValue"]),
        m(A, {
          modelValue: r(C),
          "onUpdate:modelValue": e[2] || (e[2] = (t) => O(C) ? C.value = t : null),
          horizontal: ""
        }, {
          default: f(() => [
            c(i(r(a)("burn.green")), 1)
          ]),
          _: 1
        }, 8, ["modelValue"]),
        m(A, {
          modelValue: r(w),
          "onUpdate:modelValue": e[3] || (e[3] = (t) => O(w) ? w.value = t : null),
          horizontal: ""
        }, {
          default: f(() => [
            c(i(r(a)("burn.inf")), 1)
          ]),
          _: 1
        }, 8, ["modelValue"])
      ], 2),
      u("div", {
        class: N(l.$style.quickPurchaseBar)
      }, [
        m(te, {
          primary: "",
          disabled: Object.keys(r(M)).length === 0,
          onClick: F
        }, {
          default: f(() => [
            c(i(r(a)("burn.quickPurchase")), 1)
          ]),
          _: 1
        }, 8, ["disabled"])
      ], 2),
      u("table", null, [
        u("thead", null, [
          u("tr", null, [
            r(s).length > 1 ? (p(), x("th", {
              key: 0,
              class: N(l.$style.expand),
              onClick: q
            }, i(r(Q) ? "-" : "+"), 3)) : (p(), x("th", ie)),
            u("th", null, i(r(a)("burn.inv")), 1),
            u("th", null, [
              m(D, null, {
                default: f(() => [
                  c(i(r(a)("burn.burn")) + " ", 1),
                  m(T, {
                    position: "bottom",
                    tooltip: r(a)("burn.burnTooltip")
                  }, null, 8, ["tooltip"])
                ]),
                _: 1
              })
            ]),
            u("th", null, [
              m(D, null, {
                default: f(() => [
                  c(i(r(a)("burn.need")) + " ", 1),
                  m(T, {
                    position: "bottom",
                    tooltip: r(a)("burn.needTooltip")
                  }, null, 8, ["tooltip"])
                ]),
                _: 1
              })
            ]),
            u("th", null, i(r(a)("burn.days")), 1),
            u("th", null, i(r(a)("burn.cmd")), 1)
          ])
        ]),
        u("tbody", {
          class: N(l.$style.fakeRow)
        }, [
          m(K, {
            "always-visible": "",
            burn: L,
            material: r(j)
          }, null, 8, ["material"])
        ], 2),
        (p(!0), x(E, null, ue(r(s), (t) => (p(), $(H, {
          key: t.planetName,
          "can-minimize": r(s).length > 1,
          burn: t
        }, null, 8, ["can-minimize", "burn"]))), 128))
      ])
    ], 64));
  }
});
export {
  Te as default
};
