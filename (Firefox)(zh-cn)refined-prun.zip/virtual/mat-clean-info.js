import { applyCssRule as o } from "./refined-prun-css.js";
import { C as i } from "./prun-css.js";
import n from "./feature-registry.js";
import r from "./css-utils.module.css.js";
function t() {
  o(
    "MAT",
    `.${i.MaterialInformation.container} > .${i.FormComponent.containerPassive}:nth-child(2)`,
    r.hidden
  ), o(
    "MAT",
    `.${i.MaterialInformation.container} > .${i.FormComponent.containerPassive}:nth-child(6)`,
    r.hidden
  );
}
n.add(import.meta.url, t, 'MAT: Hides "Ticker" and "Natural resource" fields.');
