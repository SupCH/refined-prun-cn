import { C as E } from "./prun-css.js";
import F from "./PrunButton.vue.js";
import N from "./SectionHeader.vue.js";
import v from "./Active.vue.js";
import G from "./TextInput.vue.js";
import U from "./Commands.vue.js";
import $ from "./SelectInput.vue.js";
import { act as y } from "./act-registry.js";
import { t as a } from "./index5.js";
import { defineComponent as D, computed as M, useTemplateRef as T, createElementBlock as I, openBlock as C, createVNode as r, createElementVNode as O, withCtx as i, createTextVNode as g, createBlock as R, createCommentVNode as j, resolveDynamicComponent as w } from "./runtime-core.esm-bundler.js";
import { ref as f, unref as e, isRef as V } from "./reactivity.esm-bundler.js";
import { toDisplayString as s, normalizeClass as z } from "./shared.esm-bundler.js";
const h = /* @__PURE__ */ D({
  __name: "EditMaterialGroup",
  props: {
    add: { type: Boolean },
    group: {},
    onSave: { type: Function }
  },
  emits: ["close"],
  setup(t, { emit: k }) {
    const b = k, n = f(t.group.name || ""), u = f(!1), S = y.getMaterialGroupTypes(), m = f(t.group.type), c = M(() => y.getMaterialGroupInfo(m.value)?.editComponent), d = T("editForm");
    function B() {
      let o = d.value.validate();
      if (u.value = n.value.length === 0, o &&= !u.value, !!o) {
        for (const l of Object.keys(t.group))
          delete t.group[l];
        d.value.save(), t.group.name = n.value, t.group.type = m.value, t.onSave?.(), b("close");
      }
    }
    return (o, l) => (C(), I("div", {
      class: z(("C" in o ? o.C : e(E)).DraftConditionEditor.form)
    }, [
      r(N, null, {
        default: i(() => [
          g(s(o.add ? e(a)("act.add") : e(a)("act.edit")) + " " + s(e(a)("act.materialGroup")), 1)
        ]),
        _: 1
      }),
      O("form", null, [
        r(v, {
          label: e(a)("act.typeLabel")
        }, {
          default: i(() => [
            r($, {
              modelValue: e(m),
              "onUpdate:modelValue": l[0] || (l[0] = (p) => V(m) ? m.value = p : null),
              options: e(S)
            }, null, 8, ["modelValue", "options"])
          ]),
          _: 1
        }, 8, ["label"]),
        r(v, {
          label: e(a)("act.name"),
          error: e(u)
        }, {
          default: i(() => [
            r(G, {
              modelValue: e(n),
              "onUpdate:modelValue": l[1] || (l[1] = (p) => V(n) ? n.value = p : null)
            }, null, 8, ["modelValue"])
          ]),
          _: 1
        }, 8, ["label", "error"]),
        e(c) ? (C(), R(w(e(c)), {
          key: 0,
          ref_key: "editForm",
          ref: d,
          group: o.group
        }, null, 8, ["group"])) : j("", !0),
        r(U, null, {
          default: i(() => [
            r(F, {
              primary: "",
              onClick: B
            }, {
              default: i(() => [
                g(s(o.add ? e(a)("act.add").toUpperCase() : e(a)("act.save").toUpperCase()), 1)
              ]),
              _: 1
            })
          ]),
          _: 1
        })
      ])
    ], 2));
  }
});
export {
  h as default
};
