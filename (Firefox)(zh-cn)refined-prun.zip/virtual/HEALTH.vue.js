import { C as c } from "./prun-css.js";
import { sitesStore as f } from "./sites.js";
import { getEntityNameFromAddress as x } from "./addresses.js";
import { workforcesStore as S } from "./workforces.js";
import { productionStore as y } from "./production.js";
import { storagesStore as d } from "./storage.js";
import { warehousesStore as B } from "./warehouses.js";
import { contractsStore as C } from "./contracts.js";
import { cxosStore as I } from "./cxos.js";
import { fxosStore as O } from "./fxos.js";
import { balancesStore as P } from "./balances.js";
import { cxStore as g } from "./cx.js";
import { dayjsEachSecond as T } from "./dayjs.js";
import { objectId as V } from "./object-id.js";
import { defineComponent as _, computed as v, createElementBlock as t, openBlock as l, createElementVNode as e, Fragment as m, renderList as k, createTextVNode as b } from "./runtime-core.esm-bundler.js";
import { toDisplayString as p, normalizeClass as n } from "./shared.esm-bundler.js";
import { unref as a } from "./reactivity.esm-bundler.js";
const W = { style: { paddingTop: "4px" } }, w = { style: { tableLayout: "fixed" } }, Y = /* @__PURE__ */ _({
  __name: "HEALTH",
  setup(A) {
    const h = v(() => f.all.value?.map((r) => ({
      name: x(r.address),
      workforce: !!S.getById(r.siteId),
      production: !!y.getBySiteId(r.siteId),
      storage: !!d.getByAddressableId(r.siteId)
    })) ?? []), E = v(() => [
      ["Base Sites", f.all.value?.length],
      ["Warehouse Sites", B.all.value?.length],
      ["Base Stores", d.all.value?.filter((r) => r.type === "STORE").length],
      ["Warehouse Stores", d.all.value?.filter((r) => r.type === "WAREHOUSE_STORE").length],
      ["Ship Stores", d.all.value?.filter((r) => r.type === "SHIP_STORE").length],
      ["Workforces", S.all.value?.length],
      ["Production Sites", y.all.value?.length],
      ["Contracts", C.all.value?.length],
      ["CXOS", I.all.value?.length],
      ["FXOS", O.all.value?.length],
      ["Currency", (P.all.value?.length ?? 0) > 0],
      ["Last CX Price Update", g.fetched ? `${T.value.to(g.age)}` : !1]
    ]), u = c.ColoredValue.positive, i = c.ColoredValue.negative;
    return (r, s) => (l(), t("div", W, [
      s[2] || (s[2] = e("span", { class: "title" }, "Bases", -1)),
      e("table", null, [
        s[0] || (s[0] = e("thead", null, [
          e("tr", null, [
            e("th", null, "Planet"),
            e("th", null, "Workforce"),
            e("th", null, "Production"),
            e("th", null, "Storage")
          ])
        ], -1)),
        e("tbody", null, [
          (l(!0), t(m, null, k(a(h), (o) => (l(), t("tr", {
            key: o.name
          }, [
            e("td", null, p(o.name), 1),
            o.workforce ? (l(), t("td", {
              key: 0,
              class: n(a(u))
            }, "✓", 2)) : (l(), t("td", {
              key: 1,
              class: n(a(i))
            }, "✗", 2)),
            o.production ? (l(), t("td", {
              key: 2,
              class: n(a(u))
            }, "✓", 2)) : (l(), t("td", {
              key: 3,
              class: n(a(i))
            }, "✗", 2)),
            o.storage ? (l(), t("td", {
              key: 4,
              class: n(a(u))
            }, "✓", 2)) : (l(), t("td", {
              key: 5,
              class: n(a(i))
            }, "✗", 2))
          ]))), 128))
        ])
      ]),
      s[3] || (s[3] = e("span", {
        class: "title",
        style: { "padding-top": "10px" }
      }, "Other Data", -1)),
      e("table", w, [
        s[1] || (s[1] = e("thead", null, [
          e("tr", null, [
            e("th", null, "Parameter"),
            e("th", null, "Value")
          ])
        ], -1)),
        e("tbody", null, [
          (l(!0), t(m, null, k(a(E), (o) => (l(), t("tr", {
            key: a(V)(o)
          }, [
            e("td", null, p(o[0]), 1),
            e("td", null, [
              o[1] === !0 ? (l(), t("span", {
                key: 0,
                class: n(a(u))
              }, "✓", 2)) : o[1] === !1 || o[1] === void 0 ? (l(), t("span", {
                key: 1,
                class: n(a(i))
              }, " ✗ ", 2)) : (l(), t(m, { key: 2 }, [
                b(p(o[1]), 1)
              ], 64))
            ])
          ]))), 128))
        ])
      ])
    ]));
  }
});
export {
  Y as default
};
