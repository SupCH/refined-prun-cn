import { act as i } from "./act-registry.js";
import { fixed0 as a } from "./format.js";
import o from "./Edit.vue7.js";
import { deepToRaw as m } from "./deep-to-raw.js";
i.addMaterialGroup({
  type: "Manual",
  description: (r) => {
    const e = r.materials;
    return !e || Object.keys(e).length == 0 ? "--" : Object.keys(e).map((t) => `${a(e[t])} ${t}`).join(", ");
  },
  editComponent: o,
  generateMaterialBill: async ({ data: r, log: e }) => {
    if (!r.materials || Object.keys(r.materials).length == 0) {
      e.error("Missing materials.");
      return;
    }
    return structuredClone(m(r.materials));
  }
});
