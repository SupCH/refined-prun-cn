const i = typeof ArrayBuffer == "function", o = (t) => typeof ArrayBuffer.isView == "function" ? ArrayBuffer.isView(t) : t.buffer instanceof ArrayBuffer, n = Object.prototype.toString, u = typeof Blob == "function" || typeof Blob < "u" && n.call(Blob) === "[object BlobConstructor]", c = typeof File == "function" || typeof File < "u" && n.call(File) === "[object FileConstructor]";
function a(t) {
  return i && (t instanceof ArrayBuffer || o(t)) || u && t instanceof Blob || c && t instanceof File;
}
function r(t, l) {
  if (!t || typeof t != "object")
    return !1;
  if (Array.isArray(t)) {
    for (let e = 0, f = t.length; e < f; e++)
      if (r(t[e]))
        return !0;
    return !1;
  }
  if (a(t))
    return !0;
  if (t.toJSON && typeof t.toJSON == "function" && arguments.length === 1)
    return r(t.toJSON(), !0);
  for (const e in t)
    if (Object.prototype.hasOwnProperty.call(t, e) && r(t[e]))
      return !0;
  return !1;
}
export {
  r as hasBinary,
  a as isBinary
};
