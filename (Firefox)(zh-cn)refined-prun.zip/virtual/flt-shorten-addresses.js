import { subscribe as e } from "./subscribe-async-generator.js";
import { $$ as r } from "./select-dom.js";
import { C as n } from "./prun-css.js";
import i from "./tiles.js";
import m from "./feature-registry.js";
import { extractPlanetName as a } from "./util.js";
function f(o) {
  e(r(o.anchor, n.Link.link), (t) => {
    t.textContent && (t.textContent = a(t.textContent));
  });
}
function s() {
  i.observe(["FLT", "FLTS", "FLTP"], f);
}
m.add(import.meta.url, s, 'FLT: Shortens addresses in "Location" and "Destination".');
