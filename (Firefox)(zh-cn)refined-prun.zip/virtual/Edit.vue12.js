import f from "./Edit.vue5.js";
export {
  f as default
};
