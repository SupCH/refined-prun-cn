import { C as o } from "./prun-css.js";
import { userData as t } from "./user-data.js";
import { defineComponent as i, computed as r, createElementBlock as p, openBlock as c, createElementVNode as a } from "./runtime-core.esm-bundler.js";
import { normalizeClass as u, toDisplayString as d } from "./shared.esm-bundler.js";
import { unref as s } from "./reactivity.esm-bundler.js";
const m = { style: { position: "relative" } }, v = /* @__PURE__ */ i({
  __name: "DaysCell",
  props: {
    days: {}
  },
  setup(n) {
    const e = r(() => Math.floor(n.days)), l = r(() => ({
      [o.Workforces.daysMissing]: e.value <= t.settings.burn.red,
      [o.Workforces.daysWarning]: e.value <= t.settings.burn.yellow,
      [o.Workforces.daysSupplied]: e.value > t.settings.burn.yellow
    }));
    return (f, y) => (c(), p("td", m, [
      a("div", {
        style: { position: "absolute", left: 0, top: 0, width: "100%", height: "100%" },
        class: u(s(l))
      }, null, 2),
      a("span", null, d(s(e) < 500 ? s(e) : "∞"), 1)
    ]));
  }
});
export {
  v as default
};
