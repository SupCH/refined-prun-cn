import { subscribe as m } from "./subscribe-async-generator.js";
import { $$ as p } from "./select-dom.js";
import { C as o } from "./prun-css.js";
import { createFragmentApp as a } from "./vue-fragment-app.js";
import { applyCssRule as t } from "./refined-prun-css.js";
import i from "./tiles.js";
import s from "./feature-registry.js";
import d from "./cxob-supply-demand-values.module.css.js";
import n from "./SupplyDemandValues.vue.js";
function l(r) {
  m(p(r.anchor, o.ComExOrderBookPanel.spread), async (e) => {
    a(n, { ticker: r.parameter }).prependTo(e);
  });
}
function f() {
  t(`.${o.ComExOrderBookPanel.spread}`, d.spread), i.observe("CXOB", l);
}
s.add(import.meta.url, f, "CXOB: Adds supply and demand value labels.");
