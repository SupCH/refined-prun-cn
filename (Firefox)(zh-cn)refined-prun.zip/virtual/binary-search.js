function r(n, h, o) {
  let e = 0, l = h.length;
  for (; e < l; ) {
    const t = Math.floor((e + l) / 2);
    o(h[t]) < n ? e = t + 1 : l = t;
  }
  return e;
}
export {
  r as binarySearch
};
