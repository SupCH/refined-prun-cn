import { subscribe as o } from "./subscribe-async-generator.js";
import { $$ as i, _$$ as p } from "./select-dom.js";
import { C as l } from "./prun-css.js";
import { createFragmentApp as c } from "./vue-fragment-app.js";
import d from "./tiles.js";
import g from "./feature-registry.js";
import { refAnimationFrame as u } from "./reactive-dom.js";
import { isEmpty as y } from "./is-empty.js";
import { createVNode as b } from "./runtime-core.esm-bundler.js";
function T(r) {
  r.parameter && o(i(r.anchor, l.Site.workforces), (s) => {
    o(i(s, "tr"), (a) => {
      const t = p(a, "td");
      if (y(t))
        return;
      const e = t[4].getElementsByTagName("div")[0];
      e.style.display = "flex", e.style.flexDirection = "row", e.style.justifyContent = "left";
      const m = e.getElementsByTagName("progress")[0], n = u(m, (f) => f.title);
      c(() => b("span", null, [n.value])).appendTo(e);
    });
  });
}
function B() {
  d.observe("BS", T);
}
g.add(import.meta.url, B, "BS: Adds a workforce satisfaction percentage label to the satisfaction progress bar.");
