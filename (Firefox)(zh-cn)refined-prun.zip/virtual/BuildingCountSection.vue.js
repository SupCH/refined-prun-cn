import o from "./BuildingCountSection.vue2.js";
import s from "./BuildingCountSection.vue3.js";
import t from "./plugin-vue_export-helper.js";
const e = {
  $style: s
}, m = /* @__PURE__ */ t(o, [["__cssModules", e]]);
export {
  m as default
};
