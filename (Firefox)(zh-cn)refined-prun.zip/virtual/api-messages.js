const r = [], s = /* @__PURE__ */ new Map();
function f(t) {
  r.push(t);
}
function i(t) {
  for (const n in t) {
    let e = s.get(n);
    e || (e = [], s.set(n, e)), e.push(t[n]);
  }
}
function u(t) {
  let n = !1;
  for (const o of r)
    o(t) && (n = !0);
  const e = s.get(t.type);
  if (e)
    for (const o of e)
      o(t.data) && (n = !0);
  return n;
}
export {
  u as dispatch,
  f as onAnyApiMessage,
  i as onApiMessage
};
