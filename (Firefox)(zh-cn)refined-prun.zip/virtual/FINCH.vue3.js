const c = "rp-FINCH__root___c2549a0", o = "rp-FINCH__clickable___0ceced3", _ = {
  root: c,
  clickable: o
};
export {
  o as clickable,
  _ as default,
  c as root
};
