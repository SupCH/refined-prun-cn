import e from "./PrunButton.vue.js";
import { defineComponent as o, createBlock as r, openBlock as s, withCtx as a, renderSlot as n } from "./runtime-core.esm-bundler.js";
import { normalizeClass as l } from "./shared.esm-bundler.js";
const _ = /* @__PURE__ */ o({
  __name: "DevButton",
  setup(m) {
    return (t, p) => (s(), r(e, {
      primary: "",
      class: l(t.$style.button)
    }, {
      default: a(() => [
        n(t.$slots, "default")
      ]),
      _: 3
    }, 8, ["class"]));
  }
});
export {
  _ as default
};
