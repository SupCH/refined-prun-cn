import m from "./xit-registry.js";
import o from "./DEV.vue.js";
m.add({
  command: "DEV",
  name: "DEVELOPMENT MENU",
  description: "Development menu.",
  component: () => o
});
