import r from "./Active.vue.js";
import L from "./Commands.vue.js";
import h from "./PrunButton.vue.js";
import k from "./SelectInput.vue.js";
import g from "./RadioItem.vue.js";
import { showTileOverlay as P } from "./tile-overlay.js";
import X from "./EditPriceLimits.vue.js";
import { materialsStore as E } from "./materials.js";
import { defineComponent as $, computed as B, createElementBlock as N, openBlock as T, createVNode as o, withCtx as a, createTextVNode as v, Fragment as G } from "./runtime-core.esm-bundler.js";
import { ref as n, unref as u, isRef as m, reactive as A } from "./reactivity.esm-bundler.js";
const H = /* @__PURE__ */ $({
  __name: "Edit",
  props: {
    action: {},
    pkg: {}
  },
  setup(t, { expose: w }) {
    const C = B(() => t.pkg.groups.map((i) => i.name).filter((i) => i)), f = n(t.action.group ?? C.value[0]), V = ["AI1", "CI1", "IC1", "NC1", "CI2", "NC2"], d = n(t.action.exchange ?? V[0]), b = n(y());
    function y() {
      const i = t.action.priceLimits ?? {};
      return Object.keys(i).map((e) => [e, i[e]]);
    }
    const s = n(t.action.buyPartial ?? !1), c = n(t.action.allowUnfilled ?? !1), p = n(t.action.useCXInv ?? !0);
    function x(i) {
      P(i, X, A({ priceLimits: b }));
    }
    function I() {
      return !0;
    }
    function U() {
      t.action.group = f.value, t.action.exchange = d.value, t.action.priceLimits = {};
      for (let [i, e] of b.value) {
        const l = E.getByTicker(i);
        !l || e === 0 || !isFinite(e) || (t.action.priceLimits[l.ticker] = e);
      }
      t.action.buyPartial = s.value, t.action.allowUnfilled = c.value, t.action.useCXInv = p.value;
    }
    return w({ validate: I, save: U }), (i, e) => (T(), N(G, null, [
      o(r, { label: "Material Group" }, {
        default: a(() => [
          o(k, {
            modelValue: u(f),
            "onUpdate:modelValue": e[0] || (e[0] = (l) => m(f) ? f.value = l : null),
            options: u(C)
          }, null, 8, ["modelValue", "options"])
        ]),
        _: 1
      }),
      o(r, { label: "Exchange" }, {
        default: a(() => [
          o(k, {
            modelValue: u(d),
            "onUpdate:modelValue": e[1] || (e[1] = (l) => m(d) ? d.value = l : null),
            options: V
          }, null, 8, ["modelValue"])
        ]),
        _: 1
      }),
      o(L, { label: "Price Limits" }, {
        default: a(() => [
          o(h, {
            primary: "",
            onClick: x
          }, {
            default: a(() => [...e[5] || (e[5] = [
              v("EDIT", -1)
            ])]),
            _: 1
          })
        ]),
        _: 1
      }),
      o(r, {
        label: "Buy Partial",
        tooltip: "Whether the action will be taken if there is not enough stock on the CX."
      }, {
        default: a(() => [
          o(g, {
            modelValue: u(s),
            "onUpdate:modelValue": e[2] || (e[2] = (l) => m(s) ? s.value = l : null)
          }, {
            default: a(() => [...e[6] || (e[6] = [
              v("buy partial", -1)
            ])]),
            _: 1
          }, 8, ["modelValue"])
        ]),
        _: 1
      }),
      o(r, {
        label: "Allow Unfilled",
        tooltip: "Create a full bid order even if there is not enough stock on the CX."
      }, {
        default: a(() => [
          o(g, {
            modelValue: u(c),
            "onUpdate:modelValue": e[3] || (e[3] = (l) => m(c) ? c.value = l : null)
          }, {
            default: a(() => [...e[7] || (e[7] = [
              v("allow unfilled", -1)
            ])]),
            _: 1
          }, 8, ["modelValue"])
        ]),
        _: 1
      }),
      o(r, {
        label: "Use CX Inventory",
        tooltip: "Whether to use stock in the CX warehouse when calculating how much needs to be bought."
      }, {
        default: a(() => [
          o(g, {
            modelValue: u(p),
            "onUpdate:modelValue": e[4] || (e[4] = (l) => m(p) ? p.value = l : null)
          }, {
            default: a(() => [...e[8] || (e[8] = [
              v("use cx inventory", -1)
            ])]),
            _: 1
          }, 8, ["modelValue"])
        ]),
        _: 1
      })
    ], 64));
  }
});
export {
  H as default
};
