import { subscribe as m } from "./subscribe-async-generator.js";
import { $$ as a, _$$ as h } from "./select-dom.js";
import { C as y } from "./prun-css.js";
import O from "./tiles.js";
import v from "./feature-registry.js";
import n from "./cxob-depth-bars.module.css.js";
import g from "./table-rows-alternating-colors.module.css.js";
import { cxobStore as k } from "./cxob.js";
import { clamp as $ } from "./clamp.js";
import { isFiniteOrder as p } from "./orders.js";
import { refPrunId as B } from "./attributes.js";
import { watchEffectWhileNodeAlive as C } from "./watch.js";
import { computed as D } from "./runtime-core.esm-bundler.js";
function M(e) {
  const s = D(() => {
    const t = k.getByTicker(e.parameter);
    if (!t)
      return;
    const r = Math.max(
      f(t.sellingOrders),
      f(t.buyingOrders)
    ), o = /* @__PURE__ */ new Map();
    return l(o, t.sellingOrders, r), l(o, t.buyingOrders, r), o;
  });
  m(a(e.anchor, y.ScrollView.view), (t) => {
    m(a(t, "table"), async (r) => {
      const o = h(r, "tbody"), i = o[0], c = o[2];
      i === void 0 || c === void 0 || (r.classList.add(g.optOut), i.classList.add(n.tbody, n.asks), c.classList.add(n.tbody, n.bids), m(a(r, "tr"), (d) => {
        const u = B(d);
        C(d, () => {
          const b = s.value?.get(u.value ?? "") ?? 0;
          d.style.setProperty("--rp-market-depth", `${b}%`);
        });
      }));
    });
  });
}
function f(e) {
  let s = 0;
  for (const t of e) {
    if (!p(t))
      break;
    s += t.amount;
  }
  return s;
}
function l(e, s, t) {
  let r = 0, o = !1;
  for (const i of s) {
    if (!p(i)) {
      o = !0, e.set(i.id, 0);
      continue;
    }
    if (o) {
      e.set(i.id, 0);
      continue;
    }
    r += i.amount, e.set(i.id, $(r / t * 100, 0, 100));
  }
}
function S() {
  O.observe("CXOB", M);
}
v.add(import.meta.url, S, "CXOB: Adds market depth bars.");
