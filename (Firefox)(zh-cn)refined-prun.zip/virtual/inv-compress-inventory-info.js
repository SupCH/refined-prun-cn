import { subscribe as a } from "./subscribe-async-generator.js";
import { _$$ as c, $$ as m } from "./select-dom.js";
import { C as o } from "./prun-css.js";
import { applyCssRule as i } from "./refined-prun-css.js";
import p from "./tiles.js";
import l from "./feature-registry.js";
import r from "./inv-compress-inventory-info.module.css.js";
async function f(n) {
  a(m(n.anchor, o.StoreView.column), (s) => {
    const t = c(s, o.StoreView.capacity);
    if (t.length < 3)
      return;
    const e = document.createElement("div");
    e.classList.add(r.capacityContainer), e.appendChild(t[1]), e.appendChild(t[2]), t[0].after(e);
  });
}
function d() {
  i(["INV", "SHPI"], `.${o.StoreView.column}`, r.storeViewColumn), i(["INV", "SHPI"], `.${o.StoreView.container}`, r.storeViewContainer), i(["INV", "SHPI"], `.${o.InventorySortControls.controls}`, r.sortControls), p.observe(["INV", "SHPI"], f);
}
l.add(import.meta.url, d, "INV/SHPI: Compresses specific inventory info into a row.");
