import d from "./FinHeader.vue.js";
import y from "./EquityHistoryChart.vue.js";
import C from "./AssetPieChart.vue.js";
import T from "./LocationsPieChart.vue.js";
import { showBuffer as n } from "./buffers.js";
import { useXitParameters as I } from "./use-xit-parameters.js";
import N from "./SectionHeader.vue.js";
import { defineComponent as E, createElementBlock as l, openBlock as t, Fragment as m, createVNode as o, createElementVNode as p, withCtx as f, createTextVNode as c, createBlock as u } from "./runtime-core.esm-bundler.js";
import { ref as S, unref as r } from "./reactivity.esm-bundler.js";
import { normalizeClass as a } from "./shared.esm-bundler.js";
const $ = { style: { marginTop: "5px" } }, F = { key: 3 }, q = /* @__PURE__ */ E({
  __name: "FINCH",
  setup(H) {
    const i = I()[0]?.toUpperCase(), k = S(Math.random() < 0.01);
    return (s, e) => (t(), l("div", {
      class: a(s.$style.root)
    }, [
      r(k) ? (t(), l(m, { key: 0 }, [
        o(N, null, {
          default: f(() => [...e[3] || (e[3] = [
            c("Finch", -1)
          ])]),
          _: 1
        }),
        p("img", {
          src: "https://refined-prun.github.io/assets/finch.jpeg",
          alt: "Finch",
          class: a(s.$style.clickable),
          onClick: e[0] || (e[0] = (v) => k.value = !1)
        }, null, 2)
      ], 64)) : r(i) ? (t(), l(m, { key: 2 }, [
        r(i) === "EQUITY" ? (t(), u(y, {
          key: 0,
          pan: "",
          zoom: ""
        })) : r(i) === "ASSETS" ? (t(), u(C, { key: 1 })) : r(i) === "LOCATIONS" ? (t(), u(T, { key: 2 })) : (t(), l("span", F, "Error: Not a valid chart type"))
      ], 64)) : (t(), l(m, { key: 1 }, [
        o(d, null, {
          default: f(() => [...e[4] || (e[4] = [
            c("Equity History", -1)
          ])]),
          _: 1
        }),
        p("div", {
          style: { marginTop: "5px" },
          class: a(s.$style.clickable)
        }, [
          o(y, {
            "maintain-aspect-ratio": "",
            "on-chart-click": () => r(n)("XIT FINCH EQUITY")
          }, null, 8, ["on-chart-click"])
        ], 2),
        o(d, null, {
          default: f(() => [...e[5] || (e[5] = [
            c("Asset Breakdown", -1)
          ])]),
          _: 1
        }),
        p("div", $, [
          o(C, {
            class: a(s.$style.clickable),
            onClick: e[1] || (e[1] = () => r(n)("XIT FINCH ASSETS"))
          }, null, 8, ["class"]),
          o(T, {
            class: a(s.$style.clickable),
            onClick: e[2] || (e[2] = () => r(n)("XIT FINCH LOCATIONS"))
          }, null, 8, ["class"])
        ])
      ], 64))
    ], 2));
  }
});
export {
  q as default
};
