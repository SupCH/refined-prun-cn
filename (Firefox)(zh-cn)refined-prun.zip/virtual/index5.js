import { userData as a } from "./user-data.js";
import u from "./en.js";
import g from "./zh.js";
const f = {
  en: u,
  zh: g
};
function p(n, ...o) {
  const i = a.settings.language || (navigator.language.startsWith("zh"), "zh"), s = n.split(".");
  let e = f[i];
  for (const r of s)
    if (e && e[r])
      e = e[r];
    else {
      e = f.en;
      for (const t of s)
        if (e && e[t])
          e = e[t];
        else
          return n;
      break;
    }
  return typeof e == "string" ? e.replace(/{(\d+)}/g, (r, t) => typeof o[t] < "u" ? o[t] : r) : n;
}
export {
  p as t
};
