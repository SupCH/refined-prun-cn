import { Chart as D, PieController as j, LineController as q } from "./chart.js";
import { defineComponent as C, h as x, version as A, onMounted as K, onUnmounted as U, watch as k, nextTick as N } from "./runtime-core.esm-bundler.js";
import { shallowRef as O, ref as $, toRaw as P, isProxy as L } from "./reactivity.esm-bundler.js";
const w = {
  data: {
    type: Object,
    required: !0
  },
  options: {
    type: Object,
    default: () => ({})
  },
  plugins: {
    type: Array,
    default: () => []
  },
  datasetIdKey: {
    type: String,
    default: "label"
  },
  updateMode: {
    type: String,
    default: void 0
  }
}, z = {
  ariaLabel: {
    type: String
  },
  ariaDescribedby: {
    type: String
  }
}, B = {
  type: {
    type: String,
    required: !0
  },
  destroyDelay: {
    type: Number,
    default: 0
    // No delay by default
  },
  ...w,
  ...z
}, E = A[0] === "2" ? (t, e) => Object.assign(t, {
  attrs: e
}) : (t, e) => Object.assign(t, e);
function u(t) {
  return L(t) ? P(t) : t;
}
function F(t) {
  let e = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : t;
  return L(e) ? new Proxy(t, {}) : t;
}
function G(t, e) {
  const n = t.options;
  n && e && Object.assign(n, e);
}
function R(t, e) {
  t.labels = e;
}
function S(t, e, n) {
  const o = [];
  t.datasets = e.map((r) => {
    const a = t.datasets.find((c) => c[n] === r[n]);
    return !a || !r.data || o.includes(a) ? {
      ...r
    } : (o.push(a), Object.assign(a, r), a);
  });
}
function H(t, e) {
  const n = {
    labels: [],
    datasets: []
  };
  return R(n, t.labels), S(n, t.datasets, e), n;
}
const J = C({
  props: B,
  setup(t, e) {
    let { expose: n, slots: o } = e;
    const r = $(null), a = O(null);
    n({
      chart: a
    });
    const c = () => {
      if (!r.value) return;
      const { type: s, data: f, options: p, plugins: d, datasetIdKey: h } = t, y = H(f, h), i = F(y, f);
      a.value = new D(r.value, {
        type: s,
        data: i,
        options: {
          ...p
        },
        plugins: d
      });
    }, g = () => {
      const s = P(a.value);
      s && (t.destroyDelay > 0 ? setTimeout(() => {
        s.destroy(), a.value = null;
      }, t.destroyDelay) : (s.destroy(), a.value = null));
    }, M = (s) => {
      s.update(t.updateMode);
    };
    return K(c), U(g), k([
      () => t.options,
      () => t.data
    ], (s, f) => {
      let [p, d] = s, [h, y] = f;
      const i = P(a.value);
      if (!i)
        return;
      let b = !1;
      if (p) {
        const l = u(p), m = u(h);
        l && l !== m && (G(i, l), b = !0);
      }
      if (d) {
        const l = u(d.labels), m = u(y.labels), v = u(d.datasets), T = u(y.datasets);
        l !== m && (R(i.config.data, l), b = !0), v && v !== T && (S(i.config.data, v, t.datasetIdKey), b = !0);
      }
      b && N(() => {
        M(i);
      });
    }, {
      deep: !0
    }), () => x("canvas", {
      role: "img",
      ariaLabel: t.ariaLabel,
      ariaDescribedby: t.ariaDescribedby,
      ref: r
    }, [
      x("p", {}, [
        o.default ? o.default() : ""
      ])
    ]);
  }
});
function I(t, e) {
  return D.register(e), C({
    props: w,
    setup(n, o) {
      let { expose: r } = o;
      const a = O(null), c = (g) => {
        a.value = g?.chart;
      };
      return r({
        chart: a
      }), () => x(J, E({
        ref: c
      }, {
        type: t,
        ...n
      }));
    }
  });
}
const X = /* @__PURE__ */ I("line", q), Y = /* @__PURE__ */ I("pie", j);
export {
  J as Chart,
  X as Line,
  Y as Pie,
  I as createTypedChart
};
