import { contractsStore as i } from "./contracts.js";
import o from "./PrunLink.vue.js";
import { isFactionContract as y } from "./utils5.js";
import { defineComponent as f, computed as k, createElementBlock as l, createBlock as c, openBlock as t, withCtx as m, createTextVNode as s } from "./runtime-core.esm-bundler.js";
import { unref as e } from "./reactivity.esm-bundler.js";
import { normalizeClass as n, toDisplayString as d } from "./shared.esm-bundler.js";
const w = /* @__PURE__ */ f({
  __name: "ContractPartnerName",
  props: {
    contractLocalId: {}
  },
  setup(p) {
    const a = k(() => i.getByLocalId(p.contractLocalId));
    return (r, u) => e(a) ? e(y)(e(a)) ? (t(), c(o, {
      key: 1,
      command: `FA ${e(a).partner.countryCode}`,
      class: n(r.$style.label)
    }, {
      default: m(() => [
        s(d(e(a).partner.name), 1)
      ]),
      _: 1
    }, 8, ["command", "class"])) : e(a).partner.name ? (t(), c(o, {
      key: 2,
      command: `CO ${e(a).partner.code}`,
      class: n(r.$style.label)
    }, {
      default: m(() => [
        s(d(e(a).partner.name), 1)
      ]),
      _: 1
    }, 8, ["command", "class"])) : e(a).partner.code ? (t(), c(o, {
      key: 3,
      command: `CO ${e(a).partner.code}`,
      class: n(r.$style.label)
    }, null, 8, ["command", "class"])) : e(a).partner.currency ? (t(), l("div", {
      key: 4,
      class: n(r.$style.label)
    }, "Planetary Government", 2)) : (t(), l("div", {
      key: 5,
      class: n(r.$style.label)
    }, "Unknown", 2)) : (t(), l("div", {
      key: 0,
      class: n(r.$style.label)
    }, "Unknown", 2));
  }
});
export {
  w as default
};
