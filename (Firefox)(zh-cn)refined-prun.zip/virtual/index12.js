import { encodePacket as i } from "./encodePacket.browser.js";
import { decodePacket as l } from "./decodePacket.browser.js";
import "./commons.js";
const d = "", h = (c, r) => {
  const e = c.length, o = new Array(e);
  let t = 0;
  c.forEach((n, a) => {
    i(n, !1, (s) => {
      o[a] = s, ++t === e && r(o.join(d));
    });
  });
}, k = (c, r) => {
  const e = c.split(d), o = [];
  for (let t = 0; t < e.length; t++) {
    const n = l(e[t], r);
    if (o.push(n), n.type === "error")
      break;
  }
  return o;
};
export {
  l as decodePacket,
  k as decodePayload,
  i as encodePacket,
  h as encodePayload
};
