import { createEntityStore as s } from "./create-entity-store.js";
import { onApiMessage as E } from "./api-messages.js";
import { request as D } from "./request-hooks2.js";
import { computed as r } from "./runtime-core.esm-bundler.js";
const t = s(), o = t.state;
E({
  FOREX_TRADER_ORDERS(e) {
    t.setAll(e.orders), t.setFetched();
  },
  FOREX_TRADER_ORDER_ADDED(e) {
    t.addOne(e);
  },
  FOREX_TRADER_ORDER_UPDATED(e) {
    t.updateOne(e);
  },
  FOREX_TRADER_ORDER_REMOVED(e) {
    t.removeOne(e.orderId);
  }
});
const R = (() => {
  const e = o.all;
  return r(() => (o.fetched.value || D.fxos(), e.value));
})(), a = r(() => R.value?.filter((e) => e.status !== "FILLED")), _ = {
  ...o,
  all: R,
  active: a
};
export {
  _ as fxosStore
};
