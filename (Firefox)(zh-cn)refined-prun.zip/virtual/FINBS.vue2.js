import { t as a } from "./index5.js";
import g from "./BalanceSheetSection.vue.js";
import { calcTotalDeposits as P, calcTotalCashAndCashEquivalents as k, calcTotalLoansReceivable as I, calcTotalBaseInventory as A, calcTotalInventory as R, calcTotalCurrentAssets as L, calcTotalBuildingsMarketValue as q, calcTotalBuildings as B, calcTotalShips as E, calcTotalLongTermReceivables as V, calcTotalIntangibleAssets as N, calcTotalNonCurrentAssets as M, calcTotalLoansPayable as w, calcTotalCurrentLiabilities as D, calcTotalLongTermPayables as S, calcTotalNonCurrentLiabilities as x, calcTotalAssets as F, calcTotalLiabilities as G, calcEquity as U } from "./balance-sheet-summary.js";
import { liveBalanceSheet as j } from "./balance-sheet-live.js";
import { ddmmyyyy as f } from "./format.js";
import { lastBalance as u, previousBalance as b } from "./user-data-balance.js";
import { defineComponent as z, computed as r, createElementBlock as t, openBlock as i, createElementVNode as s, Fragment as o, createTextVNode as c, renderList as H, createVNode as J } from "./runtime-core.esm-bundler.js";
import { toDisplayString as l } from "./shared.esm-bundler.js";
import { unref as n } from "./reactivity.esm-bundler.js";
const ae = /* @__PURE__ */ z({
  __name: "FINBS",
  setup(K) {
    const d = r(() => ({
      name: a("finbs.currentAssets"),
      total: L,
      children: [
        {
          name: a("finbs.cashAndCashEquivalents"),
          value: k,
          children: [
            {
              name: a("finbs.cash"),
              value: (e) => e.assets?.current?.cashAndCashEquivalents?.cash
            },
            {
              name: a("finbs.deposits"),
              value: P,
              children: [
                {
                  name: a("finbs.cx"),
                  value: (e) => e.assets?.current?.cashAndCashEquivalents?.deposits?.cx
                },
                {
                  name: a("finbs.fx"),
                  value: (e) => e.assets?.current?.cashAndCashEquivalents?.deposits?.fx
                }
              ]
            },
            {
              name: a("finbs.mmMaterials"),
              tooltip: a("finbs.mmMaterialsTooltip"),
              value: (e) => e.assets?.current?.cashAndCashEquivalents?.mmMaterials
            }
          ]
        },
        {
          name: a("finbs.accountsReceivable"),
          value: (e) => e.assets?.current?.accountsReceivable
        },
        {
          name: a("finbs.loansReceivable"),
          value: I,
          children: [
            {
              name: a("finbs.principal"),
              value: (e) => e.assets?.current?.loansReceivable?.principal
            },
            {
              name: a("finbs.interest"),
              value: (e) => e.assets?.current?.loansReceivable?.interest
            }
          ]
        },
        {
          name: a("finbs.inventory"),
          value: R,
          children: [
            {
              name: a("finbs.cxListedMaterials"),
              value: (e) => e.assets?.current?.inventory?.cxListedMaterials
            },
            {
              name: a("finbs.cxInventory"),
              value: (e) => e.assets?.current?.inventory?.cxInventory
            },
            {
              name: a("finbs.materialsInTransit"),
              value: (e) => e.assets?.current?.inventory?.materialsInTransit
            },
            {
              name: a("finbs.baseInventory"),
              value: A,
              children: [
                {
                  name: a("finbs.finishedGoods"),
                  value: (e) => e.assets?.current?.inventory?.baseInventory?.finishedGoods
                },
                {
                  name: a("finbs.wip"),
                  value: (e) => e.assets?.current?.inventory?.baseInventory?.workInProgress
                },
                {
                  name: a("finbs.rawMaterials"),
                  value: (e) => e.assets?.current?.inventory?.baseInventory?.rawMaterials
                },
                {
                  name: a("finbs.workforceConsumables"),
                  value: (e) => e.assets?.current?.inventory?.baseInventory?.workforceConsumables
                },
                {
                  name: a("finbs.otherItems"),
                  value: (e) => e.assets?.current?.inventory?.baseInventory?.otherItems
                }
              ]
            },
            {
              name: a("finbs.fuelTanks"),
              value: (e) => e.assets?.current?.inventory?.fuelTanks
            },
            {
              name: a("finbs.materialsReceivable"),
              value: (e) => e.assets?.current?.inventory?.materialsReceivable
            }
          ]
        }
      ]
    })), p = r(() => ({
      name: a("finbs.nonCurrentAssets"),
      total: M,
      children: [
        {
          name: a("finbs.buildingsNet"),
          value: B,
          children: [
            {
              name: a("finbs.marketValue"),
              value: q,
              children: [
                {
                  name: a("finbs.infrastructure"),
                  value: (e) => e.assets?.nonCurrent?.buildings?.marketValue?.infrastructure
                },
                {
                  name: a("finbs.resourceExtraction"),
                  value: (e) => e.assets?.nonCurrent?.buildings?.marketValue?.resourceExtraction
                },
                {
                  name: a("finbs.production"),
                  value: (e) => e.assets?.nonCurrent?.buildings?.marketValue?.production
                }
              ]
            },
            {
              name: a("finbs.accDepreciation"),
              less: !0,
              value: (e) => e.assets?.nonCurrent?.buildings?.accumulatedDepreciation
            }
          ]
        },
        {
          name: a("finbs.shipsNet"),
          value: E,
          children: [
            {
              name: a("finbs.marketValue"),
              value: (e) => e.assets?.nonCurrent?.ships?.marketValue
            },
            {
              name: a("finbs.accDepreciation"),
              less: !0,
              value: (e) => e.assets?.nonCurrent?.ships?.accumulatedDepreciation
            }
          ]
        },
        {
          name: a("finbs.longTermReceivables"),
          value: V,
          children: [
            {
              name: a("finbs.accountsReceivable"),
              value: (e) => e.assets?.nonCurrent?.longTermReceivables?.accountsReceivable
            },
            {
              name: a("finbs.materialsInTransit"),
              value: (e) => e.assets?.nonCurrent?.longTermReceivables?.materialsInTransit
            },
            {
              name: a("finbs.materialsReceivable"),
              value: (e) => e.assets?.nonCurrent?.longTermReceivables?.materialsReceivable
            },
            {
              name: a("finbs.loansPrincipal"),
              value: (e) => e.assets?.nonCurrent?.longTermReceivables?.loansPrincipal
            }
          ]
        },
        {
          name: a("finbs.intangibleAssets"),
          value: N,
          children: [
            {
              name: a("finbs.hqUpgrades"),
              value: (e) => e.assets?.nonCurrent?.intangibleAssets?.hqUpgrades
            },
            {
              name: a("finbs.arc"),
              value: (e) => e.assets?.nonCurrent?.intangibleAssets?.arc
            }
          ]
        }
      ]
    })), y = r(() => ({
      name: a("finbs.currentLiabilities"),
      total: D,
      children: [
        {
          name: a("finbs.accountsPayable"),
          value: (e) => e.liabilities?.current?.accountsPayable
        },
        {
          name: a("finbs.materialsPayable"),
          value: (e) => e.liabilities?.current?.materialsPayable
        },
        {
          name: a("finbs.loansPayable"),
          value: w,
          children: [
            {
              name: a("finbs.principal"),
              value: (e) => e.liabilities?.current?.loansPayable?.principal
            },
            {
              name: a("finbs.interest"),
              value: (e) => e.liabilities?.current?.loansPayable?.interest
            }
          ]
        }
      ]
    })), h = r(() => ({
      name: a("finbs.nonCurrentLiabilities"),
      total: x,
      children: [
        {
          name: a("finbs.longTermPayables"),
          value: S,
          children: [
            {
              name: a("finbs.accountsPayable"),
              value: (e) => e.liabilities?.nonCurrent?.longTermPayables?.accountsPayable
            },
            {
              name: a("finbs.materialsPayable"),
              value: (e) => e.liabilities?.nonCurrent?.longTermPayables?.materialsPayable
            },
            {
              name: a("finbs.loansPrincipal"),
              value: (e) => e.liabilities?.nonCurrent?.longTermPayables?.loansPrincipal
            }
          ]
        }
      ]
    })), T = r(() => ({
      name: a("finbs.equity"),
      coloredTotal: !0,
      total: U,
      children: [
        {
          name: a("finbs.totalAssets"),
          value: F
        },
        {
          name: a("finbs.totalLiabilities"),
          less: !0,
          value: G
        }
      ]
    })), C = [
      d,
      p,
      y,
      h,
      T
    ];
    return (e, m) => (i(), t("table", null, [
      s("thead", null, [
        s("tr", null, [
          m[0] || (m[0] = s("th", null, " ", -1)),
          s("th", null, l(("t" in e ? e.t : n(a))("finbs.currentPeriod")), 1),
          s("th", null, [
            n(u) ? (i(), t(o, { key: 0 }, [
              c(l(n(f)(n(u).timestamp)), 1)
            ], 64)) : (i(), t(o, { key: 1 }, [
              c(l(("t" in e ? e.t : n(a))("finbs.lastPeriod")), 1)
            ], 64))
          ]),
          s("th", null, [
            n(b) ? (i(), t(o, { key: 0 }, [
              c(l(n(f)(n(b).timestamp)), 1)
            ], 64)) : (i(), t(o, { key: 1 }, [
              c(l(("t" in e ? e.t : n(a))("finbs.previousPeriod")), 1)
            ], 64))
          ]),
          s("th", null, l(("t" in e ? e.t : n(a))("finbs.change")), 1)
        ])
      ]),
      (i(), t(o, null, H(C, (v) => J(g, {
        key: v.value.name,
        current: n(j),
        last: n(u),
        previous: n(b),
        section: v.value
      }, null, 8, ["current", "last", "previous", "section"])), 64))
    ]));
  }
});
export {
  ae as default
};
