import s from "./AddTaskItem.vue2.js";
import o from "./AddTaskItem.vue3.js";
import t from "./plugin-vue_export-helper.js";
const e = {
  $style: o
}, f = /* @__PURE__ */ t(s, [["__cssModules", e]]);
export {
  f as default
};
