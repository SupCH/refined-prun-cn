import o from "./MaterialIcon.vue.js";
import { defineComponent as r, createBlock as t, createCommentVNode as n, openBlock as a } from "./runtime-core.esm-bundler.js";
import { normalizeClass as i } from "./shared.esm-bundler.js";
const u = /* @__PURE__ */ r({
  __name: "LMMaterialIcon",
  props: {
    amount: {},
    ticker: {}
  },
  setup(m) {
    return (e, c) => e.ticker ? (a(), t(o, {
      key: 0,
      ticker: e.ticker,
      amount: e.amount,
      size: "inline",
      class: i(e.$style.icon)
    }, null, 8, ["ticker", "amount", "class"])) : n("", !0);
  }
});
export {
  u as default
};
