const e = "rp-Header__heading___01ac829", _ = "rp-Header__editable___e2b3973", a = "rp-Header__input___6bbe41a", t = {
  heading: e,
  editable: _,
  input: a
};
export {
  t as default,
  _ as editable,
  e as heading,
  a as input
};
