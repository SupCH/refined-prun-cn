function r(l, e, o) {
  const t = JSON.stringify(l), i = new Blob([t], { type: "application/json" }), n = document.createElement("a");
  n.download = e, n.href = URL.createObjectURL(i), document.body.appendChild(n), n.click(), document.body.removeChild(n);
}
function c(l) {
  const e = document.createElement("input");
  e.type = "file", e.accept = ".json", e.style.display = "none", document.body.appendChild(e), e.addEventListener("change", () => {
    const o = e.files?.[0];
    if (o && o.type === "application/json") {
      const t = new FileReader();
      t.onload = (i) => {
        try {
          const n = i.target.result;
          if (typeof n == "string") {
            const a = JSON.parse(n);
            l(a);
          } else
            alert("Invalid JSON file.");
        } catch (n) {
          console.error("Error parsing JSON:", n), alert("Invalid JSON file.");
        }
      }, t.readAsText(o);
    } else
      alert("Please upload a valid JSON file.");
    document.body.removeChild(e);
  }), e.click();
}
export {
  r as downloadJson,
  c as uploadJson
};
