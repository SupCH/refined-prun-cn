import r from "./PrunLink.vue.js";
import { defineComponent as p, computed as n, createBlock as m, openBlock as d, withCtx as i, createTextVNode as c } from "./runtime-core.esm-bundler.js";
import { unref as e } from "./reactivity.esm-bundler.js";
import { toDisplayString as s } from "./shared.esm-bundler.js";
const P = /* @__PURE__ */ p({
  __name: "AddressLink",
  props: {
    address: {}
  },
  setup(l) {
    const t = n(() => l.address.lines[1]), u = n(() => t.value.type === "PLANET"), o = n(() => t.value.entity.naturalId), a = n(() => t.value.entity.name);
    return (f, _) => e(u) ? (d(), m(r, {
      key: 0,
      inline: "",
      command: `PLI ${e(o)}`
    }, {
      default: i(() => [
        c(s(e(a)), 1)
      ]),
      _: 1
    }, 8, ["command"])) : (d(), m(r, {
      key: 1,
      inline: "",
      command: `STNS ${e(o)}`
    }, {
      default: i(() => [
        c(s(e(a)), 1)
      ]),
      _: 1
    }, 8, ["command"]));
  }
});
export {
  P as default
};
