import { applyCssRule as r } from "./refined-prun-css.js";
import i from "./feature-registry.js";
import t from "./css-utils.module.css.js";
function o() {
  r(["FLT", "FLTS", "FLTP"], "tr > :first-child", t.hidden);
}
i.add(import.meta.url, o, 'FLT: Hides the "Transponder" column.');
