import { applyCssRule as i } from "./refined-prun-css.js";
import { C as e } from "./prun-css.js";
import m from "./feature-registry.js";
import r from "./css-utils.module.css.js";
import t from "./hide-item-names.module.css.js";
function o() {
  i(`.${e.GridItemView.name}`, r.hidden), i(`.${e.GridItemView.container}`, t.gridItem);
}
m.add(
  import.meta.url,
  o,
  "Hides item names and removes item grid gaps in all inventories."
);
