import f from "./MaterialList.vue2.js";
export {
  f as default
};
