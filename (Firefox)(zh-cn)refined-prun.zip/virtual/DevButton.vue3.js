const t = "rp-DevButton__button___8c66896", o = {
  button: t
};
export {
  t as button,
  o as default
};
