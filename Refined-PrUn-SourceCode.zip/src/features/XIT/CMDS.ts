import CMDS from '@src/features/XIT/CMDS.vue';

xit.add({
  command: 'CMDS',
  name: 'XIT COMMANDS',
  description: 'List of available XIT commands.',
  component: () => CMDS,
});
