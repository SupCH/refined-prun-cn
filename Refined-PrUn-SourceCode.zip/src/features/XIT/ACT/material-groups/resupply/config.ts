export interface Config {
  planet: string;
}
