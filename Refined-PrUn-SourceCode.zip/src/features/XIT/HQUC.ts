import HQUC from '@src/features/XIT/HQUC.vue';

xit.add({
  command: ['HQUC'],
  name: 'HQ UPGRADE CALCULATOR',
  description: 'HQ upgrade calculator.',
  component: () => HQUC,
});
