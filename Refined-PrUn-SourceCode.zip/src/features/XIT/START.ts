import START from '@src/features/XIT/START.vue';

xit.add({
  command: 'START',
  name: 'REFINED PRUN INTRO',
  description: 'Refined PrUn start screen.',
  component: () => START,
});
