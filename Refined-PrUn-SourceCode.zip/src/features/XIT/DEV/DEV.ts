import DEV from '@src/features/XIT/DEV/DEV.vue';

xit.add({
  command: 'DEV',
  name: 'DEVELOPMENT MENU',
  description: 'Development menu.',
  component: () => DEV,
});
