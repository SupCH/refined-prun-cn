declare module '*.module.css' {
  const value: { [className: string]: string };
  export default value;
}

declare module '*.vue';
