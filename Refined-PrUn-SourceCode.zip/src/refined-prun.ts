import '@src/refined-prun.css';

import '@src/infrastructure/shell';

import '@src/utils/dayjs';
import '@src/utils/chartjs-dayjs';

import '@src/features/basic';
import '@src/features/advanced';
import '@src/features/XIT';

import '@src/main';
