export function tagUI() {
  // This method was used for data-prun-id tagging.
  // Currently, no other elements need it, but it's left here for future use.
}
