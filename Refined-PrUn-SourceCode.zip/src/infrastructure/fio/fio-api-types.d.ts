declare namespace FioApi {
  interface PlanetShort {
    PlanetNaturalId: string;
    PlanetName: string;
  }

  type AllPlanetsShort = PlanetShort[];
}
