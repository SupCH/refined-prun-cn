interface RefinedPrunConfig {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  userData: any;
  version: string;
  url: {
    manifest: string;
    allplanets: string;
  };
}
