const checkmark = "rp-Checkmark__checkmark___44e639f";
const circle = "rp-Checkmark__circle___2e7994b";
const mark = "rp-Checkmark__mark___44a25ff";
const markCompleted = "rp-Checkmark__markCompleted___d4c6992";
const style0 = {
  checkmark,
  circle,
  mark,
  markCompleted
};
export {
  checkmark,
  circle,
  style0 as default,
  mark,
  markCompleted
};
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiQ2hlY2ttYXJrLnZ1ZTMuanMiLCJzb3VyY2VzIjpbXSwic291cmNlc0NvbnRlbnQiOltdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7OyJ9
