import PrunLink from "./PrunLink.vue.js";
import { isFactionContract } from "./utils5.js";
import { defineComponent, computed, createBlock, openBlock, withCtx, createTextVNode } from "./runtime-core.esm-bundler.js";
import { normalizeStyle, toDisplayString } from "./shared.esm-bundler.js";
import { unref } from "./reactivity.esm-bundler.js";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "ContractLink",
  props: {
    contract: {}
  },
  setup(__props) {
    const linkStyle = computed(() => ({
      display: isFactionContract(__props.contract) ? "inline" : "block"
    }));
    return (_ctx, _cache) => {
      return openBlock(), createBlock(PrunLink, {
        command: `CONT ${_ctx.contract.localId}`,
        style: normalizeStyle(unref(linkStyle))
      }, {
        default: withCtx(() => [
          createTextVNode(toDisplayString(_ctx.contract.name || _ctx.contract.localId), 1)
        ]),
        _: 1
      }, 8, ["command", "style"]);
    };
  }
});
export {
  _sfc_main as default
};
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiQ29udHJhY3RMaW5rLnZ1ZS5qcyIsInNvdXJjZXMiOlsiLi4vLi4vLi4vc3JjL2ZlYXR1cmVzL1hJVC9DT05UQy9Db250cmFjdExpbmsudnVlIl0sInNvdXJjZXNDb250ZW50IjpbIjxzY3JpcHQgc2V0dXAgbGFuZz1cInRzXCI+XG5pbXBvcnQgUHJ1bkxpbmsgZnJvbSAnQHNyYy9jb21wb25lbnRzL1BydW5MaW5rLnZ1ZSc7XG5pbXBvcnQgeyBpc0ZhY3Rpb25Db250cmFjdCB9IGZyb20gJ0BzcmMvZmVhdHVyZXMvWElUL0NPTlRTL3V0aWxzJztcblxuY29uc3QgeyBjb250cmFjdCB9ID0gZGVmaW5lUHJvcHM8eyBjb250cmFjdDogUHJ1bkFwaS5Db250cmFjdCB9PigpO1xuXG5jb25zdCBsaW5rU3R5bGUgPSBjb21wdXRlZCgoKSA9PiAoe1xuICBkaXNwbGF5OiBpc0ZhY3Rpb25Db250cmFjdChjb250cmFjdCkgPyAnaW5saW5lJyA6ICdibG9jaycsXG59KSk7XG48L3NjcmlwdD5cblxuPHRlbXBsYXRlPlxuICA8UHJ1bkxpbmsgOmNvbW1hbmQ9XCJgQ09OVCAke2NvbnRyYWN0LmxvY2FsSWR9YFwiIDpzdHlsZT1cImxpbmtTdHlsZVwiPlxuICAgIHt7IGNvbnRyYWN0Lm5hbWUgfHwgY29udHJhY3QubG9jYWxJZCB9fVxuICA8L1BydW5MaW5rPlxuPC90ZW1wbGF0ZT5cbiJdLCJuYW1lcyI6WyJfbm9ybWFsaXplU3R5bGUiLCJfdW5yZWYiLCJfY3JlYXRlVGV4dFZOb2RlIiwiX3RvRGlzcGxheVN0cmluZyJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7QUFNQSxVQUFBLFlBQUEsU0FBQSxPQUFBO0FBQUEsTUFBa0MsU0FBQSxrQkFBQSxRQUFBLFFBQUEsSUFBQSxXQUFBO0FBQUEsSUFDa0IsRUFBQTs7O1FBT3ZDLFNBQUEsUUFBQSxLQUFBLFNBQUEsT0FBQTtBQUFBLFFBRmlDLE9BQUFBLGVBQUFDLE1BQUEsU0FBQSxDQUFBO0FBQUEsTUFBcUIsR0FBQTtBQUFBO1VBQ3hCQyxnQkFBQUMsZ0JBQUEsS0FBQSxTQUFBLFFBQUEsS0FBQSxTQUFBLE9BQUEsR0FBQSxDQUFBO0FBQUEsUUFBSCxDQUFBO0FBQUE7Ozs7OyJ9
