const icon = "rp-LMMaterialIcon__icon___97af3c9";
const style0 = {
  icon
};
export {
  style0 as default,
  icon
};
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiTE1NYXRlcmlhbEljb24udnVlMy5qcyIsInNvdXJjZXMiOltdLCJzb3VyY2VzQ29udGVudCI6W10sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7In0=
