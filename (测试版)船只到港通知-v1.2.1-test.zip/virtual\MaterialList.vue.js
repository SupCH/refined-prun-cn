import { isSelfCondition } from "./utils5.js";
import ShipmentIcon from "./ShipmentIcon.vue.js";
import MaterialIcon from "./MaterialIcon.vue.js";
import { objectId } from "./object-id.js";
import { defineComponent, computed, createElementBlock, openBlock, Fragment, renderList, createCommentVNode, createVNode } from "./runtime-core.esm-bundler.js";
import { unref } from "./reactivity.esm-bundler.js";
const _hoisted_1 = {
  key: 0,
  style: { marginBottom: "4px" }
};
const _hoisted_2 = {
  key: 1,
  style: { marginBottom: "4px" }
};
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "MaterialList",
  props: {
    contract: {}
  },
  setup(__props) {
    const icons = computed(() => {
      const result = [];
      for (const condition of __props.contract.conditions) {
        switch (condition.type) {
          case "DELIVERY_SHIPMENT": {
            if (isSelfCondition(__props.contract, condition)) {
              result.push({ type: "SHIPMENT", shipmentId: condition.shipmentItemId });
              continue;
            }
            break;
          }
          case "PROVISION":
          case "PICKUP_SHIPMENT": {
            continue;
          }
        }
        const quantity = condition.quantity;
        if (!quantity?.material) {
          continue;
        }
        const amount = quantity.amount;
        const ticker = quantity.material.ticker;
        result.push({ type: "MATERIAL", ticker, amount });
      }
      return result;
    });
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", null, [
        (openBlock(true), createElementBlock(Fragment, null, renderList(unref(icons), (icon) => {
          return openBlock(), createElementBlock(Fragment, {
            key: unref(objectId)(icon)
          }, [
            icon.type === "SHIPMENT" ? (openBlock(), createElementBlock("div", _hoisted_1, [
              createVNode(ShipmentIcon, {
                size: "medium",
                "shipment-id": icon.shipmentId
              }, null, 8, ["shipment-id"])
            ])) : createCommentVNode("", true),
            icon.type === "MATERIAL" ? (openBlock(), createElementBlock("div", _hoisted_2, [
              createVNode(MaterialIcon, {
                size: "medium",
                ticker: icon.ticker,
                amount: icon.amount
              }, null, 8, ["ticker", "amount"])
            ])) : createCommentVNode("", true)
          ], 64);
        }), 128))
      ]);
    };
  }
});
export {
  _sfc_main as default
};
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiTWF0ZXJpYWxMaXN0LnZ1ZS5qcyIsInNvdXJjZXMiOlsiLi4vLi4vLi4vc3JjL2ZlYXR1cmVzL1hJVC9DT05UUy9NYXRlcmlhbExpc3QudnVlIl0sInNvdXJjZXNDb250ZW50IjpbIjxzY3JpcHQgc2V0dXAgbGFuZz1cInRzXCI+XG5pbXBvcnQgeyBpc1NlbGZDb25kaXRpb24gfSBmcm9tICdAc3JjL2ZlYXR1cmVzL1hJVC9DT05UUy91dGlscyc7XG5pbXBvcnQgU2hpcG1lbnRJY29uIGZyb20gJ0BzcmMvY29tcG9uZW50cy9TaGlwbWVudEljb24udnVlJztcbmltcG9ydCBNYXRlcmlhbEljb24gZnJvbSAnQHNyYy9jb21wb25lbnRzL01hdGVyaWFsSWNvbi52dWUnO1xuaW1wb3J0IHsgb2JqZWN0SWQgfSBmcm9tICdAc3JjL3V0aWxzL29iamVjdC1pZCc7XG5cbmNvbnN0IHsgY29udHJhY3QgfSA9IGRlZmluZVByb3BzPHsgY29udHJhY3Q6IFBydW5BcGkuQ29udHJhY3QgfT4oKTtcblxuaW50ZXJmYWNlIFNoaXBtZW50SWNvblByb3BzIHtcbiAgdHlwZTogJ1NISVBNRU5UJztcbiAgc2hpcG1lbnRJZDogc3RyaW5nO1xufVxuXG5pbnRlcmZhY2UgTWF0ZXJpYWxJY29uUHJvcHMge1xuICB0eXBlOiAnTUFURVJJQUwnO1xuICB0aWNrZXI6IHN0cmluZztcbiAgYW1vdW50OiBudW1iZXI7XG59XG5cbmNvbnN0IGljb25zID0gY29tcHV0ZWQoKCkgPT4ge1xuICBjb25zdCByZXN1bHQ6IChTaGlwbWVudEljb25Qcm9wcyB8IE1hdGVyaWFsSWNvblByb3BzKVtdID0gW107XG4gIGZvciAoY29uc3QgY29uZGl0aW9uIG9mIGNvbnRyYWN0LmNvbmRpdGlvbnMpIHtcbiAgICBzd2l0Y2ggKGNvbmRpdGlvbi50eXBlKSB7XG4gICAgICBjYXNlICdERUxJVkVSWV9TSElQTUVOVCc6IHtcbiAgICAgICAgaWYgKGlzU2VsZkNvbmRpdGlvbihjb250cmFjdCwgY29uZGl0aW9uKSkge1xuICAgICAgICAgIHJlc3VsdC5wdXNoKHsgdHlwZTogJ1NISVBNRU5UJywgc2hpcG1lbnRJZDogY29uZGl0aW9uLnNoaXBtZW50SXRlbUlkISB9KTtcbiAgICAgICAgICBjb250aW51ZTtcbiAgICAgICAgfVxuICAgICAgICBicmVhaztcbiAgICAgIH1cbiAgICAgIGNhc2UgJ1BST1ZJU0lPTic6XG4gICAgICBjYXNlICdQSUNLVVBfU0hJUE1FTlQnOiB7XG4gICAgICAgIGNvbnRpbnVlO1xuICAgICAgfVxuICAgIH1cblxuICAgIGNvbnN0IHF1YW50aXR5ID0gY29uZGl0aW9uLnF1YW50aXR5O1xuICAgIGlmICghcXVhbnRpdHk/Lm1hdGVyaWFsKSB7XG4gICAgICBjb250aW51ZTtcbiAgICB9XG5cbiAgICBjb25zdCBhbW91bnQgPSBxdWFudGl0eS5hbW91bnQ7XG4gICAgY29uc3QgdGlja2VyID0gcXVhbnRpdHkubWF0ZXJpYWwudGlja2VyO1xuICAgIHJlc3VsdC5wdXNoKHsgdHlwZTogJ01BVEVSSUFMJywgdGlja2VyOiB0aWNrZXIsIGFtb3VudDogYW1vdW50IH0pO1xuICB9XG4gIHJldHVybiByZXN1bHQ7XG59KTtcbjwvc2NyaXB0PlxuXG48dGVtcGxhdGU+XG4gIDxkaXY+XG4gICAgPHRlbXBsYXRlIHYtZm9yPVwiaWNvbiBpbiBpY29uc1wiIDprZXk9XCJvYmplY3RJZChpY29uKVwiPlxuICAgICAgPGRpdiB2LWlmPVwiaWNvbi50eXBlID09PSAnU0hJUE1FTlQnXCIgOnN0eWxlPVwieyBtYXJnaW5Cb3R0b206ICc0cHgnIH1cIj5cbiAgICAgICAgPFNoaXBtZW50SWNvbiBzaXplPVwibWVkaXVtXCIgOnNoaXBtZW50LWlkPVwiaWNvbi5zaGlwbWVudElkXCIgLz5cbiAgICAgIDwvZGl2PlxuICAgICAgPGRpdiB2LWlmPVwiaWNvbi50eXBlID09PSAnTUFURVJJQUwnXCIgOnN0eWxlPVwieyBtYXJnaW5Cb3R0b206ICc0cHgnIH1cIj5cbiAgICAgICAgPE1hdGVyaWFsSWNvbiBzaXplPVwibWVkaXVtXCIgOnRpY2tlcj1cImljb24udGlja2VyXCIgOmFtb3VudD1cImljb24uYW1vdW50XCIgLz5cbiAgICAgIDwvZGl2PlxuICAgIDwvdGVtcGxhdGU+XG4gIDwvZGl2PlxuPC90ZW1wbGF0ZT5cblxuPHN0eWxlIHNjb3BlZD48L3N0eWxlPlxuIl0sIm5hbWVzIjpbIl9vcGVuQmxvY2siLCJfY3JlYXRlRWxlbWVudEJsb2NrIiwiX0ZyYWdtZW50IiwiX3JlbmRlckxpc3QiLCJfdW5yZWYiLCJfY3JlYXRlVk5vZGUiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBbUJBLFVBQUEsUUFBQSxTQUFBLE1BQUE7QUFDRSxZQUFBLFNBQUEsQ0FBQTtBQUNBLGlCQUFBLGFBQUEsUUFBQSxTQUFBLFlBQUE7QUFDRSxnQkFBQSxVQUFBLE1BQUE7QUFBQSxVQUF3QixLQUFBLHFCQUFBO0FBRXBCLGdCQUFBLGdCQUFBLFFBQUEsVUFBQSxTQUFBLEdBQUE7QUFDRSxxQkFBQSxLQUFBLEVBQUEsTUFBQSxZQUFBLFlBQUEsVUFBQSxnQkFBQTtBQUNBO0FBQUEsWUFBQTtBQUVGO0FBQUEsVUFBQTtBQUFBLFVBQ0YsS0FBQTtBQUFBLFVBQ0ssS0FBQSxtQkFBQTtBQUVIO0FBQUEsVUFBQTtBQUFBLFFBQ0Y7QUFHRixjQUFBLFdBQUEsVUFBQTtBQUNBLFlBQUEsQ0FBQSxVQUFBLFVBQUE7QUFDRTtBQUFBLFFBQUE7QUFHRixjQUFBLFNBQUEsU0FBQTtBQUNBLGNBQUEsU0FBQSxTQUFBLFNBQUE7QUFDQSxlQUFBLEtBQUEsRUFBQSxNQUFBLFlBQUEsUUFBQSxRQUFBO0FBQUEsTUFBZ0U7QUFFbEUsYUFBQTtBQUFBLElBQU8sQ0FBQTs7O1NBY0RBLFVBQUEsSUFBQSxHQUFBQyxtQkFBQUMsVUFBQSxNQUFBQyxXQUFBQyxNQUFBLEtBQUEsR0FBQSxDQUFBLFNBQUE7OztVQVIrQyxHQUFBO0FBQUE7Y0FHM0NDLFlBQUEsY0FBQTtBQUFBLGdCQUR5RCxNQUFBO0FBQUEsZ0JBQTFDLGVBQUEsS0FBQTtBQUFBLGNBQTRCLEdBQUEsTUFBQSxHQUFBLENBQUEsYUFBQSxDQUFBO0FBQUE7O2NBSTNDQSxZQUFBLGNBQUE7QUFBQSxnQkFEc0UsTUFBQTtBQUFBLGdCQUF2RCxRQUFBLEtBQUE7QUFBQSxnQkFBdUIsUUFBQSxLQUFBO0FBQUEsY0FBc0IsR0FBQSxNQUFBLEdBQUEsQ0FBQSxVQUFBLFFBQUEsQ0FBQTtBQUFBOzs7Ozs7OyJ9
