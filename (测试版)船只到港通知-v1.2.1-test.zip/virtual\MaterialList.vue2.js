import { materialsStore } from "./materials.js";
import MaterialRow from "./MaterialRow.vue.js";
import { sortMaterials } from "./sort-materials.js";
import { defineComponent, computed, createElementBlock, openBlock, Fragment, renderList, createBlock } from "./runtime-core.esm-bundler.js";
import { unref } from "./reactivity.esm-bundler.js";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "MaterialList",
  props: {
    burn: {}
  },
  setup(__props) {
    const materials = computed(() => Object.keys(__props.burn.burn).map(materialsStore.getByTicker));
    const sorted = computed(() => sortMaterials(materials.value.filter((x) => x !== void 0)));
    return (_ctx, _cache) => {
      return openBlock(true), createElementBlock(Fragment, null, renderList(unref(sorted), (material) => {
        return openBlock(), createBlock(MaterialRow, {
          key: material.id,
          burn: _ctx.burn.burn[material.ticker],
          material
        }, null, 8, ["burn", "material"]);
      }), 128);
    };
  }
});
export {
  _sfc_main as default
};
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiTWF0ZXJpYWxMaXN0LnZ1ZTIuanMiLCJzb3VyY2VzIjpbIi4uLy4uLy4uL3NyYy9mZWF0dXJlcy9YSVQvQlVSTi9NYXRlcmlhbExpc3QudnVlIl0sInNvdXJjZXNDb250ZW50IjpbIjxzY3JpcHQgc2V0dXAgbGFuZz1cInRzXCI+XG5pbXBvcnQgeyBtYXRlcmlhbHNTdG9yZSB9IGZyb20gJ0BzcmMvaW5mcmFzdHJ1Y3R1cmUvcHJ1bi1hcGkvZGF0YS9tYXRlcmlhbHMnO1xuaW1wb3J0IHsgUGxhbmV0QnVybiB9IGZyb20gJ0BzcmMvY29yZS9idXJuJztcbmltcG9ydCBNYXRlcmlhbFJvdyBmcm9tICdAc3JjL2ZlYXR1cmVzL1hJVC9CVVJOL01hdGVyaWFsUm93LnZ1ZSc7XG5pbXBvcnQgeyBzb3J0TWF0ZXJpYWxzIH0gZnJvbSAnQHNyYy9jb3JlL3NvcnQtbWF0ZXJpYWxzJztcblxuY29uc3QgeyBidXJuIH0gPSBkZWZpbmVQcm9wczx7IGJ1cm46IFBsYW5ldEJ1cm4gfT4oKTtcblxuY29uc3QgbWF0ZXJpYWxzID0gY29tcHV0ZWQoKCkgPT4gT2JqZWN0LmtleXMoYnVybi5idXJuKS5tYXAobWF0ZXJpYWxzU3RvcmUuZ2V0QnlUaWNrZXIpKTtcbmNvbnN0IHNvcnRlZCA9IGNvbXB1dGVkKCgpID0+IHNvcnRNYXRlcmlhbHMobWF0ZXJpYWxzLnZhbHVlLmZpbHRlcih4ID0+IHggIT09IHVuZGVmaW5lZCkpKTtcbjwvc2NyaXB0PlxuXG48dGVtcGxhdGU+XG4gIDxNYXRlcmlhbFJvd1xuICAgIHYtZm9yPVwibWF0ZXJpYWwgaW4gc29ydGVkXCJcbiAgICA6a2V5PVwibWF0ZXJpYWwuaWRcIlxuICAgIDpidXJuPVwiYnVybi5idXJuW21hdGVyaWFsLnRpY2tlcl1cIlxuICAgIDptYXRlcmlhbD1cIm1hdGVyaWFsXCIgLz5cbjwvdGVtcGxhdGU+XG4iXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7QUFRQSxVQUFBLFlBQUEsU0FBQSxNQUFBLE9BQUEsS0FBQSxRQUFBLEtBQUEsSUFBQSxFQUFBLElBQUEsZUFBQSxXQUFBLENBQUE7QUFDQSxVQUFBLFNBQUEsU0FBQSxNQUFBLGNBQUEsVUFBQSxNQUFBLE9BQUEsQ0FBQSxNQUFBLE1BQUEsTUFBQSxDQUFBLENBQUE7Ozs7VUFRMkIsS0FBQSxTQUFBO0FBQUEsVUFGUixNQUFBLEtBQUEsS0FBQSxLQUFBLFNBQUEsTUFBQTtBQUFBLFVBQ2lCO0FBQUEsUUFDL0IsR0FBQSxNQUFBLEdBQUEsQ0FBQSxRQUFBLFVBQUEsQ0FBQTtBQUFBOzs7OyJ9
