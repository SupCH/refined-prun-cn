const tbody = "rp-cxob-depth-bars__tbody___95e0d47";
const bids = "rp-cxob-depth-bars__bids___b3c73d2";
const asks = "rp-cxob-depth-bars__asks___2e5ab59";
const $style = {
  tbody,
  bids,
  asks
};
export {
  asks,
  bids,
  $style as default,
  tbody
};
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY3hvYi1kZXB0aC1iYXJzLm1vZHVsZS5jc3MuanMiLCJzb3VyY2VzIjpbXSwic291cmNlc0NvbnRlbnQiOltdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7OzsifQ==
