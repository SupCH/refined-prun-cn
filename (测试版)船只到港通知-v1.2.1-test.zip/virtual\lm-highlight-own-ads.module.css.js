const ownAd = "rp-lm-highlight-own-ads__ownAd___e546d51";
const $style = {
  ownAd
};
export {
  $style as default,
  ownAd
};
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibG0taGlnaGxpZ2h0LW93bi1hZHMubW9kdWxlLmNzcy5qcyIsInNvdXJjZXMiOltdLCJzb3VyY2VzQ29udGVudCI6W10sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7In0=
