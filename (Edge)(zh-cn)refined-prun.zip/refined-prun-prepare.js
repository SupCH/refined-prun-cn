function s() {
  if (document.documentElement.classList.contains("refined-prun"))
    return;
  const r = new MutationObserver(() => t());
  r.observe(document, { childList: !0, subtree: !0 });
  const t = () => {
    for (const e of Array.from(document.head?.getElementsByTagName("script") ?? []))
      e.src.includes("apex.prosperousuniverse.com") && (e.textContent = e.src, e.src = "", r.disconnect());
  };
  t();
}
s();
