const e = "rp-font-awesome__solid___33343de", o = "rp-font-awesome__regular___638eb05", _ = {
  solid: e,
  regular: o
};
export {
  _ as default,
  o as regular,
  e as solid
};
