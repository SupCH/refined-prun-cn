import { C as k } from "./prun-css.js";
import b from "./ActionBar.vue.js";
import u from "./PrunButton.vue.js";
import { createId as U } from "./create-id.js";
import B from "./PrunLink.vue.js";
import V from "./TextInput.vue.js";
import { vDraggable as I } from "./vue-draggable-plus.js";
import v from "./grip.module.css.js";
import O from "./font-awesome.module.css.js";
import { defineComponent as w, createElementBlock as o, openBlock as m, createElementVNode as e, createVNode as r, Fragment as f, renderList as $, withCtx as a, createTextVNode as d, withDirectives as A } from "./runtime-core.esm-bundler.js";
import { ref as D, unref as i } from "./reactivity.esm-bundler.js";
import { toDisplayString as E, normalizeClass as p } from "./shared.esm-bundler.js";
const H = { key: 0 }, M = { key: 0 }, W = /* @__PURE__ */ w({
  __name: "CommandList",
  props: {
    list: {}
  },
  setup(g) {
    const C = D(!1);
    function N() {
      g.list.commands.push({
        id: U(),
        label: "Help",
        command: "XIT HELP"
      });
    }
    function L(t) {
      g.list.commands = g.list.commands.filter((l) => l !== t);
    }
    const y = D(!1), T = {
      animation: 150,
      handle: `.${v.grip}`,
      onStart: () => y.value = !0,
      onEnd: () => y.value = !1
    };
    return (t, l) => i(C) ? (m(), o(f, { key: 1 }, [
      e("table", null, [
        l[7] || (l[7] = e("thead", null, [
          e("tr", null, [
            e("th", null, "Label"),
            e("th", null, "Command"),
            e("th")
          ])
        ], -1)),
        t.list.commands.length === 0 ? (m(), o("tbody", M, [...l[5] || (l[5] = [
          e("tr", null, [
            e("td", null, "No commands.")
          ], -1)
        ])])) : A((m(), o("tbody", {
          key: 1,
          class: p(i(y) ? t.$style.dragging : null)
        }, [
          (m(!0), o(f, null, $(t.list.commands, (n) => (m(), o("tr", {
            key: n.id
          }, [
            e("td", null, [
              e("span", {
                class: p([i(v).grip, i(O).solid, t.$style.grip])
              }, E(""), 2),
              e("div", {
                class: p([("C" in t ? t.C : i(k)).forms.input, t.$style.inline])
              }, [
                r(V, {
                  modelValue: n.label,
                  "onUpdate:modelValue": (s) => n.label = s
                }, null, 8, ["modelValue", "onUpdate:modelValue"])
              ], 2)
            ]),
            e("td", null, [
              e("div", {
                class: p(("C" in t ? t.C : i(k)).forms.input)
              }, [
                r(V, {
                  modelValue: n.command,
                  "onUpdate:modelValue": (s) => n.command = s
                }, null, 8, ["modelValue", "onUpdate:modelValue"])
              ], 2)
            ]),
            e("td", null, [
              r(u, {
                danger: "",
                onClick: (s) => L(n)
              }, {
                default: a(() => [...l[6] || (l[6] = [
                  d("DELETE", -1)
                ])]),
                _: 2
              }, 1032, ["onClick"])
            ])
          ]))), 128))
        ], 2)), [
          [i(I), [t.list.commands, T]]
        ])
      ]),
      r(b, null, {
        default: a(() => [
          r(u, {
            primary: "",
            onClick: N
          }, {
            default: a(() => [...l[8] || (l[8] = [
              d("ADD COMMAND", -1)
            ])]),
            _: 1
          }),
          r(u, {
            primary: "",
            onClick: l[1] || (l[1] = (n) => C.value = !1)
          }, {
            default: a(() => [...l[9] || (l[9] = [
              d("DONE", -1)
            ])]),
            _: 1
          })
        ]),
        _: 1
      })
    ], 64)) : (m(), o(f, { key: 0 }, [
      e("table", null, [
        l[3] || (l[3] = e("thead", null, [
          e("tr", null, [
            e("th", null, "Commands")
          ])
        ], -1)),
        e("tbody", null, [
          t.list.commands.length === 0 ? (m(), o("tr", H, [...l[2] || (l[2] = [
            e("td", null, "No commands.", -1)
          ])])) : (m(!0), o(f, { key: 1 }, $(t.list.commands, (n) => (m(), o("tr", {
            key: n.id
          }, [
            e("td", null, [
              r(B, {
                command: n.command
              }, {
                default: a(() => [
                  d(E(n.label), 1)
                ]),
                _: 2
              }, 1032, ["command"])
            ])
          ]))), 128))
        ])
      ]),
      r(b, null, {
        default: a(() => [
          r(u, {
            primary: "",
            onClick: l[0] || (l[0] = (n) => C.value = !0)
          }, {
            default: a(() => [...l[4] || (l[4] = [
              d("EDIT", -1)
            ])]),
            _: 1
          })
        ]),
        _: 1
      })
    ], 64));
  }
});
export {
  W as default
};
