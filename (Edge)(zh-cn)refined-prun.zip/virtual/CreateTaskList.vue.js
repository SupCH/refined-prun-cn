import { C as d } from "./prun-css.js";
import p from "./PrunButton.vue.js";
import C from "./SectionHeader.vue.js";
import c from "./Active.vue.js";
import _ from "./TextInput.vue.js";
import V from "./Commands.vue.js";
import { defineComponent as k, createElementBlock as N, openBlock as E, createVNode as t, createElementVNode as v, withCtx as r, createTextVNode as m } from "./runtime-core.esm-bundler.js";
import { ref as T, isRef as $, unref as l } from "./reactivity.esm-bundler.js";
import { normalizeClass as B } from "./shared.esm-bundler.js";
const D = /* @__PURE__ */ k({
  __name: "CreateTaskList",
  props: {
    onCreate: { type: Function }
  },
  emits: ["close"],
  setup(a, { emit: i }) {
    const f = i, o = T("");
    function s() {
      o.value.length !== 0 && (a.onCreate(o.value), f("close"));
    }
    return (n, e) => (E(), N("div", {
      class: B(("C" in n ? n.C : l(d)).DraftConditionEditor.form)
    }, [
      t(C, null, {
        default: r(() => [...e[1] || (e[1] = [
          m("New Task List", -1)
        ])]),
        _: 1
      }),
      v("form", null, [
        t(c, { label: "Name" }, {
          default: r(() => [
            t(_, {
              modelValue: l(o),
              "onUpdate:modelValue": e[0] || (e[0] = (u) => $(o) ? o.value = u : null)
            }, null, 8, ["modelValue"])
          ]),
          _: 1
        }),
        t(V, null, {
          default: r(() => [
            t(p, {
              primary: "",
              onClick: s
            }, {
              default: r(() => [...e[2] || (e[2] = [
                m("CREATE", -1)
              ])]),
              _: 1
            })
          ]),
          _: 1
        })
      ])
    ], 2));
  }
});
export {
  D as default
};
