import { subscribe as t } from "./subscribe-async-generator.js";
import { $$ as r, $ as p } from "./select-dom.js";
import { C as i } from "./prun-css.js";
import s from "./tiles.js";
import c from "./feature-registry.js";
function f(n) {
  t(r(n.anchor, i.ScrollView.view), (e) => {
    t(r(e, "table"), async (a) => {
      const o = await p(a, i.ComExOrderBookPanel.spread), m = o.getBoundingClientRect();
      e.scrollTop = Math.max(
        o.offsetTop - e.clientHeight / 2 + m.height / 2,
        0
      );
    });
  });
}
function d() {
  s.observe("CXOB", f);
}
c.add(import.meta.url, d, "CXOB: Centers the order book on open.");
