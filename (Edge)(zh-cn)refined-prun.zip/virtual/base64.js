function r(l) {
  return btoa(l).replaceAll("+", "-").replaceAll("/", ".").replaceAll("=", "");
}
function t(l) {
  let e = l.replaceAll("-", "+").replaceAll(".", "/");
  for (; e.length % 4 !== 0; )
    e += "=";
  return atob(e);
}
export {
  t as prunAtob,
  r as prunBtoa
};
