import n from "./GridItemView.vue.js";
import a from "./MaterialIcon.vue.js";
import { getMaterialNameByTicker as i } from "./util.js";
import { defineComponent as o, computed as m, createBlock as c, openBlock as u, withCtx as f, createVNode as l } from "./runtime-core.esm-bundler.js";
import { unref as k } from "./reactivity.esm-bundler.js";
const h = /* @__PURE__ */ o({
  __name: "GridMaterialIcon",
  props: {
    amount: {},
    text: {},
    ticker: {},
    warning: { type: Boolean }
  },
  setup(e) {
    const r = m(() => e.text !== void 0 ? e.text : e.ticker === "SHPT" ? "Shipment" : i(e.ticker) ?? "???");
    return (t, p) => (u(), c(n, { name: k(r) }, {
      default: f(() => [
        l(a, {
          ticker: t.ticker,
          amount: t.amount,
          warning: t.warning
        }, null, 8, ["ticker", "amount", "warning"])
      ]),
      _: 1
    }, 8, ["name"]));
  }
});
export {
  h as default
};
