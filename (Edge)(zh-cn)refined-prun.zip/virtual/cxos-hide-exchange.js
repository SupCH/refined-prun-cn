import { applyCssRule as i } from "./refined-prun-css.js";
import r from "./feature-registry.js";
import t from "./css-utils.module.css.js";
function m() {
  i("CXOS", "tr > :first-child", t.hidden);
}
r.add(import.meta.url, m, 'CXOS: Hides the "Exchange" column.');
