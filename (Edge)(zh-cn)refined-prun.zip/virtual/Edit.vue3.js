import m from "./Active.vue.js";
import b from "./SelectInput.vue.js";
import { storageSort as V, serializeStorage as v } from "./utils3.js";
import { configurableValue as y } from "./shared-types.js";
import x from "./RadioItem.vue.js";
import { getRefuelOrigins as F } from "./utils6.js";
import { defineComponent as h, computed as k, createElementBlock as M, openBlock as w, createVNode as n, withCtx as r, createTextVNode as B, Fragment as C } from "./runtime-core.esm-bundler.js";
import { ref as f, unref as a, isRef as g } from "./reactivity.esm-bundler.js";
const I = /* @__PURE__ */ h({
  __name: "Edit",
  props: {
    action: {},
    pkg: {}
  },
  setup(t, { expose: d }) {
    const s = k(() => {
      const i = F().sort(V).map(v);
      return i.unshift(y), i;
    }), o = f(t.action.origin ?? s.value[0]), l = f(t.action.buyMissingFuel ?? !0);
    function p() {
      return !0;
    }
    function c() {
      t.action.origin = o.value, t.action.buyMissingFuel = l.value;
    }
    return d({ validate: p, save: c }), (i, e) => (w(), M(C, null, [
      n(m, { label: "Origin" }, {
        default: r(() => [
          n(b, {
            modelValue: a(o),
            "onUpdate:modelValue": e[0] || (e[0] = (u) => g(o) ? o.value = u : null),
            options: a(s)
          }, null, 8, ["modelValue", "options"])
        ]),
        _: 1
      }),
      n(m, {
        label: "Buy Missing Fuel",
        tooltip: "Whether the fuel will be bought if there is not enough stock (CX warehouse only)."
      }, {
        default: r(() => [
          n(x, {
            modelValue: a(l),
            "onUpdate:modelValue": e[1] || (e[1] = (u) => g(l) ? l.value = u : null)
          }, {
            default: r(() => [...e[2] || (e[2] = [
              B("buy fuel", -1)
            ])]),
            _: 1
          }, 8, ["modelValue"])
        ]),
        _: 1
      })
    ], 64));
  }
});
export {
  I as default
};
