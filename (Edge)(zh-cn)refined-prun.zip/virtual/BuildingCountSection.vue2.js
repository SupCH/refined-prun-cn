import { C as n } from "./prun-css.js";
import { sitesStore as f } from "./sites.js";
import k from "./BuildingIcon.vue.js";
import { defineComponent as C, computed as g, createElementBlock as l, openBlock as s, createElementVNode as m, Fragment as u, renderList as B, createBlock as y } from "./runtime-core.esm-bundler.js";
import { normalizeClass as c } from "./shared.esm-bundler.js";
import { unref as o } from "./reactivity.esm-bundler.js";
const b = /* @__PURE__ */ C({
  __name: "BuildingCountSection",
  props: {
    naturalId: {}
  },
  setup(d) {
    const p = g(() => {
      const e = /* @__PURE__ */ new Map(), a = f.getByPlanetNaturalId(d.naturalId)?.platforms ?? [];
      for (const r of a) {
        const i = r.module.reactorTicker;
        e.set(i, (e.get(i) ?? 0) + 1);
      }
      const t = [...e.keys()];
      return t.sort(), t.map((r) => [r, e.get(r)]);
    });
    return (e, a) => (s(), l(u, null, [
      m("h2", {
        class: c([("C" in e ? e.C : o(n)).Site.header, ("C" in e ? e.C : o(n)).ui.header2, ("C" in e ? e.C : o(n)).fonts.fontRegular])
      }, "Buildings", 2),
      m("div", {
        class: c(e.$style.list)
      }, [
        (s(!0), l(u, null, B(o(p), (t) => (s(), y(k, {
          key: t[0],
          ticker: t[0],
          amount: t[1]
        }, null, 8, ["ticker", "amount"]))), 128))
      ], 2)
    ], 64));
  }
});
export {
  b as default
};
