const i = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/", r = typeof Uint8Array > "u" ? [] : new Uint8Array(256);
for (let e = 0; e < i.length; e++)
  r[i.charCodeAt(e)] = e;
const g = (e) => {
  let t = e.length * 0.75, y = e.length, n, o = 0, h, d, c, l;
  e[e.length - 1] === "=" && (t--, e[e.length - 2] === "=" && t--);
  const A = new ArrayBuffer(t), f = new Uint8Array(A);
  for (n = 0; n < y; n += 4)
    h = r[e.charCodeAt(n)], d = r[e.charCodeAt(n + 1)], c = r[e.charCodeAt(n + 2)], l = r[e.charCodeAt(n + 3)], f[o++] = h << 2 | d >> 4, f[o++] = (d & 15) << 4 | c >> 2, f[o++] = (c & 3) << 6 | l & 63;
  return A;
};
export {
  g as decode
};
