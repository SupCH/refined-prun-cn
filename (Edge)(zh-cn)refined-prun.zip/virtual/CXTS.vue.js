import { cxosStore as B } from "./cxos.js";
import D from "./DateRow.vue.js";
import N from "./TradeRow.vue.js";
import E from "./LoadingSpinner.vue.js";
import { clamp as L } from "./clamp.js";
import { isEmpty as _ } from "./is-empty.js";
import { defineComponent as g, computed as v, onBeforeUnmount as w, createBlock as T, createElementBlock as u, openBlock as l, createElementVNode as r, Fragment as c, renderList as S, createVNode as x } from "./runtime-core.esm-bundler.js";
import { ref as A, unref as o } from "./reactivity.esm-bundler.js";
const C = { key: 1 }, F = { key: 0 }, $ = /* @__PURE__ */ g({
  __name: "CXTS",
  setup(R) {
    const m = v(() => B.all.value), s = v(() => {
      const n = [];
      for (const t of m.value)
        for (const d of t.trades)
          n.push({
            order: t,
            trade: d,
            date: d.time.timestamp
          });
      n.sort((t, d) => d.date - t.date);
      const a = [];
      if (_(n))
        return a;
      let e = {
        date: p(n[0].date),
        trades: [],
        totals: {}
      };
      a.push(e);
      for (const t of n) {
        t.date < e.date && (e = {
          date: p(t.date),
          trades: [],
          totals: {}
        }, a.push(e)), e.trades.push(t);
        const d = t.trade.price.currency, y = t.trade.price.amount * t.trade.amount, k = e.totals[d] ??= { purchases: 0, sales: 0 };
        t.order.type === "SELLING" ? k.sales += y : k.purchases += y;
      }
      return a;
    });
    function p(n) {
      return new Date(new Date(n).toDateString()).getTime();
    }
    const i = A(1);
    let f = 0;
    function h() {
      f = requestAnimationFrame(h), m.value ? i.value = L(i.value + 1, 0, s.value.length) : i.value = 1;
    }
    return w(() => cancelAnimationFrame(f)), h(), (n, a) => o(m) === void 0 ? (l(), T(E, { key: 0 })) : (l(), u("table", C, [
      a[1] || (a[1] = r("thead", null, [
        r("tr", null, [
          r("th", null, "Time"),
          r("th", null, "Type"),
          r("th", null, "Ticker"),
          r("th", null, "Partner"),
          r("th", null, "Amount"),
          r("th", null, "Price"),
          r("th", null, "Total")
        ])
      ], -1)),
      r("tbody", null, [
        o(_)(o(s)) ? (l(), u("tr", F, [...a[0] || (a[0] = [
          r("td", { colSpan: "7" }, "No recent trades", -1)
        ])])) : (l(!0), u(c, { key: 1 }, S(o(i), (e) => (l(), u(c, {
          key: o(s)[e - 1].date
        }, [
          x(D, {
            date: o(s)[e - 1].date,
            totals: o(s)[e - 1].totals,
            "hide-totals": o(s)[e - 1].trades.length === 1
          }, null, 8, ["date", "totals", "hide-totals"]),
          (l(!0), u(c, null, S(o(s)[e - 1].trades, (t) => (l(), T(N, {
            key: t.trade.id,
            date: t.date,
            order: t.order,
            trade: t.trade
          }, null, 8, ["date", "order", "trade"]))), 128))
        ], 64))), 128))
      ])
    ]));
  }
});
export {
  $ as default
};
