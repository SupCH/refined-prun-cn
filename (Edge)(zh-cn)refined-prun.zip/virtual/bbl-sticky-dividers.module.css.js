const d = "rp-bbl-sticky-dividers__divider___ccb162a", i = {
  divider: d
};
export {
  i as default,
  d as divider
};
