import { materialsStore as m } from "./materials.js";
import u from "./MaterialRow.vue.js";
import { sortMaterials as c } from "./sort-materials.js";
import { defineComponent as l, computed as t, createElementBlock as s, openBlock as o, Fragment as p, renderList as f, createBlock as b } from "./runtime-core.esm-bundler.js";
import { unref as d } from "./reactivity.esm-bundler.js";
const v = /* @__PURE__ */ l({
  __name: "MaterialList",
  props: {
    burn: {}
  },
  setup(n) {
    const a = t(() => Object.keys(n.burn.burn).map(m.getByTicker)), i = t(() => c(a.value.filter((r) => r !== void 0)));
    return (r, k) => (o(!0), s(p, null, f(d(i), (e) => (o(), b(u, {
      key: e.id,
      burn: r.burn.burn[e.ticker],
      material: e
    }, null, 8, ["burn", "material"]))), 128));
  }
});
export {
  v as default
};
