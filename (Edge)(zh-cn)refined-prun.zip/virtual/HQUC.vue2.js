import { calculateHQUpgradeMaterials as c } from "./hq.js";
import { companyStore as u } from "./company.js";
import _ from "./MaterialPurchaseTable.vue.js";
import { useTileState as n } from "./user-data-tiles.js";
import v from "./PrunButton.vue.js";
import f from "./Active.vue.js";
import V from "./Commands.vue.js";
import i from "./NumberInput.vue.js";
import { defineComponent as T, computed as x, createElementBlock as C, openBlock as E, createElementVNode as N, createVNode as l, withCtx as t, createTextVNode as U, Fragment as $ } from "./runtime-core.esm-bundler.js";
import { isRef as s, unref as m } from "./reactivity.esm-bundler.js";
const w = /* @__PURE__ */ T({
  __name: "HQUC",
  setup(b) {
    const e = n("from", u.value?.headquarters.level ?? 1), o = n("to", e.value + 1), d = x(() => c(e.value, o.value));
    function p() {
      e.value = u.value?.headquarters.level ?? 1, o.value = e.value + 1;
    }
    return (k, a) => (E(), C($, null, [
      N("form", null, [
        l(f, { label: "From" }, {
          default: t(() => [
            l(i, {
              modelValue: m(e),
              "onUpdate:modelValue": a[0] || (a[0] = (r) => s(e) ? e.value = r : null)
            }, null, 8, ["modelValue"])
          ]),
          _: 1
        }),
        l(f, { label: "To" }, {
          default: t(() => [
            l(i, {
              modelValue: m(o),
              "onUpdate:modelValue": a[1] || (a[1] = (r) => s(o) ? o.value = r : null)
            }, null, 8, ["modelValue"])
          ]),
          _: 1
        }),
        l(V, null, {
          default: t(() => [
            l(v, {
              primary: "",
              onClick: p
            }, {
              default: t(() => [...a[2] || (a[2] = [
                U("RESET", -1)
              ])]),
              _: 1
            })
          ]),
          _: 1
        })
      ]),
      l(_, { materials: m(d) }, null, 8, ["materials"])
    ], 64));
  }
});
export {
  w as default
};
