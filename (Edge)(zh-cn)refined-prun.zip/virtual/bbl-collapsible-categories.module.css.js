const e = "rp-bbl-collapsible-categories__divider___b0465ea", i = {
  divider: e
};
export {
  i as default,
  e as divider
};
