import o from "./ExecuteActionPackage.vue2.js";
import s from "./ExecuteActionPackage.vue3.js";
import t from "./plugin-vue_export-helper.js";
const e = {
  $style: s
}, f = /* @__PURE__ */ t(o, [["__cssModules", e]]);
export {
  f as default
};
