import { subscribe as e } from "./subscribe-async-generator.js";
import { $$ as r } from "./select-dom.js";
import { C as t } from "./prun-css.js";
import m from "./tiles.js";
import n from "./feature-registry.js";
function s(o) {
  e(r(o.anchor, t.SectionList.button), (i) => {
    i.children[1]?.classList.add(t.Button.danger);
  });
}
function d() {
  m.observe("BBL", s);
}
n.add(import.meta.url, d, 'BBL: Applies the "danger" style to the "Demolish" button.');
