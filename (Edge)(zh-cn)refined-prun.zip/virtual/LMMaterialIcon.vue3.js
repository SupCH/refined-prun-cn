const c = "rp-LMMaterialIcon__icon___97af3c9", o = {
  icon: c
};
export {
  o as default,
  c as icon
};
