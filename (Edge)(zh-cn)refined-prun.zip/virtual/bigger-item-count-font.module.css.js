const t = "rp-bigger-item-count-font__indicator___43b9d75", i = {
  indicator: t
};
export {
  i as default,
  t as indicator
};
