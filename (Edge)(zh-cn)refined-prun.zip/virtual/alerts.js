import { createEntityStore as s } from "./create-entity-store.js";
import { onApiMessage as o } from "./api-messages.js";
const t = s(), r = t.state;
o({
  ALERTS_ALERTS(e) {
    t.setMany(e.alerts), t.setFetched();
  },
  ALERTS_ALERT(e) {
    t.setOne(e);
  }
});
const c = {
  ...r
};
export {
  c as alertsStore
};
