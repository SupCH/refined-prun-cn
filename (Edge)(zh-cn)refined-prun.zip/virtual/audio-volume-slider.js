import { subscribe as r } from "./subscribe-async-generator.js";
import { $$ as m, $ as i } from "./select-dom.js";
import { C as o } from "./prun-css.js";
import a from "./feature-registry.js";
import { setAudioVolume as n } from "./audio-interceptor.js";
import { userData as u } from "./user-data.js";
import { createFragmentApp as f } from "./vue-fragment-app.js";
import s from "./AudioVolume.vue.js";
import { watchEffect as d, createVNode as p } from "./runtime-core.esm-bundler.js";
function c() {
  d(() => {
    n(u.settings.audioVolume);
  }), r(m(document, o.MenuHeadItem.menu), async (t) => {
    const e = await i(t, o.RadioItem.container);
    f(() => p(s, null, null)).after(e);
  });
}
a.add(import.meta.url, c, "Adds a volume slider to the game settings in the top-right corner of the screen.");
