import m from "./ContractLink.vue2.js";
import d from "./MaterialList.vue.js";
import s from "./PartnerLink.vue.js";
import r from "./ConditionList.vue.js";
import { isSelfCondition as f, isPartnerCondition as u } from "./utils4.js";
import { defineComponent as p, computed as a, createElementBlock as C, openBlock as h, createElementVNode as c, createVNode as n } from "./runtime-core.esm-bundler.js";
import { unref as e } from "./reactivity.esm-bundler.js";
const k = { style: { width: "32px", paddingLeft: "10px" } }, P = /* @__PURE__ */ p({
  __name: "ContractRow",
  props: {
    contract: {}
  },
  setup(o) {
    const i = a(() => o.contract.conditions.filter((t) => f(o.contract, t))), l = a(() => o.contract.conditions.filter((t) => u(o.contract, t)));
    return (t, B) => (h(), C("tr", null, [
      c("td", null, [
        n(m, { contract: t.contract }, null, 8, ["contract"])
      ]),
      c("td", k, [
        n(d, { contract: t.contract }, null, 8, ["contract"])
      ]),
      c("td", null, [
        n(s, { contract: t.contract }, null, 8, ["contract"]),
        n(r, {
          conditions: e(l),
          contract: t.contract
        }, null, 8, ["conditions", "contract"])
      ]),
      c("td", null, [
        n(r, {
          conditions: e(i),
          contract: t.contract
        }, null, 8, ["conditions", "contract"])
      ])
    ]));
  }
});
export {
  P as default
};
