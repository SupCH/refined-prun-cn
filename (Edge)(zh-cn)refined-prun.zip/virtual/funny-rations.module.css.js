const n = "rp-funny-rations__funny___dbff329", t = "rp-funny-rations__rat___3a6bcad", _ = {
  funny: n,
  rat: t
};
export {
  _ as default,
  n as funny,
  t as rat
};
