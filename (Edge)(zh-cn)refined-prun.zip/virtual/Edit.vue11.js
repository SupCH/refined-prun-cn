import f from "./Edit.vue4.js";
export {
  f as default
};
