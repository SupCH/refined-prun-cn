const n = [];
function e() {
  window.Audio = new Proxy(Audio, {
    construct(o, i) {
      const t = new o(...i);
      return n.push(t), t;
    }
  });
}
function r(o) {
  for (const i of u())
    i.volume = o;
}
function d() {
  const o = u()[0];
  o !== void 0 && (o.paused ? o.play() : o.currentTime = 0);
}
function u() {
  return n.filter((o) => o.src.startsWith(location.origin));
}
export {
  e as initAudioInterceptor,
  d as playAudio,
  r as setAudioVolume
};
