import f from "./Active.vue.js";
export {
  f as default
};
