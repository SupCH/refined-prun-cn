async function n(t) {
  return await (await fetch(t)).json();
}
export {
  n as fetchJson
};
