import { sitesStore as f, getBuildingLastRepair as m } from "./sites.js";
import { sumMapValues as v } from "./utils.js";
import { getEntityNameFromAddress as p } from "./addresses.js";
import { timestampEachMinute as g } from "./dayjs.js";
import { calcBuildingMarketValue as b, calcBuildingCondition as y } from "./buildings.js";
import { diffDays as B } from "./time-diff.js";
import { sumBy as M } from "./sum-by.js";
import { computed as u } from "./runtime-core.esm-bundler.js";
const r = u(() => {
  const e = f.all.value;
  if (!e)
    return;
  const t = [];
  for (const i of e) {
    const n = p(i.address), o = /* @__PURE__ */ new Map();
    for (const a of i.platforms) {
      const d = a.module.reactorTicker;
      let l = o.get(d);
      if (l === void 0) {
        if (l = b(a, i), l === void 0)
          return;
        o.set(d, l);
      }
      t.push({
        location: n,
        building: a,
        value: l
      });
    }
  }
  return t;
}), c = u(() => {
  if (!r.value)
    return;
  const e = g.value, t = /* @__PURE__ */ new Map();
  for (const i of r.value) {
    const n = m(i.building), o = B(n, e, !0), a = i.value * (1 - y(o));
    t.set(i.building.id, a);
  }
  return t;
}), C = u(() => {
  if (!r.value || !c.value)
    return;
  const e = /* @__PURE__ */ new Map();
  for (const t of r.value) {
    const i = c.value.get(t.building.id);
    if (i === void 0)
      return;
    const n = t.value - i;
    e.set(t.location, (e.get(t.location) ?? 0) + n);
  }
  return e;
}), D = {
  marketValue: u(() => M(r.value, (e) => e.value)),
  infrastructure: u(() => s(["CORE", "STORAGE", "HABITATION"])),
  resourceExtraction: u(() => s(["RESOURCES"])),
  production: u(() => s(["PRODUCTION"])),
  accumulatedDepreciation: u(() => v(c.value))
};
function s(e) {
  if (!r.value)
    return;
  let t = 0;
  for (const i of e) {
    const n = r.value.filter((o) => o.building.module.type === i);
    for (const o of n)
      t += o.value;
  }
  return t;
}
export {
  D as buildings,
  C as buildingsNetValueByLocation
};
