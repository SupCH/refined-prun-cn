import { observeDescendantListChanged as o } from "./mutation-observer.js";
function s(n, a, t) {
  o(n, () => {
    const e = a();
    e && e.lastChild !== t && e.appendChild(t);
  });
}
export {
  s as keepLast
};
