import { applyCssRule as t } from "./refined-prun-css.js";
import { C as o } from "./prun-css.js";
import i from "./feature-registry.js";
import r from "./css-utils.module.css.js";
import m from "./lm-hide-rating.module.css.js";
function e() {
  t("LM", `.${o.RatingIcon.container}`, r.hidden), t("LM", `.${o.CommodityAd.text}`, m.text);
}
i.add(import.meta.url, e, "LM: Hides rating icon from ads.");
