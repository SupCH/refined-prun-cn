import { getDefaultExportFromCjs as r } from "./commonjsHelpers.js";
import { __require as a } from "./advancedFormat2.js";
var o = a();
const m = /* @__PURE__ */ r(o);
export {
  m as default
};
