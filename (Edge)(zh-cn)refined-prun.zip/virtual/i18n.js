import { materialsStore as r } from "./materials.js";
let a = {};
const n = /* @__PURE__ */ new Map();
function l() {
  a = window.PrUn_i18n;
  for (const e of r.all.value) {
    const t = o(e);
    t && n.set(t, e);
  }
}
function o(e) {
  return e ? a[`Material.${e?.name}.name`]?.[0]?.value : void 0;
}
function m(e) {
  return e ? n.get(e) : void 0;
}
export {
  a as PrunI18N,
  m as getMaterialByName,
  o as getMaterialName,
  l as loadPrunI18N
};
