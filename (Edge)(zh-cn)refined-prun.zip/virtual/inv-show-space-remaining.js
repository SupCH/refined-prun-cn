import { subscribe as v } from "./subscribe-async-generator.js";
import { _$$ as f, $$ as h } from "./select-dom.js";
import { C as p } from "./prun-css.js";
import S from "./tiles.js";
import w from "./feature-registry.js";
import { fixed02 as c } from "./format.js";
import { getInvStore as I } from "./store-id.js";
import { createReactiveSpan as l } from "./reactive-element.js";
import { computed as i } from "./runtime-core.esm-bundler.js";
function g(o) {
  const e = i(() => I(o.parameter)), [a, r] = o.command === "SHPI" ? [0, 1] : [1, 2];
  v(h(o.anchor, p.StoreView.column), (u) => {
    const t = f(u, p.StoreView.capacity);
    if (t.length < 2)
      return;
    const d = i(
      () => e.value ? ` (${c(e.value.weightCapacity - e.value.weightLoad)}t)` : void 0
    ), m = l(t[a], d);
    m.style.whiteSpace = "pre", t[a].appendChild(m);
    const s = i(
      () => e.value ? ` (${c(e.value.volumeCapacity - e.value.volumeLoad)}m³)` : void 0
    ), n = l(t[r], s);
    n.style.whiteSpace = "pre", t[r].appendChild(n);
  });
}
function y() {
  S.observe(["INV", "SHPI"], g);
}
w.add(
  import.meta.url,
  y,
  "INV/SHPI: Shows the remaining weight and volume capacity of the selected store in INV and SHPI"
);
