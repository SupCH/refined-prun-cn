import s from "./BFR.vue2.js";
import o from "./BFR.vue3.js";
import t from "./plugin-vue_export-helper.js";
const r = {
  $style: o
}, f = /* @__PURE__ */ t(s, [["__cssModules", r]]);
export {
  f as default
};
