import d from "./Active.vue.js";
import { sitesStore as h } from "./sites.js";
import { getEntityNameFromAddress as E } from "./addresses.js";
import O from "./SelectInput.vue.js";
import U from "./NumberInput.vue.js";
import { comparePlanets as C } from "./util.js";
import S from "./TextInput.vue.js";
import b from "./RadioItem.vue.js";
import { materialsStore as $ } from "./materials.js";
import { t as u } from "./index5.js";
import { configurableValue as L } from "./shared-types.js";
import { defineComponent as N, computed as T, createElementBlock as F, openBlock as W, createVNode as a, withCtx as n, createTextVNode as x, Fragment as j } from "./runtime-core.esm-bundler.js";
import { ref as s, unref as e, isRef as f } from "./reactivity.esm-bundler.js";
import { toDisplayString as k } from "./shared.esm-bundler.js";
const Z = /* @__PURE__ */ N({
  __name: "Edit",
  props: {
    group: {}
  },
  setup(t, { expose: w }) {
    const V = T(() => {
      const o = (h.all.value ?? []).map((l) => E(l.address)).filter((l) => l !== void 0).sort(C);
      return o.unshift(L), o;
    }), m = s(t.group.planet ?? V.value[0]), g = s(!1), i = s(
      typeof t.group.days == "string" ? parseInt(t.group.days || "10") : t.group.days ?? 10
    ), y = s(!1), p = s(t.group.exclusions?.join(", ") ?? ""), c = s(t.group.useBaseInv ?? !0), v = s(t.group.consumablesOnly ?? !1);
    function B() {
      let o = !0;
      return g.value = !m.value, o &&= !g.value, y.value = i.value <= 0, o &&= !y.value, o;
    }
    function I() {
      t.group.planet = m.value, t.group.days = i.value, t.group.exclusions = p.value.split(",").map((o) => $.getByTicker(o.trim())?.ticker).filter((o) => o !== void 0), t.group.useBaseInv = c.value, t.group.consumablesOnly = v.value;
    }
    return w({ validate: B, save: I }), (o, l) => (W(), F(j, null, [
      a(d, {
        label: e(u)("act.planet"),
        error: e(g)
      }, {
        default: n(() => [
          a(O, {
            modelValue: e(m),
            "onUpdate:modelValue": l[0] || (l[0] = (r) => f(m) ? m.value = r : null),
            options: e(V)
          }, null, 8, ["modelValue", "options"])
        ]),
        _: 1
      }, 8, ["label", "error"]),
      a(d, {
        label: e(u)("act.days"),
        tooltip: "The number of days of supplies to refill the planet with.",
        error: e(y)
      }, {
        default: n(() => [
          a(U, {
            modelValue: e(i),
            "onUpdate:modelValue": l[1] || (l[1] = (r) => f(i) ? i.value = r : null)
          }, null, 8, ["modelValue"])
        ]),
        _: 1
      }, 8, ["label", "error"]),
      a(d, {
        label: e(u)("act.materialExclusions"),
        tooltip: "Materials to be excluded from the group. List material tickers separated by commas."
      }, {
        default: n(() => [
          a(S, {
            modelValue: e(p),
            "onUpdate:modelValue": l[2] || (l[2] = (r) => f(p) ? p.value = r : null)
          }, null, 8, ["modelValue"])
        ]),
        _: 1
      }, 8, ["label"]),
      a(d, {
        label: e(u)("act.useBaseInv"),
        tooltip: "Whether to count the materials currently in the base towards the totals."
      }, {
        default: n(() => [
          a(b, {
            modelValue: e(c),
            "onUpdate:modelValue": l[3] || (l[3] = (r) => f(c) ? c.value = r : null)
          }, {
            default: n(() => [
              x(k(e(u)("act.useBaseInv").toLowerCase()), 1)
            ]),
            _: 1
          }, 8, ["modelValue"])
        ]),
        _: 1
      }, 8, ["label"]),
      a(d, {
        label: e(u)("act.workforceOnly"),
        tooltip: "Whether to limit the materials in the group to workforce consumables only."
      }, {
        default: n(() => [
          a(b, {
            modelValue: e(v),
            "onUpdate:modelValue": l[4] || (l[4] = (r) => f(v) ? v.value = r : null)
          }, {
            default: n(() => [
              x(k(e(u)("act.workforceOnly").toLowerCase()), 1)
            ]),
            _: 1
          }, 8, ["modelValue"])
        ]),
        _: 1
      }, 8, ["label"])
    ], 64));
  }
});
export {
  Z as default
};
