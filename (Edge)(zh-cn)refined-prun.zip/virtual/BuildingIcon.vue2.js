import { C as n } from "./prun-css.js";
import { showBuffer as u } from "./buffers.js";
import { defineComponent as d, createElementBlock as a, openBlock as t, createElementVNode as r, createCommentVNode as C } from "./runtime-core.esm-bundler.js";
import { normalizeClass as i, toDisplayString as l } from "./shared.esm-bundler.js";
import { unref as o } from "./reactivity.esm-bundler.js";
const p = ["title"], v = /* @__PURE__ */ d({
  __name: "BuildingIcon",
  props: {
    amount: {},
    ticker: {}
  },
  setup(s) {
    const c = [
      n.MaterialIcon.indicator,
      n.MaterialIcon.neutral,
      n.MaterialIcon.typeVerySmall
    ];
    function m() {
      u(`BUI ${s.ticker}`);
    }
    return (e, f) => (t(), a("div", {
      class: i([("C" in e ? e.C : o(n)).BuildingIcon.container, e.$style.container]),
      title: e.ticker,
      onClick: m
    }, [
      r("div", {
        class: i(("C" in e ? e.C : o(n)).BuildingIcon.tickerContainer)
      }, [
        r("span", {
          class: i(("C" in e ? e.C : o(n)).BuildingIcon.ticker)
        }, l(e.ticker), 3)
      ], 2),
      e.amount ? (t(), a("div", {
        key: 0,
        class: i([("C" in e ? e.C : o(n)).MaterialIcon.indicatorContainer])
      }, [
        r("div", {
          class: i(c)
        }, l(e.amount), 1)
      ], 2)) : C("", !0)
    ], 10, p));
  }
});
export {
  v as default
};
