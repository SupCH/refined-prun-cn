var o = { exports: {} };
export {
  o as __module
};
