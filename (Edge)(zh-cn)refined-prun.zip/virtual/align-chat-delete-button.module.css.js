const e = "rp-align-chat-delete-button__container___bf61efb", t = "rp-align-chat-delete-button__username___4ba777a", a = {
  container: e,
  delete: "rp-align-chat-delete-button__delete___1ae0a18",
  username: t
};
export {
  e as container,
  a as default,
  t as username
};
