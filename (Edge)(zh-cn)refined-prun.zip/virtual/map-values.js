function u(n, t) {
  const o = [];
  for (const r of n) {
    if (r === void 0)
      return;
    o.push(r);
  }
  return t(...o);
}
export {
  u as map
};
