import { applyCssRule as o } from "./refined-prun-css.js";
import t from "./feature-registry.js";
import i from "./macos-antialiased-font.module.css.js";
function m() {
  o("body", i.body);
}
t.add(import.meta.url, m, "Applies antialiased smoothing to all fonts on macOS.");
