import { __module as o } from "./isoWeek3.js";
var v = o.exports, h;
function O() {
  return h ? o.exports : (h = 1, (function(k, x) {
    (function(a, u) {
      k.exports = u();
    })(v, (function() {
      var a = "day";
      return function(u, y, d) {
        var f = function(e) {
          return e.add(4 - e.isoWeekday(), a);
        }, r = y.prototype;
        r.isoWeekYear = function() {
          return f(this).year();
        }, r.isoWeek = function(e) {
          if (!this.$utils().u(e)) return this.add(7 * (e - this.isoWeek()), a);
          var t, s, i, n, c = f(this), p = (t = this.isoWeekYear(), s = this.$u, i = (s ? d.utc : d)().year(t).startOf("year"), n = 4 - i.isoWeekday(), i.isoWeekday() > 4 && (n += 7), i.add(n, a));
          return c.diff(p, "week") + 1;
        }, r.isoWeekday = function(e) {
          return this.$utils().u(e) ? this.day() || 7 : this.day(this.day() % 7 ? e : e - 7);
        };
        var W = r.startOf;
        r.startOf = function(e, t) {
          var s = this.$utils(), i = !!s.u(t) || t;
          return s.p(e) === "isoweek" ? i ? this.date(this.date() - (this.isoWeekday() - 1)).startOf("day") : this.date(this.date() - 1 - (this.isoWeekday() - 1) + 7).endOf("day") : W.bind(this)(e, t);
        };
      };
    }));
  })(o), o.exports);
}
export {
  O as __require
};
