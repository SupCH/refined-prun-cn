import c from "./LineChart.vue.js";
import { percent0 as u } from "./format.js";
import { calcEquity as d } from "./balance-sheet-summary.js";
import { balanceHistory as f } from "./user-data-balance.js";
import { useTileState as y } from "./user-data-tiles.js";
import v from "./dayjs.min.js";
import g from "./RangeInput.vue.js";
import { defineComponent as h, watch as C, computed as F, createElementBlock as V, openBlock as k, Fragment as q, createElementVNode as B, createVNode as l } from "./runtime-core.esm-bundler.js";
import { ref as z, unref as o, isRef as E } from "./reactivity.esm-bundler.js";
import { normalizeClass as p, toDisplayString as R } from "./shared.esm-bundler.js";
const L = /* @__PURE__ */ h({
  __name: "EquityHistoryChart",
  props: {
    maintainAspectRatio: { type: Boolean },
    onChartClick: { type: Function },
    pan: { type: Boolean },
    zoom: { type: Boolean }
  },
  setup(S) {
    const n = y("averageFactor", 0.1), r = z(n.value);
    C(r, (e) => {
      const t = typeof e == "number" ? e : parseFloat(e);
      isFinite(t) && (n.value = t);
    });
    const m = F(() => {
      const e = [], t = [];
      for (const a of f.value) {
        const i = d(a);
        if (i === void 0)
          continue;
        const s = e[e.length - 1];
        s !== void 0 && v(s).isSame(a.timestamp, "day") ? (e[e.length - 1] = a.timestamp, t[t.length - 1] = i) : (e.push(a.timestamp), t.push(i));
      }
      return {
        date: e,
        equity: t
      };
    });
    return (e, t) => (k(), V(q, null, [
      B("div", {
        class: p(e.$style.wide)
      }, "Smoothing: " + R(o(u)(o(n))), 3),
      l(g, {
        modelValue: o(r),
        "onUpdate:modelValue": t[0] || (t[0] = (a) => E(r) ? r.value = a : null),
        class: p(e.$style.wide),
        min: 0,
        max: 1,
        step: 0.01
      }, null, 8, ["modelValue", "class"]),
      l(c, {
        "maintain-aspect-ratio": e.maintainAspectRatio,
        "average-factor": o(n),
        ydata: o(m).equity,
        xdata: o(m).date,
        pan: e.pan,
        zoom: e.zoom,
        onClick: e.onChartClick
      }, null, 8, ["maintain-aspect-ratio", "average-factor", "ydata", "xdata", "pan", "zoom", "onClick"])
    ], 64));
  }
});
export {
  L as default
};
