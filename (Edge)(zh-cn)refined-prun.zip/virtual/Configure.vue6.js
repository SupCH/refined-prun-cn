import f from "./Configure.vue2.js";
export {
  f as default
};
