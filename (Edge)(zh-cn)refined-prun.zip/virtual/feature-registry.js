import c from "./config.js";
import l from "./browser-version.js";
import { userData as u } from "./user-data.js";
const a = [], i = {
  info: console.log,
  http: console.log,
  error: d
};
function d(n, e) {
  const t = e instanceof Error ? e.message : String(e), o = new URL("https://github.com/refined-prun/refined-prun/issues");
  o.searchParams.set("q", `is:issue is:open label:bug ${n}`);
  const s = new URL("https://github.com/refined-prun/refined-prun/issues/new");
  s.searchParams.set("template", "bug_report.yml"), s.searchParams.set("title", `\`${n}\`: ${t}`), s.searchParams.set("version", c.version.toString()), s.searchParams.set("browser", l()), s.searchParams.set(
    "description",
    ["```", String(e instanceof Error ? e.stack : e).trim(), "```"].join(`
`)
  ), console.group(`❌ Refined PrUn: ${n}`), console.log(`📕 ${c.version}`, e), console.log("🔍 Search issue", o.href), console.log("🚨 Report issue", s.href), console.groupEnd();
}
function f(n, e, t) {
  const o = n.split("/"), s = o.pop().split(".")[0];
  let r = o.pop();
  r === s && (r = o.pop()), a.push({
    id: s,
    description: t,
    init: e,
    advanced: r === "advanced"
  });
}
function g() {
  const n = new Set(u.settings.disabled);
  for (const e of a)
    if (!(u.settings.mode !== "FULL" && e.advanced)) {
      if (n.has(e.id)) {
        i.info("↩️", "Skipping " + e.id);
        continue;
      }
      p.current = e.id;
      try {
        e.init(), i.info("✅", e.id);
      } catch (t) {
        i.error(e.id, t);
      } finally {
        p.current = void 0;
      }
    }
}
const p = {
  add: f,
  init: g,
  current: void 0,
  registry: a
};
export {
  p as default
};
