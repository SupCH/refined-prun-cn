import c from "./duration.js";
import s from "./relativeTime.js";
import d from "./isoWeek.js";
import e from "./dayjs.min.js";
import { ref as r } from "./reactivity.esm-bundler.js";
import { computed as t } from "./runtime-core.esm-bundler.js";
e.extend(c);
e.extend(s);
e.extend(d);
const o = r(0);
setInterval(() => o.value++, 1e3);
const a = r(0);
setInterval(() => a.value++, 6e4);
const x = t(() => n(e(), o)), E = t(() => n(Date.now(), o)), S = t(() => n(Date.now(), a));
function n(m, i) {
  return i.value, m;
}
export {
  x as dayjsEachSecond,
  S as timestampEachMinute,
  E as timestampEachSecond
};
