import b from "./feature-registry.js";
import { C as y } from "./prun-css.js";
import { t as o } from "./index5.js";
import I from "./SectionHeader.vue.js";
import z from "./Active.vue.js";
import T from "./TextInput.vue.js";
import V from "./PrunButton.vue.js";
import { userData as m } from "./user-data.js";
import W from "./remove-array-element.js";
import { saveUserData as k } from "./user-data-serializer.js";
import j from "./Commands.vue.js";
import { isEmpty as H } from "./is-empty.js";
import { reactive as O, ref as P, unref as i } from "./reactivity.esm-bundler.js";
import { defineComponent as Q, computed as A, createElementBlock as d, openBlock as r, createElementVNode as s, createVNode as f, createCommentVNode as g, withCtx as c, createTextVNode as C, createBlock as q, Fragment as F, renderList as S } from "./runtime-core.esm-bundler.js";
import { toDisplayString as n, normalizeClass as l } from "./shared.esm-bundler.js";
const G = { key: 0 }, J = { key: 1 }, K = ["onClick"], h = O({}), ue = /* @__PURE__ */ Q({
  __name: "FEAT",
  setup(X) {
    m.settings.mode === void 0 && (m.settings.mode = "BASIC");
    const p = m.settings.mode === "FULL", u = A(() => new Set(m.settings.disabled)), R = p ? b.registry : b.registry.filter((e) => !e.advanced), L = b.registry.filter((e) => e.advanced), v = R.sort((e, a) => {
      const t = u.value.has(e.id), $ = u.value.has(a.id);
      return t && !$ ? -1 : !t && $ ? 1 : e.id.localeCompare(a.id);
    }), B = /* @__PURE__ */ new Map();
    for (const e of v)
      B.set(e.id, `${e.id} ${e.description}`.toLowerCase());
    const w = P(""), D = A(() => {
      const e = w.value.toLowerCase().replaceAll(/\W/g, " ").split(/\s+/).filter(Boolean);
      return e.length === 0 ? v : v.filter((a) => e.some((t) => B.get(a.id).includes(t)));
    });
    function E(e) {
      h[e] ? delete h[e] : h[e] = !0;
      const a = m.settings.disabled;
      u.value.has(e) ? W(a, e) : a.push(e), k();
    }
    function N(e) {
      return u.value.has(e) ? void 0 : [y.RadioItem.active, y.effects.shadowPrimary];
    }
    async function U() {
      await k(), window.location.reload();
    }
    async function M() {
      p ? m.settings.mode = "BASIC" : m.settings.mode = "FULL", await k(), window.location.reload();
    }
    return (e, a) => (r(), d("div", null, [
      s("form", {
        class: l(e.$style.form)
      }, [
        f(j, {
          label: ("t" in e ? e.t : i(o))("feat.changeSet")
        }, {
          default: c(() => [
            f(V, {
              primary: "",
              onClick: M
            }, {
              default: c(() => [
                C(n(("t" in e ? e.t : i(o))("feat.switchTo", p ? "BASIC" : "FULL")), 1)
              ]),
              _: 1
            })
          ]),
          _: 1
        }, 8, ["label"]),
        f(z, {
          class: l(e.$style.warningRoot),
          label: ("t" in e ? e.t : i(o))("feat.search")
        }, {
          default: c(() => [
            f(T, {
              modelValue: w.value,
              "onUpdate:modelValue": a[0] || (a[0] = (t) => w.value = t)
            }, null, 8, ["modelValue"]),
            i(H)(Object.keys(i(h))) ? g("", !0) : (r(), q(V, {
              key: 0,
              primary: "",
              class: l(e.$style.warning),
              onClick: U
            }, {
              default: c(() => [
                C(n(("t" in e ? e.t : i(o))("feat.restartWarning")), 1)
              ]),
              _: 1
            }, 8, ["class"]))
          ]),
          _: 1
        }, 8, ["class", "label"])
      ], 2),
      f(I, null, {
        default: c(() => [
          C(n(("t" in e ? e.t : i(o))("feat.featuresCount", i(v).length)) + " ", 1),
          u.value.size > 0 ? (r(), d("span", G, n(("t" in e ? e.t : i(o))("feat.offCount", u.value.size)), 1)) : g("", !0),
          p ? g("", !0) : (r(), d("span", J, n(("t" in e ? e.t : i(o))("feat.moreAvailable", i(L).length)), 1))
        ]),
        _: 1
      }),
      s("table", null, [
        s("tbody", null, [
          (r(!0), d(F, null, S(D.value, (t) => (r(), d("tr", {
            key: t.id
          }, [
            s("td", {
              class: l(e.$style.row),
              onClick: ($) => E(t.id)
            }, [
              s("div", {
                class: l([("C" in e ? e.C : i(y)).RadioItem.indicator, e.$style.indicator, N(t.id)])
              }, null, 2),
              s("div", null, [
                s("div", {
                  class: l(e.$style.id)
                }, n(t.id), 3),
                s("div", {
                  class: l(e.$style.description)
                }, n(("t" in e ? e.t : i(o))("features." + t.id) === "features." + t.id ? t.description : ("t" in e ? e.t : i(o))("features." + t.id)), 3)
              ])
            ], 10, K)
          ]))), 128))
        ])
      ]),
      p ? g("", !0) : (r(), d(F, { key: 0 }, [
        f(I, null, {
          default: c(() => [
            C(n(("t" in e ? e.t : i(o))("feat.fullModeFeatures")), 1)
          ]),
          _: 1
        }),
        s("table", null, [
          s("tbody", null, [
            (r(!0), d(F, null, S(i(L), (t) => (r(), d("tr", {
              key: t.id
            }, [
              s("td", {
                class: l([e.$style.row, e.$style.rowFull])
              }, [
                s("div", {
                  class: l([("C" in e ? e.C : i(y)).RadioItem.indicator, ("C" in e ? e.C : i(y)).RadioItem.disabled, e.$style.indicator])
                }, null, 2),
                s("div", null, [
                  s("div", {
                    class: l(e.$style.id)
                  }, n(t.id), 3),
                  s("div", {
                    class: l(e.$style.description)
                  }, n(("t" in e ? e.t : i(o))("features." + t.id) === "features." + t.id ? t.description : ("t" in e ? e.t : i(o))("features." + t.id)), 3)
                ])
              ], 2)
            ]))), 128))
          ])
        ])
      ], 64))
    ]));
  }
});
export {
  ue as default
};
