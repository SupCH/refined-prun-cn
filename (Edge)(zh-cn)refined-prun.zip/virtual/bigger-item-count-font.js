import { applyCssRule as t } from "./refined-prun-css.js";
import { C as r } from "./prun-css.js";
import o from "./feature-registry.js";
import e from "./bigger-item-count-font.module.css.js";
function i() {
  t(`.${r.MaterialIcon.typeVerySmall}`, e.indicator);
}
o.add(import.meta.url, i, "Makes the item count label font bigger.");
