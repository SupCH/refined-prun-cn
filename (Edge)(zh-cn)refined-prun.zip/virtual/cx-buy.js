import { act as k } from "./act-registry.js";
import C from "./Edit.vue.js";
import { CXPO_BUY as R } from "./CXPO_BUY.js";
import { fixed0 as l, fixed02 as $ } from "./format.js";
import { fillAmount as W } from "./utils2.js";
import { t as v } from "./index5.js";
k.addAction({
  type: "CX Buy",
  description: (a) => !a.group || !a.exchange ? "--" : v("act.buyingGroup", a.group, a.exchange),
  editComponent: C,
  generateSteps: async (a) => {
    const { data: e, state: r, log: f, fail: m, getMaterialGroup: y, emitStep: b } = a, g = a.assert, p = e.allowUnfilled ?? !1, h = e.buyPartial ?? !1, o = await y(e.group);
    if (g(o, "Invalid material group"), !o) {
      m(`Material group "${e.group}" not found or returned no materials`);
      return;
    }
    const s = e.exchange;
    if (g(s, "Missing exchange"), (e.useCXInv ?? !0) && e.exchange)
      if (!r.WAR[e.exchange])
        f.warning(
          `No warehouse data found for exchange ${e.exchange}, skipping CX inventory allocation`
        );
      else
        for (const t of Object.keys(o)) {
          for (const i of Object.keys(r.WAR[e.exchange]))
            if (i === t) {
              const n = Math.min(o[t], r.WAR[e.exchange][i]);
              o[t] -= n, r.WAR[e.exchange][i] -= n, r.WAR[e.exchange][t] <= 0 && delete r.WAR[e.exchange][i];
            }
          o[t] <= 0 && delete o[t];
        }
    for (const t of Object.keys(o)) {
      const i = o[t], n = e.priceLimits?.[t] ?? 1 / 0;
      if (isNaN(n)) {
        f.error("Non-numerical price limit on " + t);
        continue;
      }
      const w = `${t}.${e.exchange}`, c = W(w, i, n);
      let d = i;
      if (c && c.amount < i && !p) {
        if (!h) {
          let x = `Not enough materials on ${s} to buy ${l(i)} ${t}`;
          isFinite(n) && (x += ` with price limit ${$(n)}/u`), m(x);
          return;
        }
        const A = i - c.amount;
        let u = `${l(A)} ${t} will not be bought on ${s} (${l(c.amount)} of ${l(i)} available`;
        if (isFinite(n) && (u += ` with price limit ${$(n)}/u`), u += ")", f.warning(u), c.amount === 0)
          continue;
        d = c.amount;
      }
      b(
        R({
          exchange: s,
          ticker: t,
          amount: d,
          priceLimit: n,
          buyPartial: h,
          allowUnfilled: p
        })
      );
    }
  }
});
