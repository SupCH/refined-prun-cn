import f from "./CXTS.vue.js";
export {
  f as default
};
