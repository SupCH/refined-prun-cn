const e = [];
function p(t) {
  e.push(t);
}
function u(t) {
  return e.find((n) => n.type === t);
}
function c() {
  return e.map((t) => t.type);
}
const o = [];
function i(t) {
  o.push(t);
}
function a(t) {
  return o.find((n) => n.type === t);
}
function s() {
  return o.map((t) => t.type);
}
const r = [];
function f(t) {
  return r.push(t), (n) => ({
    ...t.preProcessData?.(n) ?? n,
    type: t.type
  });
}
function y(t) {
  return r.find((n) => n.type === t);
}
const d = {
  addMaterialGroup: p,
  getMaterialGroupInfo: u,
  getMaterialGroupTypes: c,
  addAction: i,
  getActionInfo: a,
  getActionTypes: s,
  addActionStep: f,
  getActionStepInfo: y
};
export {
  d as act
};
