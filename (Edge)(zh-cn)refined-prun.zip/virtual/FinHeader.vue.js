import { C as e } from "./prun-css.js";
import { defineComponent as n, createElementBlock as t, openBlock as a, renderSlot as s } from "./runtime-core.esm-bundler.js";
import { normalizeClass as l } from "./shared.esm-bundler.js";
const d = /* @__PURE__ */ n({
  __name: "FinHeader",
  setup(c) {
    const r = [e.FinanceOverviewPanel.header, e.ui.header2, e.fonts.fontRegular];
    return (o, m) => (a(), t("h2", {
      class: l(r)
    }, [
      s(o.$slots, "default")
    ]));
  }
});
export {
  d as default
};
