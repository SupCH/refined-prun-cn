import { __module as y } from "./duration3.js";
var T = y.exports, O;
function z() {
  return O ? y.exports : (O = 1, (function(P, I) {
    (function(v, a) {
      P.exports = a();
    })(T, (function() {
      var v, a, p = 1e3, M = 6e4, g = 36e5, S = 864e5, _ = /\[([^\]]+)]|Y{1,4}|M{1,4}|D{1,2}|d{1,4}|H{1,2}|h{1,2}|a|A|m{1,2}|s{1,2}|Z{1,2}|SSS/g, Y = 31536e6, D = 2628e6, j = /^(-|\+)?P(?:([-+]?[0-9,.]*)Y)?(?:([-+]?[0-9,.]*)M)?(?:([-+]?[0-9,.]*)W)?(?:([-+]?[0-9,.]*)D)?(?:T(?:([-+]?[0-9,.]*)H)?(?:([-+]?[0-9,.]*)M)?(?:([-+]?[0-9,.]*)S)?)?$/, f = { years: Y, months: D, days: S, hours: g, minutes: M, seconds: p, milliseconds: 1, weeks: 6048e5 }, $ = function(n) {
        return n instanceof H;
      }, m = function(n, s, t) {
        return new H(n, t, s.$l);
      }, l = function(n) {
        return a.p(n) + "s";
      }, w = function(n) {
        return n < 0;
      }, d = function(n) {
        return w(n) ? Math.ceil(n) : Math.floor(n);
      }, q = function(n) {
        return Math.abs(n);
      }, c = function(n, s) {
        return n ? w(n) ? { negative: !0, format: "" + q(n) + s } : { negative: !1, format: "" + n + s } : { negative: !1, format: "" };
      }, H = (function() {
        function n(t, i, r) {
          var e = this;
          if (this.$d = {}, this.$l = r, t === void 0 && (this.$ms = 0, this.parseFromMilliseconds()), i) return m(t * f[l(i)], this);
          if (typeof t == "number") return this.$ms = t, this.parseFromMilliseconds(), this;
          if (typeof t == "object") return Object.keys(t).forEach((function(h) {
            e.$d[l(h)] = t[h];
          })), this.calMilliseconds(), this;
          if (typeof t == "string") {
            var o = t.match(j);
            if (o) {
              var u = o.slice(2).map((function(h) {
                return h != null ? Number(h) : 0;
              }));
              return this.$d.years = u[0], this.$d.months = u[1], this.$d.weeks = u[2], this.$d.days = u[3], this.$d.hours = u[4], this.$d.minutes = u[5], this.$d.seconds = u[6], this.calMilliseconds(), this;
            }
          }
          return this;
        }
        var s = n.prototype;
        return s.calMilliseconds = function() {
          var t = this;
          this.$ms = Object.keys(this.$d).reduce((function(i, r) {
            return i + (t.$d[r] || 0) * f[r];
          }), 0);
        }, s.parseFromMilliseconds = function() {
          var t = this.$ms;
          this.$d.years = d(t / Y), t %= Y, this.$d.months = d(t / D), t %= D, this.$d.days = d(t / S), t %= S, this.$d.hours = d(t / g), t %= g, this.$d.minutes = d(t / M), t %= M, this.$d.seconds = d(t / p), t %= p, this.$d.milliseconds = t;
        }, s.toISOString = function() {
          var t = c(this.$d.years, "Y"), i = c(this.$d.months, "M"), r = +this.$d.days || 0;
          this.$d.weeks && (r += 7 * this.$d.weeks);
          var e = c(r, "D"), o = c(this.$d.hours, "H"), u = c(this.$d.minutes, "M"), h = this.$d.seconds || 0;
          this.$d.milliseconds && (h += this.$d.milliseconds / 1e3, h = Math.round(1e3 * h) / 1e3);
          var b = c(h, "S"), F = t.negative || i.negative || e.negative || o.negative || u.negative || b.negative, N = o.format || u.format || b.format ? "T" : "", k = (F ? "-" : "") + "P" + t.format + i.format + e.format + N + o.format + u.format + b.format;
          return k === "P" || k === "-P" ? "P0D" : k;
        }, s.toJSON = function() {
          return this.toISOString();
        }, s.format = function(t) {
          var i = t || "YYYY-MM-DDTHH:mm:ss", r = { Y: this.$d.years, YY: a.s(this.$d.years, 2, "0"), YYYY: a.s(this.$d.years, 4, "0"), M: this.$d.months, MM: a.s(this.$d.months, 2, "0"), D: this.$d.days, DD: a.s(this.$d.days, 2, "0"), H: this.$d.hours, HH: a.s(this.$d.hours, 2, "0"), m: this.$d.minutes, mm: a.s(this.$d.minutes, 2, "0"), s: this.$d.seconds, ss: a.s(this.$d.seconds, 2, "0"), SSS: a.s(this.$d.milliseconds, 3, "0") };
          return i.replace(_, (function(e, o) {
            return o || String(r[e]);
          }));
        }, s.as = function(t) {
          return this.$ms / f[l(t)];
        }, s.get = function(t) {
          var i = this.$ms, r = l(t);
          return r === "milliseconds" ? i %= 1e3 : i = r === "weeks" ? d(i / f[r]) : this.$d[r], i || 0;
        }, s.add = function(t, i, r) {
          var e;
          return e = i ? t * f[l(i)] : $(t) ? t.$ms : m(t, this).$ms, m(this.$ms + e * (r ? -1 : 1), this);
        }, s.subtract = function(t, i) {
          return this.add(t, i, !0);
        }, s.locale = function(t) {
          var i = this.clone();
          return i.$l = t, i;
        }, s.clone = function() {
          return m(this.$ms, this);
        }, s.humanize = function(t) {
          return v().add(this.$ms, "ms").locale(this.$l).fromNow(!t);
        }, s.valueOf = function() {
          return this.asMilliseconds();
        }, s.milliseconds = function() {
          return this.get("milliseconds");
        }, s.asMilliseconds = function() {
          return this.as("milliseconds");
        }, s.seconds = function() {
          return this.get("seconds");
        }, s.asSeconds = function() {
          return this.as("seconds");
        }, s.minutes = function() {
          return this.get("minutes");
        }, s.asMinutes = function() {
          return this.as("minutes");
        }, s.hours = function() {
          return this.get("hours");
        }, s.asHours = function() {
          return this.as("hours");
        }, s.days = function() {
          return this.get("days");
        }, s.asDays = function() {
          return this.as("days");
        }, s.weeks = function() {
          return this.get("weeks");
        }, s.asWeeks = function() {
          return this.as("weeks");
        }, s.months = function() {
          return this.get("months");
        }, s.asMonths = function() {
          return this.as("months");
        }, s.years = function() {
          return this.get("years");
        }, s.asYears = function() {
          return this.as("years");
        }, n;
      })(), x = function(n, s, t) {
        return n.add(s.years() * t, "y").add(s.months() * t, "M").add(s.days() * t, "d").add(s.hours() * t, "h").add(s.minutes() * t, "m").add(s.seconds() * t, "s").add(s.milliseconds() * t, "ms");
      };
      return function(n, s, t) {
        v = t, a = t().$utils(), t.duration = function(e, o) {
          var u = t.locale();
          return m(e, { $l: u }, o);
        }, t.isDuration = $;
        var i = s.prototype.add, r = s.prototype.subtract;
        s.prototype.add = function(e, o) {
          return $(e) ? x(this, e, 1) : i.bind(this)(e, o);
        }, s.prototype.subtract = function(e, o) {
          return $(e) ? x(this, e, -1) : r.bind(this)(e, o);
        };
      };
    }));
  })(y), y.exports);
}
export {
  z as __require
};
