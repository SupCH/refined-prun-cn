function m(t, a, n) {
  return Math.min(Math.max(t, a), n);
}
export {
  m as clamp
};
