import { applyCssRule as i } from "./refined-prun-css.js";
import { C as e } from "./prun-css.js";
import o from "./feature-registry.js";
import r from "./css-utils.module.css.js";
function m() {
  i(`.${e.StoreView.name}`, r.hidden);
}
o.add(import.meta.url, m, 'Hides "Weight" and "Volume" labels in all inventories.');
