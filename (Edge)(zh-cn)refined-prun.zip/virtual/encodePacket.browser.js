import { PACKET_TYPES as f } from "./commons.js";
const i = typeof Blob == "function" || typeof Blob < "u" && Object.prototype.toString.call(Blob) === "[object BlobConstructor]", s = typeof ArrayBuffer == "function", u = (r) => typeof ArrayBuffer.isView == "function" ? ArrayBuffer.isView(r) : r && r.buffer instanceof ArrayBuffer, B = ({ type: r, data: e }, t, o) => i && e instanceof Blob ? n(e, o) : s && (e instanceof ArrayBuffer || u(e)) ? n(new Blob([e]), o) : o(f[r] + (e || "")), n = (r, e) => {
  const t = new FileReader();
  return t.onload = function() {
    const o = t.result.split(",")[1];
    e("b" + (o || ""));
  }, t.readAsDataURL(r);
};
export {
  B as encodePacket
};
