import { C as m } from "./prun-css.js";
import { objectId as s } from "./object-id.js";
import { defineComponent as c, useSlots as l, createElementBlock as o, openBlock as r, Fragment as p, renderList as f, createBlock as u, resolveDynamicComponent as C } from "./runtime-core.esm-bundler.js";
import { normalizeClass as a } from "./shared.esm-bundler.js";
import { unref as n } from "./reactivity.esm-bundler.js";
const b = /* @__PURE__ */ c({
  __name: "ActionBar",
  setup(d) {
    const i = l();
    return (e, B) => (r(), o("div", {
      class: a(("C" in e ? e.C : n(m)).ActionBar.container)
    }, [
      (r(!0), o(p, null, f(i.default(), (t) => (r(), o("div", {
        key: n(s)(t),
        class: a(("C" in e ? e.C : n(m)).ActionBar.element)
      }, [
        (r(), u(C(t)))
      ], 2))), 128))
    ], 2));
  }
});
export {
  b as default
};
