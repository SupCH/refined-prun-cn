import { subscribe as i } from "./subscribe-async-generator.js";
import { $$ as m } from "./select-dom.js";
import { C as e } from "./prun-css.js";
import { createFragmentApp as n } from "./vue-fragment-app.js";
import a from "./tiles.js";
import p from "./feature-registry.js";
import f from "./BuildingCountSection.vue.js";
function u(r) {
  const o = r.parameter;
  o && i(m(r.anchor, e.Site.container), (t) => {
    n(f, { naturalId: o }).appendTo(t);
  });
}
function d() {
  a.observe("BS", u);
}
p.add(import.meta.url, d, "BS: Adds a building summary list.");
