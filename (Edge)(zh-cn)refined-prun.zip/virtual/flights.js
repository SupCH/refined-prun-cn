import { createEntityStore as o } from "./create-entity-store.js";
import { onApiMessage as s } from "./api-messages.js";
const e = o(), r = e.state;
s({
  SHIP_FLIGHT_FLIGHTS(t) {
    e.setAll(t.flights), e.setFetched();
  },
  SHIP_FLIGHT_FLIGHT(t) {
    e.setOne(t);
  },
  SHIP_FLIGHT_FLIGHT_ENDED(t) {
    e.removeOne(t.id);
  }
});
const i = {
  ...r
};
export {
  i as flightsStore
};
