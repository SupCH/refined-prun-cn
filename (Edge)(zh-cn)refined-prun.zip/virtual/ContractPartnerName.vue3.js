const a = "rp-ContractPartnerName__label___62b9f27", e = {
  label: a
};
export {
  e as default,
  a as label
};
