import o from "./FIN.vue2.js";
/* empty css         */
import t from "./plugin-vue_export-helper.js";
const m = /* @__PURE__ */ t(o, [["__scopeId", "data-v-bac0642f"]]);
export {
  m as default
};
