import f from "./HELP.vue.js";
export {
  f as default
};
