import { useXitParameters as p } from "./use-xit-parameters.js";
import s from "./ActionPackageList.vue.js";
import f from "./EditActionPackage.vue.js";
import { userData as m } from "./user-data.js";
import k from "./ExecuteActionPackage.vue.js";
import { defineComponent as l, computed as g, createBlock as c, createElementBlock as u, openBlock as i } from "./runtime-core.esm-bundler.js";
import { unref as t } from "./reactivity.esm-bundler.js";
import { toDisplayString as d } from "./shared.esm-bundler.js";
const _ = { key: 1 }, b = /* @__PURE__ */ l({
  __name: "ACT",
  setup(A) {
    const e = p();
    e.unshift("ACT");
    let o;
    const r = e[1]?.toLowerCase() === "gen" || e[1]?.toLowerCase() === "edit";
    r && (o = e.slice(2).join(" ")), e[1] !== void 0 && !r && (o = e.slice(1).join(" "));
    const a = g(() => {
      if (o)
        return m.actionPackages.find((n) => n.global.name === o) || m.actionPackages.find((n) => n.global.name === o.split(" ").join("_"));
    });
    return (n, y) => t(e).length === 1 ? (i(), c(s, { key: 0 })) : t(a) ? t(r) ? (i(), c(f, {
      key: 2,
      pkg: t(a)
    }, null, 8, ["pkg"])) : (i(), c(k, {
      key: 3,
      pkg: t(a)
    }, null, 8, ["pkg"])) : (i(), u("div", _, 'Action package "' + d(t(o)) + '" not found.', 1));
  }
});
export {
  b as default
};
