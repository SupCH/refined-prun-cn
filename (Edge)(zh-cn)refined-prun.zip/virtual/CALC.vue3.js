const _ = "rp-CALC__loading___a435280", a = "rp-CALC__calc___29001eb", c = {
  loading: _,
  calc: a
};
export {
  a as calc,
  c as default,
  _ as loading
};
