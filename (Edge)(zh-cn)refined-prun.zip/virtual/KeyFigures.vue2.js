import { C as e } from "./prun-css.js";
import m from "./Tooltip.vue.js";
import { defineComponent as u, createElementBlock as s, openBlock as a, Fragment as f, renderList as d, createElementVNode as n, createTextVNode as y, createBlock as v, createCommentVNode as g } from "./runtime-core.esm-bundler.js";
import { normalizeClass as o, toDisplayString as r } from "./shared.esm-bundler.js";
const N = /* @__PURE__ */ u({
  __name: "KeyFigures",
  props: {
    figures: {}
  },
  setup(_) {
    const i = [e.FinanceOverviewPanel.data, e.figures.container], c = [e.FinanceOverviewPanel.info, e.figures.figure, e.type.typeLarge], p = [
      e.FinanceOverviewPanel.label,
      e.figures.label,
      e.type.typeRegular,
      e.type.typeSmall
    ];
    return (l, C) => (a(), s("div", {
      class: o(i)
    }, [
      (a(!0), s(f, null, d(l.figures, (t) => (a(), s("div", {
        key: t.name,
        class: o(c)
      }, [
        n("span", null, r(t.value), 1),
        n("div", {
          class: o(p)
        }, [
          y(r(t.name) + " ", 1),
          t.tooltip ? (a(), v(m, {
            key: 0,
            tooltip: t.tooltip,
            position: "bottom",
            class: o(l.$style.tooltip)
          }, null, 8, ["tooltip", "class"])) : g("", !0)
        ])
      ]))), 128))
    ]));
  }
});
export {
  N as default
};
