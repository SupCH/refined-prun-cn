import m from "./xit-registry.js";
import o from "./CMDS.vue.js";
m.add({
  command: "CMDS",
  name: "XIT COMMANDS",
  description: "List of available XIT commands.",
  component: () => o
});
