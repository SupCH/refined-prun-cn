import e from "./PieChart.vue.js";
import { calculateLocationAssets as n } from "./financials.js";
import { defineComponent as r, computed as c, createBlock as m, openBlock as l } from "./runtime-core.esm-bundler.js";
import { unref as o } from "./reactivity.esm-bundler.js";
const b = /* @__PURE__ */ r({
  __name: "LocationsPieChart",
  setup(i) {
    const t = c(() => n() ?? []);
    return (p, s) => (l(), m(e, {
      "label-data": o(t).map((a) => a.name),
      "numerical-data": o(t).map((a) => a.total)
    }, null, 8, ["label-data", "numerical-data"]));
  }
});
export {
  b as default
};
