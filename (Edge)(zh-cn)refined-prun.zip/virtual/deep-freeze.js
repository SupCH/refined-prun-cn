function f(o) {
  const n = Reflect.ownKeys(o);
  for (const t of n) {
    const e = o[t];
    (e && typeof e == "object" || typeof e == "function") && f(e);
  }
  return Object.freeze(o);
}
export {
  f as deepFreeze
};
