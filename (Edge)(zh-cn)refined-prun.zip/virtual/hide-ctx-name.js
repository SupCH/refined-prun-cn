import { applyCssRule as t } from "./refined-prun-css.js";
import { C as e } from "./prun-css.js";
import o from "./feature-registry.js";
import r from "./css-utils.module.css.js";
function n() {
  t(`.ContextControls__container___pADKUO4 > .${e.HeadItem.container}`, r.hidden);
}
o.add(import.meta.url, n, "Hides the current context name label (CTX).");
