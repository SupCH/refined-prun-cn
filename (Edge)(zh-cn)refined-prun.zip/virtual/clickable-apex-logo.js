import { applyCssRule as e } from "./refined-prun-css.js";
import { C as o } from "./prun-css.js";
import { subscribe as m } from "./subscribe-async-generator.js";
import { $$ as t } from "./select-dom.js";
import i from "./feature-registry.js";
import a from "./clickable-apex-logo.module.css.js";
import { companyStore as f } from "./company.js";
import { showBuffer as l } from "./buffers.js";
function p() {
  e(`.${o.Frame.logo}`, a.logo), m(t(document, o.Frame.logo), (r) => {
    r.addEventListener("click", () => l(`CO ${f.value?.code}`));
  });
}
i.add(
  import.meta.url,
  p,
  "Makes the APEX logo clickable and leading to the user company info screen."
);
