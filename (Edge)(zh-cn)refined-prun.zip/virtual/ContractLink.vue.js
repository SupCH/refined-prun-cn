import r from "./PrunLink.vue.js";
import { isFactionContract as e } from "./utils4.js";
import { defineComponent as c, computed as a, createBlock as m, openBlock as i, withCtx as l, createTextVNode as p } from "./runtime-core.esm-bundler.js";
import { normalizeStyle as s, toDisplayString as d } from "./shared.esm-bundler.js";
import { unref as f } from "./reactivity.esm-bundler.js";
const h = /* @__PURE__ */ c({
  __name: "ContractLink",
  props: {
    contract: {}
  },
  setup(o) {
    const n = a(() => ({
      display: e(o.contract) ? "inline" : "block"
    }));
    return (t, u) => (i(), m(r, {
      command: `CONT ${t.contract.localId}`,
      style: s(f(n))
    }, {
      default: l(() => [
        p(d(t.contract.name || t.contract.localId), 1)
      ]),
      _: 1
    }, 8, ["command", "style"]));
  }
});
export {
  h as default
};
