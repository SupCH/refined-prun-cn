import u from "./PrunLink.vue.js";
import { canAcceptContract as k, canPartnerAcceptContract as C, isFactionContract as y } from "./utils4.js";
import a from "./font-awesome.module.css.js";
import l from "./colored-value.module.css.js";
import { defineComponent as A, computed as n, createBlock as g, openBlock as e, withCtx as w, createTextVNode as B, createElementBlock as m, createCommentVNode as i } from "./runtime-core.esm-bundler.js";
import { normalizeStyle as N, toDisplayString as r, normalizeClass as s } from "./shared.esm-bundler.js";
import { unref as t } from "./reactivity.esm-bundler.js";
const b = /* @__PURE__ */ A({
  __name: "ContractLink",
  props: {
    contract: {}
  },
  setup(c) {
    const p = n(() => k(c.contract)), d = n(() => C(c.contract)), f = n(() => ({
      display: y(c.contract) ? "inline" : "block"
    }));
    return (o, P) => (e(), g(u, {
      command: `CONT ${o.contract.localId}`,
      style: N(t(f))
    }, {
      default: w(() => [
        B(r(o.contract.name || o.contract.localId) + " ", 1),
        t(p) ? (e(), m("span", {
          key: 0,
          class: s([t(a).solid, t(l).warning])
        }, r(""), 2)) : i("", !0),
        t(d) ? (e(), m("span", {
          key: 1,
          class: s([t(a).solid, t(l).warning])
        }, r(""), 2)) : i("", !0)
      ]),
      _: 1
    }, 8, ["command", "style"]));
  }
});
export {
  b as default
};
