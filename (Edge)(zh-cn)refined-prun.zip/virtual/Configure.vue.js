import u from "./config.js";
import V from "./Active.vue.js";
import b from "./Passive.vue.js";
import k from "./SelectInput.vue.js";
import { storagesStore as B } from "./storage.js";
import { deserializeStorage as s, atSameLocation as y, storageSort as E, serializeStorage as r } from "./utils3.js";
import { configurableValue as t } from "./shared-types.js";
import { defineComponent as N, computed as g, watchEffect as U, createElementBlock as C, openBlock as d, createBlock as m, withCtx as c, createVNode as T, createElementVNode as h } from "./runtime-core.esm-bundler.js";
import { unref as a } from "./reactivity.esm-bundler.js";
import { toDisplayString as F } from "./shared.esm-bundler.js";
const H = /* @__PURE__ */ N({
  __name: "Configure",
  props: {
    data: {},
    config: {}
  },
  setup(e) {
    const v = g(() => (B.all.value ?? []).filter(
      (i) => i.type !== "STL_FUEL_STORE" && i.type !== "FTL_FUEL_STORE"
    )), l = g(() => {
      let i = [...v.value];
      if (e.data.dest !== t) {
        const n = s(e.data.dest);
        n && (i = i.filter((o) => y(o, n) && o !== n));
      }
      return i.sort(E);
    }), L = g(() => S(l.value));
    e.data.origin === t && !e.config.origin && l.value.length > 0 && (e.config.origin = r(l.value[0]));
    const f = g(() => {
      let i = [...v.value];
      if (e.data.origin !== t) {
        const n = s(e.data.origin);
        n && (i = i.filter((o) => y(o, n) && o !== n));
      }
      return i.sort(E);
    }), O = g(() => S(f.value));
    e.data.dest === t && !e.config.destination && f.value.length > 0 && (e.config.destination = r(f.value[0])), U(() => {
      if (e.data.origin === t) {
        if (e.config.origin) {
          const i = s(e.config.origin);
          (!i || !l.value.includes(i)) && (e.config.origin = void 0);
        }
        !e.config.origin && l.value.length === 1 && (e.config.origin = r(l.value[0]));
      }
      if (e.data.dest === t) {
        if (e.config.destination) {
          const i = s(e.config.destination);
          (!i || !f.value.includes(i)) && (e.config.destination = void 0);
        }
        !e.config.destination && f.value.length === 1 && (e.config.destination = r(f.value[0]));
      }
    });
    function S(i) {
      const n = i.map(r).map((o) => ({ label: o, value: o }));
      return n.length === 0 && n.push({ label: "No locations available", value: void 0 }), n;
    }
    return (i, n) => (d(), C("form", null, [
      i.data.origin === a(t) ? (d(), m(V, {
        key: 0,
        label: "From"
      }, {
        default: c(() => [
          T(k, {
            modelValue: ("config" in i ? i.config : a(u)).origin,
            "onUpdate:modelValue": n[0] || (n[0] = (o) => ("config" in i ? i.config : a(u)).origin = o),
            options: a(L)
          }, null, 8, ["modelValue", "options"])
        ]),
        _: 1
      })) : (d(), m(b, {
        key: 1,
        label: "From"
      }, {
        default: c(() => [
          h("span", null, F(i.data.origin), 1)
        ]),
        _: 1
      })),
      i.data.dest === a(t) ? (d(), m(V, {
        key: 2,
        label: "To"
      }, {
        default: c(() => [
          T(k, {
            modelValue: ("config" in i ? i.config : a(u)).destination,
            "onUpdate:modelValue": n[1] || (n[1] = (o) => ("config" in i ? i.config : a(u)).destination = o),
            options: a(O)
          }, null, 8, ["modelValue", "options"])
        ]),
        _: 1
      })) : (d(), m(b, {
        key: 3,
        label: "To"
      }, {
        default: c(() => [
          h("span", null, F(i.data.dest), 1)
        ]),
        _: 1
      }))
    ]));
  }
});
export {
  H as default
};
