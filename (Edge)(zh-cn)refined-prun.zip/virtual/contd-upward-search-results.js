import { applyCssRule as r } from "./refined-prun-css.js";
import { C as e } from "./prun-css.js";
import t from "./feature-registry.js";
import o from "./contd-upward-search-results.module.css.js";
function s() {
  r("CONTD", `.${e.UserSelector.suggestionsContainer}`, o.suggestions);
}
t.add(import.meta.url, s, "CONTD: Moves the search bar results above the search bar.");
