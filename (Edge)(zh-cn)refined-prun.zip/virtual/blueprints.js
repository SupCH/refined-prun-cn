import { createEntityStore as o } from "./create-entity-store.js";
import { onApiMessage as s } from "./api-messages.js";
import { createRequestStore as a, request as n } from "./request-hooks2.js";
import { createMapGetter as p } from "./create-map-getter.js";
const e = o(), r = e.state;
s({
  BLUEPRINT_BLUEPRINTS(t) {
    e.setAll(t.blueprints), e.setFetched();
  },
  BLUEPRINT_BLUEPRINT(t) {
    e.setOne(t);
  }
});
const i = p(r.all, (t) => t.naturalId), I = a(n.blueprints, {
  ...r,
  getByNaturalId: i
});
export {
  I as blueprintsStore
};
