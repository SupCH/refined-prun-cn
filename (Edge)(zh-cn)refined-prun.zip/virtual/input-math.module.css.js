const n = "rp-input-math__inputContainer___c8a05e0", t = "rp-input-math__functionIcon___efb146b", c = "rp-input-math__functionIconDynamic___e7c50c0", o = {
  inputContainer: n,
  functionIcon: t,
  functionIconDynamic: c
};
export {
  o as default,
  t as functionIcon,
  c as functionIconDynamic,
  n as inputContainer
};
