import o from "./xit-registry.js";
import m from "./HQUC.vue.js";
o.add({
  command: ["HQUC"],
  name: "HQ UPGRADE CALCULATOR",
  description: "HQ upgrade calculator.",
  component: () => m
});
