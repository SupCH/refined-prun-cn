import { subscribe as l } from "./subscribe-async-generator.js";
import { $$ as m } from "./select-dom.js";
import { createFragmentApp as r } from "./vue-fragment-app.js";
import { C as o } from "./prun-css.js";
import { applyCssRule as f } from "./refined-prun-css.js";
import T from "./tiles.js";
import v from "./feature-registry.js";
import y from "./finla-more-columns.module.css.js";
import b from "./css-utils.module.css.js";
import { refTextContent as A } from "./reactive-dom.js";
import { fixed0 as u } from "./format.js";
import { currentAssets as e } from "./current-assets.js";
import { createVNode as i, createTextVNode as d, computed as x } from "./runtime-core.esm-bundler.js";
function h(t) {
  l(m(t.anchor, "thead"), L), l(m(t.anchor, "tbody"), q);
}
function L(t) {
  l(m(t, "tr"), (s) => {
    r(() => i("th", {
      class: [o.LiquidAssetsPanel.number, n(e.cxDepositsTotal)]
    }, [d("CX Deposits")])).appendTo(s), r(() => i("th", {
      class: [o.LiquidAssetsPanel.number, n(e.fxDepositsTotal)]
    }, [d("FX Deposits")])).appendTo(s), r(() => i("th", {
      class: [o.LiquidAssetsPanel.number, n(e.inventory.mmMaterialsTotal)]
    }, [d("MM Materials")])).appendTo(s);
  });
}
function q(t) {
  l(m(t, "tr"), (s) => {
    const p = s.children[0];
    if (p === void 0)
      return;
    const a = A(p);
    r(() => i("td", {
      class: [o.LiquidAssetsPanel.number, n(e.cxDepositsTotal)]
    }, [u(a.value ? e.cxDeposits.value?.get(a.value) ?? 0 : 0)])).appendTo(s), r(() => i("td", {
      class: [o.LiquidAssetsPanel.number, n(e.fxDepositsTotal)]
    }, [u(a.value ? e.fxDeposits.value?.get(a.value) ?? 0 : 0)])).appendTo(s);
    const c = x(() => a.value ? e.inventory.cxInventory.value?.mmMaterialsTotal.get(a.value) ?? 0 : 0);
    r(() => i("td", {
      class: [o.LiquidAssetsPanel.number, n(e.inventory.mmMaterialsTotal)]
    }, [u(c.value)])).appendTo(s);
  });
}
function n(t) {
  return (t.value ?? 0) === 0 ? b.hidden : void 0;
}
function D() {
  f(`.${o.LiquidAssetsPanel.row}`, y.row), T.observe("FINLA", h);
}
v.add(import.meta.url, D, "FINLA: Adds columns for additional liquid asset types.");
