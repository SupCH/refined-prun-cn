const o = "rp-finla-more-columns__row___845c4e0", r = {
  row: o
};
export {
  r as default,
  o as row
};
