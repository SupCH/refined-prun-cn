import { subscribe as m } from "./subscribe-async-generator.js";
import { $$ as a, $ as p } from "./select-dom.js";
import { C as o } from "./prun-css.js";
import s from "./tiles.js";
import l from "./feature-registry.js";
import { getPrunId as c } from "./attributes.js";
import { localAdsStore as I } from "./local-ads.js";
function f(t) {
  m(a(t.anchor, o.CommodityAd.container), y);
}
async function y(t) {
  const r = await p(t, o.CommodityAd.text), i = c(t), e = I.getById(i);
  if (!e || e.type !== "COMMODITY_BUYING" && e.type !== "COMMODITY_SELLING" || e.type !== "COMMODITY_BUYING" && e.type !== "COMMODITY_SELLING")
    return;
  const d = r.firstChild?.nodeValue ?? null, n = document.createElement("span");
  n.className = e.type === "COMMODITY_BUYING" ? o.OrderTypeLabel.BUYING : o.OrderTypeLabel.SELLING, n.textContent = d, r.replaceChild(n, r.firstChild);
}
function C() {
  s.observe(["LM", "LMA"], f);
}
l.add(
  import.meta.url,
  C,
  "LM: Colors the BUYING and SELLING in green and red respectively."
);
