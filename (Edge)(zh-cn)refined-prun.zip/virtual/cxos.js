import { createEntityStore as E } from "./create-entity-store.js";
import { onApiMessage as R } from "./api-messages.js";
import { request as D } from "./request-hooks2.js";
import { computed as r } from "./runtime-core.esm-bundler.js";
const t = E(), o = t.state;
R({
  COMEX_TRADER_ORDERS(e) {
    t.setAll(e.orders), t.setFetched();
  },
  COMEX_TRADER_ORDER_ADDED(e) {
    t.addOne(e);
  },
  COMEX_TRADER_ORDER_UPDATED(e) {
    t.updateOne(e);
  },
  COMEX_TRADER_ORDER_REMOVED(e) {
    t.removeOne(e.orderId);
  }
});
const s = (() => {
  const e = o.all;
  return r(() => (o.fetched.value || D.cxos(), e.value));
})(), a = r(() => s.value?.filter((e) => e.status !== "FILLED")), _ = {
  ...o,
  all: s,
  active: a
};
export {
  _ as cxosStore
};
