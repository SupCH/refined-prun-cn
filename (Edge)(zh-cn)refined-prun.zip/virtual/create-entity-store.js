import { onApiMessage as s } from "./api-messages.js";
import { shallowReactive as i, ref as u } from "./reactivity.esm-bundler.js";
import { computed as a } from "./runtime-core.esm-bundler.js";
function p(n, f) {
  n = n ?? ((e) => e.id);
  let t = i({});
  const r = u(!1);
  return f?.preserveOnConnectionOpen || s({
    CLIENT_CONNECTION_OPENED() {
      r.value = !1, t = i({});
    }
  }), {
    state: {
      fetched: r,
      entities: a(() => r.value ? t : void 0),
      all: a(() => r.value ? Object.values(t) : void 0),
      getById: (e) => r.value && e ? t[e] : void 0
    },
    setAll(e) {
      for (const o in t)
        delete t[o];
      for (const o of e)
        t[n(o)] = o;
    },
    setOne(e) {
      t[n(e)] = e;
    },
    setMany(e) {
      for (const o of e)
        t[n(o)] = o;
    },
    addOne(e) {
      const o = n(e);
      t[o] || (t[o] = e);
    },
    updateOne(e) {
      const o = n(e);
      t[o] && (t[o] = {
        ...t[o],
        ...e
      });
    },
    removeOne(e) {
      delete t[e];
    },
    setFetched() {
      r.value = !0;
    }
  };
}
export {
  p as createEntityStore
};
