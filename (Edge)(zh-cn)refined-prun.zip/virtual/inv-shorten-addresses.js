import { subscribe as e } from "./subscribe-async-generator.js";
import { $$ as o } from "./select-dom.js";
import { C as m } from "./prun-css.js";
import n from "./tiles.js";
import i from "./feature-registry.js";
import { extractPlanetName as a } from "./util.js";
function f(r) {
  r.parameter || e(o(r.anchor, m.Link.link), (t) => {
    t.textContent && (t.textContent = a(t.textContent));
  });
}
function s() {
  n.observe("INV", f);
}
i.add(import.meta.url, s, "INV: Shortens addresses in the main INV command.");
