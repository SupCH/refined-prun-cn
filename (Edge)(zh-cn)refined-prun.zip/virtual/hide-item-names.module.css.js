const e = "rp-hide-item-names__gridItem___8b1a22f", t = {
  gridItem: e
};
export {
  t as default,
  e as gridItem
};
