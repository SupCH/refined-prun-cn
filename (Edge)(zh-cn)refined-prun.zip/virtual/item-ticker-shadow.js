import { applyCssRule as o } from "./refined-prun-css.js";
import { C as r } from "./prun-css.js";
import i from "./feature-registry.js";
import t from "./item-ticker-shadow.module.css.js";
function m() {
  o(`.${r.ColoredIcon.label}`, t.shadow), o(`.${r.BuildingIcon.ticker}`, t.shadow);
}
i.add(import.meta.url, m, "Adds a shadow to item tickers.");
