const t = "rp-cxpc-chart-types__settings___f60a2dd", s = {
  settings: t
};
export {
  s as default,
  t as settings
};
