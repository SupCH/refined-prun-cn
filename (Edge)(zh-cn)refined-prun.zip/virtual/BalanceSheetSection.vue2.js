import { C as s } from "./prun-css.js";
import { formatChange as v } from "./utils7.js";
import C from "./BalanceSheetRow.vue.js";
import { formatCurrency as u } from "./format.js";
import { defineComponent as h, computed as g, createElementBlock as f, openBlock as c, createElementVNode as t, Fragment as B, renderList as S, createBlock as k } from "./runtime-core.esm-bundler.js";
import { toDisplayString as l, normalizeClass as m } from "./shared.esm-bundler.js";
import { unref as n } from "./reactivity.esm-bundler.js";
const y = { colspan: "5" }, T = /* @__PURE__ */ h({
  __name: "BalanceSheetSection",
  props: {
    current: {},
    last: {},
    previous: {},
    section: {}
  },
  setup(i) {
    function r(e, a) {
      return e !== void 0 ? a(e) : void 0;
    }
    function d(e) {
      const a = r(i.last, e), o = r(i.previous, e);
      if (!(a === void 0 || o === void 0 || o === 0))
        return (a - o) / o;
    }
    const p = g(() => {
      if (!i.section.coloredTotal)
        return;
      const e = d(i.section.total);
      if (e !== void 0)
        return {
          [s.ColoredValue.positive]: e > 0,
          [s.ColoredValue.negative]: e < 0
        };
    });
    return (e, a) => (c(), f("tbody", null, [
      t("tr", null, [
        t("th", y, l(e.section.name), 1)
      ]),
      (c(!0), f(B, null, S(e.section.children, (o) => (c(), k(C, {
        key: o.name,
        current: e.current,
        last: e.last,
        previous: e.previous,
        row: o,
        indent: 0
      }, null, 8, ["current", "last", "previous", "row"]))), 128)),
      t("tr", {
        class: m(("C" in e ? e.C : n(s)).IncomeStatementPanel.totals)
      }, [
        t("td", {
          class: m(("C" in e ? e.C : n(s)).IncomeStatementPanel.number)
        }, "Total", 2),
        t("td", null, l(n(u)(r(e.current, e.section.total))), 1),
        t("td", null, l(n(u)(r(e.last, e.section.total))), 1),
        t("td", null, l(n(u)(r(e.previous, e.section.total))), 1),
        t("td", {
          class: m(n(p))
        }, l(n(v)(d(e.section.total))), 3)
      ], 2)
    ]));
  }
});
export {
  T as default
};
