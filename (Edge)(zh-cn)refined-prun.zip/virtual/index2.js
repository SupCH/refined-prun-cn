import { startRelay as t } from "./relay.js";
import { listenPrunApi as e } from "./prun-api-listener.js";
import { preloadFioResponses as i, loadFallbackPlanetData as m } from "./fio-api.js";
import { watchUntil as a } from "./watch.js";
import { companyStore as s } from "./company.js";
import { alertsStore as p } from "./alerts.js";
import { materialsStore as f } from "./materials.js";
import { uiDataStore as l } from "./ui-data.js";
import { balancesStore as n } from "./balances.js";
import { flightsStore as c } from "./flights.js";
import { shipsStore as S } from "./ships.js";
import { starsStore as u } from "./stars.js";
import { sitesStore as d } from "./sites.js";
import { storagesStore as h } from "./storage.js";
import { warehousesStore as v } from "./warehouses.js";
import { contractsStore as w } from "./contracts.js";
import { fetchPrices as y } from "./cx.js";
async function H() {
  t(), y(), i(), e();
  const o = [
    p,
    n,
    w,
    c,
    f,
    S,
    d,
    u,
    h,
    v
  ];
  await a(
    () => l.screens !== void 0 && s.value !== void 0 && o.every((r) => r.fetched.value)
  ), await m();
}
export {
  H as initializeApi
};
