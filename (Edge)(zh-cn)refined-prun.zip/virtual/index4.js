import { loadUserData as i } from "./user-data-serializer.js";
import { initializeTileListener as r } from "./user-data-tiles.js";
import { trackBalanceHistory as t } from "./user-data-balance.js";
function m() {
  i(), r(), t();
}
export {
  m as initializeUserData
};
