import { withKeys as M } from "./runtime-dom.esm-bundler.js";
import { t as l } from "./index5.js";
import p from "./SectionHeader.vue.js";
import w from "./Tooltip.vue.js";
import C from "./Commands.vue.js";
import g from "./PrunButton.vue.js";
import { hhmm as E, ddmmyyyy as I, fixed0 as K } from "./format.js";
import { userData as d, clearBalanceHistory as T } from "./user-data.js";
import { calcEquity as q } from "./balance-sheet-summary.js";
import { showConfirmationOverlay as V } from "./tile-overlay.js";
import { balanceHistory as _, collectFinDataPoint as j, canCollectFinDataPoint as z } from "./user-data-balance.js";
import h from "./Active.vue.js";
import b from "./TextInput.vue.js";
import { objectId as L } from "./object-id.js";
import { defineComponent as O, computed as R, createElementBlock as c, openBlock as y, createVNode as i, createElementVNode as o, withCtx as r, createTextVNode as m, Fragment as k, renderList as Z } from "./runtime-core.esm-bundler.js";
import { ref as F, unref as e, isRef as $ } from "./reactivity.esm-bundler.js";
import { toDisplayString as a, normalizeClass as G } from "./shared.esm-bundler.js";
const dt = /* @__PURE__ */ O({
  __name: "FIN",
  setup(J) {
    const B = R(() => _.value.slice().reverse());
    function H(t, n) {
      n = _.value.length - n - 1, V(t, () => N(n), {
        message: l("fin_settings.confirmDelete")
      });
    }
    function N(t) {
      const n = d.balanceHistory;
      t < n.v1.length ? n.v1.splice(t, 1) : n.v2.splice(t - n.v1.length, 1);
    }
    function S(t) {
      V(t, T, {
        message: l("fin_settings.confirmClearAll")
      });
    }
    function A(t) {
      return t !== void 0 ? K(t) : "--";
    }
    const f = F(d.settings.financial.mmMaterials);
    function v() {
      const t = (f.value ?? "").replaceAll(" ", "").toUpperCase();
      d.settings.financial.mmMaterials = t, f.value = t;
    }
    const u = F(d.settings.financial.ignoredMaterials);
    function D() {
      const t = (u.value ?? "").replaceAll(" ", "").toUpperCase();
      d.settings.financial.ignoredMaterials = t, u.value = t;
    }
    return (t, n) => (y(), c(k, null, [
      i(p, null, {
        default: r(() => [
          m(a(("t" in t ? t.t : e(l))("fin_settings.priceSettings")), 1)
        ]),
        _: 1
      }),
      i(h, {
        label: ("t" in t ? t.t : e(l))("fin_settings.mmMaterials"),
        tooltip: ("t" in t ? t.t : e(l))("fin_settings.mmMaterialsTooltip")
      }, {
        default: r(() => [
          i(b, {
            modelValue: e(f),
            "onUpdate:modelValue": n[0] || (n[0] = (s) => $(f) ? f.value = s : null),
            onKeyup: M(v, ["enter"]),
            onFocusout: v
          }, null, 8, ["modelValue"])
        ]),
        _: 1
      }, 8, ["label", "tooltip"]),
      i(h, {
        label: ("t" in t ? t.t : e(l))("fin_settings.ignoredMaterials"),
        tooltip: ("t" in t ? t.t : e(l))("fin_settings.ignoredMaterialsTooltip")
      }, {
        default: r(() => [
          i(b, {
            modelValue: e(u),
            "onUpdate:modelValue": n[1] || (n[1] = (s) => $(u) ? u.value = s : null),
            onKeyup: M(D, ["enter"]),
            onFocusout: D
          }, null, 8, ["modelValue"])
        ]),
        _: 1
      }, 8, ["label", "tooltip"]),
      i(p, null, {
        default: r(() => [
          m(a(("t" in t ? t.t : e(l))("fin_settings.collectedData")), 1)
        ]),
        _: 1
      }),
      o("form", null, [
        i(C, null, {
          default: r(() => [
            i(g, {
              primary: "",
              disabled: !e(z)(),
              onClick: e(j)
            }, {
              default: r(() => [
                m(a(("t" in t ? t.t : e(l))("fin_settings.collectData")), 1)
              ]),
              _: 1
            }, 8, ["disabled", "onClick"])
          ]),
          _: 1
        })
      ]),
      o("table", null, [
        o("thead", null, [
          o("tr", null, [
            o("th", null, a(("t" in t ? t.t : e(l))("fin_settings.date")), 1),
            o("th", null, a(("t" in t ? t.t : e(l))("fin_settings.equity")), 1),
            o("th", null, a(("t" in t ? t.t : e(l))("fin_settings.command")), 1)
          ])
        ]),
        o("tbody", null, [
          (y(!0), c(k, null, Z(e(B), (s, P) => (y(), c("tr", {
            key: e(L)(s)
          }, [
            o("td", null, a(e(E)(s.timestamp)) + " " + a(e(I)(s.timestamp)), 1),
            o("td", null, a(A(e(q)(s))), 1),
            o("td", null, [
              i(g, {
                dark: "",
                inline: "",
                onClick: (U) => H(U, P)
              }, {
                default: r(() => [
                  m(a(("t" in t ? t.t : e(l))("fin_settings.delete")), 1)
                ]),
                _: 2
              }, 1032, ["onClick"])
            ])
          ]))), 128))
        ])
      ]),
      i(p, null, {
        default: r(() => [
          m(a(("t" in t ? t.t : e(l))("fin_settings.dangerZone")) + " ", 1),
          i(w, {
            class: G(t.$style.tooltip),
            tooltip: ("t" in t ? t.t : e(l))("fin_settings.clearData")
          }, null, 8, ["class", "tooltip"])
        ]),
        _: 1
      }),
      o("form", null, [
        i(C, null, {
          default: r(() => [
            i(g, {
              danger: "",
              onClick: S
            }, {
              default: r(() => [
                m(a(("t" in t ? t.t : e(l))("fin_settings.clearData")), 1)
              ]),
              _: 1
            })
          ]),
          _: 1
        })
      ])
    ], 64));
  }
});
export {
  dt as default
};
