import { C as r } from "./prun-css.js";
import { defineComponent as s, createElementBlock as i, openBlock as m, createElementVNode as n, renderSlot as l } from "./runtime-core.esm-bundler.js";
import { normalizeClass as t, toDisplayString as p } from "./shared.esm-bundler.js";
import { unref as o } from "./reactivity.esm-bundler.js";
const g = /* @__PURE__ */ s({
  __name: "GridItemView",
  props: {
    name: {}
  },
  setup(d) {
    const a = [r.GridItemView.name, r.fonts.fontRegular, r.type.typeRegular];
    return (e, f) => (m(), i("div", {
      class: t(("C" in e ? e.C : o(r)).GridItemView.container)
    }, [
      n("div", {
        class: t(("C" in e ? e.C : o(r)).GridItemView.image)
      }, [
        l(e.$slots, "default")
      ], 2),
      n("span", {
        class: t(a)
      }, p(e.name), 1)
    ], 2));
  }
});
export {
  g as default
};
