import { C as o } from "./prun-css.js";
import { applyCssRule as i } from "./refined-prun-css.js";
import n from "./feature-registry.js";
import e from "./css-utils.module.css.js";
function r() {
  const t = `.${o.Tile.tile} .${o.TileControls.splitControls} + .${o.TileControls.control}`;
  i(`.${o.MainState.tileContainer} > ${t}`, e.hidden), i(`.${o.Window.body} > ${t}`, e.hidden);
}
n.add(
  import.meta.url,
  r,
  "Hides the close button on single tile windows where it does nothing."
);
