import f from "./AssetPieChart.vue.js";
export {
  f as default
};
