import o from "./ContractPartnerName.vue2.js";
import s from "./ContractPartnerName.vue3.js";
import t from "./plugin-vue_export-helper.js";
const r = {
  $style: s
}, a = /* @__PURE__ */ t(o, [["__cssModules", r]]);
export {
  a as default
};
