import { isValidUrl as o } from "./is-valid-url.js";
const c = document.head.getElementsByTagName("script");
for (let n = 0; n < c.length; n++) {
  const e = c[n];
  if (e.textContent && o(e.textContent)) {
    const t = document.createElement("script");
    t.src = e.textContent, t.defer = e.defer, t.async = e.async, t.type = e.type, document.head.appendChild(t), e.remove();
  }
}
