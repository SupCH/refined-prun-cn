import { subscribe as x } from "./subscribe-async-generator.js";
import { _$ as y, $$ as v } from "./select-dom.js";
import R from "./tiles.js";
import I from "./feature-registry.js";
import { expertsStore as T } from "./experts.js";
import { productionStore as S } from "./production.js";
import { sitesStore as g } from "./sites.js";
import { timestampEachMinute as h } from "./dayjs.js";
import { formatEta as C } from "./format.js";
import { createReactiveDiv as N } from "./reactive-element.js";
import { computed as m } from "./runtime-core.esm-bundler.js";
const d = [
  "AGRICULTURE",
  "CHEMISTRY",
  "CONSTRUCTION",
  "ELECTRONICS",
  "FOOD_INDUSTRIES",
  "FUEL_REFINING",
  "MANUFACTURING",
  "METALLURGY",
  "RESOURCE_EXTRACTION"
], A = [10, 12.5, 57.57, 276.5, 915.1], l = 1440 * 60 * 1e3;
function O(t) {
  const i = g.getById(t.parameter);
  x(v(t.anchor, "tr"), (r) => {
    if (y(r, "th")) {
      const e = document.createElement("th");
      e.textContent = "ETA", r.append(e);
      return;
    }
    const n = r.parentElement, c = Array.from(n.children).indexOf(r);
    if (c >= d.length)
      return;
    const o = d[c];
    U(r, o, i.siteId);
  });
}
function U(t, i, r) {
  const n = m(() => T.getBySiteId(r)?.experts.find((a) => a.category === i)?.entry), c = m(() => S.getBySiteId(r)?.filter(
    (a) => a.efficiencyFactors.some((f) => f.type === "EXPERTS" && f.expertiseCategory === i)
  )), o = m(() => {
    const s = n.value, a = c.value;
    return s && a ? F(s, a) : void 0;
  }), e = m(() => {
    const s = n.value, a = c.value;
    return !s || !a ? "--" : E(s) >= s.limit ? "Maxed" : o.value ? o.value.type === "precise" ? `${C(h.value, o.value.ms)}` : o.value.type === "estimate" ? isFinite(o.value.ms) ? `~${(o.value.ms / l).toFixed(1)}d` : "∞" : "--" : "--";
  }), p = N(t, e);
  p.style.whiteSpace = "pre-wrap";
  const u = document.createElement("td");
  u.append(p), t.append(u);
}
function F(t, i) {
  if (i.length === 0)
    return;
  const r = (1 - t.progress) * A[E(t)] * l, n = i.flatMap(
    (e) => e.orders.filter((p) => p.completion).map((p) => ({
      order: p,
      completion: p.completion.timestamp,
      experience: M(p, e)
    }))
  ).sort((e, p) => e.completion - p.completion);
  if (n.length === 0)
    return;
  let c = 0;
  for (const e of n)
    if (c += e.experience, c >= r)
      return {
        type: "precise",
        ms: e.completion
      };
  let o = 0;
  for (const e of i)
    o += e.capacity * e.efficiency;
  return {
    type: "estimate",
    ms: r / o
  };
}
function M(t, i) {
  const r = t.recipeId, n = i.productionTemplates.find((o) => o.id === r);
  if (!n)
    return 0;
  const c = t.outputs[0].amount / n.outputFactors[0].factor;
  return n.experience * c;
}
function E(t) {
  return t.current + t.available;
}
function D() {
  R.observe("EXP", O);
}
I.add(import.meta.url, D, "EXP: Displays ETA for the next expert to appear.");
