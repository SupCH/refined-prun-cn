import f from "./Edit.vue3.js";
export {
  f as default
};
