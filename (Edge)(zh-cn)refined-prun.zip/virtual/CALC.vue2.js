import a from "./LoadingSpinner.vue.js";
import { defineComponent as l, createElementBlock as s, openBlock as o, createBlock as i, createCommentVNode as m, createElementVNode as c, Fragment as p } from "./runtime-core.esm-bundler.js";
import { ref as u, unref as f } from "./reactivity.esm-bundler.js";
import { normalizeClass as n } from "./shared.esm-bundler.js";
const _ = /* @__PURE__ */ l({
  __name: "CALC",
  setup(d) {
    const e = u(!0);
    return (t, r) => (o(), s(p, null, [
      f(e) ? (o(), i(a, {
        key: 0,
        class: n(t.$style.loading)
      }, null, 8, ["class"])) : m("", !0),
      c("iframe", {
        src: "https://refined-prun.github.io/xit-calc/",
        width: "100%",
        height: "100%",
        class: n(t.$style.calc),
        onLoad: r[0] || (r[0] = (g) => e.value = !1)
      }, null, 34)
    ], 64));
  }
});
export {
  _ as default
};
