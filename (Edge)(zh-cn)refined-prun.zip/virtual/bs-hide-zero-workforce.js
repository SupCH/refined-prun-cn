import { subscribe as t } from "./subscribe-async-generator.js";
import { $$ as i, _$$ as a } from "./select-dom.js";
import { C as s } from "./prun-css.js";
import u from "./tiles.js";
import p from "./feature-registry.js";
import { watchEffectWhileNodeAlive as l } from "./watch.js";
import { refPrunId as d } from "./attributes.js";
import { sitesStore as k } from "./sites.js";
import { workforcesStore as v } from "./workforces.js";
import { PrunI18N as y } from "./i18n.js";
import { isEmpty as h } from "./is-empty.js";
import { computed as w } from "./runtime-core.esm-bundler.js";
function I(r) {
  r.parameter && t(i(r.anchor, s.Site.container), () => {
    t(i(r.anchor, "tr"), (o) => {
      if (h(a(o, "td")))
        return;
      const f = d(o), m = w(() => {
        const n = k.getByPlanetNaturalId(r.parameter), e = v.getById(n?.siteId)?.workforces.find((c) => c.level === f.value);
        return e && e.capacity < 1 && e.required < 1 && e.population < 1;
      });
      l(o, () => o.style.display = m.value ? "none" : "");
    });
  });
}
function S() {
  const r = y["SiteWorkforces.table.currentWorkforce"]?.[0];
  r && (r.value = r.value.replace("Current Workforce", "Current")), u.observe("BS", I);
}
p.add(import.meta.url, S, "BS: Hides workforce rows with zero current workforce.");
