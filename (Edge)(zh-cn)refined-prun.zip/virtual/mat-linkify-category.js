import { subscribe as n } from "./subscribe-async-generator.js";
import { _$$ as c, $$ as s } from "./select-dom.js";
import { C as r } from "./prun-css.js";
import l from "./tiles.js";
import f from "./feature-registry.js";
import { materialsStore as d } from "./materials.js";
import { materialCategoriesStore as p, toSerializableCategoryName as g } from "./material-categories.js";
import { showBuffer as y } from "./buffers.js";
function u(e) {
  const i = e.parameter, o = d.getByTicker(i), a = p.getById(o?.category);
  a && n(s(e.anchor, r.MaterialInformation.container), async (m) => {
    const t = c(m, r.StaticInput.static)[1];
    t !== void 0 && (t.classList.add(r.Link.link), t.addEventListener("click", () => {
      y("XIT MATS " + g(a.name));
    }));
  });
}
function T() {
  l.observe("MAT", u);
}
f.add(
  import.meta.url,
  T,
  "MAT: Makes material category clickable and leading to XIT MATS with the material category."
);
