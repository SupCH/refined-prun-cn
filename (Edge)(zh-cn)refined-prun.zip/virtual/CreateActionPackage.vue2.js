import f from "./CreateActionPackage.vue.js";
export {
  f as default
};
