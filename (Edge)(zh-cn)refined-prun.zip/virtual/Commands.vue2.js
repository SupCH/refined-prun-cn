import f from "./Commands.vue.js";
export {
  f as default
};
