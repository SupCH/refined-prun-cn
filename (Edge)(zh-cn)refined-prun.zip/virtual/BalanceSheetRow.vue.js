import o from "./BalanceSheetRow.vue2.js";
import s from "./BalanceSheetRow.vue3.js";
/* empty css                     */
import t from "./plugin-vue_export-helper.js";
const e = {
  $style: s
}, a = /* @__PURE__ */ t(o, [["__cssModules", e], ["__scopeId", "data-v-082288d5"]]);
export {
  a as default
};
