import s from "./Active.vue.js";
import p from "./SelectInput.vue.js";
import { storagesStore as U } from "./storage.js";
import { storageSort as k, serializeStorage as F } from "./utils3.js";
import { configurableValue as L } from "./shared-types.js";
import { t as d } from "./index5.js";
import { defineComponent as T, computed as V, createElementBlock as x, openBlock as G, createVNode as a, withCtx as f, Fragment as R } from "./runtime-core.esm-bundler.js";
import { ref as c, unref as t, isRef as g } from "./reactivity.esm-bundler.js";
const $ = /* @__PURE__ */ T({
  __name: "Edit",
  props: {
    action: {},
    pkg: {}
  },
  setup(o, { expose: b }) {
    const v = V(() => o.pkg.groups.map((l) => l.name).filter((l) => l)), i = c(o.action.group ?? v.value[0]), r = V(() => {
      const l = [...U.all.value ?? []].filter((e) => e.type !== "STL_FUEL_STORE" && e.type !== "FTL_FUEL_STORE").sort(k).map(F);
      return l.unshift(L), l;
    }), u = c(o.action.origin ?? r.value[0]), m = c(o.action.dest ?? r.value[0]);
    function S() {
      return !0;
    }
    function E() {
      o.action.group = i.value, o.action.origin = u.value, o.action.dest = m.value;
    }
    return b({ validate: S, save: E }), (l, e) => (G(), x(R, null, [
      a(s, {
        label: t(d)("act.materialGroup")
      }, {
        default: f(() => [
          a(p, {
            modelValue: t(i),
            "onUpdate:modelValue": e[0] || (e[0] = (n) => g(i) ? i.value = n : null),
            options: t(v)
          }, null, 8, ["modelValue", "options"])
        ]),
        _: 1
      }, 8, ["label"]),
      a(s, {
        label: t(d)("act.origin")
      }, {
        default: f(() => [
          a(p, {
            modelValue: t(u),
            "onUpdate:modelValue": e[1] || (e[1] = (n) => g(u) ? u.value = n : null),
            options: t(r)
          }, null, 8, ["modelValue", "options"])
        ]),
        _: 1
      }, 8, ["label"]),
      a(s, {
        label: t(d)("act.destination")
      }, {
        default: f(() => [
          a(p, {
            modelValue: t(m),
            "onUpdate:modelValue": e[2] || (e[2] = (n) => g(m) ? m.value = n : null),
            options: t(r)
          }, null, 8, ["modelValue", "options"])
        ]),
        _: 1
      }, 8, ["label"])
    ], 64));
  }
});
export {
  $ as default
};
