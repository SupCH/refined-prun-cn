const t = "rp-cxpo-bigger-buttons__container___2b49772", n = {
  container: t
};
export {
  t as container,
  n as default
};
