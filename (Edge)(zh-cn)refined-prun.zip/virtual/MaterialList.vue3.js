import f from "./MaterialList.vue.js";
export {
  f as default
};
