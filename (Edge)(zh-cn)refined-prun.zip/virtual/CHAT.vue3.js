const t = "rp-CHAT__title___7f90d0a", _ = "rp-CHAT__name___989f301", e = {
  title: t,
  name: _
};
export {
  e as default,
  _ as name,
  t as title
};
