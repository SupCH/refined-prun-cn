import { C as e } from "./prun-css.js";
import s from "./Tooltip.vue.js";
import { defineComponent as a, computed as p, createElementBlock as C, openBlock as t, createElementVNode as n, createBlock as f, createCommentVNode as u, renderSlot as d } from "./runtime-core.esm-bundler.js";
import { normalizeClass as i, toDisplayString as c } from "./shared.esm-bundler.js";
import { unref as r } from "./reactivity.esm-bundler.js";
const F = /* @__PURE__ */ a({
  __name: "Active",
  props: {
    error: { type: Boolean },
    label: {},
    tooltip: {},
    tooltipPosition: {}
  },
  setup(l) {
    const m = p(() => l.error ? [e.FormComponent.containerError, e.forms.error] : []);
    return (o, v) => (t(), C("div", {
      class: i([("C" in o ? o.C : r(e)).FormComponent.containerActive, ("C" in o ? o.C : r(e)).forms.active, ("C" in o ? o.C : r(e)).forms.formComponent, r(m)])
    }, [
      n("label", null, [
        n("span", null, c(o.label), 1),
        o.tooltip ? (t(), f(s, {
          key: 0,
          position: o.tooltipPosition,
          tooltip: o.tooltip
        }, null, 8, ["position", "tooltip"])) : u("", !0)
      ]),
      n("div", {
        class: i([("C" in o ? o.C : r(e)).FormComponent.input, ("C" in o ? o.C : r(e)).forms.input])
      }, [
        n("div", {
          class: i([("C" in o ? o.C : r(e)).DynamicInput.dynamic, ("C" in o ? o.C : r(e)).forms.dynamic])
        }, [
          d(o.$slots, "default")
        ], 2)
      ], 2)
    ], 2));
  }
});
export {
  F as default
};
