import o from "./xit-registry.js";
import a from "./GIF.vue.js";
o.add({
  command: "GIF",
  name: "RANDOM GIF",
  description: "Displays a random gif.",
  optionalParameters: "Gif Category",
  component: () => a
});
