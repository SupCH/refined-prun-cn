import p from "./LoadingSpinner.vue.js";
import { useXitParameters as f } from "./use-xit-parameters.js";
import { defineComponent as d, onMounted as g, createElementBlock as v, openBlock as i, createBlock as _, createCommentVNode as y, createElementVNode as c, Fragment as h } from "./runtime-core.esm-bundler.js";
import { ref as l, unref as m } from "./reactivity.esm-bundler.js";
import { normalizeClass as u } from "./shared.esm-bundler.js";
const k = ["src"], L = /* @__PURE__ */ d({
  __name: "GIF",
  setup(w) {
    const t = f().join(" "), o = l(!1), a = l();
    async function n() {
      if (o.value)
        return;
      o.value = !0, a.value = void 0;
      let e = "https://api.giphy.com/v1/gifs/random?api_key=c92SYJwV9J9MYJ33WGRdux4mNxAipq9y";
      t && (e += "&tag=" + t);
      try {
        const r = await (await fetch(encodeURI(e))).json();
        a.value = r.data.images.original.webp;
      } catch (r) {
        console.error(r), a.value = "";
      }
    }
    function s() {
      o.value = !1;
    }
    return g(() => void n()), (e, r) => (i(), v(h, null, [
      m(o) ? (i(), _(p, { key: 0 })) : y("", !0),
      c("div", {
        class: u(e.$style.container)
      }, [
        c("img", {
          class: u(e.$style.image),
          src: m(a),
          alt: "gif",
          onClick: n,
          onLoad: s,
          onError: s
        }, null, 42, k)
      ], 2)
    ], 64));
  }
});
export {
  L as default
};
