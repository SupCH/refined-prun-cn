import f from "./GridMaterialIcon.vue.js";
export {
  f as default
};
