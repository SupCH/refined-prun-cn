import o from "./xit-registry.js";
import m from "./CXTS.vue.js";
o.add({
  command: ["CXTS"],
  name: "COMMODITY EXCHANGE TRADES",
  description: "List of all your commodity exchange trades.",
  component: () => m
});
