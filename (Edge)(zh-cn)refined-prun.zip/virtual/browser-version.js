function f() {
  const e = navigator.userAgent;
  let n, i;
  return e.indexOf("Firefox") > -1 ? (n = "Firefox", i = e.substring(e.indexOf("Firefox") + 8)) : e.indexOf("Opera") > -1 || e.indexOf("OPR") > -1 ? (n = "Opera", i = e.substring(e.indexOf("Opera") + 6), e.indexOf("OPR") > -1 && (i = e.substring(e.indexOf("OPR") + 4))) : e.indexOf("Trident") > -1 ? (n = "Microsoft Internet Explorer", i = e.substring(e.indexOf("rv:") + 3)) : e.indexOf("Edge") > -1 ? (n = "Microsoft Edge", i = e.substring(e.indexOf("Edge") + 5)) : e.indexOf("Chrome") > -1 ? (n = "Chrome", i = e.substring(e.indexOf("Chrome") + 7)) : e.indexOf("Safari") > -1 ? (n = "Safari", i = e.substring(e.indexOf("Safari") + 7), e.indexOf("Version") > -1 && (i = e.substring(e.indexOf("Version") + 8))) : (n = "Unknown", i = "Unknown"), i.indexOf(" ") > -1 && (i = i.substring(0, i.indexOf(" "))), i.indexOf(";") > -1 && (i = i.substring(0, i.indexOf(";"))), i.indexOf(")") > -1 && (i = i.substring(0, i.indexOf(")"))), `${n} ${i}`;
}
export {
  f as default
};
