import { createFragmentApp as i } from "./vue-fragment-app.js";
import { $ as o } from "./select-dom.js";
import { C as r } from "./prun-css.js";
import t from "./config.js";
import m from "./feature-registry.js";
import n from "./xit-registry.js";
import { initializeApi as e } from "./index2.js";
import { initializeUI as a } from "./index3.js";
import { initializeUserData as f } from "./index4.js";
import { initAudioInterceptor as p } from "./audio-interceptor.js";
import c from "./PmmgMigrationGuide.vue.js";
async function s() {
  if (p(), await e(), await a(), window.PMMG_COLLECTOR_HAS_RUN) {
    i(c).before(await o(document, r.App.container));
    return;
  }
  console.log(`(zh-cn)refined-prun ${t.version}`), f(), m.init(), n.init();
}
s();
