import { subscribe as n } from "./subscribe-async-generator.js";
import { $$ as f } from "./select-dom.js";
import p from "./tiles.js";
import s from "./feature-registry.js";
import { shipsStore as c } from "./ships.js";
import { flightsStore as d } from "./flights.js";
import { formatEta as l } from "./format.js";
import { timestampEachMinute as u } from "./dayjs.js";
import { refPrunId as v } from "./attributes.js";
import { createReactiveSpan as h } from "./reactive-element.js";
import { keepLast as g } from "./keep-last.js";
import { computed as r } from "./runtime-core.esm-bundler.js";
function T(t) {
  n(f(t.anchor, "tr"), L);
}
function L(t) {
  const i = v(t), o = r(() => {
    const a = c.getById(i.value);
    return d.getById(a?.flightId)?.arrival.timestamp;
  }), e = r(
    () => o.value !== void 0 ? ` (${l(u.value, o.value)})` : void 0
  ), m = h(t, e);
  g(t, () => t.children[7], m);
}
function y() {
  p.observe(["FLT", "FLTS", "FLTP"], T);
}
s.add(import.meta.url, y, 'FLT: Adds an arrival date to the "ETA" column.');
