import { C as a } from "./prun-css.js";
import u from "./LoadingSpinner.vue.js";
import { ddmm as y, hhmm as M } from "./format.js";
import { useXitParameters as v } from "./use-xit-parameters.js";
import { objectId as h } from "./object-id.js";
import { defineComponent as T, watchEffect as k, createElementBlock as t, createBlock as N, openBlock as o, createElementVNode as r, Fragment as m, renderList as E, createCommentVNode as d } from "./runtime-core.esm-bundler.js";
import { ref as g, unref as s } from "./reactivity.esm-bundler.js";
import { toDisplayString as l, normalizeClass as n } from "./shared.esm-bundler.js";
const A = { key: 0 }, S = {
  key: 2,
  style: { height: "100%", flexGrow: 1, paddingTop: "4px" }
}, G = /* @__PURE__ */ T({
  __name: "CHAT",
  setup(B) {
    const C = v()[0], p = g(!1), f = g([]);
    return k(() => {
      C && fetch(`https://rest.fnar.net/chat/display/${C}`).then((e) => e.json()).then((e) => {
        p.value = !0, f.value = e;
      });
    }), (e, R) => s(C) ? s(p) ? (o(), t("div", S, [
      r("div", {
        class: n(e.$style.title)
      }, l(s(C)) + " Global Site Owners", 3),
      (o(!0), t(m, null, E(s(f), (i) => (o(), t("div", {
        key: s(h)(i),
        class: n([("C" in e ? e.C : s(a)).Message.message, ("C" in e ? e.C : s(a)).type.typeRegular, ("C" in e ? e.C : s(a)).fonts.fontRegular])
      }, [
        r("div", {
          class: n(("C" in e ? e.C : s(a)).Message.timestamp)
        }, [
          r("div", {
            class: n(("C" in e ? e.C : s(a)).Message.date)
          }, l(s(y)(i.MessageTimestamp)), 3),
          r("div", {
            class: n(("C" in e ? e.C : s(a)).Message.time),
            style: { color: "#999999" }
          }, l(s(M)(i.MessageTimestamp)), 3)
        ], 2),
        i.MessageType === "CHAT" ? (o(), t(m, { key: 0 }, [
          r("div", {
            class: n(("C" in e ? e.C : s(a)).Message.name)
          }, [
            r("div", {
              class: n([("C" in e ? e.C : s(a)).Sender.container, ("C" in e ? e.C : s(a)).type.typeRegular, ("C" in e ? e.C : s(a)).fonts.fontRegular])
            }, [
              r("div", {
                class: n([("C" in e ? e.C : s(a)).Sender.name, e.$style.name])
              }, l(i.UserName), 3)
            ], 2)
          ], 2),
          r("div", {
            class: n(("C" in e ? e.C : s(a)).Message.controlsAndText)
          }, [
            r("div", {
              class: n(("C" in e ? e.C : s(a)).Message.text)
            }, l(i.MessageText), 3)
          ], 2)
        ], 64)) : d("", !0),
        i.MessageType === "JOINED" ? (o(), t(m, { key: 1 }, [
          r("div", {
            class: n(("C" in e ? e.C : s(a)).Message.name)
          }, null, 2),
          r("div", {
            class: n(("C" in e ? e.C : s(a)).Message.controlsAndText)
          }, [
            r("div", {
              class: n([("C" in e ? e.C : s(a)).Message.text, ("C" in e ? e.C : s(a)).Message.system])
            }, l(i.UserName) + " joined.", 3)
          ], 2)
        ], 64)) : d("", !0),
        i.MessageType === "LEFT" ? (o(), t(m, { key: 2 }, [
          r("div", {
            class: n(("C" in e ? e.C : s(a)).Message.name)
          }, null, 2),
          r("div", {
            class: n(("C" in e ? e.C : s(a)).Message.controlsAndText)
          }, [
            r("div", {
              class: n([("C" in e ? e.C : s(a)).Message.text, ("C" in e ? e.C : s(a)).Message.system])
            }, l(i.UserName) + " left.", 3)
          ], 2)
        ], 64)) : d("", !0)
      ], 2))), 128))
    ])) : (o(), N(u, { key: 1 })) : (o(), t("div", A, "Error! Not Enough Parameters!"));
  }
});
export {
  G as default
};
