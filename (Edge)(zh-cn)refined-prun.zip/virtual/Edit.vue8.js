import f from "./Edit.vue.js";
export {
  f as default
};
