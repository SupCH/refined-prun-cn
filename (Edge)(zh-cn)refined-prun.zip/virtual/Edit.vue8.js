import f from "./Edit.vue7.js";
export {
  f as default
};
