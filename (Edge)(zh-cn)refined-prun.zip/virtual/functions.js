import { __exports as e } from "./functions2.js";
var f;
function s() {
  return f ? e : (f = 1, Object.defineProperty(e, "__esModule", { value: !0 }), e.createMathFunctions = function(r) {
    return { isDegree: !0, acos: function(n) {
      return r.math.isDegree ? 180 / Math.PI * Math.acos(n) : Math.acos(n);
    }, add: function(n, t) {
      return n + t;
    }, asin: function(n) {
      return r.math.isDegree ? 180 / Math.PI * Math.asin(n) : Math.asin(n);
    }, atan: function(n) {
      return r.math.isDegree ? 180 / Math.PI * Math.atan(n) : Math.atan(n);
    }, acosh: function(n) {
      return Math.log(n + Math.sqrt(n * n - 1));
    }, asinh: function(n) {
      return Math.log(n + Math.sqrt(n * n + 1));
    }, atanh: function(n) {
      return Math.log((1 + n) / (1 - n));
    }, C: function(n, t) {
      var o = 1, a = n - t, u = t;
      u < a && (u = a, a = t);
      for (var i = u + 1; i <= n; i++) o *= i;
      var h = r.math.fact(a);
      return h === "NaN" ? "NaN" : o / h;
    }, changeSign: function(n) {
      return -n;
    }, cos: function(n) {
      return r.math.isDegree && (n = r.math.toRadian(n)), Math.cos(n);
    }, cosh: function(n) {
      return (Math.pow(Math.E, n) + Math.pow(Math.E, -1 * n)) / 2;
    }, div: function(n, t) {
      return n / t;
    }, fact: function(n) {
      if (n % 1 != 0) return "NaN";
      for (var t = 1, o = 2; o <= n; o++) t *= o;
      return t;
    }, inverse: function(n) {
      return 1 / n;
    }, log: function(n) {
      return Math.log(n) / Math.log(10);
    }, mod: function(n, t) {
      return n % t;
    }, mul: function(n, t) {
      return n * t;
    }, P: function(n, t) {
      for (var o = 1, a = Math.floor(n) - Math.floor(t) + 1; a <= Math.floor(n); a++) o *= a;
      return o;
    }, Pi: function(n, t, o) {
      for (var a = 1, u = n; u <= t; u++) a *= Number(r.postfixEval(o, { n: u }));
      return a;
    }, pow10x: function(n) {
      for (var t = 1; n--; ) t *= 10;
      return t;
    }, sigma: function(n, t, o) {
      for (var a = 0, u = n; u <= t; u++) a += Number(r.postfixEval(o, { n: u }));
      return a;
    }, sin: function(n) {
      return r.math.isDegree && (n = r.math.toRadian(n)), Math.sin(n);
    }, sinh: function(n) {
      return (Math.pow(Math.E, n) - Math.pow(Math.E, -1 * n)) / 2;
    }, sub: function(n, t) {
      return n - t;
    }, tan: function(n) {
      return r.math.isDegree && (n = r.math.toRadian(n)), Math.tan(n);
    }, tanh: function(n) {
      return r.math.sinh(n) / r.math.cosh(n);
    }, toRadian: function(n) {
      return n * Math.PI / 180;
    }, and: function(n, t) {
      return n & t;
    } };
  }, e);
}
export {
  s as __require
};
