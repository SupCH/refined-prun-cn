import { $ as t } from "./select-dom.js";
import { C as e } from "./prun-css.js";
import { createFragmentApp as m } from "./vue-fragment-app.js";
import i from "./tiles.js";
import n from "./feature-registry.js";
import { showBuffer as a } from "./buffers.js";
import f from "./TileControlsButton.vue.js";
async function p(o) {
  const r = await t(o.frame, e.TileFrame.controls);
  m(f, {
    icon: "",
    onClick: () => a("XIT CALC"),
    marginTop: 4
  }).prependTo(r);
}
function l() {
  i.observe(["LM", "CX", "XIT"], p);
}
n.add(
  import.meta.url,
  l,
  "Adds a calculator button to the buffer header of LM, CX and XIT commands."
);
