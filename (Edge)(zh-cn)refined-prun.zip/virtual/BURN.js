import o from "./xit-registry.js";
import r from "./BURN.vue.js";
import { sitesStore as m } from "./sites.js";
import { getEntityNameFromAddress as n } from "./addresses.js";
o.add({
  command: "BURN",
  name: (t) => {
    if (t[0] && !t[1]) {
      const e = m.getByPlanetNaturalIdOrName(t[0]);
      if (e)
        return `ENHANCED BURN - ${n(e.address)}`;
    }
    return "ENHANCED BURN";
  },
  description: "Shows the number of days of consumables left.",
  optionalParameters: "Planet Identifier(s), OVERALL, NOT",
  component: () => r
});
