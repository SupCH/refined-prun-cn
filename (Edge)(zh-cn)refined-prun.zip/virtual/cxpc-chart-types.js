import { subscribe as h } from "./subscribe-async-generator.js";
import { $$ as u } from "./select-dom.js";
import { C as m } from "./prun-css.js";
import { createFragmentApp as d } from "./vue-fragment-app.js";
import y from "./tiles.js";
import { applyCssRule as T } from "./refined-prun-css.js";
import b from "./feature-registry.js";
import w from "./cxpc-chart-types.module.css.js";
import { watchEffectWhileNodeAlive as S } from "./watch.js";
import { cxobStore as k } from "./cxob.js";
import { cxpcStore as A } from "./cxpc.js";
import { COMEX_BROKER_PRICES as l } from "./client-messages.js";
import { dispatchClientPrunMessage as f } from "./prun-api-listener.js";
import { userData as E } from "./user-data.js";
import R from "./SettingsGroup.vue.js";
import { computedTileState as M } from "./user-data-tiles.js";
import { getTileState as O } from "./tile-state.js";
import { computed as v } from "./runtime-core.esm-bundler.js";
import { reactive as P } from "./reactivity.esm-bundler.js";
function x(o) {
  const n = o.parameter, a = v(() => k.getByTicker(n)), t = v(() => A.getById(a.value?.id)), s = M(O(o), "chartType", void 0);
  s.value === void 0 && (s.value = E.settings.defaultChartType), h(u(o.anchor, m.ChartContainer.container), (r) => {
    S(r, () => {
      if (t.value)
        switch (s.value) {
          case "SMOOTH": {
            X(t.value);
            break;
          }
          case "ALIGNED": {
            _(t.value);
            break;
          }
          case "RAW": {
            $(t.value);
            break;
          }
        }
    });
  }), h(u(o.anchor, m.ChartContainer.settings), (r) => {
    d(
      R,
      P({
        chartType: s,
        onChange: (e) => {
          s.value = e;
        }
      })
    ).appendTo(r);
  });
}
function X(o) {
  const n = { ...o, prices: [] };
  for (const t of o.prices) {
    const s = { ...t };
    if (n.prices.push(s), t.prices.length < 2)
      continue;
    const r = [];
    t.prices.forEach((e, c) => {
      const i = (e.open + e.high + e.low + e.close) / 4, p = c === 0 ? (e.open + e.close) / 2 : (r[c - 1].open + r[c - 1].close) / 2, g = Math.max(e.high, p, i), C = Math.min(e.low, p, i);
      r.push({ ...e, open: p, high: g, low: C, close: i });
    }), s.prices = r;
  }
  const a = l(n);
  f(a);
}
function _(o) {
  const n = { ...o, prices: [] };
  o = structuredClone(o);
  for (const t of o.prices) {
    const s = { ...t };
    if (n.prices.push(s), t.prices.length < 2)
      continue;
    const r = [];
    r.push({ ...t.prices[0] });
    let e = r[0];
    for (let c = 1; c < t.prices.length; c++) {
      const i = { ...t.prices[c] };
      r.push(i);
      const p = (i.open * i.volume + e.close * e.volume) / (i.volume + e.volume);
      e.close = p, i.open = p, e = i;
    }
    s.prices = r;
  }
  const a = l(n);
  f(a);
}
function $(o) {
  const n = l(o);
  f(n);
}
function B() {
  y.observe("CXPC", x), T("CXPC", `.${m.ChartContainer.settings}`, w.settings);
}
b.add(import.meta.url, B, 'CXPC: Adds "Smooth" and "Aligned" chart types.');
