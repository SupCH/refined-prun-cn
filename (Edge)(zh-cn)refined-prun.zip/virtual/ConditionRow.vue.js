import l from "./ContractLink.vue2.js";
import { timestampEachSecond as s } from "./dayjs.js";
import u from "./dayjs.min.js";
import m from "./ConditionText.vue.js";
import { defineComponent as f, computed as p, createElementBlock as h, openBlock as $, createElementVNode as a, createVNode as c } from "./runtime-core.esm-bundler.js";
import { toDisplayString as y } from "./shared.esm-bundler.js";
import { unref as M } from "./reactivity.esm-bundler.js";
const k = /* @__PURE__ */ f({
  __name: "ConditionRow",
  props: {
    condition: {},
    contract: {},
    deadline: {}
  },
  setup(r) {
    const d = p(() => {
      if (!isFinite(r.deadline))
        return "∞";
      if (r.deadline <= s.value)
        return "-";
      let t = u.duration({ milliseconds: r.deadline - s.value });
      const o = Math.floor(t.asDays());
      t = t.subtract(o, "days");
      const n = Math.floor(t.asHours());
      if (o > 0)
        return `${o}d ${n}h`;
      t = t.subtract(n, "hours");
      const e = Math.floor(t.asMinutes());
      if (n > 0)
        return `${n}h ${e}m`;
      t = t.subtract(e, "minutes");
      const i = Math.floor(t.asSeconds());
      return e > 0 ? `${e}m ${i}s` : `${i}s`;
    });
    return (t, o) => ($(), h("tr", null, [
      a("td", null, [
        c(l, { contract: t.contract }, null, 8, ["contract"])
      ]),
      a("td", null, y(M(d)), 1),
      a("td", null, [
        c(m, { condition: t.condition }, null, 8, ["condition"])
      ])
    ]));
  }
});
export {
  k as default
};
