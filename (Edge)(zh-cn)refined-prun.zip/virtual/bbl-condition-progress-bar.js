import { subscribe as f } from "./subscribe-async-generator.js";
import { _$$ as l, $$ as v } from "./select-dom.js";
import { C as g } from "./prun-css.js";
import { createFragmentApp as b } from "./vue-fragment-app.js";
import B from "./tiles.js";
import $ from "./feature-registry.js";
import { sitesStore as h } from "./sites.js";
import { refPrunId as w } from "./attributes.js";
import { isRepairableBuilding as I } from "./buildings.js";
import L from "./ProgressBar.vue.js";
import { computed as o } from "./runtime-core.esm-bundler.js";
import { reactive as y } from "./reactivity.esm-bundler.js";
function A(i) {
  const m = i.parameter, a = o(() => h.getById(m));
  f(v(i.anchor, g.SectionList.section), (e) => {
    const s = w(e), t = o(() => a.value?.platforms.find((u) => u.id == s.value));
    if (!t.value || !I(t.value))
      return;
    const d = l(e, "tr"), r = o(() => t.value?.condition ?? 0), n = o(() => r.value > 0.9), p = o(() => !n.value && r.value > 0.8), c = o(() => r.value <= 0.8);
    b(
      L,
      y({
        value: r,
        max: 1,
        good: n,
        warning: p,
        danger: c
      })
    ).prependTo(d[5].children[1]);
  });
}
function P() {
  B.observe("BBL", A);
}
$.add(import.meta.url, P, "BBL: Adds a progress bar to the building condition row.");
