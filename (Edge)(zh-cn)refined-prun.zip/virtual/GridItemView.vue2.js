import f from "./GridItemView.vue.js";
export {
  f as default
};
