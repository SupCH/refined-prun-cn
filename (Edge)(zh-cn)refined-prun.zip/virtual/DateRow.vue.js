import o from "./DateRow.vue2.js";
import s from "./DateRow.vue3.js";
import t from "./plugin-vue_export-helper.js";
const e = {
  $style: s
}, f = /* @__PURE__ */ t(o, [["__cssModules", e]]);
export {
  f as default
};
