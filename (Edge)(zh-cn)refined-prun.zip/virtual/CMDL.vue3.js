const t = "rp-CMDL__create___7052d84", _ = "rp-CMDL__button___64cc033", e = {
  create: t,
  button: _
};
export {
  _ as button,
  t as create,
  e as default
};
