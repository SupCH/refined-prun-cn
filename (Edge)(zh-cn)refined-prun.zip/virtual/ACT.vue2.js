import f from "./ACT.vue.js";
export {
  f as default
};
