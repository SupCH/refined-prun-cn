import { C as d } from "./prun-css.js";
import p from "./PrunButton.vue.js";
import C from "./SectionHeader.vue.js";
import c from "./Active.vue.js";
import _ from "./TextInput.vue.js";
import V from "./Commands.vue.js";
import { defineComponent as N, createElementBlock as v, openBlock as E, createVNode as t, createElementVNode as k, withCtx as r, createTextVNode as n } from "./runtime-core.esm-bundler.js";
import { ref as $, isRef as y, unref as l } from "./reactivity.esm-bundler.js";
import { normalizeClass as B } from "./shared.esm-bundler.js";
const D = /* @__PURE__ */ N({
  __name: "CreateCommandListOverlay",
  props: {
    onCreate: { type: Function }
  },
  emits: ["close"],
  setup(a, { emit: i }) {
    const f = i, o = $("");
    function s() {
      o.value.length !== 0 && (a.onCreate(o.value), f("close"));
    }
    return (m, e) => (E(), v("div", {
      class: B(("C" in m ? m.C : l(d)).DraftConditionEditor.form)
    }, [
      t(C, null, {
        default: r(() => [...e[1] || (e[1] = [
          n("New Command List", -1)
        ])]),
        _: 1
      }),
      k("form", null, [
        t(c, { label: "List Name" }, {
          default: r(() => [
            t(_, {
              modelValue: l(o),
              "onUpdate:modelValue": e[0] || (e[0] = (u) => y(o) ? o.value = u : null)
            }, null, 8, ["modelValue"])
          ]),
          _: 1
        }),
        t(V, null, {
          default: r(() => [
            t(p, {
              primary: "",
              onClick: s
            }, {
              default: r(() => [...e[2] || (e[2] = [
                n("CREATE", -1)
              ])]),
              _: 1
            })
          ]),
          _: 1
        })
      ])
    ], 2));
  }
});
export {
  D as default
};
