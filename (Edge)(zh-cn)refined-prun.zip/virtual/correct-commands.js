import { $$ as s, $ as f } from "./select-dom.js";
import { C as n } from "./prun-css.js";
import { subscribe as p } from "./subscribe-async-generator.js";
import u from "./feature-registry.js";
import { changeInputValue as l } from "./util.js";
import { correctMaterialCommand as d } from "./material-commands.js";
import { correctPlanetCommand as C } from "./planet-commands.js";
import { correctShipCommand as b } from "./ship-commands.js";
import { correctSystemCommand as S } from "./system-commands.js";
import { correctXitWeb as g } from "./xit-web.js";
import { correctXitArgs as v } from "./xit-args.js";
const y = [
  d,
  C,
  b,
  S,
  g,
  v
];
async function P(c) {
  const r = await f(c, n.PanelSelector.input), o = r.form;
  let t = !1;
  o.addEventListener("submit", (e) => {
    if (t) {
      t = !1;
      return;
    }
    const m = r.value.split(" ");
    for (const a of y)
      a(m);
    const i = m.join(" ");
    r.value !== i && (e.stopPropagation(), e.preventDefault(), l(r, i), setTimeout(() => o.requestSubmit(), 0), t = !0);
  });
}
function $() {
  p(s(document, n.Tile.selector), P);
}
u.add(import.meta.url, $, "Corrects tile commands.");
