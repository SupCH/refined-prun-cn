const t = "rp-GAME__tooltip___74e4fdf", _ = "rp-GAME__sidebarInputPair___76840bf", p = "rp-GAME__sidebarInput___41eca58", r = {
  tooltip: t,
  sidebarInputPair: _,
  sidebarInput: p
};
export {
  r as default,
  p as sidebarInput,
  _ as sidebarInputPair,
  t as tooltip
};
