import { t } from "./index5.js";
import { calculateLocationAssets as R } from "./financials.js";
import g from "./KeyFigures.vue.js";
import c from "./FinHeader.vue.js";
import { formatCurrency as a, fixed0 as s, fixed1 as L, fixed2 as T, percent0 as N, percent1 as V, percent2 as F } from "./format.js";
import { liveBalanceSummary as r } from "./balance-sheet-live.js";
import { defineComponent as B, computed as d, createElementBlock as f, openBlock as m, createVNode as p, createElementVNode as i, withCtx as b, createTextVNode as v, Fragment as k, renderList as C } from "./runtime-core.esm-bundler.js";
import { toDisplayString as u } from "./shared.esm-bundler.js";
import { unref as n } from "./reactivity.esm-bundler.js";
const z = /* @__PURE__ */ B({
  __name: "FIN",
  setup(w) {
    const q = d(() => R());
    function A(e) {
      if (e === void 0)
        return "--";
      if (!isFinite(e))
        return "N/A";
      const l = Math.abs(e);
      return l > 1e3 ? e > 0 ? "> 1,000" : "< -1,000" : l > 100 ? s(e) : l > 10 ? L(e) : T(e);
    }
    function y(e) {
      if (e === void 0)
        return "--";
      if (!isFinite(e))
        return "N/A";
      const l = Math.abs(e);
      return l > 10 ? e > 0 ? "> 1,000%" : "< -1,000%" : l > 1 ? N(e) : l > 0.1 ? V(e) : F(e);
    }
    const h = d(() => [
      {
        name: t("fin.quickAssets"),
        value: a(r.quickAssets),
        tooltip: t("fin.quickAssetsTooltip")
      },
      {
        name: t("fin.currentAssets"),
        value: a(r.currentAssets)
      },
      { name: t("fin.totalAssets"), value: a(r.assets) },
      { name: t("fin.equity"), value: a(r.equity) },
      {
        name: t("fin.quickLiabilities"),
        value: a(r.quickLiabilities),
        tooltip: t("fin.quickLiabilitiesTooltip")
      },
      {
        name: t("fin.currentLiabilities"),
        value: a(r.currentLiabilities)
      },
      {
        name: t("fin.totalLiabilities"),
        value: a(r.liabilities)
      },
      {
        name: t("fin.liquidationValue"),
        value: a(r.liquidationValue),
        tooltip: t("fin.liquidationValueTooltip")
      },
      {
        name: t("fin.quickRatio"),
        value: A(r.acidTestRatio),
        tooltip: t("fin.quickRatioTooltip")
      },
      {
        name: t("fin.debtRatio"),
        value: y(r.debtRatio),
        tooltip: t("fin.debtRatioTooltip")
      }
    ]);
    return (e, l) => (m(), f(k, null, [
      p(c, null, {
        default: b(() => [
          v(u(("t" in e ? e.t : n(t))("fin.keyFigures")), 1)
        ]),
        _: 1
      }),
      p(g, { figures: n(h) }, null, 8, ["figures"]),
      p(c, null, {
        default: b(() => [
          v(u(("t" in e ? e.t : n(t))("fin.inventoryBreakdown")), 1)
        ]),
        _: 1
      }),
      i("table", null, [
        i("thead", null, [
          i("tr", null, [
            i("th", null, u(("t" in e ? e.t : n(t))("fin.name")), 1),
            i("th", null, u(("t" in e ? e.t : n(t))("fin.nonCurrentAssets")), 1),
            i("th", null, u(("t" in e ? e.t : n(t))("fin.currentAssets")), 1),
            i("th", null, u(("t" in e ? e.t : n(t))("fin.totalAssetsTable")), 1)
          ])
        ]),
        i("tbody", null, [
          (m(!0), f(k, null, C(n(q), (o) => (m(), f("tr", {
            key: o.name
          }, [
            i("td", null, u(o.name), 1),
            i("td", null, u(n(s)(o.nonCurrent)), 1),
            i("td", null, u(n(s)(o.current)), 1),
            i("td", null, u(n(s)(o.total)), 1)
          ]))), 128))
        ])
      ])
    ], 64));
  }
});
export {
  z as default
};
