import { subscribe as f } from "./subscribe-async-generator.js";
import { _$$ as l, $$ as c } from "./select-dom.js";
import { C as n } from "./prun-css.js";
import p from "./tiles.js";
import u from "./feature-registry.js";
import { watchEffectWhileNodeAlive as d } from "./watch.js";
import { refValue as v } from "./reactive-dom.js";
function B(o) {
  o.parameter && f(c(o.anchor, n.Site.info), (m) => {
    const r = l(m, n.FormComponent.containerPassive);
    if (r.length < 2)
      return;
    const t = r[0];
    t.style.display = "none";
    const e = t.getElementsByTagName("progress")[0];
    if (e === void 0)
      return;
    const a = e.cloneNode(!0), s = v(e);
    d(e, () => a.value = s.value);
    const i = r[1].getElementsByTagName("div")[0];
    i.insertBefore(a, i.lastChild);
  });
}
function g() {
  p.observe("BS", B);
}
u.add(import.meta.url, g, "BS: 合并区域进度条与详细区域统计行。");
