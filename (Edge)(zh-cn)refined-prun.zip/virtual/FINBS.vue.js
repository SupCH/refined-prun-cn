import o from "./FINBS.vue2.js";
/* empty css           */
import t from "./plugin-vue_export-helper.js";
const p = /* @__PURE__ */ t(o, [["__scopeId", "data-v-e7f564c4"]]);
export {
  p as default
};
