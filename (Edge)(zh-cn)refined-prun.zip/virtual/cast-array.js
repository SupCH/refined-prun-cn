function t(r) {
  return Array.isArray(r) ? r : [r];
}
export {
  t as castArray
};
