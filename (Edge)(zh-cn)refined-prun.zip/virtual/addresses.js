import { onApiMessage as y } from "./api-messages.js";
import { shallowReactive as f } from "./reactivity.esm-bundler.js";
const r = f({});
y({
  SHIP_SHIPS(t) {
    for (const e of t.ships)
      r[e.id] = e.address;
  },
  SHIP_DATA(t) {
    r[t.id] = t.address;
  },
  SITE_SITES(t) {
    for (const e of t.sites)
      r[e.siteId] = e.address;
  },
  SITE_SITE(t) {
    r[t.siteId] = t.address;
  },
  WAREHOUSE_STORAGES(t) {
    for (const e of t.storages)
      r[e.storeId] = e.address;
  },
  WAREHOUSE_STORAGE(t) {
    r[t.storeId] = t.address;
  }
});
({
  ...r
});
const d = (t) => o(t)?.entity.naturalId, c = (t) => {
  const e = o(t);
  if (!e)
    return;
  if (e.type !== "PLANET" || e.entity.name !== e.entity.naturalId)
    return e.entity.name;
  const n = m(t);
  return !n || n.entity.name === n.entity.naturalId ? e.entity.name : e.entity.name.replace(n.entity.naturalId, `${n.entity.name} `);
}, m = (t) => {
  if (t)
    return a(t.lines[0]) ? t.lines[0] : t.lines.find(a);
}, o = (t) => {
  if (t)
    return u(t.lines[1]) ? t.lines[1] : t.lines.find(u);
};
function p(t) {
  if (!t)
    return;
  const e = o(t);
  return e?.type === "STATION" ? e.entity.naturalId : c(t);
}
function T(t) {
  if (!t)
    return;
  const e = o(t);
  if (e?.type === "STATION")
    return e.entity.name;
  const n = t.lines[0], i = t.lines[1];
  if (n === void 0)
    return;
  if (i === void 0)
    return n.entity.name;
  if (i.entity.name !== i.entity.naturalId)
    return `${n.entity.name} - ${i.entity.name}`;
  const l = i.entity.naturalId.replace(n.entity.naturalId, "");
  return `${n.entity.name} ${l}`;
}
function a(t) {
  return t?.type === "SYSTEM";
}
function u(t) {
  return t?.type === "PLANET" || t?.type === "STATION";
}
function A(t, e) {
  if (!t || !e)
    return !1;
  if (t === e)
    return !0;
  for (let n = 0; n < t.lines.length; n++) {
    const i = t.lines[n], s = e.lines[n];
    if (i === void 0 || s === void 0 || i.entity.id !== s.entity.id)
      return !1;
  }
  return !0;
}
export {
  T as getDestinationFullName,
  p as getDestinationName,
  c as getEntityNameFromAddress,
  d as getEntityNaturalIdFromAddress,
  o as getLocationLineFromAddress,
  m as getSystemLineFromAddress,
  A as isSameAddress
};
