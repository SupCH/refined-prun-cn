const e = "rp-ConfigureWindow__config___5e0ce79", o = "rp-ConfigureWindow__sectionHeader___94a4730", n = {
  config: e,
  sectionHeader: o
};
export {
  e as config,
  n as default,
  o as sectionHeader
};
