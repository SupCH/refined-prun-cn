function a(r, e) {
  let t = r.get(e);
  return t === void 0 && (t = [], r.set(e, t)), t;
}
export {
  a as default
};
