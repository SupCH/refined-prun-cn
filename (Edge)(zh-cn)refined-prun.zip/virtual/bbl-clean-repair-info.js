import { subscribe as c } from "./subscribe-async-generator.js";
import { $$ as f } from "./select-dom.js";
import { C as t } from "./prun-css.js";
import { applyCssRule as s } from "./refined-prun-css.js";
import u from "./tiles.js";
import h from "./feature-registry.js";
import n from "./css-utils.module.css.js";
import { watchEffectWhileNodeAlive as b } from "./watch.js";
import { refPrunId as L } from "./attributes.js";
import { sitesStore as B } from "./sites.js";
import { isRepairableBuilding as v } from "./buildings.js";
import { computed as p } from "./runtime-core.esm-bundler.js";
function S(i) {
  const e = i.parameter, a = p(() => B.getById(e));
  c(f(i.anchor, t.SectionList.section), (r) => {
    const l = L(r), o = p(() => a.value?.platforms.find((m) => m.id == l.value));
    b(r, () => {
      o.value && (d(r, "data-rp-established", o.value.lastRepair === null), d(r, "data-rp-repaired", o.value.lastRepair !== null), d(r, "data-rp-infrastructure", !v(o.value)));
    });
  });
}
function d(i, e, a) {
  a ? i.setAttribute(e, "") : i.removeAttribute(e);
}
function $() {
  s(
    "BBL",
    `.${t.SectionList.section}[data-rp-established] .${t.SectionList.table} tr:nth-child(2)`,
    n.hidden
  ), s(
    "BBL",
    `.${t.SectionList.section}[data-rp-repaired] .${t.SectionList.table} tr:nth-child(1)`,
    n.hidden
  ), s(
    "BBL",
    `.${t.SectionList.section}[data-rp-infrastructure] .${t.SectionList.table} tr:nth-child(3)`,
    n.hidden
  ), u.observe("BBL", S);
}
h.add(
  import.meta.url,
  $,
  'BBL: Hides "Last repair", "Established", and "Repair costs" rows if they are empty or irrelevant to repairs.'
);
