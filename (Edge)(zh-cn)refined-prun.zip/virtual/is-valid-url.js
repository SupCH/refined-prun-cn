function r(e) {
  if (!e)
    return !1;
  try {
    return !!new URL(e);
  } catch {
    return !1;
  }
}
export {
  r as isValidUrl
};
