import r from "./font-awesome.module.css.js";
import { defineComponent as l, createElementBlock as m, openBlock as p, createElementVNode as o } from "./runtime-core.esm-bundler.js";
import { normalizeClass as a, toDisplayString as t } from "./shared.esm-bundler.js";
import { unref as s } from "./reactivity.esm-bundler.js";
const u = /* @__PURE__ */ l({
  __name: "Checkmark",
  props: {
    task: {}
  },
  setup(i) {
    return (e, n) => (p(), m("div", {
      class: a(e.$style.checkmark)
    }, [
      o("div", {
        class: a([s(r).regular, e.$style.circle])
      }, t(""), 2),
      o("div", {
        class: a([e.$style.mark, e.task.completed ? [s(r).solid, e.$style.markCompleted] : s(r).regular])
      }, t(e.task.completed ? "" : e.task.recurring ? "" : ""), 3)
    ], 2));
  }
});
export {
  u as default
};
