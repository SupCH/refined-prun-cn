import f from "./Edit.vue2.js";
export {
  f as default
};
