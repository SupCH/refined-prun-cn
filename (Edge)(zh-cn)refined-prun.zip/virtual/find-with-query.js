import { castArray as u } from "./cast-array.js";
function g(e, m) {
  typeof e == "string" && (e = e.trim().split(" ").filter((t) => t.length > 0)), e = e.map((t) => t.toLowerCase());
  let i = [];
  const c = /* @__PURE__ */ new Set(), o = /* @__PURE__ */ new Set();
  let r = !0, f = !1, a = !1, n = "";
  const s = [];
  for (; e.length > 0; ) {
    const t = e.shift();
    if (s.push(t), n.length === 0 ? n = t : n += " " + t, n === "not") {
      a = !0, f = !0, n = "", s.length = 0;
      continue;
    }
    const h = m(n, s);
    if (h === void 0)
      continue;
    const d = u(h);
    if (a) {
      f = !1;
      for (const l of d)
        o.add(l);
    } else {
      r = !1;
      for (const l of d)
        c.has(l) || (i.push(l), c.add(l));
    }
    n = "", s.length = 0;
  }
  return i = i.filter((t) => !o.has(t)), {
    include: i,
    exclude: o,
    includeAll: r,
    excludeAll: f
  };
}
export {
  g as findWithQuery
};
