import f from "./EditPriceLimits.vue.js";
export {
  f as default
};
