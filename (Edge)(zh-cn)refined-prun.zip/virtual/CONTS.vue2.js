import f from "./CONTS.vue.js";
export {
  f as default
};
