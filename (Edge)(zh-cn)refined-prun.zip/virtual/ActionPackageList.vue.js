import s from "./ActionPackageList.vue2.js";
import o from "./ActionPackageList.vue3.js";
import t from "./plugin-vue_export-helper.js";
const c = {
  $style: o
}, f = /* @__PURE__ */ t(s, [["__cssModules", c]]);
export {
  f as default
};
