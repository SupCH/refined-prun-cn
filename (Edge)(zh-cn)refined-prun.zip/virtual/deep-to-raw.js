import { isRef as a, isReactive as s, isProxy as c, toRaw as y } from "./reactivity.esm-bundler.js";
function b(f) {
  const e = (r) => Array.isArray(r) ? r.map((o) => e(o)) : a(r) || s(r) || c(r) ? e(y(r)) : r && typeof r == "object" ? Object.keys(r).reduce((o, t) => (o[t] = e(r[t]), o), {}) : r;
  return e(f);
}
export {
  b as deepToRaw
};
