import f from "./DateInput.vue.js";
export {
  f as default
};
