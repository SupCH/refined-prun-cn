import { createEntityStore as m } from "./create-entity-store.js";
import { onApiMessage as n } from "./api-messages.js";
import { createMapGetter as r } from "./create-map-getter.js";
import { castArray as c } from "./cast-array.js";
import { defaultExchanges as d } from "./exchanges.default.js";
import { getEntityNaturalIdFromAddress as s } from "./addresses.js";
import { isEmpty as i } from "./is-empty.js";
const e = m((t) => t.id, { preserveOnConnectionOpen: !0 }), o = e.state;
n({
  CLIENT_CONNECTION_OPENED() {
    e.setAll(d), e.setFetched();
  },
  DATA_DATA(t) {
    i(t.path) || t.path[0] !== "commodityexchanges" || e.setMany(c(t.body));
  }
});
const p = r(o.all, (t) => s(t.address)), a = r(o.all, (t) => t.code), l = r(o.all, (t) => t.name), y = (t) => s(a(t)?.address), C = {
  ...o,
  getByNaturalId: p,
  getByCode: a,
  getByName: l,
  getNaturalIdFromCode: y
};
export {
  C as exchangesStore
};
