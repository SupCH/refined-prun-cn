import { useCssModule as C } from "./runtime-dom.esm-bundler.js";
import { C as a } from "./prun-css.js";
import { defineComponent as z, computed as n, createElementBlock as t, openBlock as r, createElementVNode as m, createCommentVNode as f } from "./runtime-core.esm-bundler.js";
import { normalizeStyle as g, normalizeClass as i, toDisplayString as u } from "./shared.esm-bundler.js";
import { unref as s } from "./reactivity.esm-bundler.js";
const y = ["title"], N = /* @__PURE__ */ z({
  __name: "ColoredIcon",
  props: {
    background: {},
    color: {},
    subLabel: {},
    label: {},
    size: { default: "large" },
    title: {}
  },
  setup(e) {
    const o = C(), c = n(() => ({
      [a.ColoredIcon.container]: !0,
      [o.large]: e.size === "large",
      [o.medium]: e.size === "medium",
      [o.small]: e.size === "small",
      [o.inline]: e.size === "inline",
      [o.inlineTable]: e.size === "inline-table"
    })), b = n(() => e.subLabel && (e.size === "large" || e.size === "medium")), d = [
      a.ColoredIcon.subLabel,
      a.type.typeVerySmall,
      {
        [o.mediumSubLabel]: e.size === "medium"
      }
    ];
    return (l, L) => (r(), t("div", {
      class: i(s(c)),
      style: g({ background: l.background, color: l.color }),
      title: l.title
    }, [
      m("div", {
        class: i(("C" in l ? l.C : s(a)).ColoredIcon.labelContainer)
      }, [
        m("span", {
          class: i(("C" in l ? l.C : s(a)).ColoredIcon.label)
        }, u(l.label), 3),
        s(b) ? (r(), t("span", {
          key: 0,
          class: i(d)
        }, u(l.subLabel), 1)) : f("", !0)
      ], 2)
    ], 14, y));
  }
});
export {
  N as default
};
