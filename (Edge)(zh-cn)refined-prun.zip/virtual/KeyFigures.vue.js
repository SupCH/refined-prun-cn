import s from "./KeyFigures.vue2.js";
import o from "./KeyFigures.vue3.js";
import t from "./plugin-vue_export-helper.js";
const e = {
  $style: o
}, f = /* @__PURE__ */ t(s, [["__cssModules", e]]);
export {
  f as default
};
