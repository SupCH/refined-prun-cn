import { __module as t } from "./advancedFormat3.js";
var g = t.exports, c;
function h() {
  return c ? t.exports : (c = 1, (function(d, w) {
    (function(f, a) {
      d.exports = a();
    })(g, (function() {
      return function(f, a) {
        var s = a.prototype, o = s.format;
        s.format = function(i) {
          var e = this, u = this.$locale();
          if (!this.isValid()) return o.bind(this)(i);
          var n = this.$utils(), m = (i || "YYYY-MM-DDTHH:mm:ssZ").replace(/\[([^\]]+)]|Q|wo|ww|w|WW|W|zzz|z|gggg|GGGG|Do|X|x|k{1,2}|S/g, (function(r) {
            switch (r) {
              case "Q":
                return Math.ceil((e.$M + 1) / 3);
              case "Do":
                return u.ordinal(e.$D);
              case "gggg":
                return e.weekYear();
              case "GGGG":
                return e.isoWeekYear();
              case "wo":
                return u.ordinal(e.week(), "W");
              case "w":
              case "ww":
                return n.s(e.week(), r === "w" ? 1 : 2, "0");
              case "W":
              case "WW":
                return n.s(e.isoWeek(), r === "W" ? 1 : 2, "0");
              case "k":
              case "kk":
                return n.s(String(e.$H === 0 ? 24 : e.$H), r === "k" ? 1 : 2, "0");
              case "X":
                return Math.floor(e.$d.getTime() / 1e3);
              case "x":
                return e.$d.getTime();
              case "z":
                return "[" + e.offsetName() + "]";
              case "zzz":
                return "[" + e.offsetName("long") + "]";
              default:
                return r;
            }
          }));
          return o.bind(this)(m);
        };
      };
    }));
  })(t), t.exports);
}
export {
  h as __require
};
