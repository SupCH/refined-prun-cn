import o from "./FINPR.vue2.js";
/* empty css           */
import t from "./plugin-vue_export-helper.js";
const p = /* @__PURE__ */ t(o, [["__scopeId", "data-v-64f55482"]]);
export {
  p as default
};
