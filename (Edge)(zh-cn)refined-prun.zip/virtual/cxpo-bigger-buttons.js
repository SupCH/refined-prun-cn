import { applyCssRule as t } from "./refined-prun-css.js";
import { C as o } from "./prun-css.js";
import m from "./feature-registry.js";
import r from "./cxpo-bigger-buttons.module.css.js";
function n() {
  t(
    "CXPO",
    `.${o.FormComponent.containerCommand} .${o.FormComponent.input}`,
    r.container
  );
}
m.add(import.meta.url, n, 'CXPO: Makes "Buy" and "Sell" buttons bigger.');
