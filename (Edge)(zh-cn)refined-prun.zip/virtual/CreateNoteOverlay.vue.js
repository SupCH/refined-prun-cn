import { C as d } from "./prun-css.js";
import p from "./PrunButton.vue.js";
import C from "./SectionHeader.vue.js";
import c from "./Active.vue.js";
import _ from "./TextInput.vue.js";
import N from "./Commands.vue.js";
import { defineComponent as V, createElementBlock as v, openBlock as E, createVNode as t, createElementVNode as k, withCtx as r, createTextVNode as l } from "./runtime-core.esm-bundler.js";
import { ref as $, isRef as y, unref as m } from "./reactivity.esm-bundler.js";
import { normalizeClass as B } from "./shared.esm-bundler.js";
const F = /* @__PURE__ */ V({
  __name: "CreateNoteOverlay",
  props: {
    onCreate: { type: Function }
  },
  emits: ["close"],
  setup(a, { emit: i }) {
    const f = i, o = $("");
    function u() {
      o.value.length !== 0 && (a.onCreate(o.value), f("close"));
    }
    return (n, e) => (E(), v("div", {
      class: B(("C" in n ? n.C : m(d)).DraftConditionEditor.form)
    }, [
      t(C, null, {
        default: r(() => [...e[1] || (e[1] = [
          l("New Note", -1)
        ])]),
        _: 1
      }),
      k("form", null, [
        t(c, { label: "Note Name" }, {
          default: r(() => [
            t(_, {
              modelValue: m(o),
              "onUpdate:modelValue": e[0] || (e[0] = (s) => y(o) ? o.value = s : null)
            }, null, 8, ["modelValue"])
          ]),
          _: 1
        }),
        t(N, null, {
          default: r(() => [
            t(p, {
              primary: "",
              onClick: u
            }, {
              default: r(() => [...e[2] || (e[2] = [
                l("CREATE", -1)
              ])]),
              _: 1
            })
          ]),
          _: 1
        })
      ])
    ], 2));
  }
});
export {
  F as default
};
