import { Line as C } from "./index15.js";
import { Chart as k, LineController as w, LineElement as R, PointElement as M, LinearScale as S, Title as B, Tooltip as E, CategoryScale as A, TimeScale as L } from "./chart.js";
import $ from "./chartjs-plugin-zoom.esm.js";
import { formatCurrency as D, hhmm as N, ddmmyyyy as O, fixed0 as T, ddmm as W } from "./format.js";
import { defineComponent as H, computed as f, useTemplateRef as V, onMounted as q, createElementBlock as F, openBlock as I, createElementVNode as P, createVNode as Y } from "./runtime-core.esm-bundler.js";
import { ref as g, unref as l } from "./reactivity.esm-bundler.js";
import { normalizeClass as j, normalizeStyle as G } from "./shared.esm-bundler.js";
const ee = /* @__PURE__ */ H({
  __name: "LineChart",
  props: {
    averageFactor: { default: 0.2 },
    maintainAspectRatio: { type: Boolean },
    pan: { type: Boolean },
    xdata: {},
    ydata: {},
    zoom: { type: Boolean }
  },
  setup(t) {
    k.register(
      w,
      R,
      M,
      S,
      B,
      E,
      A,
      L
    );
    const s = f(() => t.ydata.slice().sort((e, a) => e - a));
    function x(e, a) {
      a = Math.min(Math.max(a, 0), 1);
      const o = Math.max(Math.floor(a * e.length), 1);
      if (o === 1)
        return e;
      const y = Math.floor(o / 2), c = [];
      c.push(e[0]);
      let m = e[0], d = 0, u = 0;
      for (let r = 1; r < e.length; r++) {
        let i = r - y, n = r + y;
        for (i < 0 ? (n += i, i = 0) : n >= e.length && (i += n - e.length + 1, n = e.length - 1, i === n && (i = n - 1)); i > d; )
          m -= e[d++];
        for (; n > u; )
          m += e[++u];
        c.push(m / (u - d + 1));
      }
      return c;
    }
    const b = f(() => ({
      labels: t.xdata,
      datasets: [
        {
          label: "Equity",
          data: t.ydata,
          borderColor: "#f7a600",
          fill: !1,
          pointRadius: 0.25,
          pointBackgroundColor: "#f7a600",
          showLine: !1
        },
        {
          label: void 0,
          data: x(t.ydata, t.averageFactor),
          borderColor: "#f7a600",
          fill: !1,
          pointRadius: 0,
          pointHitRadius: 0
        }
      ]
    })), v = f(() => ({
      maintainAspectRatio: t.maintainAspectRatio,
      scales: {
        x: {
          type: "time",
          title: {
            display: !0,
            text: "Date",
            color: "#eeeeee",
            font: {
              family: '"Droid Sans", sans-serif'
            }
          },
          grid: {
            color: "#505050"
          },
          ticks: {
            color: "#999",
            callback(e) {
              return W(Number(e));
            }
          }
        },
        y: {
          type: "linear",
          title: {
            display: !0,
            text: "Equity",
            color: "#eeeeee",
            font: {
              family: '"Droid Sans", sans-serif'
            }
          },
          grid: {
            color: "#505050"
          },
          ticks: {
            color: "#999",
            callback(e) {
              return typeof e == "number" ? `${T(e / 1e6)}M` : e;
            }
          }
        }
      },
      plugins: {
        legend: {
          display: !1
        },
        tooltip: {
          mode: "nearest",
          axis: "x",
          intersect: !1,
          callbacks: {
            title(e) {
              const o = e[0]?.parsed?.x;
              if (o !== void 0)
                return `${N(o)} ${O(o)}`;
            },
            label(e) {
              let a = e.dataset.label || "";
              return a && (a += ": "), a += D(e.parsed.y), a;
            }
          },
          filter: (e) => e.datasetIndex === 0
        },
        zoom: {
          limits: {
            x: { min: t.xdata[0], max: t.xdata[t.xdata.length - 1] },
            y: { min: 0, max: s.value[s.value.length - 1] + s.value[0] }
          },
          pan: {
            enabled: t.pan,
            mode: "xy",
            threshold: 5
          },
          zoom: {
            wheel: {
              enabled: t.zoom
            },
            pinch: {
              enabled: t.zoom
            },
            mode: "xy"
          }
        }
      },
      elements: {
        point: {
          radius: 0
        }
      }
    })), z = V("outer-container"), h = g(400), p = g(200);
    return q(() => {
      const e = z.value;
      new ResizeObserver(() => {
        h.value = e.clientWidth, p.value = t.maintainAspectRatio ? e.clientWidth / 2 : e.clientHeight;
      }).observe(e);
    }), (e, a) => (I(), F("div", {
      ref: "outer-container",
      class: j(e.$style.outer)
    }, [
      P("div", {
        style: G({ position: "relative", width: `${l(h)}px`, height: `${l(p)}px` })
      }, [
        Y(l(C), {
          options: l(v),
          data: l(b),
          plugins: [l($)]
        }, null, 8, ["options", "data", "plugins"])
      ], 4)
    ], 2));
  }
});
export {
  ee as default
};
