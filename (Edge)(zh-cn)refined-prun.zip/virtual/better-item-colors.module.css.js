const s = "rp-better-item-colors__agriculturalProducts___f0e6cc7", e = "rp-better-item-colors__consumablesBasic___76284e0", t = "rp-better-item-colors__consumablesLuxury___0f2f54e", c = "rp-better-item-colors__fuels___15ea6b9", _ = "rp-better-item-colors__liquids___f6104c3", r = "rp-better-item-colors__plastics___47722f5", l = "rp-better-item-colors__shipShields___a54eb70", o = {
  agriculturalProducts: s,
  consumablesBasic: e,
  consumablesLuxury: t,
  fuels: c,
  liquids: _,
  plastics: r,
  shipShields: l
};
export {
  s as agriculturalProducts,
  e as consumablesBasic,
  t as consumablesLuxury,
  o as default,
  c as fuels,
  _ as liquids,
  r as plastics,
  l as shipShields
};
