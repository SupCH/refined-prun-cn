import l from "./config.js";
import d from "./Active.vue.js";
import s from "./SelectInput.vue.js";
import { storageSort as v, serializeStorage as r, deserializeStorage as p } from "./utils3.js";
import { configurableValue as f } from "./shared-types.js";
import { getRefuelOrigins as b } from "./utils6.js";
import { defineComponent as h, computed as g, watchEffect as S, createElementBlock as V, openBlock as C, createVNode as m, withCtx as O } from "./runtime-core.esm-bundler.js";
import { unref as a } from "./reactivity.esm-bundler.js";
const R = /* @__PURE__ */ h({
  __name: "Configure",
  props: {
    data: {},
    config: {}
  },
  setup(i) {
    const n = g(() => b().sort(v)), u = g(() => c(n.value));
    i.data.origin === f && !i.config.origin && n.value.length > 0 && (i.config.origin = r(n.value[0])), S(() => {
      if (i.data.origin === f) {
        if (i.config.origin) {
          const o = p(i.config.origin);
          (!o || !n.value.includes(o)) && (i.config.origin = void 0);
        }
        !i.config.origin && n.value.length === 1 && (i.config.origin = r(n.value[0]));
      }
    });
    function c(o) {
      const e = o.map(r).map((t) => ({ label: t, value: t }));
      return e.length === 0 && e.push({ label: "No locations available", value: void 0 }), e;
    }
    return (o, e) => (C(), V("form", null, [
      m(d, { label: "From" }, {
        default: O(() => [
          m(s, {
            modelValue: ("config" in o ? o.config : a(l)).origin,
            "onUpdate:modelValue": e[0] || (e[0] = (t) => ("config" in o ? o.config : a(l)).origin = t),
            options: a(u)
          }, null, 8, ["modelValue", "options"])
        ]),
        _: 1
      })
    ]));
  }
});
export {
  R as default
};
