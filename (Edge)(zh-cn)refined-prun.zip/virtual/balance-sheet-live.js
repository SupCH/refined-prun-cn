import { timestampEachSecond as u } from "./dayjs.js";
import { currentAssets as e } from "./current-assets.js";
import { nonCurrentAssets as a } from "./non-current-assets.js";
import { currentLiabilities as o } from "./current-liabilities.js";
import { nonCurrentLiabilities as l } from "./non-current-liabilities.js";
import { calcDebtRatio as m, calcAcidTestRatio as b, calcQuickLiabilities as p, calcQuickAssets as y, calcLiquidationValue as f, calcEquity as v, calcTotalIntangibleAssets as d, calcTotalLiabilities as T, calcTotalNonCurrentLiabilities as h, calcTotalCurrentLiabilities as g, calcTotalAssets as P, calcTotalNonCurrentAssets as R, calcTotalCurrentAssets as k } from "./balance-sheet-summary.js";
import { isRef as L } from "./reactivity.esm-bundler.js";
import { computed as A } from "./runtime-core.esm-bundler.js";
const x = C();
function C() {
  return t({
    timestamp: u,
    assets: {
      current: t({
        cashAndCashEquivalents: t({
          cash: e.cashTotal,
          deposits: t({
            cx: e.cxDepositsTotal,
            fx: e.fxDepositsTotal
          }),
          mmMaterials: e.inventory.mmMaterialsTotal
        }),
        accountsReceivable: e.accountsReceivable,
        loansReceivable: t({
          principal: e.shortTermLoans,
          interest: e.interestReceivable
        }),
        inventory: t({
          cxListedMaterials: e.inventory.cxListedMaterials,
          cxInventory: e.inventory.cxInventoryTotal,
          materialsInTransit: e.inventory.materialsInTransit,
          baseInventory: t({
            finishedGoods: e.inventory.finishedGoods,
            workInProgress: e.inventory.workInProgress,
            rawMaterials: e.inventory.rawMaterials,
            workforceConsumables: e.inventory.workforceConsumables,
            otherItems: e.inventory.otherItems
          }),
          fuelTanks: e.inventory.fuelTanks,
          materialsReceivable: e.inventory.materialsReceivable
        })
      }),
      nonCurrent: t({
        buildings: t({
          marketValue: t({
            infrastructure: a.buildings.infrastructure,
            resourceExtraction: a.buildings.resourceExtraction,
            production: a.buildings.production
          }),
          accumulatedDepreciation: a.buildings.accumulatedDepreciation
        }),
        ships: t({
          marketValue: a.shipsMarketValue,
          accumulatedDepreciation: a.shipsDepreciation
        }),
        longTermReceivables: t({
          accountsReceivable: a.accountsReceivable,
          materialsInTransit: a.materialsInTransit,
          materialsReceivable: a.materialsReceivable,
          loansPrincipal: a.longTermLoans
        }),
        intangibleAssets: t({
          hqUpgrades: a.hqUpgrades,
          arc: a.arc
        })
      })
    },
    liabilities: {
      current: t({
        accountsPayable: o.accountsPayable,
        materialsPayable: o.materialsPayable,
        loansPayable: t({
          principal: o.shortTermDebt,
          interest: o.interestPayable
        })
      }),
      nonCurrent: t({
        longTermPayables: t({
          accountsPayable: l.accountsPayable,
          materialsPayable: l.materialsPayable,
          loansPrincipal: l.longTermDebt
        })
      })
    }
  });
}
function t(r) {
  const s = {};
  for (const i in r)
    if (Object.prototype.hasOwnProperty.call(r, i)) {
      const n = r[i];
      L(n) ? Object.defineProperty(s, i, {
        get: () => n.value,
        enumerable: !0,
        configurable: !0
      }) : s[i] = n;
    }
  return s;
}
const B = I({
  currentAssets: k,
  nonCurrentAssets: R,
  assets: P,
  currentLiabilities: g,
  nonCurrentLiabilities: h,
  liabilities: T,
  intangibleAssets: d,
  equity: v,
  liquidationValue: f,
  quickAssets: y,
  quickLiabilities: p,
  acidTestRatio: b,
  debtRatio: m
});
function I(r) {
  const s = {};
  for (const i in r)
    if (Object.prototype.hasOwnProperty.call(r, i)) {
      const n = r[i], c = A(() => n(x));
      Object.defineProperty(s, i, {
        get: () => c.value,
        enumerable: !0,
        configurable: !0
      });
    }
  return s;
}
export {
  x as liveBalanceSheet,
  B as liveBalanceSummary
};
