import { _adapters as f } from "./chart.js";
import t from "./dayjs.min.js";
import a from "./customParseFormat.js";
import i from "./advancedFormat.js";
import d from "./quarterOfYear.js";
import m from "./localizedFormat.js";
import s from "./isoWeek.js";
t.extend(i);
t.extend(d);
t.extend(m);
t.extend(a);
t.extend(s);
const u = {
  datetime: "MMM D, YYYY, h:mm:ss a",
  millisecond: "h:mm:ss.SSS a",
  second: "h:mm:ss a",
  minute: "h:mm a",
  hour: "hA",
  day: "MMM D",
  week: "ll",
  month: "MMM YYYY",
  quarter: "[Q]Q - YYYY",
  year: "YYYY"
};
f._date.override({
  formats: () => u,
  parse: function(r, e) {
    const n = typeof r;
    return r === null || n === "undefined" ? null : n === "string" && typeof e == "string" ? t(r, e).isValid() ? t(r, e).valueOf() : null : r instanceof t ? null : t(r).isValid() ? t(r).valueOf() : null;
  },
  format: function(r, e) {
    return t(r).format(e);
  },
  add: function(r, e, n) {
    return t(r).add(e, n).valueOf();
  },
  diff: function(r, e, n) {
    return t(r).diff(t(e), n);
  },
  startOf: function(r, e, n) {
    if (e === "isoWeek") {
      const o = typeof n == "number" && n > 0 && n < 7 ? n : 1;
      return t(r).isoWeekday(o).startOf("day").valueOf();
    }
    return t(r).startOf(e).valueOf();
  },
  endOf: function(r, e) {
    return t(r).endOf(e).valueOf();
  }
});
