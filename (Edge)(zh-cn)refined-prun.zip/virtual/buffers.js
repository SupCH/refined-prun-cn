import E from "./tiles.js";
import { C as i } from "./prun-css.js";
import { _$ as f, $ as u, _$$ as y } from "./select-dom.js";
import { clickElement as k, changeInputValue as W } from "./util.js";
import { sleep as C } from "./sleep.js";
import l from "./css-utils.module.css.js";
import _ from "./on-node-disconnected.js";
import { getPrunId as D } from "./attributes.js";
import { watchUntil as I } from "./watch.js";
import { dispatchClientPrunMessage as p } from "./prun-api-listener.js";
import { clamp as S } from "./clamp.js";
import { UI_WINDOWS_REQUEST_FOCUS as P, UI_TILES_CHANGE_COMMAND as T, UI_WINDOWS_UPDATE_SIZE as N } from "./client-messages.js";
import { onNodeTreeMutation as U } from "./on-node-tree-mutation.js";
import { isEmpty as x } from "./is-empty.js";
let d = !1;
const w = [];
async function K(t, r) {
  if (!r?.force) {
    const e = E.find(t).find((o) => !o.docked);
    if (e) {
      const o = e.frame.closest(`.${i.Window.window}`), s = P(e.id);
      if (p(s))
        return o;
      const c = f(o, i.Window.header);
      return k(c), o;
    }
  }
  await B();
  const n = await u(document.documentElement, i.Dock.create);
  try {
    const e = document.getElementsByClassName(i.Window.window), o = new Set(Array.from(e)), s = await new Promise((c) => {
      U(document, () => {
        for (let a = 0; a < e.length; a++)
          if (!o.has(e[a]))
            return c(e[a]), !0;
        return !1;
      }), n.click();
    });
    return await $(s, t, r), s;
  } finally {
    L();
  }
}
async function B() {
  if (!d) {
    d = !0;
    return;
  }
  await new Promise((t) => w.push(t));
}
function L() {
  x(w) ? d = !1 : setTimeout(w.shift(), 0);
}
async function $(t, r, n) {
  const e = f(t, i.PanelSelector.input), o = e.form;
  if (!o?.isConnected)
    return;
  if (!(n?.autoSubmit ?? !0)) {
    W(e, r);
    return;
  }
  t.classList.add(l.hidden);
  const s = f(t, i.Tile.tile), c = D(s);
  if (n?.autoClose) {
    const m = c?.padStart(2, "0"), h = y(document, i.Dock.buffer).find(
      (g) => f(g, i.Dock.title)?.textContent === m
    );
    h && h.classList.add(l.hidden);
  }
  const a = T(c, r);
  p(a) || (W(e, r), await C(0), o.requestSubmit());
  const b = await u(t, i.Tile.selector);
  if (await Promise.any([
    new Promise((m) => _(e, m)),
    u(b, i.Tile.warning)
  ]), !n?.autoClose) {
    t.classList.remove(l.hidden);
    return;
  }
  v(t, n);
}
async function v(t, r) {
  await C(0);
  const n = r?.closeWhen;
  n && await I(n);
  const o = y(t, i.Window.button).find((s) => s.textContent === "x");
  o && o?.click(), await new Promise((s) => _(t, s));
}
function X(t, r, n) {
  p(
    N(
      t,
      S(r, 100, document.body.clientWidth - 50),
      S(n, 50, document.body.clientHeight - 50)
    )
  );
}
export {
  X as setBufferSize,
  K as showBuffer
};
