import f from "./EditMaterialGroup.vue.js";
export {
  f as default
};
