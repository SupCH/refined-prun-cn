import { subscribe as n } from "./subscribe-async-generator.js";
import { $$ as r } from "./select-dom.js";
import { C as o } from "./prun-css.js";
import { createFragmentApp as s } from "./vue-fragment-app.js";
import a from "./tiles.js";
import p from "./feature-registry.js";
import { createVNode as i, Fragment as g } from "./runtime-core.esm-bundler.js";
function l(t) {
  n(r(t.anchor, o.MessageList.messages), (e) => {
    n(r(e, o.Link.link), f);
  });
}
function f(t) {
  const e = t.textContent;
  if (!e || !c(e))
    return;
  const m = {
    maxHeight: "300px",
    maxWidth: "90%"
  };
  s(() => i(g, null, [i("br", null, null), i("img", {
    src: e,
    alt: "Chat image",
    style: m
  }, null)])).appendTo(t.parentElement);
}
function c(t) {
  return /\.(jpg|jpeg|png|webp|avif|gif|svg)$/.test(t);
}
function u() {
  a.observe(["COMG", "COMP", "COMU"], l);
}
p.add(import.meta.url, u, "Adds images to chat messages containing image URLs.");
