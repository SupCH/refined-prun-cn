import d from "./PlanetHeader.vue.js";
import s from "./MaterialList.vue.js";
import { useTileState as f } from "./tile-state5.js";
import { defineComponent as p, computed as t, createElementBlock as o, openBlock as u, Fragment as b, createElementVNode as v, createCommentVNode as z, createVNode as m } from "./runtime-core.esm-bundler.js";
import { unref as l } from "./reactivity.esm-bundler.js";
const k = { key: 0 }, C = /* @__PURE__ */ p({
  __name: "BurnSection",
  props: {
    burn: {},
    canMinimize: { type: Boolean }
  },
  setup(i) {
    const e = f("expand"), a = t(() => i.burn.naturalId), r = t(() => i.canMinimize && !e.value.includes(a.value)), c = () => {
      i.canMinimize && (r.value ? e.value = [...e.value, a.value] : e.value = e.value.filter((n) => n !== a.value));
    };
    return (n, B) => (u(), o(b, null, [
      v("tbody", null, [
        m(d, {
          "has-minimize": n.canMinimize,
          burn: n.burn,
          minimized: l(r),
          "on-click": c
        }, null, 8, ["has-minimize", "burn", "minimized"])
      ]),
      l(r) ? z("", !0) : (u(), o("tbody", k, [
        m(s, { burn: n.burn }, null, 8, ["burn"])
      ]))
    ], 64));
  }
});
export {
  C as default
};
