import { Color as he } from "./color.esm.js";
/*!
 * Chart.js v4.5.0
 * https://www.chartjs.org
 * (c) 2025 Chart.js Contributors
 * Released under the MIT License
 */
function Jt() {
}
const Vt = /* @__PURE__ */ (() => {
  let e = 0;
  return () => e++;
})();
function R(e) {
  return e == null;
}
function x(e) {
  if (Array.isArray && Array.isArray(e))
    return !0;
  const t = Object.prototype.toString.call(e);
  return t.slice(0, 7) === "[object" && t.slice(-6) === "Array]";
}
function _(e) {
  return e !== null && Object.prototype.toString.call(e) === "[object Object]";
}
function ge(e) {
  return (typeof e == "number" || e instanceof Number) && isFinite(+e);
}
function Xt(e, t) {
  return ge(e) ? e : t;
}
function w(e, t) {
  return typeof e > "u" ? t : e;
}
const Zt = (e, t) => typeof e == "string" && e.endsWith("%") ? parseFloat(e) / 100 : +e / t, Ae = (e, t) => typeof e == "string" && e.endsWith("%") ? parseFloat(e) / 100 * t : +e;
function en(e, t, n) {
  if (e && typeof e.call == "function")
    return e.apply(n, t);
}
function tn(e, t, n, o) {
  let r, i, s;
  if (x(e))
    for (i = e.length, r = 0; r < i; r++)
      t.call(n, e[r], r);
  else if (_(e))
    for (s = Object.keys(e), i = s.length, r = 0; r < i; r++)
      t.call(n, e[s[r]], s[r]);
}
function nn(e, t) {
  let n, o, r, i;
  if (!e || !t || e.length !== t.length)
    return !1;
  for (n = 0, o = e.length; n < o; ++n)
    if (r = e[n], i = t[n], r.datasetIndex !== i.datasetIndex || r.index !== i.index)
      return !1;
  return !0;
}
function E(e) {
  if (x(e))
    return e.map(E);
  if (_(e)) {
    const t = /* @__PURE__ */ Object.create(null), n = Object.keys(e), o = n.length;
    let r = 0;
    for (; r < o; ++r)
      t[n[r]] = E(e[n[r]]);
    return t;
  }
  return e;
}
function me(e) {
  return [
    "__proto__",
    "prototype",
    "constructor"
  ].indexOf(e) === -1;
}
function Be(e, t, n, o) {
  if (!me(e))
    return;
  const r = t[e], i = n[e];
  _(r) && _(i) ? F(r, i, o) : t[e] = E(i);
}
function F(e, t, n) {
  const o = x(t) ? t : [
    t
  ], r = o.length;
  if (!_(e))
    return e;
  n = n || {};
  const i = n.merger || Be;
  let s;
  for (let a = 0; a < r; ++a) {
    if (s = o[a], !_(s))
      continue;
    const c = Object.keys(s);
    for (let l = 0, u = c.length; l < u; ++l)
      i(c[l], e, s, n);
  }
  return e;
}
function De(e, t) {
  return F(e, t, {
    merger: je
  });
}
function je(e, t, n) {
  if (!me(e))
    return;
  const o = t[e], r = n[e];
  _(o) && _(r) ? De(o, r) : Object.prototype.hasOwnProperty.call(t, e) || (t[e] = E(r));
}
const ee = {
  // Chart.helpers.core resolveObjectKey should resolve empty key to root object
  "": (e) => e,
  // default resolvers
  x: (e) => e.x,
  y: (e) => e.y
};
function Le(e) {
  const t = e.split("."), n = [];
  let o = "";
  for (const r of t)
    o += r, o.endsWith("\\") ? o = o.slice(0, -1) + "." : (n.push(o), o = "");
  return n;
}
function We(e) {
  const t = Le(e);
  return (n) => {
    for (const o of t) {
      if (o === "")
        break;
      n = n && n[o];
    }
    return n;
  };
}
function Ne(e, t) {
  return (ee[t] || (ee[t] = We(t)))(e);
}
function pe(e) {
  return e.charAt(0).toUpperCase() + e.slice(1);
}
const on = (e) => typeof e < "u", z = (e) => typeof e == "function", rn = (e, t) => {
  if (e.size !== t.size)
    return !1;
  for (const n of e)
    if (!t.has(n))
      return !1;
  return !0;
};
function sn(e) {
  return e.type === "mouseup" || e.type === "click" || e.type === "contextmenu";
}
const y = Math.PI, M = 2 * y, Ee = M + y, H = Number.POSITIVE_INFINITY, Fe = y / 180, S = y / 2, P = y / 4, te = y * 2 / 3, be = Math.log10, ne = Math.sign;
function ye(e, t, n) {
  return Math.abs(e - t) < n;
}
function an(e) {
  const t = Math.round(e);
  e = ye(e, t, e / 1e3) ? t : e;
  const n = Math.pow(10, Math.floor(be(e))), o = e / n;
  return (o <= 1 ? 1 : o <= 2 ? 2 : o <= 5 ? 5 : 10) * n;
}
function cn(e) {
  const t = [], n = Math.sqrt(e);
  let o;
  for (o = 1; o < n; o++)
    e % o === 0 && (t.push(o), t.push(e / o));
  return n === (n | 0) && t.push(n), t.sort((r, i) => r - i).pop(), t;
}
function ze(e) {
  return typeof e == "symbol" || typeof e == "object" && e !== null && !(Symbol.toPrimitive in e || "toString" in e || "valueOf" in e);
}
function ln(e) {
  return !ze(e) && !isNaN(parseFloat(e)) && isFinite(e);
}
function un(e, t) {
  const n = Math.round(e);
  return n - t <= e && n + t >= e;
}
function fn(e, t, n) {
  let o, r, i;
  for (o = 0, r = e.length; o < r; o++)
    i = e[o][n], isNaN(i) || (t.min = Math.min(t.min, i), t.max = Math.max(t.max, i));
}
function dn(e) {
  return e * (y / 180);
}
function hn(e) {
  return e * (180 / y);
}
function gn(e) {
  if (!ge(e))
    return;
  let t = 1, n = 0;
  for (; Math.round(e * t) / t !== e; )
    t *= 10, n++;
  return n;
}
function mn(e, t) {
  const n = t.x - e.x, o = t.y - e.y, r = Math.sqrt(n * n + o * o);
  let i = Math.atan2(o, n);
  return i < -0.5 * y && (i += M), {
    angle: i,
    distance: r
  };
}
function oe(e, t) {
  return Math.sqrt(Math.pow(t.x - e.x, 2) + Math.pow(t.y - e.y, 2));
}
function He(e, t) {
  return (e - t + Ee) % M - y;
}
function O(e) {
  return (e % M + M) % M;
}
function qe(e, t, n, o) {
  const r = O(e), i = O(t), s = O(n), a = O(i - r), c = O(s - r), l = O(r - i), u = O(r - s);
  return r === i || r === s || o && i === s || a > c && l < u;
}
function Y(e, t, n) {
  return Math.max(t, Math.min(n, e));
}
function pn(e) {
  return Y(e, -32768, 32767);
}
function Ke(e, t, n, o = 1e-6) {
  return e >= Math.min(t, n) - o && e <= Math.max(t, n) + o;
}
function _e(e, t, n) {
  n = n || ((s) => e[s] < t);
  let o = e.length - 1, r = 0, i;
  for (; o - r > 1; )
    i = r + o >> 1, n(i) ? r = i : o = i;
  return {
    lo: r,
    hi: o
  };
}
const D = (e, t, n, o) => _e(e, n, o ? (r) => {
  const i = e[r][t];
  return i < n || i === n && e[r + 1][t] === n;
} : (r) => e[r][t] < n), bn = (e, t, n) => _e(e, n, (o) => e[o][t] >= n);
function yn(e, t, n) {
  let o = 0, r = e.length;
  for (; o < r && e[o] < t; )
    o++;
  for (; r > o && e[r - 1] > n; )
    r--;
  return o > 0 || r < e.length ? e.slice(o, r) : e;
}
const Me = [
  "push",
  "pop",
  "shift",
  "splice",
  "unshift"
];
function _n(e, t) {
  if (e._chartjs) {
    e._chartjs.listeners.push(t);
    return;
  }
  Object.defineProperty(e, "_chartjs", {
    configurable: !0,
    enumerable: !1,
    value: {
      listeners: [
        t
      ]
    }
  }), Me.forEach((n) => {
    const o = "_onData" + pe(n), r = e[n];
    Object.defineProperty(e, n, {
      configurable: !0,
      enumerable: !1,
      value(...i) {
        const s = r.apply(this, i);
        return e._chartjs.listeners.forEach((a) => {
          typeof a[o] == "function" && a[o](...i);
        }), s;
      }
    });
  });
}
function Mn(e, t) {
  const n = e._chartjs;
  if (!n)
    return;
  const o = n.listeners, r = o.indexOf(t);
  r !== -1 && o.splice(r, 1), !(o.length > 0) && (Me.forEach((i) => {
    delete e[i];
  }), delete e._chartjs);
}
function Sn(e) {
  const t = new Set(e);
  return t.size === e.length ? e : Array.from(t);
}
const Ge = (function() {
  return typeof window > "u" ? function(e) {
    return e();
  } : window.requestAnimationFrame;
})();
function On(e, t) {
  let n = [], o = !1;
  return function(...r) {
    n = r, o || (o = !0, Ge.call(window, () => {
      o = !1, e.apply(t, n);
    }));
  };
}
function xn(e, t) {
  let n;
  return function(...o) {
    return t ? (clearTimeout(n), n = setTimeout(e, t, o)) : e.apply(this, o), t;
  };
}
const Pn = (e) => e === "start" ? "left" : e === "end" ? "right" : "center", wn = (e, t, n) => e === "start" ? t : e === "end" ? n : (t + n) / 2, Tn = (e, t, n, o) => e === (o ? "left" : "right") ? n : e === "center" ? (t + n) / 2 : t;
function kn(e, t, n) {
  const o = t.length;
  let r = 0, i = o;
  if (e._sorted) {
    const { iScale: s, vScale: a, _parsed: c } = e, l = e.dataset && e.dataset.options ? e.dataset.options.spanGaps : null, u = s.axis, { min: h, max: g, minDefined: m, maxDefined: p } = s.getUserBounds();
    if (m) {
      if (r = Math.min(
        // @ts-expect-error Need to type _parsed
        D(c, u, h).lo,
        // @ts-expect-error Need to fix types on _lookupByKey
        n ? o : D(t, u, s.getPixelForValue(h)).lo
      ), l) {
        const d = c.slice(0, r + 1).reverse().findIndex((f) => !R(f[a.axis]));
        r -= Math.max(0, d);
      }
      r = Y(r, 0, o - 1);
    }
    if (p) {
      let d = Math.max(
        // @ts-expect-error Need to type _parsed
        D(c, s.axis, g, !0).hi + 1,
        // @ts-expect-error Need to fix types on _lookupByKey
        n ? 0 : D(t, u, s.getPixelForValue(g), !0).hi + 1
      );
      if (l) {
        const f = c.slice(d - 1).findIndex((b) => !R(b[a.axis]));
        d += Math.max(0, f);
      }
      i = Y(d, r, o) - r;
    } else
      i = o - r;
  }
  return {
    start: r,
    count: i
  };
}
function Cn(e) {
  const { xScale: t, yScale: n, _scaleRanges: o } = e, r = {
    xmin: t.min,
    xmax: t.max,
    ymin: n.min,
    ymax: n.max
  };
  if (!o)
    return e._scaleRanges = r, !0;
  const i = o.xmin !== t.min || o.xmax !== t.max || o.ymin !== n.min || o.ymax !== n.max;
  return Object.assign(o, r), i;
}
const j = (e) => e === 0 || e === 1, re = (e, t, n) => -(Math.pow(2, 10 * (e -= 1)) * Math.sin((e - t) * M / n)), ie = (e, t, n) => Math.pow(2, -10 * e) * Math.sin((e - t) * M / n) + 1, Q = {
  linear: (e) => e,
  easeInQuad: (e) => e * e,
  easeOutQuad: (e) => -e * (e - 2),
  easeInOutQuad: (e) => (e /= 0.5) < 1 ? 0.5 * e * e : -0.5 * (--e * (e - 2) - 1),
  easeInCubic: (e) => e * e * e,
  easeOutCubic: (e) => (e -= 1) * e * e + 1,
  easeInOutCubic: (e) => (e /= 0.5) < 1 ? 0.5 * e * e * e : 0.5 * ((e -= 2) * e * e + 2),
  easeInQuart: (e) => e * e * e * e,
  easeOutQuart: (e) => -((e -= 1) * e * e * e - 1),
  easeInOutQuart: (e) => (e /= 0.5) < 1 ? 0.5 * e * e * e * e : -0.5 * ((e -= 2) * e * e * e - 2),
  easeInQuint: (e) => e * e * e * e * e,
  easeOutQuint: (e) => (e -= 1) * e * e * e * e + 1,
  easeInOutQuint: (e) => (e /= 0.5) < 1 ? 0.5 * e * e * e * e * e : 0.5 * ((e -= 2) * e * e * e * e + 2),
  easeInSine: (e) => -Math.cos(e * S) + 1,
  easeOutSine: (e) => Math.sin(e * S),
  easeInOutSine: (e) => -0.5 * (Math.cos(y * e) - 1),
  easeInExpo: (e) => e === 0 ? 0 : Math.pow(2, 10 * (e - 1)),
  easeOutExpo: (e) => e === 1 ? 1 : -Math.pow(2, -10 * e) + 1,
  easeInOutExpo: (e) => j(e) ? e : e < 0.5 ? 0.5 * Math.pow(2, 10 * (e * 2 - 1)) : 0.5 * (-Math.pow(2, -10 * (e * 2 - 1)) + 2),
  easeInCirc: (e) => e >= 1 ? e : -(Math.sqrt(1 - e * e) - 1),
  easeOutCirc: (e) => Math.sqrt(1 - (e -= 1) * e),
  easeInOutCirc: (e) => (e /= 0.5) < 1 ? -0.5 * (Math.sqrt(1 - e * e) - 1) : 0.5 * (Math.sqrt(1 - (e -= 2) * e) + 1),
  easeInElastic: (e) => j(e) ? e : re(e, 0.075, 0.3),
  easeOutElastic: (e) => j(e) ? e : ie(e, 0.075, 0.3),
  easeInOutElastic(e) {
    return j(e) ? e : e < 0.5 ? 0.5 * re(e * 2, 0.1125, 0.45) : 0.5 + 0.5 * ie(e * 2 - 1, 0.1125, 0.45);
  },
  easeInBack(e) {
    return e * e * ((1.70158 + 1) * e - 1.70158);
  },
  easeOutBack(e) {
    return (e -= 1) * e * ((1.70158 + 1) * e + 1.70158) + 1;
  },
  easeInOutBack(e) {
    let t = 1.70158;
    return (e /= 0.5) < 1 ? 0.5 * (e * e * (((t *= 1.525) + 1) * e - t)) : 0.5 * ((e -= 2) * e * (((t *= 1.525) + 1) * e + t) + 2);
  },
  easeInBounce: (e) => 1 - Q.easeOutBounce(1 - e),
  easeOutBounce(e) {
    return e < 1 / 2.75 ? 7.5625 * e * e : e < 2 / 2.75 ? 7.5625 * (e -= 1.5 / 2.75) * e + 0.75 : e < 2.5 / 2.75 ? 7.5625 * (e -= 2.25 / 2.75) * e + 0.9375 : 7.5625 * (e -= 2.625 / 2.75) * e + 0.984375;
  },
  easeInOutBounce: (e) => e < 0.5 ? Q.easeInBounce(e * 2) * 0.5 : Q.easeOutBounce(e * 2 - 1) * 0.5 + 0.5
};
function J(e) {
  if (e && typeof e == "object") {
    const t = e.toString();
    return t === "[object CanvasPattern]" || t === "[object CanvasGradient]";
  }
  return !1;
}
function In(e) {
  return J(e) ? e : new he(e);
}
function $(e) {
  return J(e) ? e : new he(e).saturate(0.5).darken(0.1).hexString();
}
const Qe = [
  "x",
  "y",
  "borderWidth",
  "radius",
  "tension"
], $e = [
  "color",
  "borderColor",
  "backgroundColor"
];
function Ue(e) {
  e.set("animation", {
    delay: void 0,
    duration: 1e3,
    easing: "easeOutQuart",
    fn: void 0,
    from: void 0,
    loop: void 0,
    to: void 0,
    type: void 0
  }), e.describe("animation", {
    _fallback: !1,
    _indexable: !1,
    _scriptable: (t) => t !== "onProgress" && t !== "onComplete" && t !== "fn"
  }), e.set("animations", {
    colors: {
      type: "color",
      properties: $e
    },
    numbers: {
      type: "number",
      properties: Qe
    }
  }), e.describe("animations", {
    _fallback: "animation"
  }), e.set("transitions", {
    active: {
      animation: {
        duration: 400
      }
    },
    resize: {
      animation: {
        duration: 0
      }
    },
    show: {
      animations: {
        colors: {
          from: "transparent"
        },
        visible: {
          type: "boolean",
          duration: 0
        }
      }
    },
    hide: {
      animations: {
        colors: {
          to: "transparent"
        },
        visible: {
          type: "boolean",
          easing: "linear",
          fn: (t) => t | 0
        }
      }
    }
  });
}
function Ye(e) {
  e.set("layout", {
    autoPadding: !0,
    padding: {
      top: 0,
      right: 0,
      bottom: 0,
      left: 0
    }
  });
}
const se = /* @__PURE__ */ new Map();
function Je(e, t) {
  t = t || {};
  const n = e + JSON.stringify(t);
  let o = se.get(n);
  return o || (o = new Intl.NumberFormat(e, t), se.set(n, o)), o;
}
function Ve(e, t, n) {
  return Je(t, n).format(e);
}
const Xe = {
  values(e) {
    return x(e) ? e : "" + e;
  },
  numeric(e, t, n) {
    if (e === 0)
      return "0";
    const o = this.chart.options.locale;
    let r, i = e;
    if (n.length > 1) {
      const l = Math.max(Math.abs(n[0].value), Math.abs(n[n.length - 1].value));
      (l < 1e-4 || l > 1e15) && (r = "scientific"), i = Ze(e, n);
    }
    const s = be(Math.abs(i)), a = isNaN(s) ? 1 : Math.max(Math.min(-1 * Math.floor(s), 20), 0), c = {
      notation: r,
      minimumFractionDigits: a,
      maximumFractionDigits: a
    };
    return Object.assign(c, this.options.ticks.format), Ve(e, o, c);
  }
};
function Ze(e, t) {
  let n = t.length > 3 ? t[2].value - t[1].value : t[1].value - t[0].value;
  return Math.abs(n) >= 1 && e !== Math.floor(e) && (n = e - Math.floor(e)), n;
}
var et = {
  formatters: Xe
};
function tt(e) {
  e.set("scale", {
    display: !0,
    offset: !1,
    reverse: !1,
    beginAtZero: !1,
    bounds: "ticks",
    clip: !0,
    grace: 0,
    grid: {
      display: !0,
      lineWidth: 1,
      drawOnChartArea: !0,
      drawTicks: !0,
      tickLength: 8,
      tickWidth: (t, n) => n.lineWidth,
      tickColor: (t, n) => n.color,
      offset: !1
    },
    border: {
      display: !0,
      dash: [],
      dashOffset: 0,
      width: 1
    },
    title: {
      display: !1,
      text: "",
      padding: {
        top: 4,
        bottom: 4
      }
    },
    ticks: {
      minRotation: 0,
      maxRotation: 50,
      mirror: !1,
      textStrokeWidth: 0,
      textStrokeColor: "",
      padding: 3,
      display: !0,
      autoSkip: !0,
      autoSkipPadding: 3,
      labelOffset: 0,
      callback: et.formatters.values,
      minor: {},
      major: {},
      align: "center",
      crossAlign: "near",
      showLabelBackdrop: !1,
      backdropColor: "rgba(255, 255, 255, 0.75)",
      backdropPadding: 2
    }
  }), e.route("scale.ticks", "color", "", "color"), e.route("scale.grid", "color", "", "borderColor"), e.route("scale.border", "color", "", "borderColor"), e.route("scale.title", "color", "", "color"), e.describe("scale", {
    _fallback: !1,
    _scriptable: (t) => !t.startsWith("before") && !t.startsWith("after") && t !== "callback" && t !== "parser",
    _indexable: (t) => t !== "borderDash" && t !== "tickBorderDash" && t !== "dash"
  }), e.describe("scales", {
    _fallback: "scale"
  }), e.describe("scale.ticks", {
    _scriptable: (t) => t !== "backdropPadding" && t !== "callback",
    _indexable: (t) => t !== "backdropPadding"
  });
}
const nt = /* @__PURE__ */ Object.create(null), ot = /* @__PURE__ */ Object.create(null);
function B(e, t) {
  if (!t)
    return e;
  const n = t.split(".");
  for (let o = 0, r = n.length; o < r; ++o) {
    const i = n[o];
    e = e[i] || (e[i] = /* @__PURE__ */ Object.create(null));
  }
  return e;
}
function U(e, t, n) {
  return typeof t == "string" ? F(B(e, t), n) : F(B(e, ""), t);
}
class rt {
  constructor(t, n) {
    this.animation = void 0, this.backgroundColor = "rgba(0,0,0,0.1)", this.borderColor = "rgba(0,0,0,0.1)", this.color = "#666", this.datasets = {}, this.devicePixelRatio = (o) => o.chart.platform.getDevicePixelRatio(), this.elements = {}, this.events = [
      "mousemove",
      "mouseout",
      "click",
      "touchstart",
      "touchmove"
    ], this.font = {
      family: "'Helvetica Neue', 'Helvetica', 'Arial', sans-serif",
      size: 12,
      style: "normal",
      lineHeight: 1.2,
      weight: null
    }, this.hover = {}, this.hoverBackgroundColor = (o, r) => $(r.backgroundColor), this.hoverBorderColor = (o, r) => $(r.borderColor), this.hoverColor = (o, r) => $(r.color), this.indexAxis = "x", this.interaction = {
      mode: "nearest",
      intersect: !0,
      includeInvisible: !1
    }, this.maintainAspectRatio = !0, this.onHover = null, this.onClick = null, this.parsing = !0, this.plugins = {}, this.responsive = !0, this.scale = void 0, this.scales = {}, this.showLine = !0, this.drawActiveElementsOnTop = !0, this.describe(t), this.apply(n);
  }
  set(t, n) {
    return U(this, t, n);
  }
  get(t) {
    return B(this, t);
  }
  describe(t, n) {
    return U(ot, t, n);
  }
  override(t, n) {
    return U(nt, t, n);
  }
  route(t, n, o, r) {
    const i = B(this, t), s = B(this, o), a = "_" + n;
    Object.defineProperties(i, {
      [a]: {
        value: i[n],
        writable: !0
      },
      [n]: {
        enumerable: !0,
        get() {
          const c = this[a], l = s[r];
          return _(c) ? Object.assign({}, l, c) : w(c, l);
        },
        set(c) {
          this[a] = c;
        }
      }
    });
  }
  apply(t) {
    t.forEach((n) => n(this));
  }
}
var it = /* @__PURE__ */ new rt({
  _scriptable: (e) => !e.startsWith("on"),
  _indexable: (e) => e !== "events",
  hover: {
    _fallback: "interaction"
  },
  interaction: {
    _scriptable: !1,
    _indexable: !1
  }
}, [
  Ue,
  Ye,
  tt
]);
function st(e) {
  return !e || R(e.size) || R(e.family) ? null : (e.style ? e.style + " " : "") + (e.weight ? e.weight + " " : "") + e.size + "px " + e.family;
}
function Rn(e, t, n, o, r) {
  let i = t[r];
  return i || (i = t[r] = e.measureText(r).width, n.push(r)), i > o && (o = i), o;
}
function vn(e, t, n) {
  const o = e.currentDevicePixelRatio, r = n !== 0 ? Math.max(n / 2, 0.5) : 0;
  return Math.round((t - r) * o) / o + r;
}
function An(e, t) {
  !t && !e || (t = t || e.getContext("2d"), t.save(), t.resetTransform(), t.clearRect(0, 0, e.width, e.height), t.restore());
}
function Bn(e, t, n, o) {
  at(e, t, n, o, null);
}
function at(e, t, n, o, r) {
  let i, s, a, c, l, u, h, g;
  const m = t.pointStyle, p = t.rotation, d = t.radius;
  let f = (p || 0) * Fe;
  if (m && typeof m == "object" && (i = m.toString(), i === "[object HTMLImageElement]" || i === "[object HTMLCanvasElement]")) {
    e.save(), e.translate(n, o), e.rotate(f), e.drawImage(m, -m.width / 2, -m.height / 2, m.width, m.height), e.restore();
    return;
  }
  if (!(isNaN(d) || d <= 0)) {
    switch (e.beginPath(), m) {
      // Default includes circle
      default:
        r ? e.ellipse(n, o, r / 2, d, 0, 0, M) : e.arc(n, o, d, 0, M), e.closePath();
        break;
      case "triangle":
        u = r ? r / 2 : d, e.moveTo(n + Math.sin(f) * u, o - Math.cos(f) * d), f += te, e.lineTo(n + Math.sin(f) * u, o - Math.cos(f) * d), f += te, e.lineTo(n + Math.sin(f) * u, o - Math.cos(f) * d), e.closePath();
        break;
      case "rectRounded":
        l = d * 0.516, c = d - l, s = Math.cos(f + P) * c, h = Math.cos(f + P) * (r ? r / 2 - l : c), a = Math.sin(f + P) * c, g = Math.sin(f + P) * (r ? r / 2 - l : c), e.arc(n - h, o - a, l, f - y, f - S), e.arc(n + g, o - s, l, f - S, f), e.arc(n + h, o + a, l, f, f + S), e.arc(n - g, o + s, l, f + S, f + y), e.closePath();
        break;
      case "rect":
        if (!p) {
          c = Math.SQRT1_2 * d, u = r ? r / 2 : c, e.rect(n - u, o - c, 2 * u, 2 * c);
          break;
        }
        f += P;
      /* falls through */
      case "rectRot":
        h = Math.cos(f) * (r ? r / 2 : d), s = Math.cos(f) * d, a = Math.sin(f) * d, g = Math.sin(f) * (r ? r / 2 : d), e.moveTo(n - h, o - a), e.lineTo(n + g, o - s), e.lineTo(n + h, o + a), e.lineTo(n - g, o + s), e.closePath();
        break;
      case "crossRot":
        f += P;
      /* falls through */
      case "cross":
        h = Math.cos(f) * (r ? r / 2 : d), s = Math.cos(f) * d, a = Math.sin(f) * d, g = Math.sin(f) * (r ? r / 2 : d), e.moveTo(n - h, o - a), e.lineTo(n + h, o + a), e.moveTo(n + g, o - s), e.lineTo(n - g, o + s);
        break;
      case "star":
        h = Math.cos(f) * (r ? r / 2 : d), s = Math.cos(f) * d, a = Math.sin(f) * d, g = Math.sin(f) * (r ? r / 2 : d), e.moveTo(n - h, o - a), e.lineTo(n + h, o + a), e.moveTo(n + g, o - s), e.lineTo(n - g, o + s), f += P, h = Math.cos(f) * (r ? r / 2 : d), s = Math.cos(f) * d, a = Math.sin(f) * d, g = Math.sin(f) * (r ? r / 2 : d), e.moveTo(n - h, o - a), e.lineTo(n + h, o + a), e.moveTo(n + g, o - s), e.lineTo(n - g, o + s);
        break;
      case "line":
        s = r ? r / 2 : Math.cos(f) * d, a = Math.sin(f) * d, e.moveTo(n - s, o - a), e.lineTo(n + s, o + a);
        break;
      case "dash":
        e.moveTo(n, o), e.lineTo(n + Math.cos(f) * (r ? r / 2 : d), o + Math.sin(f) * d);
        break;
      case !1:
        e.closePath();
        break;
    }
    e.fill(), t.borderWidth > 0 && e.stroke();
  }
}
function ae(e, t, n) {
  return n = n || 0.5, !t || e && e.x > t.left - n && e.x < t.right + n && e.y > t.top - n && e.y < t.bottom + n;
}
function Dn(e, t) {
  e.save(), e.beginPath(), e.rect(t.left, t.top, t.right - t.left, t.bottom - t.top), e.clip();
}
function jn(e) {
  e.restore();
}
function Ln(e, t, n, o, r) {
  if (!t)
    return e.lineTo(n.x, n.y);
  if (r === "middle") {
    const i = (t.x + n.x) / 2;
    e.lineTo(i, t.y), e.lineTo(i, n.y);
  } else r === "after" != !!o ? e.lineTo(t.x, n.y) : e.lineTo(n.x, t.y);
  e.lineTo(n.x, n.y);
}
function Wn(e, t, n, o) {
  if (!t)
    return e.lineTo(n.x, n.y);
  e.bezierCurveTo(o ? t.cp1x : t.cp2x, o ? t.cp1y : t.cp2y, o ? n.cp2x : n.cp1x, o ? n.cp2y : n.cp1y, n.x, n.y);
}
function ct(e, t) {
  t.translation && e.translate(t.translation[0], t.translation[1]), R(t.rotation) || e.rotate(t.rotation), t.color && (e.fillStyle = t.color), t.textAlign && (e.textAlign = t.textAlign), t.textBaseline && (e.textBaseline = t.textBaseline);
}
function lt(e, t, n, o, r) {
  if (r.strikethrough || r.underline) {
    const i = e.measureText(o), s = t - i.actualBoundingBoxLeft, a = t + i.actualBoundingBoxRight, c = n - i.actualBoundingBoxAscent, l = n + i.actualBoundingBoxDescent, u = r.strikethrough ? (c + l) / 2 : l;
    e.strokeStyle = e.fillStyle, e.beginPath(), e.lineWidth = r.decorationWidth || 2, e.moveTo(s, u), e.lineTo(a, u), e.stroke();
  }
}
function ut(e, t) {
  const n = e.fillStyle;
  e.fillStyle = t.color, e.fillRect(t.left, t.top, t.width, t.height), e.fillStyle = n;
}
function Nn(e, t, n, o, r, i = {}) {
  const s = x(t) ? t : [
    t
  ], a = i.strokeWidth > 0 && i.strokeColor !== "";
  let c, l;
  for (e.save(), e.font = r.string, ct(e, i), c = 0; c < s.length; ++c)
    l = s[c], i.backdrop && ut(e, i.backdrop), a && (i.strokeColor && (e.strokeStyle = i.strokeColor), R(i.strokeWidth) || (e.lineWidth = i.strokeWidth), e.strokeText(l, n, o, i.maxWidth)), e.fillText(l, n, o, i.maxWidth), lt(e, n, o, l, i), o += Number(r.lineHeight);
  e.restore();
}
function En(e, t) {
  const { x: n, y: o, w: r, h: i, radius: s } = t;
  e.arc(n + s.topLeft, o + s.topLeft, s.topLeft, 1.5 * y, y, !0), e.lineTo(n, o + i - s.bottomLeft), e.arc(n + s.bottomLeft, o + i - s.bottomLeft, s.bottomLeft, y, S, !0), e.lineTo(n + r - s.bottomRight, o + i), e.arc(n + r - s.bottomRight, o + i - s.bottomRight, s.bottomRight, S, 0, !0), e.lineTo(n + r, o + s.topRight), e.arc(n + r - s.topRight, o + s.topRight, s.topRight, 0, -S, !0), e.lineTo(n + s.topLeft, o);
}
const ft = /^(normal|(\d+(?:\.\d+)?)(px|em|%)?)$/, dt = /^(normal|italic|initial|inherit|unset|(oblique( -?[0-9]?[0-9]deg)?))$/;
function ht(e, t) {
  const n = ("" + e).match(ft);
  if (!n || n[1] === "normal")
    return t * 1.2;
  switch (e = +n[2], n[3]) {
    case "px":
      return e;
    case "%":
      e /= 100;
      break;
  }
  return t * e;
}
const gt = (e) => +e || 0;
function Se(e, t) {
  const n = {}, o = _(t), r = o ? Object.keys(t) : t, i = _(e) ? o ? (s) => w(e[s], e[t[s]]) : (s) => e[s] : () => e;
  for (const s of r)
    n[s] = gt(i(s));
  return n;
}
function mt(e) {
  return Se(e, {
    top: "y",
    right: "x",
    bottom: "y",
    left: "x"
  });
}
function Fn(e) {
  return Se(e, [
    "topLeft",
    "topRight",
    "bottomLeft",
    "bottomRight"
  ]);
}
function zn(e) {
  const t = mt(e);
  return t.width = t.left + t.right, t.height = t.top + t.bottom, t;
}
function Hn(e, t) {
  e = e || {}, t = t || it.font;
  let n = w(e.size, t.size);
  typeof n == "string" && (n = parseInt(n, 10));
  let o = w(e.style, t.style);
  o && !("" + o).match(dt) && (console.warn('Invalid font style specified: "' + o + '"'), o = void 0);
  const r = {
    family: w(e.family, t.family),
    lineHeight: ht(w(e.lineHeight, t.lineHeight), n),
    size: n,
    style: o,
    weight: w(e.weight, t.weight),
    string: ""
  };
  return r.string = st(r), r;
}
function qn(e, t, n, o) {
  let r, i, s;
  for (r = 0, i = e.length; r < i; ++r)
    if (s = e[r], s !== void 0 && (t !== void 0 && typeof s == "function" && (s = s(t)), n !== void 0 && x(s) && (s = s[n % s.length]), s !== void 0))
      return s;
}
function Kn(e, t, n) {
  const { min: o, max: r } = e, i = Ae(t, (r - o) / 2), s = (a, c) => n && a === 0 ? 0 : a + c;
  return {
    min: s(o, -Math.abs(i)),
    max: s(r, i)
  };
}
function pt(e, t) {
  return Object.assign(Object.create(e), t);
}
function Oe(e, t = [
  ""
], n, o, r = () => e[0]) {
  const i = n || e;
  typeof o > "u" && (o = we("_fallback", e));
  const s = {
    [Symbol.toStringTag]: "Object",
    _cacheable: !0,
    _scopes: e,
    _rootScopes: i,
    _fallback: o,
    _getTarget: r,
    override: (a) => Oe([
      a,
      ...e
    ], t, i, o)
  };
  return new Proxy(s, {
    /**
    * A trap for the delete operator.
    */
    deleteProperty(a, c) {
      return delete a[c], delete a._keys, delete e[0][c], !0;
    },
    /**
    * A trap for getting property values.
    */
    get(a, c) {
      return xe(a, c, () => wt(c, t, e, a));
    },
    /**
    * A trap for Object.getOwnPropertyDescriptor.
    * Also used by Object.hasOwnProperty.
    */
    getOwnPropertyDescriptor(a, c) {
      return Reflect.getOwnPropertyDescriptor(a._scopes[0], c);
    },
    /**
    * A trap for Object.getPrototypeOf.
    */
    getPrototypeOf() {
      return Reflect.getPrototypeOf(e[0]);
    },
    /**
    * A trap for the in operator.
    */
    has(a, c) {
      return le(a).includes(c);
    },
    /**
    * A trap for Object.getOwnPropertyNames and Object.getOwnPropertySymbols.
    */
    ownKeys(a) {
      return le(a);
    },
    /**
    * A trap for setting property values.
    */
    set(a, c, l) {
      const u = a._storage || (a._storage = r());
      return a[c] = u[c] = l, delete a._keys, !0;
    }
  });
}
function q(e, t, n, o) {
  const r = {
    _cacheable: !1,
    _proxy: e,
    _context: t,
    _subProxy: n,
    _stack: /* @__PURE__ */ new Set(),
    _descriptors: bt(e, o),
    setContext: (i) => q(e, i, n, o),
    override: (i) => q(e.override(i), t, n, o)
  };
  return new Proxy(r, {
    /**
    * A trap for the delete operator.
    */
    deleteProperty(i, s) {
      return delete i[s], delete e[s], !0;
    },
    /**
    * A trap for getting property values.
    */
    get(i, s, a) {
      return xe(i, s, () => _t(i, s, a));
    },
    /**
    * A trap for Object.getOwnPropertyDescriptor.
    * Also used by Object.hasOwnProperty.
    */
    getOwnPropertyDescriptor(i, s) {
      return i._descriptors.allKeys ? Reflect.has(e, s) ? {
        enumerable: !0,
        configurable: !0
      } : void 0 : Reflect.getOwnPropertyDescriptor(e, s);
    },
    /**
    * A trap for Object.getPrototypeOf.
    */
    getPrototypeOf() {
      return Reflect.getPrototypeOf(e);
    },
    /**
    * A trap for the in operator.
    */
    has(i, s) {
      return Reflect.has(e, s);
    },
    /**
    * A trap for Object.getOwnPropertyNames and Object.getOwnPropertySymbols.
    */
    ownKeys() {
      return Reflect.ownKeys(e);
    },
    /**
    * A trap for setting property values.
    */
    set(i, s, a) {
      return e[s] = a, delete i[s], !0;
    }
  });
}
function bt(e, t = {
  scriptable: !0,
  indexable: !0
}) {
  const { _scriptable: n = t.scriptable, _indexable: o = t.indexable, _allKeys: r = t.allKeys } = e;
  return {
    allKeys: r,
    scriptable: n,
    indexable: o,
    isScriptable: z(n) ? n : () => n,
    isIndexable: z(o) ? o : () => o
  };
}
const yt = (e, t) => e ? e + pe(t) : t, V = (e, t) => _(t) && e !== "adapters" && (Object.getPrototypeOf(t) === null || t.constructor === Object);
function xe(e, t, n) {
  if (Object.prototype.hasOwnProperty.call(e, t) || t === "constructor")
    return e[t];
  const o = n();
  return e[t] = o, o;
}
function _t(e, t, n) {
  const { _proxy: o, _context: r, _subProxy: i, _descriptors: s } = e;
  let a = o[t];
  return z(a) && s.isScriptable(t) && (a = Mt(t, a, e, n)), x(a) && a.length && (a = St(t, a, e, s.isIndexable)), V(t, a) && (a = q(a, r, i && i[t], s)), a;
}
function Mt(e, t, n, o) {
  const { _proxy: r, _context: i, _subProxy: s, _stack: a } = n;
  if (a.has(e))
    throw new Error("Recursion detected: " + Array.from(a).join("->") + "->" + e);
  a.add(e);
  let c = t(i, s || o);
  return a.delete(e), V(e, c) && (c = X(r._scopes, r, e, c)), c;
}
function St(e, t, n, o) {
  const { _proxy: r, _context: i, _subProxy: s, _descriptors: a } = n;
  if (typeof i.index < "u" && o(e))
    return t[i.index % t.length];
  if (_(t[0])) {
    const c = t, l = r._scopes.filter((u) => u !== c);
    t = [];
    for (const u of c) {
      const h = X(l, r, e, u);
      t.push(q(h, i, s && s[e], a));
    }
  }
  return t;
}
function Pe(e, t, n) {
  return z(e) ? e(t, n) : e;
}
const Ot = (e, t) => e === !0 ? t : typeof e == "string" ? Ne(t, e) : void 0;
function xt(e, t, n, o, r) {
  for (const i of t) {
    const s = Ot(n, i);
    if (s) {
      e.add(s);
      const a = Pe(s._fallback, n, r);
      if (typeof a < "u" && a !== n && a !== o)
        return a;
    } else if (s === !1 && typeof o < "u" && n !== o)
      return null;
  }
  return !1;
}
function X(e, t, n, o) {
  const r = t._rootScopes, i = Pe(t._fallback, n, o), s = [
    ...e,
    ...r
  ], a = /* @__PURE__ */ new Set();
  a.add(o);
  let c = ce(a, s, n, i || n, o);
  return c === null || typeof i < "u" && i !== n && (c = ce(a, s, i, c, o), c === null) ? !1 : Oe(Array.from(a), [
    ""
  ], r, i, () => Pt(t, n, o));
}
function ce(e, t, n, o, r) {
  for (; n; )
    n = xt(e, t, n, o, r);
  return n;
}
function Pt(e, t, n) {
  const o = e._getTarget();
  t in o || (o[t] = {});
  const r = o[t];
  return x(r) && _(n) ? n : r || {};
}
function wt(e, t, n, o) {
  let r;
  for (const i of t)
    if (r = we(yt(i, e), n), typeof r < "u")
      return V(e, r) ? X(n, o, e, r) : r;
}
function we(e, t) {
  for (const n of t) {
    if (!n)
      continue;
    const o = n[e];
    if (typeof o < "u")
      return o;
  }
}
function le(e) {
  let t = e._keys;
  return t || (t = e._keys = Tt(e._scopes)), t;
}
function Tt(e) {
  const t = /* @__PURE__ */ new Set();
  for (const n of e)
    for (const o of Object.keys(n).filter((r) => !r.startsWith("_")))
      t.add(o);
  return Array.from(t);
}
const kt = Number.EPSILON || 1e-14, v = (e, t) => t < e.length && !e[t].skip && e[t], Te = (e) => e === "x" ? "y" : "x";
function Ct(e, t, n, o) {
  const r = e.skip ? t : e, i = t, s = n.skip ? t : n, a = oe(i, r), c = oe(s, i);
  let l = a / (a + c), u = c / (a + c);
  l = isNaN(l) ? 0 : l, u = isNaN(u) ? 0 : u;
  const h = o * l, g = o * u;
  return {
    previous: {
      x: i.x - h * (s.x - r.x),
      y: i.y - h * (s.y - r.y)
    },
    next: {
      x: i.x + g * (s.x - r.x),
      y: i.y + g * (s.y - r.y)
    }
  };
}
function It(e, t, n) {
  const o = e.length;
  let r, i, s, a, c, l = v(e, 0);
  for (let u = 0; u < o - 1; ++u)
    if (c = l, l = v(e, u + 1), !(!c || !l)) {
      if (ye(t[u], 0, kt)) {
        n[u] = n[u + 1] = 0;
        continue;
      }
      r = n[u] / t[u], i = n[u + 1] / t[u], a = Math.pow(r, 2) + Math.pow(i, 2), !(a <= 9) && (s = 3 / Math.sqrt(a), n[u] = r * s * t[u], n[u + 1] = i * s * t[u]);
    }
}
function Rt(e, t, n = "x") {
  const o = Te(n), r = e.length;
  let i, s, a, c = v(e, 0);
  for (let l = 0; l < r; ++l) {
    if (s = a, a = c, c = v(e, l + 1), !a)
      continue;
    const u = a[n], h = a[o];
    s && (i = (u - s[n]) / 3, a[`cp1${n}`] = u - i, a[`cp1${o}`] = h - i * t[l]), c && (i = (c[n] - u) / 3, a[`cp2${n}`] = u + i, a[`cp2${o}`] = h + i * t[l]);
  }
}
function vt(e, t = "x") {
  const n = Te(t), o = e.length, r = Array(o).fill(0), i = Array(o);
  let s, a, c, l = v(e, 0);
  for (s = 0; s < o; ++s)
    if (a = c, c = l, l = v(e, s + 1), !!c) {
      if (l) {
        const u = l[t] - c[t];
        r[s] = u !== 0 ? (l[n] - c[n]) / u : 0;
      }
      i[s] = a ? l ? ne(r[s - 1]) !== ne(r[s]) ? 0 : (r[s - 1] + r[s]) / 2 : r[s - 1] : r[s];
    }
  It(e, r, i), Rt(e, i, t);
}
function L(e, t, n) {
  return Math.max(Math.min(e, n), t);
}
function At(e, t) {
  let n, o, r, i, s, a = ae(e[0], t);
  for (n = 0, o = e.length; n < o; ++n)
    s = i, i = a, a = n < o - 1 && ae(e[n + 1], t), i && (r = e[n], s && (r.cp1x = L(r.cp1x, t.left, t.right), r.cp1y = L(r.cp1y, t.top, t.bottom)), a && (r.cp2x = L(r.cp2x, t.left, t.right), r.cp2y = L(r.cp2y, t.top, t.bottom)));
}
function Gn(e, t, n, o, r) {
  let i, s, a, c;
  if (t.spanGaps && (e = e.filter((l) => !l.skip)), t.cubicInterpolationMode === "monotone")
    vt(e, r);
  else {
    let l = o ? e[e.length - 1] : e[0];
    for (i = 0, s = e.length; i < s; ++i)
      a = e[i], c = Ct(l, a, e[Math.min(i + 1, s - (o ? 0 : 1)) % s], t.tension), a.cp1x = c.previous.x, a.cp1y = c.previous.y, a.cp2x = c.next.x, a.cp2y = c.next.y, l = a;
  }
  t.capBezierPoints && At(e, n);
}
function Bt() {
  return typeof window < "u" && typeof document < "u";
}
function Dt(e) {
  let t = e.parentNode;
  return t && t.toString() === "[object ShadowRoot]" && (t = t.host), t;
}
function K(e, t, n) {
  let o;
  return typeof e == "string" ? (o = parseInt(e, 10), e.indexOf("%") !== -1 && (o = o / 100 * t.parentNode[n])) : o = e, o;
}
const G = (e) => e.ownerDocument.defaultView.getComputedStyle(e, null);
function jt(e, t) {
  return G(e).getPropertyValue(t);
}
const Lt = [
  "top",
  "right",
  "bottom",
  "left"
];
function T(e, t, n) {
  const o = {};
  n = n ? "-" + n : "";
  for (let r = 0; r < 4; r++) {
    const i = Lt[r];
    o[i] = parseFloat(e[t + "-" + i + n]) || 0;
  }
  return o.width = o.left + o.right, o.height = o.top + o.bottom, o;
}
const Wt = (e, t, n) => (e > 0 || t > 0) && (!n || !n.shadowRoot);
function Nt(e, t) {
  const n = e.touches, o = n && n.length ? n[0] : e, { offsetX: r, offsetY: i } = o;
  let s = !1, a, c;
  if (Wt(r, i, e.target))
    a = r, c = i;
  else {
    const l = t.getBoundingClientRect();
    a = o.clientX - l.left, c = o.clientY - l.top, s = !0;
  }
  return {
    x: a,
    y: c,
    box: s
  };
}
function Qn(e, t) {
  if ("native" in e)
    return e;
  const { canvas: n, currentDevicePixelRatio: o } = t, r = G(n), i = r.boxSizing === "border-box", s = T(r, "padding"), a = T(r, "border", "width"), { x: c, y: l, box: u } = Nt(e, n), h = s.left + (u && a.left), g = s.top + (u && a.top);
  let { width: m, height: p } = t;
  return i && (m -= s.width + a.width, p -= s.height + a.height), {
    x: Math.round((c - h) / m * n.width / o),
    y: Math.round((l - g) / p * n.height / o)
  };
}
function Et(e, t, n) {
  let o, r;
  if (t === void 0 || n === void 0) {
    const i = e && Dt(e);
    if (!i)
      t = e.clientWidth, n = e.clientHeight;
    else {
      const s = i.getBoundingClientRect(), a = G(i), c = T(a, "border", "width"), l = T(a, "padding");
      t = s.width - l.width - c.width, n = s.height - l.height - c.height, o = K(a.maxWidth, i, "clientWidth"), r = K(a.maxHeight, i, "clientHeight");
    }
  }
  return {
    width: t,
    height: n,
    maxWidth: o || H,
    maxHeight: r || H
  };
}
const W = (e) => Math.round(e * 10) / 10;
function $n(e, t, n, o) {
  const r = G(e), i = T(r, "margin"), s = K(r.maxWidth, e, "clientWidth") || H, a = K(r.maxHeight, e, "clientHeight") || H, c = Et(e, t, n);
  let { width: l, height: u } = c;
  if (r.boxSizing === "content-box") {
    const g = T(r, "border", "width"), m = T(r, "padding");
    l -= m.width + g.width, u -= m.height + g.height;
  }
  return l = Math.max(0, l - i.width), u = Math.max(0, o ? l / o : u - i.height), l = W(Math.min(l, s, c.maxWidth)), u = W(Math.min(u, a, c.maxHeight)), l && !u && (u = W(l / 2)), (t !== void 0 || n !== void 0) && o && c.height && u > c.height && (u = c.height, l = W(Math.floor(u * o))), {
    width: l,
    height: u
  };
}
function Un(e, t, n) {
  const o = t || 1, r = Math.floor(e.height * o), i = Math.floor(e.width * o);
  e.height = Math.floor(e.height), e.width = Math.floor(e.width);
  const s = e.canvas;
  return s.style && (n || !s.style.height && !s.style.width) && (s.style.height = `${e.height}px`, s.style.width = `${e.width}px`), e.currentDevicePixelRatio !== o || s.height !== r || s.width !== i ? (e.currentDevicePixelRatio = o, s.height = r, s.width = i, e.ctx.setTransform(o, 0, 0, o, 0, 0), !0) : !1;
}
const Yn = (function() {
  let e = !1;
  try {
    const t = {
      get passive() {
        return e = !0, !1;
      }
    };
    Bt() && (window.addEventListener("test", null, t), window.removeEventListener("test", null, t));
  } catch {
  }
  return e;
})();
function Jn(e, t) {
  const n = jt(e, t), o = n && n.match(/^(\d+)(\.\d+)?px$/);
  return o ? +o[1] : void 0;
}
function I(e, t, n, o) {
  return {
    x: e.x + n * (t.x - e.x),
    y: e.y + n * (t.y - e.y)
  };
}
function Vn(e, t, n, o) {
  return {
    x: e.x + n * (t.x - e.x),
    y: o === "middle" ? n < 0.5 ? e.y : t.y : o === "after" ? n < 1 ? e.y : t.y : n > 0 ? t.y : e.y
  };
}
function Xn(e, t, n, o) {
  const r = {
    x: e.cp2x,
    y: e.cp2y
  }, i = {
    x: t.cp1x,
    y: t.cp1y
  }, s = I(e, r, n), a = I(r, i, n), c = I(i, t, n), l = I(s, a, n), u = I(a, c, n);
  return I(l, u, n);
}
const Ft = function(e, t) {
  return {
    x(n) {
      return e + e + t - n;
    },
    setWidth(n) {
      t = n;
    },
    textAlign(n) {
      return n === "center" ? n : n === "right" ? "left" : "right";
    },
    xPlus(n, o) {
      return n - o;
    },
    leftForLtr(n, o) {
      return n - o;
    }
  };
}, zt = function() {
  return {
    x(e) {
      return e;
    },
    setWidth(e) {
    },
    textAlign(e) {
      return e;
    },
    xPlus(e, t) {
      return e + t;
    },
    leftForLtr(e, t) {
      return e;
    }
  };
};
function Zn(e, t, n) {
  return e ? Ft(t, n) : zt();
}
function eo(e, t) {
  let n, o;
  (t === "ltr" || t === "rtl") && (n = e.canvas.style, o = [
    n.getPropertyValue("direction"),
    n.getPropertyPriority("direction")
  ], n.setProperty("direction", t, "important"), e.prevTextDirection = o);
}
function to(e, t) {
  t !== void 0 && (delete e.prevTextDirection, e.canvas.style.setProperty("direction", t[0], t[1]));
}
function ke(e) {
  return e === "angle" ? {
    between: qe,
    compare: He,
    normalize: O
  } : {
    between: Ke,
    compare: (t, n) => t - n,
    normalize: (t) => t
  };
}
function ue({ start: e, end: t, count: n, loop: o, style: r }) {
  return {
    start: e % n,
    end: t % n,
    loop: o && (t - e + 1) % n === 0,
    style: r
  };
}
function Ht(e, t, n) {
  const { property: o, start: r, end: i } = n, { between: s, normalize: a } = ke(o), c = t.length;
  let { start: l, end: u, loop: h } = e, g, m;
  if (h) {
    for (l += c, u += c, g = 0, m = c; g < m && s(a(t[l % c][o]), r, i); ++g)
      l--, u--;
    l %= c, u %= c;
  }
  return u < l && (u += c), {
    start: l,
    end: u,
    loop: h,
    style: e.style
  };
}
function qt(e, t, n) {
  if (!n)
    return [
      e
    ];
  const { property: o, start: r, end: i } = n, s = t.length, { compare: a, between: c, normalize: l } = ke(o), { start: u, end: h, loop: g, style: m } = Ht(e, t, n), p = [];
  let d = !1, f = null, b, k, A;
  const Ce = () => c(r, A, b) && a(r, A) !== 0, Ie = () => a(i, b) === 0 || c(i, A, b), Re = () => d || Ce(), ve = () => !d || Ie();
  for (let C = u, Z = u; C <= h; ++C)
    k = t[C % s], !k.skip && (b = l(k[o]), b !== A && (d = c(b, r, i), f === null && Re() && (f = a(b, r) === 0 ? C : Z), f !== null && ve() && (p.push(ue({
      start: f,
      end: C,
      loop: g,
      count: s,
      style: m
    })), f = null), Z = C, A = b));
  return f !== null && p.push(ue({
    start: f,
    end: h,
    loop: g,
    count: s,
    style: m
  })), p;
}
function no(e, t) {
  const n = [], o = e.segments;
  for (let r = 0; r < o.length; r++) {
    const i = qt(o[r], e.points, t);
    i.length && n.push(...i);
  }
  return n;
}
function Kt(e, t, n, o) {
  let r = 0, i = t - 1;
  if (n && !o)
    for (; r < t && !e[r].skip; )
      r++;
  for (; r < t && e[r].skip; )
    r++;
  for (r %= t, n && (i += r); i > r && e[i % t].skip; )
    i--;
  return i %= t, {
    start: r,
    end: i
  };
}
function Gt(e, t, n, o) {
  const r = e.length, i = [];
  let s = t, a = e[t], c;
  for (c = t + 1; c <= n; ++c) {
    const l = e[c % r];
    l.skip || l.stop ? a.skip || (o = !1, i.push({
      start: t % r,
      end: (c - 1) % r,
      loop: o
    }), t = s = l.stop ? c : null) : (s = c, a.skip && (t = c)), a = l;
  }
  return s !== null && i.push({
    start: t % r,
    end: s % r,
    loop: o
  }), i;
}
function oo(e, t) {
  const n = e.points, o = e.options.spanGaps, r = n.length;
  if (!r)
    return [];
  const i = !!e._loop, { start: s, end: a } = Kt(n, r, i, o);
  if (o === !0)
    return fe(e, [
      {
        start: s,
        end: a,
        loop: i
      }
    ], n, t);
  const c = a < s ? a + r : a, l = !!e._fullLoop && s === 0 && a === r - 1;
  return fe(e, Gt(n, s, c, l), n, t);
}
function fe(e, t, n, o) {
  return !o || !o.setContext || !n ? t : Qt(e, t, n, o);
}
function Qt(e, t, n, o) {
  const r = e._chart.getContext(), i = de(e.options), { _datasetIndex: s, options: { spanGaps: a } } = e, c = n.length, l = [];
  let u = i, h = t[0].start, g = h;
  function m(p, d, f, b) {
    const k = a ? -1 : 1;
    if (p !== d) {
      for (p += c; n[p % c].skip; )
        p -= k;
      for (; n[d % c].skip; )
        d += k;
      p % c !== d % c && (l.push({
        start: p % c,
        end: d % c,
        loop: f,
        style: b
      }), u = b, h = d % c);
    }
  }
  for (const p of t) {
    h = a ? h : p.start;
    let d = n[h % c], f;
    for (g = h + 1; g <= p.end; g++) {
      const b = n[g % c];
      f = de(o.setContext(pt(r, {
        type: "segment",
        p0: d,
        p1: b,
        p0DataIndex: (g - 1) % c,
        p1DataIndex: g % c,
        datasetIndex: s
      }))), $t(f, u) && m(h, g - 1, p.loop, u), d = b, u = f;
    }
    h < g - 1 && m(h, g - 1, p.loop, u);
  }
  return l;
}
function de(e) {
  return {
    backgroundColor: e.backgroundColor,
    borderCapStyle: e.borderCapStyle,
    borderDash: e.borderDash,
    borderDashOffset: e.borderDashOffset,
    borderJoinStyle: e.borderJoinStyle,
    borderWidth: e.borderWidth,
    borderColor: e.borderColor
  };
}
function $t(e, t) {
  if (!t)
    return !1;
  const n = [], o = function(r, i) {
    return J(i) ? (n.includes(i) || n.push(i), n.indexOf(i)) : i;
  };
  return JSON.stringify(e, o) !== JSON.stringify(t, o);
}
function N(e, t, n) {
  return e.options.clip ? e[n] : t[n];
}
function Ut(e, t) {
  const { xScale: n, yScale: o } = e;
  return n && o ? {
    left: N(n, t, "left"),
    right: N(n, t, "right"),
    top: N(o, t, "top"),
    bottom: N(o, t, "bottom")
  } : t;
}
function ro(e, t) {
  const n = t._clip;
  if (n.disabled)
    return !1;
  const o = Ut(t, e.chartArea);
  return {
    left: n.left === !1 ? 0 : o.left - (n.left === !0 ? 0 : n.left),
    right: n.right === !1 ? e.width : o.right + (n.right === !0 ? 0 : n.right),
    top: n.top === !1 ? 0 : o.top - (n.top === !0 ? 0 : n.top),
    bottom: n.bottom === !1 ? e.height : o.bottom + (n.bottom === !0 ? 0 : n.bottom)
  };
}
export {
  jn as $,
  bn as A,
  D as B,
  ae as C,
  mn as D,
  zn as E,
  tn as F,
  $n as G,
  S as H,
  Dt as I,
  Jn as J,
  Yn as K,
  On as L,
  Bt as M,
  cn as N,
  Xt as O,
  y as P,
  en as Q,
  Kn as R,
  Y as S,
  M as T,
  hn as U,
  Rn as V,
  pn as W,
  vn as X,
  Dn as Y,
  Nn as Z,
  Sn as _,
  qn as a,
  jt as a$,
  Hn as a0,
  Pn as a1,
  wn as a2,
  nt as a3,
  F as a4,
  pe as a5,
  ot as a6,
  z as a7,
  q as a8,
  Oe as a9,
  Zn as aA,
  eo as aB,
  Tn as aC,
  to as aD,
  at as aE,
  oe as aF,
  Jt as aG,
  fn as aH,
  an as aI,
  un as aJ,
  ye as aK,
  gn as aL,
  et as aM,
  be as aN,
  yn as aP,
  _e as aQ,
  J as aR,
  $ as aS,
  E as aT,
  Be as aU,
  je as aV,
  Le as aX,
  st as aY,
  Ct as aZ,
  vt as a_,
  bt as aa,
  De as ab,
  Vt as ac,
  xn as ad,
  Un as ae,
  An as af,
  rn as ag,
  ro as ah,
  nn as ai,
  sn as aj,
  Ke as ak,
  O as al,
  Se as am,
  Gn as an,
  oo as ao,
  no as ap,
  Vn as aq,
  Xn as ar,
  I as as,
  Ln as at,
  Wn as au,
  Bn as av,
  En as aw,
  mt as ax,
  Fn as ay,
  qt as az,
  x as b,
  ht as b1,
  Ee as b2,
  H as b3,
  Fe as b4,
  P as b5,
  te as b6,
  He as b7,
  In as c,
  it as d,
  Q as e,
  Ne as f,
  ge as g,
  on as h,
  _ as i,
  pt as j,
  R as k,
  _n as l,
  Zt as m,
  Ae as n,
  Ve as o,
  qe as p,
  kn as q,
  Ge as r,
  ne as s,
  dn as t,
  Mn as u,
  w as v,
  Cn as w,
  ln as x,
  Qn as z
};
