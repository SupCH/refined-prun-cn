import { $ as I, _$$ as _ } from "./select-dom.js";
import { C as O } from "./prun-css.js";
import { act as V } from "./act-registry.js";
import { t as u } from "./index5.js";
import { fixed0 as n, fixed02 as p } from "./format.js";
import { changeInputValue as b, clickElement as Y } from "./util.js";
import { fillAmount as S } from "./utils2.js";
import { storagesStore as j } from "./storage.js";
import { warehousesStore as z } from "./warehouses.js";
import { watchWhile as G } from "./watch.js";
import { materialsStore as H } from "./materials.js";
import { computed as N, watchEffect as J } from "./runtime-core.esm-bundler.js";
const lt = V.addActionStep({
  type: "CXPO_BUY",
  preProcessData: (i) => ({ ...i, ticker: i.ticker.toUpperCase() }),
  description: (i) => {
    const { ticker: e, exchange: r } = i, w = `${e}.${r}`, a = S(w, i.amount, i.priceLimit), C = a?.amount ?? i.amount, g = a?.priceLimit ?? i.priceLimit, k = i.allowUnfilled ?? !1;
    if (!(a && a.amount === i.amount) && k) {
      let c = u("act.bidDescription", n(i.amount), e, r);
      return isFinite(g) && (c += " " + u("act.atPrice", p(i.priceLimit)), c += " (" + u("act.totalCost", n(i.amount * i.priceLimit)) + ")"), c;
    }
    let m = u("act.buyDescription", n(C), e, r);
    return isFinite(g) && (m += " " + u("act.buyWithLimit", p(g))), a ? m += " (" + u("act.totalCost", n(a.cost)) + ")" : m += " (" + u("act.noPriceData") + ")", m;
  },
  execute: async (i) => {
    const { data: e, log: r, setStatus: w, requestTile: a, waitAct: C, waitActionFeedback: g, complete: k, skip: F, fail: m } = i, c = i.assert, { amount: o, ticker: s, exchange: d, priceLimit: f } = e, h = `${s}.${d}`, l = N(() => {
      const t = z.getByEntityNaturalIdOrName(d);
      return j.getById(t?.storeId);
    });
    if (l.value || r.warning(u("act.warehouseNotLoaded", d)), o <= 0) {
      r.warning(`No ${s} was bought (target amount is 0)`), F();
      return;
    }
    const L = H.getByTicker(s);
    if (c(L, `Unknown material ${s}`), l.value) {
      const t = L.weight * o <= l.value.weightCapacity - l.value.weightLoad, $ = L.volume * o <= l.value.volumeCapacity - l.value.volumeLoad;
      c(
        t && $,
        `Cannot not buy ${n(o)} ${s} (will not fit in the warehouse)`
      );
    }
    const y = await a(`CXPO ${h}`);
    if (!y)
      return;
    w("Setting up CXPO buffer...");
    const q = await I(y.anchor, O.Button.success), E = await I(y.anchor, O.ComExPlaceOrderForm.form), W = _(E, "input"), P = W[0];
    c(P !== void 0, "Missing quantity input");
    const U = W[1];
    c(U !== void 0, "Missing price input");
    let x = !1, B = !1;
    const A = J(() => {
      if (x) {
        A();
        return;
      }
      const t = S(h, o, f);
      if (!t) {
        B || (r.warning(
          `等待 ${h} 订单簿数据加载... (Waiting for ${h} order book data to load...)`
        ), B = !0);
        return;
      }
      if (B = !1, t.amount < o && !e.allowUnfilled) {
        if (!e.buyPartial) {
          let D = `Not enough materials on ${d} to buy ${n(o)} ${s}`;
          isFinite(f) && (D += ` with price limit ${p(f)}/u`), x = !0, m(D);
          return;
        }
        const $ = o - t.amount;
        let v = `${n($)} ${s} will not be bought on ${d} (${n(t.amount)} of ${n(o)} available`;
        if (isFinite(f) && (v += ` with price limit ${p(f)}/u`), v += ")", r.warning(v), t.amount === 0) {
          x = !0, F();
          return;
        }
      }
      e.allowUnfilled ? (b(P, e.amount.toString()), b(U, p(e.priceLimit))) : (b(P, t.amount.toString()), b(U, p(t.priceLimit))), i.cacheDescription();
    });
    await C(), A();
    const T = N(() => l.value?.items.map((t) => t.quantity ?? void 0).filter((t) => t !== void 0).find((t) => t.material.ticker === s)?.amount ?? 0), X = T.value, M = (S(h, o, f)?.amount ?? 0) > 0;
    if (await Y(q), await g(y), M && l.value) {
      w("Waiting for storage update...");
      const t = G(() => T.value === X), $ = new Promise((v) => setTimeout(v, 5e3));
      await Promise.race([t, $]);
    } else
      w("Bid order created");
    k();
  }
});
export {
  lt as CXPO_BUY
};
