import { applyCssRule as i } from "./refined-prun-css.js";
import { C as r } from "./prun-css.js";
import t from "./feature-registry.js";
import o from "./bbl-sticky-dividers.module.css.js";
function e() {
  i("BBL", `.${r.SectionList.divider}`, o.divider);
}
t.add(import.meta.url, e, "BBL: Makes building category dividers sticky.");
