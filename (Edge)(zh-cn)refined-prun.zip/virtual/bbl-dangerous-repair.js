import { subscribe as n } from "./subscribe-async-generator.js";
import { $$ as s } from "./select-dom.js";
import { C as i } from "./prun-css.js";
import u from "./tiles.js";
import l from "./feature-registry.js";
import { refPrunId as p } from "./attributes.js";
import { sitesStore as v } from "./sites.js";
import { watchEffectWhileNodeAlive as b } from "./watch.js";
import { isRepairableBuilding as h } from "./buildings.js";
import { computed as m } from "./runtime-core.esm-bundler.js";
function B(o) {
  const a = o.parameter, d = m(() => v.getById(a));
  n(s(o.anchor, i.SectionList.section), (f) => {
    const c = p(f), e = m(() => d.value?.platforms.find((r) => r.id == c.value));
    n(s(o.anchor, i.SectionList.button), (r) => {
      const t = r.children[0];
      t !== void 0 && b(t, () => {
        !e.value || !h(e.value) || (e.value.condition > 0.98 ? t.classList.add(i.Button.danger) : t.classList.remove(i.Button.danger));
      });
    });
  });
}
function g() {
  u.observe("BBL", B);
}
l.add(
  import.meta.url,
  g,
  'BBL: Applies the "danger" style to the "Repair" button if the building condition is >98%.'
);
