import { applyCssRule as o } from "./refined-prun-css.js";
import { C as n } from "./prun-css.js";
import a from "./feature-registry.js";
import e from "./funny-rations.module.css.js";
import r from "./css-utils.module.css.js";
function i() {
  const t = /* @__PURE__ */ new Date();
  t.getDate() === 1 && t.getMonth() === 3 ? document.body.classList.add(e.funny) : document.body.classList.remove(e.funny);
}
function d() {
  setInterval(i, 6e4), o(`.${e.funny} .rp-ticker-RAT.${n.ColoredIcon.container}:before`, r.hidden), o(`.${e.funny} .rp-ticker-RAT .${n.ColoredIcon.label}`, r.hidden), o(
    `.${e.funny} .rp-ticker-RAT .${n.ColoredIcon.labelContainer}:after`,
    e.rat
  );
}
a.add(import.meta.url, d, "I've heard a squeak.");
