import { __module as k } from "./customParseFormat3.js";
var nt = k.exports, G;
function it() {
  return G ? k.exports : (G = 1, (function(I, ot) {
    (function(E, F) {
      I.exports = F();
    })(nt, (function() {
      var E = { LTS: "h:mm:ss A", LT: "h:mm A", L: "MM/DD/YYYY", LL: "MMMM D, YYYY", LLL: "MMMM D, YYYY h:mm A", LLLL: "dddd, MMMM D, YYYY h:mm A" }, F = /(\[[^[]*\])|([-_:/.,()\s]+)|(A|a|Q|YYYY|YY?|ww?|MM?M?M?|Do|DD?|hh?|HH?|mm?|ss?|S{1,3}|z|ZZ?)/g, Q = /\d/, L = /\d\d/, s = /\d\d?/, x = /\d*[^-_:/,()\s\d]+/, m = {}, X = function(t) {
        return (t = +t) + (t > 68 ? 1900 : 2e3);
      }, o = function(t) {
        return function(r) {
          this[t] = +r;
        };
      }, R = [/[+-]\d\d:?(\d\d)?|Z/, function(t) {
        (this.zone || (this.zone = {})).offset = (function(r) {
          if (!r || r === "Z") return 0;
          var e = r.match(/([+-]|\d\d)/g), n = 60 * e[1] + (+e[2] || 0);
          return n === 0 ? 0 : e[0] === "+" ? -n : n;
        })(t);
      }], P = function(t) {
        var r = m[t];
        return r && (r.indexOf ? r : r.s.concat(r.f));
      }, V = function(t, r) {
        var e, n = m.meridiem;
        if (n) {
          for (var f = 1; f <= 24; f += 1) if (t.indexOf(n(f, 0, r)) > -1) {
            e = f > 12;
            break;
          }
        } else e = t === (r ? "pm" : "PM");
        return e;
      }, J = { A: [x, function(t) {
        this.afternoon = V(t, !1);
      }], a: [x, function(t) {
        this.afternoon = V(t, !0);
      }], Q: [Q, function(t) {
        this.month = 3 * (t - 1) + 1;
      }], S: [Q, function(t) {
        this.milliseconds = 100 * +t;
      }], SS: [L, function(t) {
        this.milliseconds = 10 * +t;
      }], SSS: [/\d{3}/, function(t) {
        this.milliseconds = +t;
      }], s: [s, o("seconds")], ss: [s, o("seconds")], m: [s, o("minutes")], mm: [s, o("minutes")], H: [s, o("hours")], h: [s, o("hours")], HH: [s, o("hours")], hh: [s, o("hours")], D: [s, o("day")], DD: [L, o("day")], Do: [x, function(t) {
        var r = m.ordinal, e = t.match(/\d+/);
        if (this.day = e[0], r) for (var n = 1; n <= 31; n += 1) r(n).replace(/\[|\]/g, "") === t && (this.day = n);
      }], w: [s, o("week")], ww: [L, o("week")], M: [s, o("month")], MM: [L, o("month")], MMM: [x, function(t) {
        var r = P("months"), e = (P("monthsShort") || r.map((function(n) {
          return n.slice(0, 3);
        }))).indexOf(t) + 1;
        if (e < 1) throw new Error();
        this.month = e % 12 || e;
      }], MMMM: [x, function(t) {
        var r = P("months").indexOf(t) + 1;
        if (r < 1) throw new Error();
        this.month = r % 12 || r;
      }], Y: [/[+-]?\d+/, o("year")], YY: [L, function(t) {
        this.year = X(t);
      }], YYYY: [/\d{4}/, o("year")], Z: R, ZZ: R };
      function K(t) {
        var r, e;
        r = t, e = m && m.formats;
        for (var n = (t = r.replace(/(\[[^\]]+])|(LTS?|l{1,4}|L{1,4})/g, (function(v, l, u) {
          var i = u && u.toUpperCase();
          return l || e[u] || E[u] || e[i].replace(/(\[[^\]]+])|(MMMM|MM|DD|dddd)/g, (function(M, Y, D) {
            return Y || D.slice(1);
          }));
        }))).match(F), f = n.length, h = 0; h < f; h += 1) {
          var $ = n[h], p = J[$], c = p && p[0], d = p && p[1];
          n[h] = d ? { regex: c, parser: d } : $.replace(/^\[|\]$/g, "");
        }
        return function(v) {
          for (var l = {}, u = 0, i = 0; u < f; u += 1) {
            var M = n[u];
            if (typeof M == "string") i += M.length;
            else {
              var Y = M.regex, D = M.parser, y = v.slice(i), g = Y.exec(y)[0];
              D.call(l, g), v = v.replace(g, "");
            }
          }
          return (function(w) {
            var S = w.afternoon;
            if (S !== void 0) {
              var a = w.hours;
              S ? a < 12 && (w.hours += 12) : a === 12 && (w.hours = 0), delete w.afternoon;
            }
          })(l), l;
        };
      }
      return function(t, r, e) {
        e.p.customParseFormat = !0, t && t.parseTwoDigitYear && (X = t.parseTwoDigitYear);
        var n = r.prototype, f = n.parse;
        n.parse = function(h) {
          var $ = h.date, p = h.utc, c = h.args;
          this.$u = p;
          var d = c[1];
          if (typeof d == "string") {
            var v = c[2] === !0, l = c[3] === !0, u = v || l, i = c[2];
            l && (i = c[2]), m = this.$locale(), !v && i && (m = e.Ls[i]), this.$d = (function(y, g, w, S) {
              try {
                if (["x", "X"].indexOf(g) > -1) return new Date((g === "X" ? 1e3 : 1) * y);
                var a = K(g)(y), _ = a.year, A = a.month, N = a.day, W = a.hours, tt = a.minutes, rt = a.seconds, et = a.milliseconds, j = a.zone, B = a.week, C = /* @__PURE__ */ new Date(), H = N || (_ || A ? 1 : C.getDate()), O = _ || C.getFullYear(), T = 0;
                _ && !A || (T = A > 0 ? A - 1 : C.getMonth());
                var Z, z = W || 0, q = tt || 0, U = rt || 0, b = et || 0;
                return j ? new Date(Date.UTC(O, T, H, z, q, U, b + 60 * j.offset * 1e3)) : w ? new Date(Date.UTC(O, T, H, z, q, U, b)) : (Z = new Date(O, T, H, z, q, U, b), B && (Z = S(Z).week(B).toDate()), Z);
              } catch {
                return /* @__PURE__ */ new Date("");
              }
            })($, d, p, e), this.init(), i && i !== !0 && (this.$L = this.locale(i).$L), u && $ != this.format(d) && (this.$d = /* @__PURE__ */ new Date("")), m = {};
          } else if (d instanceof Array) for (var M = d.length, Y = 1; Y <= M; Y += 1) {
            c[1] = d[Y - 1];
            var D = e.apply(this, c);
            if (D.isValid()) {
              this.$d = D.$d, this.$L = D.$L, this.init();
              break;
            }
            Y === M && (this.$d = /* @__PURE__ */ new Date(""));
          }
          else f.call(this, h);
        };
      };
    }));
  })(k), k.exports);
}
export {
  it as __require
};
