import { applyCssRule as t } from "./refined-prun-css.js";
import { C as r } from "./prun-css.js";
import o from "./feature-registry.js";
import i from "./highlight-production-order-error.module.css.js";
function s() {
  t(
    "PROD",
    `.${r.OrderSlot.container}:has(.${r.OrderStatus.error})`,
    i.inputMissingContainer
  ), t("PRODQ", `tr:has(.${r.OrderStatus.error})`, i.orderRow), t(
    "PRODCO",
    `.${r.InputsOutputsView.input}:has(.${r.InputsOutputsView.amountMissing})`,
    i.inputMissingContainer
  );
}
o.add(
  import.meta.url,
  s,
  "Highlights production orders with errors in PROD, PRODQ, and PRODCO."
);
