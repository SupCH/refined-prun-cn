import l from "./config.js";
import { planetsStore as e } from "./planets.js";
import { dispatch as o } from "./api-messages.js";
function r() {
  s();
}
async function s() {
  const a = await (await fetch("https://rest.fnar.net/planet/allplanets")).json();
  n(a);
}
async function f() {
  if (e.fetched.value)
    return;
  const a = await (await fetch(l.url.allplanets)).json();
  e.fetched.value || n(a);
}
function n(t) {
  o({
    type: "FIO_PLANET_DATA",
    data: {
      planets: t.map((a) => ({
        naturalId: a.PlanetNaturalId,
        name: a.PlanetName
      }))
    }
  });
}
export {
  f as loadFallbackPlanetData,
  r as preloadFioResponses
};
