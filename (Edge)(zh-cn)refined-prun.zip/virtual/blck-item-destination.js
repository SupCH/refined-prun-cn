import { subscribe as n } from "./subscribe-async-generator.js";
import { $ as m, $$ as s } from "./select-dom.js";
import { C as t } from "./prun-css.js";
import { createFragmentApp as c } from "./vue-fragment-app.js";
import l from "./feature-registry.js";
import { contractsStore as p } from "./contracts.js";
import { getDestinationFullName as d } from "./addresses.js";
import { refPrunId as f } from "./attributes.js";
import { watchUntil as u } from "./watch.js";
import { createVNode as C } from "./runtime-core.esm-bundler.js";
function b() {
  n(s(document, t.ColoredIcon.container), async (o) => {
    const e = await m(o, t.ColoredIcon.label);
    if (e.textContent !== "BLCK")
      return;
    const r = f(o);
    await u(() => !!r.value);
    const a = p.getDestinationByShipmentId(r.value), i = d(a);
    i && c(() => C("span", {
      class: [t.ColoredIcon.subLabel, t.type.typeVerySmall]
    }, [i])).after(e);
  });
}
l.add(import.meta.url, b, "Adds a destination address to BLCK items.");
