import f from "./InventorySortControls.vue.js";
export {
  f as default
};
