import { fixed02 as s } from "./format.js";
import r from "./AddressLink.vue.js";
import { defineComponent as u, createElementBlock as o, openBlock as i, Fragment as e, createTextVNode as t, createVNode as a } from "./runtime-core.esm-bundler.js";
import { toDisplayString as d } from "./shared.esm-bundler.js";
import { unref as p } from "./reactivity.esm-bundler.js";
const O = /* @__PURE__ */ u({
  __name: "ConditionText",
  props: {
    condition: {}
  },
  setup(m) {
    return (n, y) => n.condition.type === "PAYMENT" ? (i(), o(e, { key: 0 }, [
      t(" Pay " + d(p(s)(n.condition.amount.amount)) + " " + d(n.condition.amount.currency), 1)
    ], 64)) : n.condition.type === "LOAN_PAYOUT" ? (i(), o(e, { key: 1 }, [
      t(" Pay " + d(p(s)(n.condition.amount.amount)) + " " + d(n.condition.amount.currency), 1)
    ], 64)) : n.condition.type === "LOAN_INSTALLMENT" ? (i(), o(e, { key: 2 }, [
      t(" Pay " + d(p(s)(n.condition.repayment.amount + n.condition.interest.amount)) + " " + d(n.condition.repayment.currency) + " (auto) ", 1)
    ], 64)) : n.condition.type === "DELIVERY_SHIPMENT" ? (i(), o(e, { key: 3 }, [
      y[0] || (y[0] = t(" Deliver SHPT @ ", -1)),
      a(r, {
        address: n.condition.destination
      }, null, 8, ["address"])
    ], 64)) : n.condition.type === "DELIVERY" ? (i(), o(e, { key: 4 }, [
      t(" Deliver " + d(n.condition.quantity.amount) + " " + d(n.condition.quantity.material.ticker) + " @ ", 1),
      a(r, {
        address: n.condition.address
      }, null, 8, ["address"])
    ], 64)) : n.condition.type === "PICKUP_SHIPMENT" ? (i(), o(e, { key: 5 }, [
      y[1] || (y[1] = t(" Pick up SHPT @ ", -1)),
      a(r, {
        address: n.condition.address
      }, null, 8, ["address"])
    ], 64)) : n.condition.type === "PROVISION_SHIPMENT" ? (i(), o(e, { key: 6 }, [
      t(" Provision " + d(n.condition.quantity.amount) + " " + d(n.condition.quantity.material.ticker) + " @ ", 1),
      a(r, {
        address: n.condition.address
      }, null, 8, ["address"])
    ], 64)) : n.condition.type === "PROVISION" ? (i(), o(e, { key: 7 }, [
      t(" Provision " + d(n.condition.quantity.amount) + " " + d(n.condition.quantity.material.ticker) + " @ ", 1),
      a(r, {
        address: n.condition.address
      }, null, 8, ["address"])
    ], 64)) : n.condition.type === "EXPLORATION" ? (i(), o(e, { key: 8 }, [
      y[2] || (y[2] = t(" Explore ", -1)),
      a(r, {
        address: n.condition.address
      }, null, 8, ["address"])
    ], 64)) : n.condition.type === "COMEX_PURCHASE_PICKUP" ? (i(), o(e, { key: 9 }, [
      t(" Pick up " + d(n.condition.quantity.amount - n.condition.pickedUp.amount) + " " + d(n.condition.quantity.material.ticker) + " @ ", 1),
      a(r, {
        address: n.condition.address
      }, null, 8, ["address"])
    ], 64)) : n.condition.type === "HEADQUARTERS_UPGRADE" ? (i(), o(e, { key: 10 }, [
      t("Upgrade HQ")
    ], 64)) : n.condition.type === "BASE_CONSTRUCTION" ? (i(), o(e, { key: 11 }, [
      t("Construct Base")
    ], 64)) : n.condition.type === "FINISH_FLIGHT" ? (i(), o(e, { key: 12 }, [
      t("Finish Flight")
    ], 64)) : n.condition.type === "PLACE_ORDER" ? (i(), o(e, { key: 13 }, [
      t("Place Order")
    ], 64)) : n.condition.type === "PRODUCTION_ORDER_COMPLETED" ? (i(), o(e, { key: 14 }, [
      t(" Complete Production Order ")
    ], 64)) : n.condition.type === "PRODUCTION_RUN" ? (i(), o(e, { key: 15 }, [
      t("Run Production")
    ], 64)) : n.condition.type === "START_FLIGHT" ? (i(), o(e, { key: 16 }, [
      t("Start Flight")
    ], 64)) : n.condition.type === "POWER" ? (i(), o(e, { key: 17 }, [
      t("Become Governor")
    ], 64)) : n.condition.type === "REPAIR_SHIP" ? (i(), o(e, { key: 18 }, [
      t("Repair Ship")
    ], 64)) : n.condition.type === "CONTRIBUTION" ? (i(), o(e, { key: 19 }, [
      t("Contribution")
    ], 64)) : (i(), o(e, { key: 20 }, [
      t(d(n.condition.type), 1)
    ], 64));
  }
});
export {
  O as default
};
