import { t } from "./index5.js";
import o from "./PrunLink.vue.js";
import { defineComponent as u, createElementBlock as d, openBlock as a, createElementVNode as l, createVNode as r } from "./runtime-core.esm-bundler.js";
import { toDisplayString as e } from "./shared.esm-bundler.js";
import { unref as m } from "./reactivity.esm-bundler.js";
const I = /* @__PURE__ */ u({
  __name: "HELP",
  setup(i) {
    return (n, p) => (a(), d("table", null, [
      l("thead", null, [
        l("tr", null, [
          l("th", null, e(("t" in n ? n.t : m(t))("help.wantTo")), 1),
          l("th", null, e(("t" in n ? n.t : m(t))("help.command")), 1)
        ])
      ]),
      l("tbody", null, [
        l("tr", null, [
          l("td", null, e(("t" in n ? n.t : m(t))("help.changeSettings")), 1),
          l("td", null, [
            r(o, { command: "XIT SET" })
          ])
        ]),
        l("tr", null, [
          l("td", null, e(("t" in n ? n.t : m(t))("help.changeFeatureSet")), 1),
          l("td", null, [
            r(o, { command: "XIT SET FEAT" })
          ])
        ]),
        l("tr", null, [
          l("td", null, e(("t" in n ? n.t : m(t))("help.disableFeature")), 1),
          l("td", null, [
            r(o, { command: "XIT SET FEAT" })
          ])
        ]),
        l("tr", null, [
          l("td", null, e(("t" in n ? n.t : m(t))("help.findCommands")), 1),
          l("td", null, [
            r(o, { command: "XIT CMDS" })
          ])
        ]),
        l("tr", null, [
          l("td", null, e(("t" in n ? n.t : m(t))("help.importPmmg")), 1),
          l("td", null, [
            r(o, { command: "XIT SET PMMG" })
          ])
        ]),
        l("tr", null, [
          l("td", null, e(("t" in n ? n.t : m(t))("help.corgiGif")), 1),
          l("td", null, [
            r(o, { command: "XIT GIF CORGI" })
          ])
        ])
      ])
    ]));
  }
});
export {
  I as default
};
