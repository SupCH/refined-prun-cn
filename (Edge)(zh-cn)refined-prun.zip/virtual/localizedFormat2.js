import { __module as e } from "./localizedFormat3.js";
var v = e.exports, m;
function F() {
  return m ? e.exports : (m = 1, (function(u, h) {
    (function(o, n) {
      u.exports = n();
    })(v, (function() {
      var o = { LTS: "h:mm:ss A", LT: "h:mm A", L: "MM/DD/YYYY", LL: "MMMM D, YYYY", LLL: "MMMM D, YYYY h:mm A", LLLL: "dddd, MMMM D, YYYY h:mm A" };
      return function(n, Y, c) {
        var a = Y.prototype, s = a.format;
        c.en.formats = o, a.format = function(t) {
          t === void 0 && (t = "YYYY-MM-DDTHH:mm:ssZ");
          var i = this.$locale().formats, d = (function(L, M) {
            return L.replace(/(\[[^\]]+])|(LTS?|l{1,4}|L{1,4})/g, (function(x, f, r) {
              var l = r && r.toUpperCase();
              return f || M[r] || o[r] || M[l].replace(/(\[[^\]]+])|(MMMM|MM|DD|dddd)/g, (function(z, p, D) {
                return p || D.slice(1);
              }));
            }));
          })(t, i === void 0 ? {} : i);
          return s.call(this, d);
        };
      };
    }));
  })(e), e.exports);
}
export {
  F as __require
};
