function e(t) {
  return t && t.__esModule && Object.prototype.hasOwnProperty.call(t, "default") ? t.default : t;
}
export {
  e as getDefaultExportFromCjs
};
