const t = "rp-KeyFigures__tooltip___e4622e7", o = {
  tooltip: t
};
export {
  o as default,
  t as tooltip
};
