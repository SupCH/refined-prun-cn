const n = "rp-LMShipmentIcon__icon___0708a41", o = {
  icon: n
};
export {
  o as default,
  n as icon
};
