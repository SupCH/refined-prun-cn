import { subscribe as p } from "./subscribe-async-generator.js";
import { $$ as c, $ as s } from "./select-dom.js";
import { C as a } from "./prun-css.js";
import { createFragmentApp as m } from "./vue-fragment-app.js";
import f from "./tiles.js";
import l from "./feature-registry.js";
import I from "./LMMaterialIcon.vue.js";
import M from "./LMShipmentIcon.vue.js";
import { getPrunId as u } from "./attributes.js";
import { localAdsStore as y } from "./local-ads.js";
function C(t) {
  p(c(t.anchor, a.CommodityAd.container), L);
}
async function L(t) {
  const r = await s(t, a.CommodityAd.text), d = u(t), o = y.getById(d);
  if (!o)
    return;
  const e = o.type, i = o.quantity;
  if (e === "COMMODITY_SHIPPING" && m(M).prependTo(t), (e === "COMMODITY_BUYING" || e === "COMMODITY_SELLING") && i) {
    const n = i.material.ticker;
    r.childNodes[1].textContent = r.childNodes[1].textContent.replace(`(${n})`, ""), m(I, { ticker: n }).prependTo(t);
  }
}
function O() {
  f.observe("LM", C);
}
l.add(import.meta.url, O, "LM: Adds material and shipment icons to ads.");
