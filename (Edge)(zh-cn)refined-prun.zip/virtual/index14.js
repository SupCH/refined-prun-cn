function r(t) {
  if (t) return n(t);
}
function n(t) {
  for (var s in r.prototype)
    t[s] = r.prototype[s];
  return t;
}
r.prototype.on = r.prototype.addEventListener = function(t, s) {
  return this._callbacks = this._callbacks || {}, (this._callbacks["$" + t] = this._callbacks["$" + t] || []).push(s), this;
};
r.prototype.once = function(t, s) {
  function e() {
    this.off(t, e), s.apply(this, arguments);
  }
  return e.fn = s, this.on(t, e), this;
};
r.prototype.off = r.prototype.removeListener = r.prototype.removeAllListeners = r.prototype.removeEventListener = function(t, s) {
  if (this._callbacks = this._callbacks || {}, arguments.length == 0)
    return this._callbacks = {}, this;
  var e = this._callbacks["$" + t];
  if (!e) return this;
  if (arguments.length == 1)
    return delete this._callbacks["$" + t], this;
  for (var a, i = 0; i < e.length; i++)
    if (a = e[i], a === s || a.fn === s) {
      e.splice(i, 1);
      break;
    }
  return e.length === 0 && delete this._callbacks["$" + t], this;
};
r.prototype.emit = function(t) {
  this._callbacks = this._callbacks || {};
  for (var s = new Array(arguments.length - 1), e = this._callbacks["$" + t], a = 1; a < arguments.length; a++)
    s[a - 1] = arguments[a];
  if (e) {
    e = e.slice(0);
    for (var a = 0, i = e.length; a < i; ++a)
      e[a].apply(this, s);
  }
  return this;
};
r.prototype.emitReserved = r.prototype.emit;
r.prototype.listeners = function(t) {
  return this._callbacks = this._callbacks || {}, this._callbacks["$" + t] || [];
};
r.prototype.hasListeners = function(t) {
  return !!this.listeners(t).length;
};
export {
  r as Emitter
};
