import { t as r } from "./index5.js";
import { selfCurrentConditions as k, selfNonCurrentConditions as C } from "./contract-conditions.js";
import { contractsStore as _ } from "./contracts.js";
import L from "./LoadingSpinner.vue.js";
import m from "./ConditionRow.vue.js";
import { isEmpty as p } from "./is-empty.js";
import { defineComponent as g, computed as f, createBlock as s, createElementBlock as c, openBlock as i, createElementVNode as t, Fragment as h, renderList as y } from "./runtime-core.esm-bundler.js";
import { unref as o } from "./reactivity.esm-bundler.js";
import { toDisplayString as d } from "./shared.esm-bundler.js";
const E = { key: 1 }, F = { colspan: "3" }, v = { key: 0 }, B = { colspan: "3" }, N = { colspan: "3" }, b = { key: 0 }, D = { colspan: "3" }, w = /* @__PURE__ */ g({
  __name: "CONTC",
  setup(S) {
    const a = f(
      () => k.value.filter((n) => n.dependencies.every((l) => l.status === "FULFILLED"))
    ), u = f(
      () => C.value.filter((n) => n.dependencies.every((l) => l.status === "FULFILLED"))
    );
    return (n, l) => o(_).fetched ? (i(), c("table", E, [
      t("thead", null, [
        t("tr", null, [
          t("th", null, d(("t" in n ? n.t : o(r))("conts.contract")), 1),
          t("th", null, d(("t" in n ? n.t : o(r))("contc.deadline")), 1),
          t("th", null, d(("t" in n ? n.t : o(r))("contc.condition")), 1)
        ])
      ]),
      t("thead", null, [
        t("tr", null, [
          t("th", F, d(("t" in n ? n.t : o(r))("contc.currentConditions")), 1)
        ])
      ]),
      t("tbody", null, [
        o(p)(o(a)) ? (i(), c("tr", v, [
          t("td", B, d(("t" in n ? n.t : o(r))("contc.noPending")), 1)
        ])) : (i(!0), c(h, { key: 1 }, y(o(a), (e) => (i(), s(m, {
          key: e.condition.id,
          contract: e.contract,
          condition: e.condition,
          deadline: e.deadline
        }, null, 8, ["contract", "condition", "deadline"]))), 128))
      ]),
      t("thead", null, [
        t("tr", null, [
          t("th", N, d(("t" in n ? n.t : o(r))("contc.nonCurrentConditions")), 1)
        ])
      ]),
      t("tbody", null, [
        o(p)(o(u)) ? (i(), c("tr", b, [
          t("td", D, d(("t" in n ? n.t : o(r))("contc.noPending")), 1)
        ])) : (i(!0), c(h, { key: 1 }, y(o(u), (e) => (i(), s(m, {
          key: e.condition.id,
          contract: e.contract,
          condition: e.condition,
          deadline: e.deadline
        }, null, 8, ["contract", "condition", "deadline"]))), 128))
      ])
    ])) : (i(), s(L, { key: 0 }));
  }
});
export {
  w as default
};
