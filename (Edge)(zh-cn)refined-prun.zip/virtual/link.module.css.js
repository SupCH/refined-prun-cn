const n = "rp-link__link___6e3c9e9", l = {
  link: n
};
export {
  l as default,
  n as link
};
