import { subscribe as c } from "./subscribe-async-generator.js";
import { $ as m, $$ as u } from "./select-dom.js";
import { C as d } from "./prun-css.js";
import { createFragmentApp as p } from "./vue-fragment-app.js";
import h from "./tiles.js";
import C from "./feature-registry.js";
import I from "./inv-search.module.css.js";
import a from "./css-utils.module.css.js";
import { createVNode as s } from "./runtime-core.esm-bundler.js";
function b(t) {
  t.parameter || c(u(t.anchor, d.InventoriesListContainer.filter), async (e) => {
    const r = await m(t.anchor, "tbody"), o = (f) => {
      const l = f.target;
      for (let n = 0; n < r.children.length; n++) {
        const i = r.children[n];
        L(i, l.value) ? i.classList.remove(a.hidden) : i.classList.add(a.hidden);
      }
    };
    p(() => s("div", null, [s("input", {
      class: I.inputText,
      placeholder: "Enter location",
      onInput: o
    }, null)])).after(e);
  });
}
function L(t, e) {
  if (!e || e === "")
    return !0;
  const r = t.children[1].textContent.toLowerCase();
  if (r !== "--" && r.includes(e.toLowerCase()))
    return !0;
  const o = t.children[2].textContent.toLowerCase();
  return !!(o !== "" && o.includes(e.toLowerCase()));
}
function w() {
  h.observe(["INV", "SHPI"], b);
}
C.add(import.meta.url, w, "INV/SHPI: Adds a search bar to the main INV buffer.");
