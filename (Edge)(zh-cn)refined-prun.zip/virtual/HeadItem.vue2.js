import f from "./HeadItem.vue.js";
export {
  f as default
};
