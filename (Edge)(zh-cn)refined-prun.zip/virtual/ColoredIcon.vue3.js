const e = "rp-ColoredIcon__large___faa6371", _ = "rp-ColoredIcon__medium___4b4e2e9", l = "rp-ColoredIcon__small___3005653", o = "rp-ColoredIcon__inline___9807fdd", n = "rp-ColoredIcon__inlineTable___ef5b1f1", i = "rp-ColoredIcon__mediumSubLabel___6536266", a = {
  large: e,
  medium: _,
  small: l,
  inline: o,
  inlineTable: n,
  mediumSubLabel: i
};
export {
  a as default,
  o as inline,
  n as inlineTable,
  e as large,
  _ as medium,
  i as mediumSubLabel,
  l as small
};
