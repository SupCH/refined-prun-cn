import { subscribe as s } from "./subscribe-async-generator.js";
import { $$ as u } from "./select-dom.js";
import { applyCssRule as r } from "./refined-prun-css.js";
import { C as l } from "./prun-css.js";
import f from "./feature-registry.js";
import c from "./font-awesome.module.css.js";
import m from "./input-math.module.css.js";
import { changeInputValue as p } from "./util.js";
import d from "./index6.js";
import { materialsStore as b } from "./materials.js";
const v = new d();
function y(e, o) {
  if (o.key !== "Enter" && o.key !== "Tab" || !e.value)
    return;
  let t = e.value.charAt(0) === "=" ? e.value.substring(1) : e.value;
  t = h(t), t = $(t);
  const a = parseFloat(v.eval(t).toFixed(6));
  p(e, a.toString());
}
function h(e) {
  const o = e.match(/\b([a-zA-Z0-9]{1,3})\.(?:w|t|v|m|m3|max)\b/gi) ?? [];
  for (const t of o) {
    const a = t.split("."), i = b.getByTicker(a[0]);
    if (i === void 0)
      continue;
    let n;
    switch (a[1]) {
      case "w":
      case "t":
        n = i.weight;
        break;
      case "v":
      case "m":
      case "m3":
        n = i.volume;
        break;
      case "max":
        n = Math.max(i.weight, i.volume);
        break;
    }
    n !== void 0 && (e = e.replace(t, n.toFixed(3)));
  }
  return e;
}
function $(e) {
  return e.replace(/(\d+)k\b/gi, (o, t) => (parseFloat(t) * 1e3).toString());
}
function g() {
  w(), s(u(document, "input"), (e) => {
    e.inputMode !== "numeric" && e.inputMode !== "decimal" || e.addEventListener("keydown", (o) => y(e, o));
  });
}
function w() {
  const e = "div:has(> input:is([inputmode='numeric'], [inputmode='decimal']):focus)", o = `.FormComponent__input___f43wqaQ > ${e}`;
  r(o, m.inputContainer), r(`${o}:before`, c.solid), r(`${o}:before`, m.functionIcon);
  const t = `.${l.DynamicInput.dynamic} > ${e}`;
  r(t, m.inputContainer), r(`${t}:before`, c.solid), r(`${t}:before`, m.functionIconDynamic);
}
f.add(
  import.meta.url,
  g,
  "Evaluates math expressions in numeric text fields on Enter or Tab."
);
