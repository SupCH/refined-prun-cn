async function d() {
  if (document.documentElement.classList.contains("refined-prun")) {
    window.postMessage({ type: "rp-reload-page" }, "*");
    return;
  }
  const e = l();
  await m();
  const r = document.createElement("refined-prun");
  document.documentElement.appendChild(r);
  const n = Date.now(), t = document.createElement("link");
  t.href = chrome.runtime.getURL("refined-prun.css") + "?" + n, t.rel = "stylesheet", t.id = "refined-prun-css", await new Promise((a) => {
    t.onload = a, r.appendChild(t);
  });
  const i = {}, c = t.sheet;
  for (let a = 0; a < c.cssRules.length; a++) {
    const o = c.cssRules.item(a);
    o && (i[o.selectorText] = o.cssText);
  }
  t.textContent = JSON.stringify(i);
  const s = document.createElement("script");
  s.src = chrome.runtime.getURL("refined-prun.js") + "?" + n, s.type = "module", s.id = "refined-prun-js";
  const u = {
    userData: await e,
    version: chrome.runtime.getManifest().version,
    url: {
      manifest: chrome.runtime.getURL("manifest.json"),
      allplanets: chrome.runtime.getURL("json/fallback-fio-responses/allplanets.json")
    }
  };
  s.textContent = JSON.stringify(u), r.appendChild(s);
}
async function l() {
  const e = "rp-user-data";
  return window.addEventListener("message", async (n) => {
    n.source === window && n.data.type === "rp-save-user-data" && (await chrome.storage.local.set({
      [e]: n.data.userData
    }), window.postMessage({ type: "rp-user-data-saved" }, "*"));
  }), (await chrome.storage.local.get(e))[e];
}
async function m() {
  for (; document.head === null || document.body === null; )
    await new Promise((e) => setTimeout(e, 10));
}
d();
